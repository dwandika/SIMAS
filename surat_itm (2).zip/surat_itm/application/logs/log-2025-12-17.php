<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-17 04:21:45 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated D:\xampp\htdocs\surat_itm\system\database\DB_driver.php 372
ERROR - 2025-12-17 04:21:46 --> 404 Page Not Found: Assets/images
ERROR - 2025-12-17 04:26:51 --> Severity: error --> Exception: syntax error, unexpected token "#[" D:\xampp\htdocs\surat_itm\system\database\DB_driver.php 55
ERROR - 2025-12-17 04:27:13 --> 404 Page Not Found: Assets/images
ERROR - 2025-12-17 04:28:59 --> 404 Page Not Found: Assets/images
ERROR - 2025-12-17 04:29:01 --> 404 Page Not Found: Assets/images
ERROR - 2025-12-17 04:30:30 --> 404 Page Not Found: Assets/images
ERROR - 2025-12-17 05:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:07:09 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:13:36 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:13:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:16:47 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:20:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:20:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:20:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:21 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:42 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:22:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:37:26 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:41:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:41:35 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:57:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 05:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:01:57 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:34 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:02:36 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:03:20 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:23:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:25:34 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:25:37 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:25:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:28:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:28:15 --> 404 Page Not Found: Bagian/index
ERROR - 2025-12-17 06:28:22 --> 404 Page Not Found: Bagian/index
ERROR - 2025-12-17 06:31:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:33:41 --> 404 Page Not Found: Kategori/index
ERROR - 2025-12-17 06:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\kategori\index.php 54
ERROR - 2025-12-17 06:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:37:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:42:09 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:42:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:42:30 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:42:35 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:50:01 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:50:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:57:14 --> 404 Page Not Found: Templates/index
ERROR - 2025-12-17 06:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 06:58:04 --> Query error: Table 'surat_itm.template' doesn't exist - Invalid query: SELECT `template`.*, `kategori`.`nama_kategori`
FROM `template`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `template`.`kode_kategori`
ORDER BY `template`.`kode_template` ASC
ERROR - 2025-12-17 07:01:11 --> Severity: Compile Error --> Cannot declare class Template_model, because the name is already in use D:\xampp\htdocs\surat_itm\application\models\Kategori_model.php 4
ERROR - 2025-12-17 07:01:49 --> Query error: Table 'surat_itm.template' doesn't exist - Invalid query: SELECT `template`.*, `kategori`.`nama_kategori`
FROM `template`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `template`.`kode_kategori`
ORDER BY `template`.`kode_template` ASC
ERROR - 2025-12-17 07:01:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:07 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:20 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:02:21 --> Query error: Table 'surat_itm.template' doesn't exist - Invalid query: SELECT `template`.*, `kategori`.`nama_kategori`
FROM `template`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `template`.`kode_kategori`
ORDER BY `template`.`kode_template` ASC
ERROR - 2025-12-17 07:08:26 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 07:08:28 --> Unable to load the requested class: Pdf
ERROR - 2025-12-17 07:10:20 --> Severity: error --> Exception: Call to undefined method Laporan_model::rekap_surat_masuk() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 29
ERROR - 2025-12-17 07:10:49 --> Query error: Unknown column 'surat_keluar.penandatangan_id' in 'on clause' - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` as `nama_ttd`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`penandatangan_id`
ORDER BY `surat_keluar`.`tgl_surat` DESC
ERROR - 2025-12-17 07:10:53 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tgl_surat` DESC
ERROR - 2025-12-17 07:10:56 --> Severity: error --> Exception: Call to undefined method Laporan_model::rekap_surat_masuk() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 29
ERROR - 2025-12-17 07:13:04 --> Query error: Unknown column 'tgl_diterima' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE MONTH(tgl_diterima) = '12'
AND YEAR(tgl_diterima) = '2025'
ERROR - 2025-12-17 07:13:05 --> Query error: Unknown column 'tgl_diterima' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE MONTH(tgl_diterima) = '12'
AND YEAR(tgl_diterima) = '2025'
ERROR - 2025-12-17 07:13:05 --> Query error: Unknown column 'tgl_diterima' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE MONTH(tgl_diterima) = '12'
AND YEAR(tgl_diterima) = '2025'
ERROR - 2025-12-17 09:21:15 --> Query error: Unknown column 'tgl_diterima' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE MONTH(tgl_diterima) = '12'
AND YEAR(tgl_diterima) = '2025'
ERROR - 2025-12-17 09:23:04 --> Query error: Unknown column 'surat_masuk.id' in 'order clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
ORDER BY `surat_masuk`.`id` DESC
 LIMIT 5
ERROR - 2025-12-17 09:23:05 --> Query error: Unknown column 'surat_masuk.id' in 'order clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
ORDER BY `surat_masuk`.`id` DESC
 LIMIT 5
ERROR - 2025-12-17 09:23:05 --> Query error: Unknown column 'surat_masuk.id' in 'order clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
ORDER BY `surat_masuk`.`id` DESC
 LIMIT 5
ERROR - 2025-12-17 09:23:06 --> Query error: Unknown column 'surat_masuk.id' in 'order clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
ORDER BY `surat_masuk`.`id` DESC
 LIMIT 5
ERROR - 2025-12-17 09:23:06 --> Query error: Unknown column 'surat_masuk.id' in 'order clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
ORDER BY `surat_masuk`.`id` DESC
 LIMIT 5
ERROR - 2025-12-17 09:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:37 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:39 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:24:44 --> Query error: Table 'surat_itm.template' doesn't exist - Invalid query: SELECT `template`.*, `kategori`.`nama_kategori`
FROM `template`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `template`.`kode_kategori`
ORDER BY `template`.`kode_template` ASC
ERROR - 2025-12-17 09:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:26:59 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:27:36 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-17 09:27:38 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-17 09:27:39 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-17 09:27:39 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-17 09:30:21 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:30:22 --> Query error: Unknown column 'surat_masuk.bagian_tujuan' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian_tujuan`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-17 09:39:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:07 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:09 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:34 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:39 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:47 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:52 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:57 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:40:59 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:42 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:44:47 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:46:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:29 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:30 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:52 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:53 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:47:59 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:01 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:04 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 09:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:29:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:29:15 --> 404 Page Not Found: Users/tambah
ERROR - 2025-12-17 10:30:05 --> 404 Page Not Found: Users/tambah
ERROR - 2025-12-17 10:36:29 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:36:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:37:26 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:32 --> Query error: Unknown column 'keterangan' in 'field list' - Invalid query: INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`, `keterangan`, `status`) VALUES ('HIMASI', 'Himpunan Mahasiswa Sistem Informasi', 'Sebagai ketua himpunan mahasiswa sistem informasi', '1')
ERROR - 2025-12-17 10:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:46 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:38:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:13 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:22 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:23 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:24 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 10:39:27 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:07 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:09 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:15 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:53:08 --> Query error: Unknown column 'keterangan' in 'field list' - Invalid query: INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`, `keterangan`, `status`) VALUES ('HIMASI', 'Himpunan Mahasiswa Sistem Informasi', 'pp', '1')
ERROR - 2025-12-17 12:58:14 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:59:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 12:59:57 --> Query error: Unknown column 'keterangan' in 'field list' - Invalid query: INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`, `keterangan`, `status`) VALUES ('HIMASI', 'Himpunan Mahasiswa Sistem Informasi', NULL, '1')
ERROR - 2025-12-17 13:00:52 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:00:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:00:57 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:01:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`surat_itm`.`bagian`, CONSTRAINT `fk_bagian_user` FOREIGN KEY (`user_login`) REFERENCES `user` (`username`)) - Invalid query: INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`, `status`) VALUES ('HIMASI', 'Himpunan Mahasiswa Sistem Informasi', '1')
ERROR - 2025-12-17 13:06:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:06:31 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\bagian\index.php 54
ERROR - 2025-12-17 13:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:06:37 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:06:39 --> Severity: Warning --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\surat_itm\application\views\bagian\index.php 54
ERROR - 2025-12-17 13:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:07:51 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:07:53 --> Severity: error --> Exception: Call to undefined method Bagian_model::get_active() D:\xampp\htdocs\surat_itm\application\controllers\Users.php 38
ERROR - 2025-12-17 13:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:42 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:11:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:13 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:16 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:19 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:20 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:46 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:12:53 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:13:45 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:14:01 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:14:04 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:16:46 --> 404 Page Not Found: Surat-masuk/detail
ERROR - 2025-12-17 13:16:56 --> 404 Page Not Found: Disposisi/tambah
ERROR - 2025-12-17 13:17:04 --> 404 Page Not Found: Surat-masuk/delete
ERROR - 2025-12-17 13:17:09 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:17:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:17:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:18:32 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 13:18:35 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:20 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:43 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:28:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:11 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:35:31 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:37:47 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:37:48 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:38:32 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:39:41 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:41:35 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-17 15:41:40 --> 404 Page Not Found: Assets/js
