<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-26 00:01:20 --> Config Class Initialized
INFO - 2025-12-26 00:01:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 00:01:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 00:01:20 --> Utf8 Class Initialized
INFO - 2025-12-26 00:01:20 --> URI Class Initialized
INFO - 2025-12-26 00:01:20 --> Router Class Initialized
INFO - 2025-12-26 00:01:20 --> Output Class Initialized
INFO - 2025-12-26 00:01:20 --> Security Class Initialized
DEBUG - 2025-12-26 00:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 00:01:20 --> CSRF cookie sent
INFO - 2025-12-26 00:01:20 --> Input Class Initialized
INFO - 2025-12-26 00:01:20 --> Language Class Initialized
INFO - 2025-12-26 00:01:20 --> Loader Class Initialized
INFO - 2025-12-26 00:01:20 --> Helper loaded: url_helper
INFO - 2025-12-26 00:01:20 --> Helper loaded: form_helper
INFO - 2025-12-26 00:01:20 --> Helper loaded: file_helper
INFO - 2025-12-26 00:01:20 --> Helper loaded: html_helper
INFO - 2025-12-26 00:01:20 --> Helper loaded: security_helper
INFO - 2025-12-26 00:01:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 00:01:20 --> Database Driver Class Initialized
INFO - 2025-12-26 00:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 00:01:20 --> Form Validation Class Initialized
INFO - 2025-12-26 00:01:20 --> Controller Class Initialized
INFO - 2025-12-26 00:01:20 --> Final output sent to browser
DEBUG - 2025-12-26 00:01:20 --> Total execution time: 0.1668
INFO - 2025-12-26 00:01:29 --> Config Class Initialized
INFO - 2025-12-26 00:01:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 00:01:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 00:01:29 --> Utf8 Class Initialized
INFO - 2025-12-26 00:01:29 --> URI Class Initialized
INFO - 2025-12-26 00:01:29 --> Router Class Initialized
INFO - 2025-12-26 00:01:29 --> Output Class Initialized
INFO - 2025-12-26 00:01:29 --> Security Class Initialized
DEBUG - 2025-12-26 00:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 00:01:29 --> Input Class Initialized
INFO - 2025-12-26 00:01:29 --> Language Class Initialized
INFO - 2025-12-26 00:01:29 --> Loader Class Initialized
INFO - 2025-12-26 00:01:29 --> Helper loaded: url_helper
INFO - 2025-12-26 00:01:29 --> Helper loaded: form_helper
INFO - 2025-12-26 00:01:29 --> Helper loaded: file_helper
INFO - 2025-12-26 00:01:29 --> Helper loaded: html_helper
INFO - 2025-12-26 00:01:29 --> Helper loaded: security_helper
INFO - 2025-12-26 00:01:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 00:01:29 --> Database Driver Class Initialized
INFO - 2025-12-26 00:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 00:01:29 --> Form Validation Class Initialized
INFO - 2025-12-26 00:01:29 --> Controller Class Initialized
INFO - 2025-12-26 00:01:29 --> Final output sent to browser
DEBUG - 2025-12-26 00:01:29 --> Total execution time: 0.0921
INFO - 2025-12-26 04:07:40 --> Config Class Initialized
INFO - 2025-12-26 04:07:40 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:07:40 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:07:40 --> Utf8 Class Initialized
INFO - 2025-12-26 04:07:40 --> URI Class Initialized
INFO - 2025-12-26 04:07:40 --> Router Class Initialized
INFO - 2025-12-26 04:07:40 --> Output Class Initialized
INFO - 2025-12-26 04:07:40 --> Security Class Initialized
DEBUG - 2025-12-26 04:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:07:40 --> Input Class Initialized
INFO - 2025-12-26 04:07:40 --> Language Class Initialized
INFO - 2025-12-26 04:07:40 --> Loader Class Initialized
INFO - 2025-12-26 04:07:40 --> Helper loaded: url_helper
INFO - 2025-12-26 04:07:40 --> Helper loaded: form_helper
INFO - 2025-12-26 04:07:40 --> Helper loaded: file_helper
INFO - 2025-12-26 04:07:40 --> Helper loaded: html_helper
INFO - 2025-12-26 04:07:40 --> Helper loaded: security_helper
INFO - 2025-12-26 04:07:40 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:07:40 --> Database Driver Class Initialized
INFO - 2025-12-26 04:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:07:40 --> Form Validation Class Initialized
INFO - 2025-12-26 04:07:40 --> Controller Class Initialized
INFO - 2025-12-26 04:07:43 --> Final output sent to browser
DEBUG - 2025-12-26 04:07:43 --> Total execution time: 2.8268
INFO - 2025-12-26 04:08:56 --> Config Class Initialized
INFO - 2025-12-26 04:08:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:08:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:08:56 --> Utf8 Class Initialized
INFO - 2025-12-26 04:08:56 --> URI Class Initialized
INFO - 2025-12-26 04:08:56 --> Router Class Initialized
INFO - 2025-12-26 04:08:56 --> Output Class Initialized
INFO - 2025-12-26 04:08:56 --> Security Class Initialized
DEBUG - 2025-12-26 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:08:56 --> CSRF cookie sent
INFO - 2025-12-26 04:08:56 --> Input Class Initialized
INFO - 2025-12-26 04:08:56 --> Language Class Initialized
INFO - 2025-12-26 04:08:56 --> Loader Class Initialized
INFO - 2025-12-26 04:08:56 --> Helper loaded: url_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: form_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: file_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: html_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: security_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:08:56 --> Database Driver Class Initialized
INFO - 2025-12-26 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:08:56 --> Form Validation Class Initialized
INFO - 2025-12-26 04:08:56 --> Controller Class Initialized
INFO - 2025-12-26 04:08:56 --> Config Class Initialized
INFO - 2025-12-26 04:08:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:08:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:08:56 --> Utf8 Class Initialized
INFO - 2025-12-26 04:08:56 --> URI Class Initialized
INFO - 2025-12-26 04:08:56 --> Router Class Initialized
INFO - 2025-12-26 04:08:56 --> Output Class Initialized
INFO - 2025-12-26 04:08:56 --> Security Class Initialized
DEBUG - 2025-12-26 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:08:56 --> CSRF cookie sent
INFO - 2025-12-26 04:08:56 --> Input Class Initialized
INFO - 2025-12-26 04:08:56 --> Language Class Initialized
INFO - 2025-12-26 04:08:56 --> Loader Class Initialized
INFO - 2025-12-26 04:08:56 --> Helper loaded: url_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: form_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: file_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: html_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: security_helper
INFO - 2025-12-26 04:08:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:08:56 --> Database Driver Class Initialized
INFO - 2025-12-26 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:08:56 --> Form Validation Class Initialized
INFO - 2025-12-26 04:08:56 --> Controller Class Initialized
INFO - 2025-12-26 04:08:56 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:08:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:08:56 --> Final output sent to browser
DEBUG - 2025-12-26 04:08:56 --> Total execution time: 0.0539
INFO - 2025-12-26 04:09:03 --> Config Class Initialized
INFO - 2025-12-26 04:09:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:03 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:03 --> URI Class Initialized
INFO - 2025-12-26 04:09:03 --> Router Class Initialized
INFO - 2025-12-26 04:09:03 --> Output Class Initialized
INFO - 2025-12-26 04:09:03 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:03 --> CSRF cookie sent
INFO - 2025-12-26 04:09:03 --> CSRF token verified
INFO - 2025-12-26 04:09:03 --> Input Class Initialized
INFO - 2025-12-26 04:09:03 --> Language Class Initialized
INFO - 2025-12-26 04:09:03 --> Loader Class Initialized
INFO - 2025-12-26 04:09:03 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:03 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:03 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:03 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:03 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:03 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:03 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:03 --> Controller Class Initialized
INFO - 2025-12-26 04:09:03 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:09:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:09:03 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:03 --> Total execution time: 0.0767
INFO - 2025-12-26 04:09:10 --> Config Class Initialized
INFO - 2025-12-26 04:09:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:10 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:10 --> URI Class Initialized
INFO - 2025-12-26 04:09:10 --> Router Class Initialized
INFO - 2025-12-26 04:09:10 --> Output Class Initialized
INFO - 2025-12-26 04:09:10 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:10 --> CSRF cookie sent
INFO - 2025-12-26 04:09:10 --> CSRF token verified
INFO - 2025-12-26 04:09:10 --> Input Class Initialized
INFO - 2025-12-26 04:09:10 --> Language Class Initialized
INFO - 2025-12-26 04:09:10 --> Loader Class Initialized
INFO - 2025-12-26 04:09:10 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:10 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:10 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:10 --> Controller Class Initialized
INFO - 2025-12-26 04:09:10 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:09:10 --> Config Class Initialized
INFO - 2025-12-26 04:09:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:10 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:10 --> URI Class Initialized
INFO - 2025-12-26 04:09:10 --> Router Class Initialized
INFO - 2025-12-26 04:09:10 --> Output Class Initialized
INFO - 2025-12-26 04:09:10 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:10 --> CSRF cookie sent
INFO - 2025-12-26 04:09:10 --> Input Class Initialized
INFO - 2025-12-26 04:09:10 --> Language Class Initialized
INFO - 2025-12-26 04:09:10 --> Loader Class Initialized
INFO - 2025-12-26 04:09:10 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:10 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:10 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:10 --> Controller Class Initialized
INFO - 2025-12-26 04:09:10 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:09:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:09:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:10 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:10 --> Total execution time: 0.0552
INFO - 2025-12-26 04:09:15 --> Config Class Initialized
INFO - 2025-12-26 04:09:15 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:15 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:15 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:15 --> URI Class Initialized
INFO - 2025-12-26 04:09:15 --> Router Class Initialized
INFO - 2025-12-26 04:09:15 --> Output Class Initialized
INFO - 2025-12-26 04:09:15 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:15 --> CSRF cookie sent
INFO - 2025-12-26 04:09:15 --> Input Class Initialized
INFO - 2025-12-26 04:09:15 --> Language Class Initialized
INFO - 2025-12-26 04:09:15 --> Loader Class Initialized
INFO - 2025-12-26 04:09:15 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:15 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:15 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:15 --> Controller Class Initialized
INFO - 2025-12-26 04:09:15 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:15 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:15 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:15 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:15 --> Upload Class Initialized
INFO - 2025-12-26 04:09:15 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:15 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:09:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:15 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:15 --> Total execution time: 0.0756
INFO - 2025-12-26 04:09:17 --> Config Class Initialized
INFO - 2025-12-26 04:09:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:17 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:17 --> URI Class Initialized
INFO - 2025-12-26 04:09:17 --> Router Class Initialized
INFO - 2025-12-26 04:09:17 --> Output Class Initialized
INFO - 2025-12-26 04:09:17 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:17 --> CSRF cookie sent
INFO - 2025-12-26 04:09:17 --> Input Class Initialized
INFO - 2025-12-26 04:09:17 --> Language Class Initialized
INFO - 2025-12-26 04:09:17 --> Loader Class Initialized
INFO - 2025-12-26 04:09:17 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:17 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:17 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:17 --> Controller Class Initialized
INFO - 2025-12-26 04:09:17 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:17 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:17 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:17 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:17 --> Upload Class Initialized
INFO - 2025-12-26 04:09:17 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:17 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:20 --> Config Class Initialized
INFO - 2025-12-26 04:09:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:20 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:20 --> URI Class Initialized
INFO - 2025-12-26 04:09:20 --> Router Class Initialized
INFO - 2025-12-26 04:09:20 --> Output Class Initialized
INFO - 2025-12-26 04:09:20 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:20 --> CSRF cookie sent
INFO - 2025-12-26 04:09:20 --> Input Class Initialized
INFO - 2025-12-26 04:09:20 --> Language Class Initialized
INFO - 2025-12-26 04:09:20 --> Loader Class Initialized
INFO - 2025-12-26 04:09:20 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:20 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:20 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:20 --> Controller Class Initialized
INFO - 2025-12-26 04:09:20 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:20 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:20 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:20 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:20 --> Upload Class Initialized
INFO - 2025-12-26 04:09:20 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:20 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:20 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:20 --> Total execution time: 0.0700
INFO - 2025-12-26 04:09:22 --> Config Class Initialized
INFO - 2025-12-26 04:09:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:22 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:22 --> URI Class Initialized
INFO - 2025-12-26 04:09:22 --> Router Class Initialized
INFO - 2025-12-26 04:09:22 --> Output Class Initialized
INFO - 2025-12-26 04:09:22 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:22 --> CSRF cookie sent
INFO - 2025-12-26 04:09:22 --> Input Class Initialized
INFO - 2025-12-26 04:09:22 --> Language Class Initialized
INFO - 2025-12-26 04:09:22 --> Loader Class Initialized
INFO - 2025-12-26 04:09:22 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:22 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:22 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:22 --> Controller Class Initialized
INFO - 2025-12-26 04:09:22 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:22 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:22 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:22 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:22 --> Upload Class Initialized
INFO - 2025-12-26 04:09:22 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:22 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 04:09:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:22 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:22 --> Total execution time: 0.0756
INFO - 2025-12-26 04:09:39 --> Config Class Initialized
INFO - 2025-12-26 04:09:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:39 --> URI Class Initialized
INFO - 2025-12-26 04:09:39 --> Router Class Initialized
INFO - 2025-12-26 04:09:39 --> Output Class Initialized
INFO - 2025-12-26 04:09:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:39 --> CSRF cookie sent
INFO - 2025-12-26 04:09:39 --> CSRF token verified
INFO - 2025-12-26 04:09:39 --> Input Class Initialized
INFO - 2025-12-26 04:09:39 --> Language Class Initialized
INFO - 2025-12-26 04:09:39 --> Loader Class Initialized
INFO - 2025-12-26 04:09:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:39 --> Controller Class Initialized
INFO - 2025-12-26 04:09:39 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:39 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:39 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:39 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:39 --> Upload Class Initialized
INFO - 2025-12-26 04:09:39 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:39 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:41 --> Config Class Initialized
INFO - 2025-12-26 04:09:41 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:41 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:41 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:41 --> URI Class Initialized
INFO - 2025-12-26 04:09:41 --> Router Class Initialized
INFO - 2025-12-26 04:09:41 --> Output Class Initialized
INFO - 2025-12-26 04:09:41 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:41 --> CSRF cookie sent
INFO - 2025-12-26 04:09:41 --> Input Class Initialized
INFO - 2025-12-26 04:09:41 --> Language Class Initialized
INFO - 2025-12-26 04:09:41 --> Loader Class Initialized
INFO - 2025-12-26 04:09:41 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:41 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:41 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:41 --> Controller Class Initialized
INFO - 2025-12-26 04:09:41 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:09:41 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:41 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:41 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:09:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:41 --> Upload Class Initialized
INFO - 2025-12-26 04:09:41 --> Helper loaded: text_helper
INFO - 2025-12-26 04:09:41 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:09:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:09:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 04:09:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:41 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:41 --> Total execution time: 0.0880
INFO - 2025-12-26 04:09:58 --> Config Class Initialized
INFO - 2025-12-26 04:09:58 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:09:58 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:09:58 --> Utf8 Class Initialized
INFO - 2025-12-26 04:09:58 --> URI Class Initialized
INFO - 2025-12-26 04:09:58 --> Router Class Initialized
INFO - 2025-12-26 04:09:58 --> Output Class Initialized
INFO - 2025-12-26 04:09:58 --> Security Class Initialized
DEBUG - 2025-12-26 04:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:09:58 --> CSRF cookie sent
INFO - 2025-12-26 04:09:58 --> Input Class Initialized
INFO - 2025-12-26 04:09:58 --> Language Class Initialized
INFO - 2025-12-26 04:09:58 --> Loader Class Initialized
INFO - 2025-12-26 04:09:58 --> Helper loaded: url_helper
INFO - 2025-12-26 04:09:58 --> Helper loaded: form_helper
INFO - 2025-12-26 04:09:58 --> Helper loaded: file_helper
INFO - 2025-12-26 04:09:58 --> Helper loaded: html_helper
INFO - 2025-12-26 04:09:58 --> Helper loaded: security_helper
INFO - 2025-12-26 04:09:58 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:09:58 --> Database Driver Class Initialized
INFO - 2025-12-26 04:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:09:58 --> Form Validation Class Initialized
INFO - 2025-12-26 04:09:58 --> Controller Class Initialized
INFO - 2025-12-26 04:09:58 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:09:58 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:09:58 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:09:58 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:09:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:09:58 --> Upload Class Initialized
INFO - 2025-12-26 04:09:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:09:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:09:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-26 04:09:58 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-26 04:09:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:09:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:09:58 --> Final output sent to browser
DEBUG - 2025-12-26 04:09:58 --> Total execution time: 0.0640
INFO - 2025-12-26 04:11:28 --> Config Class Initialized
INFO - 2025-12-26 04:11:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:11:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:11:28 --> Utf8 Class Initialized
INFO - 2025-12-26 04:11:28 --> URI Class Initialized
INFO - 2025-12-26 04:11:28 --> Router Class Initialized
INFO - 2025-12-26 04:11:28 --> Output Class Initialized
INFO - 2025-12-26 04:11:28 --> Security Class Initialized
DEBUG - 2025-12-26 04:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:11:28 --> CSRF cookie sent
INFO - 2025-12-26 04:11:28 --> Input Class Initialized
INFO - 2025-12-26 04:11:28 --> Language Class Initialized
INFO - 2025-12-26 04:11:28 --> Loader Class Initialized
INFO - 2025-12-26 04:11:28 --> Helper loaded: url_helper
INFO - 2025-12-26 04:11:28 --> Helper loaded: form_helper
INFO - 2025-12-26 04:11:28 --> Helper loaded: file_helper
INFO - 2025-12-26 04:11:28 --> Helper loaded: html_helper
INFO - 2025-12-26 04:11:28 --> Helper loaded: security_helper
INFO - 2025-12-26 04:11:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:11:28 --> Database Driver Class Initialized
INFO - 2025-12-26 04:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:11:28 --> Form Validation Class Initialized
INFO - 2025-12-26 04:11:28 --> Controller Class Initialized
INFO - 2025-12-26 04:11:28 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:11:28 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:11:28 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:11:28 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:11:28 --> Upload Class Initialized
INFO - 2025-12-26 04:11:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:11:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:11:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:11:28 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-26 04:11:28 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-26 04:11:28 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-26 04:11:28 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-26 04:11:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:11:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:11:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:11:28 --> Total execution time: 0.2950
INFO - 2025-12-26 04:12:03 --> Config Class Initialized
INFO - 2025-12-26 04:12:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:12:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:12:03 --> Utf8 Class Initialized
INFO - 2025-12-26 04:12:03 --> URI Class Initialized
INFO - 2025-12-26 04:12:03 --> Router Class Initialized
INFO - 2025-12-26 04:12:03 --> Output Class Initialized
INFO - 2025-12-26 04:12:03 --> Security Class Initialized
DEBUG - 2025-12-26 04:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:12:03 --> CSRF cookie sent
INFO - 2025-12-26 04:12:03 --> Input Class Initialized
INFO - 2025-12-26 04:12:03 --> Language Class Initialized
INFO - 2025-12-26 04:12:03 --> Loader Class Initialized
INFO - 2025-12-26 04:12:03 --> Helper loaded: url_helper
INFO - 2025-12-26 04:12:03 --> Helper loaded: form_helper
INFO - 2025-12-26 04:12:03 --> Helper loaded: file_helper
INFO - 2025-12-26 04:12:03 --> Helper loaded: html_helper
INFO - 2025-12-26 04:12:03 --> Helper loaded: security_helper
INFO - 2025-12-26 04:12:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:12:03 --> Database Driver Class Initialized
INFO - 2025-12-26 04:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:12:03 --> Form Validation Class Initialized
INFO - 2025-12-26 04:12:03 --> Controller Class Initialized
INFO - 2025-12-26 04:12:03 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:12:03 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:12:03 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:12:03 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:12:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:12:03 --> Upload Class Initialized
INFO - 2025-12-26 04:12:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:12:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:12:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:12:04 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-26 04:12:04 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-26 04:12:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:12:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:12:04 --> Final output sent to browser
DEBUG - 2025-12-26 04:12:04 --> Total execution time: 0.3088
INFO - 2025-12-26 04:12:23 --> Config Class Initialized
INFO - 2025-12-26 04:12:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:12:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:12:23 --> Utf8 Class Initialized
INFO - 2025-12-26 04:12:23 --> URI Class Initialized
INFO - 2025-12-26 04:12:23 --> Router Class Initialized
INFO - 2025-12-26 04:12:23 --> Output Class Initialized
INFO - 2025-12-26 04:12:23 --> Security Class Initialized
DEBUG - 2025-12-26 04:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:12:23 --> CSRF cookie sent
INFO - 2025-12-26 04:12:23 --> Input Class Initialized
INFO - 2025-12-26 04:12:23 --> Language Class Initialized
INFO - 2025-12-26 04:12:23 --> Loader Class Initialized
INFO - 2025-12-26 04:12:23 --> Helper loaded: url_helper
INFO - 2025-12-26 04:12:23 --> Helper loaded: form_helper
INFO - 2025-12-26 04:12:23 --> Helper loaded: file_helper
INFO - 2025-12-26 04:12:23 --> Helper loaded: html_helper
INFO - 2025-12-26 04:12:23 --> Helper loaded: security_helper
INFO - 2025-12-26 04:12:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:12:23 --> Database Driver Class Initialized
INFO - 2025-12-26 04:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:12:23 --> Form Validation Class Initialized
INFO - 2025-12-26 04:12:23 --> Controller Class Initialized
INFO - 2025-12-26 04:12:23 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:12:23 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:12:23 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:12:23 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:12:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:12:23 --> Upload Class Initialized
INFO - 2025-12-26 04:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:12:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-26 04:12:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-26 04:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:12:23 --> Final output sent to browser
DEBUG - 2025-12-26 04:12:23 --> Total execution time: 0.2580
INFO - 2025-12-26 04:12:54 --> Config Class Initialized
INFO - 2025-12-26 04:12:54 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:12:54 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:12:54 --> Utf8 Class Initialized
INFO - 2025-12-26 04:12:54 --> URI Class Initialized
INFO - 2025-12-26 04:12:54 --> Router Class Initialized
INFO - 2025-12-26 04:12:54 --> Output Class Initialized
INFO - 2025-12-26 04:12:54 --> Security Class Initialized
DEBUG - 2025-12-26 04:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:12:54 --> CSRF cookie sent
INFO - 2025-12-26 04:12:54 --> Input Class Initialized
INFO - 2025-12-26 04:12:54 --> Language Class Initialized
INFO - 2025-12-26 04:12:54 --> Loader Class Initialized
INFO - 2025-12-26 04:12:54 --> Helper loaded: url_helper
INFO - 2025-12-26 04:12:54 --> Helper loaded: form_helper
INFO - 2025-12-26 04:12:54 --> Helper loaded: file_helper
INFO - 2025-12-26 04:12:54 --> Helper loaded: html_helper
INFO - 2025-12-26 04:12:54 --> Helper loaded: security_helper
INFO - 2025-12-26 04:12:54 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:12:54 --> Database Driver Class Initialized
INFO - 2025-12-26 04:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:12:54 --> Form Validation Class Initialized
INFO - 2025-12-26 04:12:54 --> Controller Class Initialized
INFO - 2025-12-26 04:12:54 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:12:54 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:12:54 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:12:54 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:12:54 --> Upload Class Initialized
INFO - 2025-12-26 04:12:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:12:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:12:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:12:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:12:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:12:55 --> Final output sent to browser
DEBUG - 2025-12-26 04:12:55 --> Total execution time: 0.3602
INFO - 2025-12-26 04:13:00 --> Config Class Initialized
INFO - 2025-12-26 04:13:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:00 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:00 --> URI Class Initialized
INFO - 2025-12-26 04:13:00 --> Router Class Initialized
INFO - 2025-12-26 04:13:00 --> Output Class Initialized
INFO - 2025-12-26 04:13:00 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:00 --> CSRF cookie sent
INFO - 2025-12-26 04:13:00 --> Input Class Initialized
INFO - 2025-12-26 04:13:00 --> Language Class Initialized
ERROR - 2025-12-26 04:13:00 --> 404 Page Not Found: Surat-keluar/ajukan-ttd
INFO - 2025-12-26 04:13:03 --> Config Class Initialized
INFO - 2025-12-26 04:13:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:03 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:03 --> URI Class Initialized
INFO - 2025-12-26 04:13:03 --> Router Class Initialized
INFO - 2025-12-26 04:13:03 --> Output Class Initialized
INFO - 2025-12-26 04:13:03 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:03 --> CSRF cookie sent
INFO - 2025-12-26 04:13:03 --> Input Class Initialized
INFO - 2025-12-26 04:13:03 --> Language Class Initialized
INFO - 2025-12-26 04:13:03 --> Loader Class Initialized
INFO - 2025-12-26 04:13:03 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:03 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:03 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:03 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:03 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:03 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:03 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:03 --> Controller Class Initialized
INFO - 2025-12-26 04:13:03 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:03 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:03 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:03 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:03 --> Upload Class Initialized
INFO - 2025-12-26 04:13:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:13:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:03 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:03 --> Total execution time: 0.0646
INFO - 2025-12-26 04:13:07 --> Config Class Initialized
INFO - 2025-12-26 04:13:07 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:07 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:07 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:07 --> URI Class Initialized
INFO - 2025-12-26 04:13:07 --> Router Class Initialized
INFO - 2025-12-26 04:13:07 --> Output Class Initialized
INFO - 2025-12-26 04:13:07 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:07 --> CSRF cookie sent
INFO - 2025-12-26 04:13:07 --> Input Class Initialized
INFO - 2025-12-26 04:13:07 --> Language Class Initialized
INFO - 2025-12-26 04:13:07 --> Loader Class Initialized
INFO - 2025-12-26 04:13:07 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:07 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:07 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:07 --> Controller Class Initialized
INFO - 2025-12-26 04:13:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:13:07 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:07 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:07 --> Upload Class Initialized
INFO - 2025-12-26 04:13:07 --> Helper loaded: text_helper
INFO - 2025-12-26 04:13:07 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:13:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:13:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:07 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:07 --> Total execution time: 0.0629
INFO - 2025-12-26 04:13:09 --> Config Class Initialized
INFO - 2025-12-26 04:13:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:09 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:09 --> URI Class Initialized
INFO - 2025-12-26 04:13:09 --> Router Class Initialized
INFO - 2025-12-26 04:13:09 --> Output Class Initialized
INFO - 2025-12-26 04:13:09 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:09 --> CSRF cookie sent
INFO - 2025-12-26 04:13:09 --> Input Class Initialized
INFO - 2025-12-26 04:13:09 --> Language Class Initialized
INFO - 2025-12-26 04:13:09 --> Loader Class Initialized
INFO - 2025-12-26 04:13:09 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:09 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:09 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:09 --> Controller Class Initialized
INFO - 2025-12-26 04:13:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:13:09 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:09 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:13:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:09 --> Upload Class Initialized
INFO - 2025-12-26 04:13:09 --> Helper loaded: text_helper
INFO - 2025-12-26 04:13:09 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:13:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:13:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:09 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:09 --> Total execution time: 0.0613
INFO - 2025-12-26 04:13:10 --> Config Class Initialized
INFO - 2025-12-26 04:13:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:10 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:10 --> URI Class Initialized
INFO - 2025-12-26 04:13:10 --> Router Class Initialized
INFO - 2025-12-26 04:13:10 --> Output Class Initialized
INFO - 2025-12-26 04:13:10 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:10 --> CSRF cookie sent
INFO - 2025-12-26 04:13:10 --> Input Class Initialized
INFO - 2025-12-26 04:13:10 --> Language Class Initialized
INFO - 2025-12-26 04:13:10 --> Loader Class Initialized
INFO - 2025-12-26 04:13:10 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:10 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:10 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:10 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:10 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:10 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:10 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:10 --> Controller Class Initialized
INFO - 2025-12-26 04:13:10 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:10 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:10 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:10 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:10 --> Upload Class Initialized
INFO - 2025-12-26 04:13:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:13:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:10 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:10 --> Total execution time: 0.0801
INFO - 2025-12-26 04:13:14 --> Config Class Initialized
INFO - 2025-12-26 04:13:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:14 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:14 --> URI Class Initialized
INFO - 2025-12-26 04:13:14 --> Router Class Initialized
INFO - 2025-12-26 04:13:14 --> Output Class Initialized
INFO - 2025-12-26 04:13:14 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:14 --> CSRF cookie sent
INFO - 2025-12-26 04:13:14 --> Input Class Initialized
INFO - 2025-12-26 04:13:14 --> Language Class Initialized
INFO - 2025-12-26 04:13:14 --> Loader Class Initialized
INFO - 2025-12-26 04:13:14 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:14 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:14 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:14 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:14 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:14 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:14 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:14 --> Controller Class Initialized
INFO - 2025-12-26 04:13:14 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:14 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:14 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:14 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:14 --> Upload Class Initialized
INFO - 2025-12-26 04:13:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:13:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:14 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:14 --> Total execution time: 0.0580
INFO - 2025-12-26 04:13:27 --> Config Class Initialized
INFO - 2025-12-26 04:13:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:27 --> URI Class Initialized
INFO - 2025-12-26 04:13:27 --> Router Class Initialized
INFO - 2025-12-26 04:13:27 --> Output Class Initialized
INFO - 2025-12-26 04:13:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:27 --> CSRF cookie sent
INFO - 2025-12-26 04:13:27 --> Input Class Initialized
INFO - 2025-12-26 04:13:27 --> Language Class Initialized
INFO - 2025-12-26 04:13:27 --> Loader Class Initialized
INFO - 2025-12-26 04:13:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:27 --> Controller Class Initialized
INFO - 2025-12-26 04:13:27 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:27 --> Upload Class Initialized
INFO - 2025-12-26 04:13:27 --> Config Class Initialized
INFO - 2025-12-26 04:13:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:27 --> URI Class Initialized
INFO - 2025-12-26 04:13:27 --> Router Class Initialized
INFO - 2025-12-26 04:13:27 --> Output Class Initialized
INFO - 2025-12-26 04:13:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:27 --> CSRF cookie sent
INFO - 2025-12-26 04:13:27 --> Input Class Initialized
INFO - 2025-12-26 04:13:27 --> Language Class Initialized
INFO - 2025-12-26 04:13:27 --> Loader Class Initialized
INFO - 2025-12-26 04:13:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:27 --> Controller Class Initialized
INFO - 2025-12-26 04:13:27 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:27 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:27 --> Upload Class Initialized
INFO - 2025-12-26 04:13:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:13:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:27 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:27 --> Total execution time: 0.1004
INFO - 2025-12-26 04:13:29 --> Config Class Initialized
INFO - 2025-12-26 04:13:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:29 --> URI Class Initialized
INFO - 2025-12-26 04:13:29 --> Router Class Initialized
INFO - 2025-12-26 04:13:29 --> Output Class Initialized
INFO - 2025-12-26 04:13:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:29 --> CSRF cookie sent
INFO - 2025-12-26 04:13:29 --> Input Class Initialized
INFO - 2025-12-26 04:13:29 --> Language Class Initialized
INFO - 2025-12-26 04:13:29 --> Loader Class Initialized
INFO - 2025-12-26 04:13:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:29 --> Controller Class Initialized
INFO - 2025-12-26 04:13:29 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:29 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:29 --> Upload Class Initialized
INFO - 2025-12-26 04:13:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 04:13:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:29 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:29 --> Total execution time: 0.0650
INFO - 2025-12-26 04:13:40 --> Config Class Initialized
INFO - 2025-12-26 04:13:40 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:40 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:40 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:40 --> URI Class Initialized
INFO - 2025-12-26 04:13:40 --> Router Class Initialized
INFO - 2025-12-26 04:13:40 --> Output Class Initialized
INFO - 2025-12-26 04:13:40 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:40 --> CSRF cookie sent
INFO - 2025-12-26 04:13:40 --> CSRF token verified
INFO - 2025-12-26 04:13:40 --> Input Class Initialized
INFO - 2025-12-26 04:13:40 --> Language Class Initialized
INFO - 2025-12-26 04:13:40 --> Loader Class Initialized
INFO - 2025-12-26 04:13:40 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:40 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:40 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:40 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:40 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:40 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:40 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:40 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:40 --> Controller Class Initialized
INFO - 2025-12-26 04:13:40 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:40 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:40 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:40 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:40 --> Upload Class Initialized
INFO - 2025-12-26 04:13:41 --> Config Class Initialized
INFO - 2025-12-26 04:13:41 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:13:41 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:13:41 --> Utf8 Class Initialized
INFO - 2025-12-26 04:13:41 --> URI Class Initialized
INFO - 2025-12-26 04:13:41 --> Router Class Initialized
INFO - 2025-12-26 04:13:41 --> Output Class Initialized
INFO - 2025-12-26 04:13:41 --> Security Class Initialized
DEBUG - 2025-12-26 04:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:13:41 --> CSRF cookie sent
INFO - 2025-12-26 04:13:41 --> Input Class Initialized
INFO - 2025-12-26 04:13:41 --> Language Class Initialized
INFO - 2025-12-26 04:13:41 --> Loader Class Initialized
INFO - 2025-12-26 04:13:41 --> Helper loaded: url_helper
INFO - 2025-12-26 04:13:41 --> Helper loaded: form_helper
INFO - 2025-12-26 04:13:41 --> Helper loaded: file_helper
INFO - 2025-12-26 04:13:41 --> Helper loaded: html_helper
INFO - 2025-12-26 04:13:41 --> Helper loaded: security_helper
INFO - 2025-12-26 04:13:41 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:13:41 --> Database Driver Class Initialized
INFO - 2025-12-26 04:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:13:41 --> Form Validation Class Initialized
INFO - 2025-12-26 04:13:41 --> Controller Class Initialized
INFO - 2025-12-26 04:13:41 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:13:41 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:13:41 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:13:41 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:13:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:13:41 --> Upload Class Initialized
INFO - 2025-12-26 04:13:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:13:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:13:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:13:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 04:13:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:13:41 --> Final output sent to browser
DEBUG - 2025-12-26 04:13:41 --> Total execution time: 0.0872
INFO - 2025-12-26 04:14:04 --> Config Class Initialized
INFO - 2025-12-26 04:14:04 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:14:04 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:14:04 --> Utf8 Class Initialized
INFO - 2025-12-26 04:14:04 --> URI Class Initialized
INFO - 2025-12-26 04:14:04 --> Router Class Initialized
INFO - 2025-12-26 04:14:04 --> Output Class Initialized
INFO - 2025-12-26 04:14:04 --> Security Class Initialized
DEBUG - 2025-12-26 04:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:14:04 --> CSRF cookie sent
INFO - 2025-12-26 04:14:04 --> CSRF token verified
INFO - 2025-12-26 04:14:04 --> Input Class Initialized
INFO - 2025-12-26 04:14:04 --> Language Class Initialized
INFO - 2025-12-26 04:14:04 --> Loader Class Initialized
INFO - 2025-12-26 04:14:04 --> Helper loaded: url_helper
INFO - 2025-12-26 04:14:04 --> Helper loaded: form_helper
INFO - 2025-12-26 04:14:04 --> Helper loaded: file_helper
INFO - 2025-12-26 04:14:04 --> Helper loaded: html_helper
INFO - 2025-12-26 04:14:04 --> Helper loaded: security_helper
INFO - 2025-12-26 04:14:04 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:14:04 --> Database Driver Class Initialized
INFO - 2025-12-26 04:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:14:05 --> Form Validation Class Initialized
INFO - 2025-12-26 04:14:05 --> Controller Class Initialized
INFO - 2025-12-26 04:14:05 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:14:05 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:14:05 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:14:05 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:14:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:14:05 --> Upload Class Initialized
INFO - 2025-12-26 04:14:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-26 04:14:05 --> Query error: Unknown column 'status_ttd' in 'field list' - Invalid query: INSERT INTO `surat_keluar` (`no_surat`, `kode_bagian`, `kode_kategori`, `tujuan`, `perihal`, `tanggal_surat`, `nama_file_surat`, `file_type`, `file_size`, `status_ttd`, `created_by`) VALUES ('04.074/ITM/X11/2025', 'ITM', '04', 'mahasiswa Institut Teknologi Mojosari tentang pelaksanaan kegiatan Ujian Akhir', 'UJIAN AKHIR SEMESTER GANJIL', '2025-12-26', 'fa90ad647c6e950cf0dfe4cc27bedb9f.png', 'png', 151155, 'ditandatangani', 1)
INFO - 2025-12-26 04:14:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 04:15:08 --> Config Class Initialized
INFO - 2025-12-26 04:15:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:08 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:08 --> URI Class Initialized
INFO - 2025-12-26 04:15:08 --> Router Class Initialized
INFO - 2025-12-26 04:15:08 --> Output Class Initialized
INFO - 2025-12-26 04:15:08 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:08 --> CSRF cookie sent
INFO - 2025-12-26 04:15:08 --> Input Class Initialized
INFO - 2025-12-26 04:15:08 --> Language Class Initialized
INFO - 2025-12-26 04:15:08 --> Loader Class Initialized
INFO - 2025-12-26 04:15:08 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:08 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:08 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:08 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:08 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:08 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:08 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:08 --> Controller Class Initialized
INFO - 2025-12-26 04:15:08 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:15:08 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:15:08 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:15:08 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:15:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:08 --> Upload Class Initialized
INFO - 2025-12-26 04:15:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:15:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:15:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:15:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 04:15:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:15:08 --> Final output sent to browser
DEBUG - 2025-12-26 04:15:08 --> Total execution time: 0.0554
INFO - 2025-12-26 04:15:11 --> Config Class Initialized
INFO - 2025-12-26 04:15:11 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:11 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:11 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:11 --> URI Class Initialized
INFO - 2025-12-26 04:15:11 --> Router Class Initialized
INFO - 2025-12-26 04:15:11 --> Output Class Initialized
INFO - 2025-12-26 04:15:11 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:11 --> CSRF cookie sent
INFO - 2025-12-26 04:15:11 --> Input Class Initialized
INFO - 2025-12-26 04:15:11 --> Language Class Initialized
INFO - 2025-12-26 04:15:11 --> Loader Class Initialized
INFO - 2025-12-26 04:15:11 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:11 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:11 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:11 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:11 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:11 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:11 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:11 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:11 --> Controller Class Initialized
INFO - 2025-12-26 04:15:11 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:15:11 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:15:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:15:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:15:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:15:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:15:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:15:11 --> Final output sent to browser
DEBUG - 2025-12-26 04:15:11 --> Total execution time: 0.0724
INFO - 2025-12-26 04:15:17 --> Config Class Initialized
INFO - 2025-12-26 04:15:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:17 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:17 --> URI Class Initialized
INFO - 2025-12-26 04:15:17 --> Router Class Initialized
INFO - 2025-12-26 04:15:17 --> Output Class Initialized
INFO - 2025-12-26 04:15:17 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:17 --> CSRF cookie sent
INFO - 2025-12-26 04:15:17 --> Input Class Initialized
INFO - 2025-12-26 04:15:17 --> Language Class Initialized
INFO - 2025-12-26 04:15:17 --> Loader Class Initialized
INFO - 2025-12-26 04:15:17 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:17 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:17 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:17 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:17 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:17 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:17 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:17 --> Controller Class Initialized
INFO - 2025-12-26 04:15:17 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:15:17 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:15:17 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:15:17 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:17 --> Upload Class Initialized
INFO - 2025-12-26 04:15:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:15:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:15:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:15:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:15:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:15:17 --> Final output sent to browser
DEBUG - 2025-12-26 04:15:17 --> Total execution time: 0.0635
INFO - 2025-12-26 04:15:19 --> Config Class Initialized
INFO - 2025-12-26 04:15:19 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:19 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:19 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:19 --> URI Class Initialized
INFO - 2025-12-26 04:15:19 --> Router Class Initialized
INFO - 2025-12-26 04:15:19 --> Output Class Initialized
INFO - 2025-12-26 04:15:19 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:19 --> CSRF cookie sent
INFO - 2025-12-26 04:15:19 --> Input Class Initialized
INFO - 2025-12-26 04:15:19 --> Language Class Initialized
INFO - 2025-12-26 04:15:19 --> Loader Class Initialized
INFO - 2025-12-26 04:15:19 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:19 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:19 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:19 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:19 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:19 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:19 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:19 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:19 --> Controller Class Initialized
INFO - 2025-12-26 04:15:19 --> Model "User_model" initialized
INFO - 2025-12-26 04:15:19 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:15:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:19 --> Upload Class Initialized
INFO - 2025-12-26 04:15:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:15:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:15:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:15:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:15:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:15:19 --> Final output sent to browser
DEBUG - 2025-12-26 04:15:19 --> Total execution time: 0.0608
INFO - 2025-12-26 04:15:21 --> Config Class Initialized
INFO - 2025-12-26 04:15:21 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:21 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:21 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:21 --> URI Class Initialized
INFO - 2025-12-26 04:15:21 --> Router Class Initialized
INFO - 2025-12-26 04:15:21 --> Output Class Initialized
INFO - 2025-12-26 04:15:21 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:21 --> CSRF cookie sent
INFO - 2025-12-26 04:15:21 --> Input Class Initialized
INFO - 2025-12-26 04:15:21 --> Language Class Initialized
INFO - 2025-12-26 04:15:21 --> Loader Class Initialized
INFO - 2025-12-26 04:15:21 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:21 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:21 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:21 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:21 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:21 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:21 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:21 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:21 --> Controller Class Initialized
INFO - 2025-12-26 04:15:21 --> Model "User_model" initialized
INFO - 2025-12-26 04:15:21 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:15:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:21 --> Upload Class Initialized
INFO - 2025-12-26 04:15:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:15:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:15:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:15:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:15:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:15:21 --> Final output sent to browser
DEBUG - 2025-12-26 04:15:21 --> Total execution time: 0.0739
INFO - 2025-12-26 04:15:50 --> Config Class Initialized
INFO - 2025-12-26 04:15:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:15:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:15:50 --> Utf8 Class Initialized
INFO - 2025-12-26 04:15:50 --> URI Class Initialized
INFO - 2025-12-26 04:15:50 --> Router Class Initialized
INFO - 2025-12-26 04:15:50 --> Output Class Initialized
INFO - 2025-12-26 04:15:50 --> Security Class Initialized
DEBUG - 2025-12-26 04:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:15:50 --> CSRF cookie sent
INFO - 2025-12-26 04:15:50 --> CSRF token verified
INFO - 2025-12-26 04:15:50 --> Input Class Initialized
INFO - 2025-12-26 04:15:50 --> Language Class Initialized
INFO - 2025-12-26 04:15:50 --> Loader Class Initialized
INFO - 2025-12-26 04:15:50 --> Helper loaded: url_helper
INFO - 2025-12-26 04:15:50 --> Helper loaded: form_helper
INFO - 2025-12-26 04:15:50 --> Helper loaded: file_helper
INFO - 2025-12-26 04:15:50 --> Helper loaded: html_helper
INFO - 2025-12-26 04:15:50 --> Helper loaded: security_helper
INFO - 2025-12-26 04:15:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:15:50 --> Database Driver Class Initialized
INFO - 2025-12-26 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:15:50 --> Form Validation Class Initialized
INFO - 2025-12-26 04:15:50 --> Controller Class Initialized
INFO - 2025-12-26 04:15:50 --> Model "User_model" initialized
INFO - 2025-12-26 04:15:50 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:15:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:15:50 --> Upload Class Initialized
INFO - 2025-12-26 04:15:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-26 04:15:50 --> Query error: Unknown column 'tanda_tangan' in 'field list' - Invalid query: INSERT INTO `user` (`username`, `password`, `nama`, `role`, `jabatan`, `kode_bagian`, `foto_profil`, `tanda_tangan`, `status`) VALUES ('rektor', '$2y$10$T8qyNxxuULDOeqkzXnh9BOetVVAU0XszgDlACPYRxVw1PK610z0Sa', 'Wardi, M. Pd', 'pimpinan', 'Rektor', 'ITM', NULL, NULL, '1')
INFO - 2025-12-26 04:15:50 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 04:17:24 --> Config Class Initialized
INFO - 2025-12-26 04:17:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:24 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:24 --> URI Class Initialized
INFO - 2025-12-26 04:17:24 --> Router Class Initialized
INFO - 2025-12-26 04:17:24 --> Output Class Initialized
INFO - 2025-12-26 04:17:24 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:24 --> CSRF cookie sent
INFO - 2025-12-26 04:17:27 --> Config Class Initialized
INFO - 2025-12-26 04:17:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:27 --> URI Class Initialized
INFO - 2025-12-26 04:17:27 --> Router Class Initialized
INFO - 2025-12-26 04:17:27 --> Output Class Initialized
INFO - 2025-12-26 04:17:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:27 --> CSRF cookie sent
INFO - 2025-12-26 04:17:27 --> Input Class Initialized
INFO - 2025-12-26 04:17:27 --> Language Class Initialized
INFO - 2025-12-26 04:17:27 --> Loader Class Initialized
INFO - 2025-12-26 04:17:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:28 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:28 --> Controller Class Initialized
INFO - 2025-12-26 04:17:28 --> Model "User_model" initialized
INFO - 2025-12-26 04:17:28 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:28 --> Upload Class Initialized
INFO - 2025-12-26 04:17:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:17:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:17:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:17:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:17:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:17:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:17:28 --> Total execution time: 0.1032
INFO - 2025-12-26 04:17:37 --> Config Class Initialized
INFO - 2025-12-26 04:17:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:37 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:37 --> URI Class Initialized
INFO - 2025-12-26 04:17:37 --> Router Class Initialized
INFO - 2025-12-26 04:17:37 --> Output Class Initialized
INFO - 2025-12-26 04:17:37 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:37 --> CSRF cookie sent
INFO - 2025-12-26 04:17:37 --> CSRF token verified
INFO - 2025-12-26 04:17:37 --> Input Class Initialized
INFO - 2025-12-26 04:17:37 --> Language Class Initialized
INFO - 2025-12-26 04:17:37 --> Loader Class Initialized
INFO - 2025-12-26 04:17:37 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:37 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:37 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:37 --> Controller Class Initialized
INFO - 2025-12-26 04:17:37 --> Model "User_model" initialized
INFO - 2025-12-26 04:17:37 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:37 --> Upload Class Initialized
INFO - 2025-12-26 04:17:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:17:37 --> Config Class Initialized
INFO - 2025-12-26 04:17:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:37 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:37 --> URI Class Initialized
INFO - 2025-12-26 04:17:37 --> Router Class Initialized
INFO - 2025-12-26 04:17:37 --> Output Class Initialized
INFO - 2025-12-26 04:17:37 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:37 --> CSRF cookie sent
INFO - 2025-12-26 04:17:37 --> Input Class Initialized
INFO - 2025-12-26 04:17:37 --> Language Class Initialized
INFO - 2025-12-26 04:17:37 --> Loader Class Initialized
INFO - 2025-12-26 04:17:37 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:37 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:37 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:37 --> Controller Class Initialized
INFO - 2025-12-26 04:17:37 --> Model "User_model" initialized
INFO - 2025-12-26 04:17:37 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:37 --> Upload Class Initialized
INFO - 2025-12-26 04:17:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:17:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:17:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:17:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:17:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:17:37 --> Final output sent to browser
DEBUG - 2025-12-26 04:17:37 --> Total execution time: 0.0617
INFO - 2025-12-26 04:17:42 --> Config Class Initialized
INFO - 2025-12-26 04:17:42 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:42 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:42 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:42 --> URI Class Initialized
INFO - 2025-12-26 04:17:42 --> Router Class Initialized
INFO - 2025-12-26 04:17:42 --> Output Class Initialized
INFO - 2025-12-26 04:17:42 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:42 --> CSRF cookie sent
INFO - 2025-12-26 04:17:42 --> Input Class Initialized
INFO - 2025-12-26 04:17:42 --> Language Class Initialized
INFO - 2025-12-26 04:17:42 --> Loader Class Initialized
INFO - 2025-12-26 04:17:42 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:42 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:42 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:42 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:43 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:43 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:43 --> Controller Class Initialized
INFO - 2025-12-26 04:17:43 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:43 --> Config Class Initialized
INFO - 2025-12-26 04:17:43 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:43 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:43 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:43 --> URI Class Initialized
INFO - 2025-12-26 04:17:43 --> Router Class Initialized
INFO - 2025-12-26 04:17:43 --> Output Class Initialized
INFO - 2025-12-26 04:17:43 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:43 --> CSRF cookie sent
INFO - 2025-12-26 04:17:43 --> Input Class Initialized
INFO - 2025-12-26 04:17:43 --> Language Class Initialized
INFO - 2025-12-26 04:17:43 --> Loader Class Initialized
INFO - 2025-12-26 04:17:43 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:43 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:43 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:43 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:43 --> Controller Class Initialized
INFO - 2025-12-26 04:17:43 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:17:43 --> Final output sent to browser
DEBUG - 2025-12-26 04:17:43 --> Total execution time: 0.0491
INFO - 2025-12-26 04:17:52 --> Config Class Initialized
INFO - 2025-12-26 04:17:52 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:17:52 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:17:52 --> Utf8 Class Initialized
INFO - 2025-12-26 04:17:52 --> URI Class Initialized
INFO - 2025-12-26 04:17:52 --> Router Class Initialized
INFO - 2025-12-26 04:17:52 --> Output Class Initialized
INFO - 2025-12-26 04:17:52 --> Security Class Initialized
DEBUG - 2025-12-26 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:17:52 --> CSRF cookie sent
INFO - 2025-12-26 04:17:52 --> CSRF token verified
INFO - 2025-12-26 04:17:52 --> Input Class Initialized
INFO - 2025-12-26 04:17:52 --> Language Class Initialized
INFO - 2025-12-26 04:17:52 --> Loader Class Initialized
INFO - 2025-12-26 04:17:52 --> Helper loaded: url_helper
INFO - 2025-12-26 04:17:52 --> Helper loaded: form_helper
INFO - 2025-12-26 04:17:52 --> Helper loaded: file_helper
INFO - 2025-12-26 04:17:52 --> Helper loaded: html_helper
INFO - 2025-12-26 04:17:52 --> Helper loaded: security_helper
INFO - 2025-12-26 04:17:52 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:17:52 --> Database Driver Class Initialized
INFO - 2025-12-26 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:17:52 --> Form Validation Class Initialized
INFO - 2025-12-26 04:17:52 --> Controller Class Initialized
INFO - 2025-12-26 04:17:52 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:17:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:17:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:17:52 --> Final output sent to browser
DEBUG - 2025-12-26 04:17:52 --> Total execution time: 0.0590
INFO - 2025-12-26 04:18:01 --> Config Class Initialized
INFO - 2025-12-26 04:18:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:01 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:01 --> URI Class Initialized
INFO - 2025-12-26 04:18:01 --> Router Class Initialized
INFO - 2025-12-26 04:18:01 --> Output Class Initialized
INFO - 2025-12-26 04:18:01 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:01 --> CSRF cookie sent
INFO - 2025-12-26 04:18:01 --> CSRF token verified
INFO - 2025-12-26 04:18:01 --> Input Class Initialized
INFO - 2025-12-26 04:18:01 --> Language Class Initialized
INFO - 2025-12-26 04:18:01 --> Loader Class Initialized
INFO - 2025-12-26 04:18:01 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:01 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:01 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:01 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:01 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:01 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:01 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:01 --> Controller Class Initialized
INFO - 2025-12-26 04:18:01 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:18:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:18:01 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:01 --> Total execution time: 0.0491
INFO - 2025-12-26 04:18:08 --> Config Class Initialized
INFO - 2025-12-26 04:18:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:08 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:08 --> URI Class Initialized
INFO - 2025-12-26 04:18:08 --> Router Class Initialized
INFO - 2025-12-26 04:18:08 --> Output Class Initialized
INFO - 2025-12-26 04:18:08 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:08 --> CSRF cookie sent
INFO - 2025-12-26 04:18:08 --> CSRF token verified
INFO - 2025-12-26 04:18:08 --> Input Class Initialized
INFO - 2025-12-26 04:18:08 --> Language Class Initialized
INFO - 2025-12-26 04:18:08 --> Loader Class Initialized
INFO - 2025-12-26 04:18:08 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:08 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:08 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:08 --> Controller Class Initialized
INFO - 2025-12-26 04:18:08 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:18:08 --> Config Class Initialized
INFO - 2025-12-26 04:18:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:08 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:08 --> URI Class Initialized
INFO - 2025-12-26 04:18:08 --> Router Class Initialized
INFO - 2025-12-26 04:18:08 --> Output Class Initialized
INFO - 2025-12-26 04:18:08 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:08 --> CSRF cookie sent
INFO - 2025-12-26 04:18:08 --> Input Class Initialized
INFO - 2025-12-26 04:18:08 --> Language Class Initialized
INFO - 2025-12-26 04:18:08 --> Loader Class Initialized
INFO - 2025-12-26 04:18:08 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:08 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:08 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:08 --> Controller Class Initialized
INFO - 2025-12-26 04:18:08 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:18:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:18:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:08 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:08 --> Total execution time: 0.0606
INFO - 2025-12-26 04:18:14 --> Config Class Initialized
INFO - 2025-12-26 04:18:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:14 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:14 --> URI Class Initialized
INFO - 2025-12-26 04:18:14 --> Router Class Initialized
INFO - 2025-12-26 04:18:14 --> Output Class Initialized
INFO - 2025-12-26 04:18:14 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:14 --> CSRF cookie sent
INFO - 2025-12-26 04:18:14 --> Input Class Initialized
INFO - 2025-12-26 04:18:14 --> Language Class Initialized
INFO - 2025-12-26 04:18:14 --> Loader Class Initialized
INFO - 2025-12-26 04:18:14 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:14 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:14 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:14 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:14 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:14 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:14 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:14 --> Controller Class Initialized
INFO - 2025-12-26 04:18:14 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:18:14 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:18:14 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:18:14 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:14 --> Upload Class Initialized
INFO - 2025-12-26 04:18:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:18:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:14 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:14 --> Total execution time: 0.0574
INFO - 2025-12-26 04:18:16 --> Config Class Initialized
INFO - 2025-12-26 04:18:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:16 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:16 --> URI Class Initialized
INFO - 2025-12-26 04:18:16 --> Router Class Initialized
INFO - 2025-12-26 04:18:16 --> Output Class Initialized
INFO - 2025-12-26 04:18:16 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:16 --> CSRF cookie sent
INFO - 2025-12-26 04:18:16 --> Input Class Initialized
INFO - 2025-12-26 04:18:16 --> Language Class Initialized
INFO - 2025-12-26 04:18:16 --> Loader Class Initialized
INFO - 2025-12-26 04:18:16 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:16 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:16 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:16 --> Controller Class Initialized
INFO - 2025-12-26 04:18:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:18:16 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:18:16 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:18:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:16 --> Upload Class Initialized
INFO - 2025-12-26 04:18:16 --> Helper loaded: text_helper
INFO - 2025-12-26 04:18:16 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:18:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:18:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:16 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:16 --> Total execution time: 0.0607
INFO - 2025-12-26 04:18:17 --> Config Class Initialized
INFO - 2025-12-26 04:18:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:17 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:17 --> URI Class Initialized
INFO - 2025-12-26 04:18:17 --> Router Class Initialized
INFO - 2025-12-26 04:18:17 --> Output Class Initialized
INFO - 2025-12-26 04:18:17 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:17 --> CSRF cookie sent
INFO - 2025-12-26 04:18:17 --> Input Class Initialized
INFO - 2025-12-26 04:18:17 --> Language Class Initialized
INFO - 2025-12-26 04:18:17 --> Loader Class Initialized
INFO - 2025-12-26 04:18:17 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:17 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:17 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:17 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:17 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:17 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:17 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:17 --> Controller Class Initialized
INFO - 2025-12-26 04:18:17 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:18:17 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:18:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:17 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:17 --> Total execution time: 0.0606
INFO - 2025-12-26 04:18:19 --> Config Class Initialized
INFO - 2025-12-26 04:18:19 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:19 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:19 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:19 --> URI Class Initialized
INFO - 2025-12-26 04:18:19 --> Router Class Initialized
INFO - 2025-12-26 04:18:19 --> Output Class Initialized
INFO - 2025-12-26 04:18:19 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:19 --> CSRF cookie sent
INFO - 2025-12-26 04:18:19 --> Input Class Initialized
INFO - 2025-12-26 04:18:19 --> Language Class Initialized
INFO - 2025-12-26 04:18:19 --> Loader Class Initialized
INFO - 2025-12-26 04:18:19 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:19 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:19 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:19 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:19 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:19 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:19 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:19 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:19 --> Controller Class Initialized
INFO - 2025-12-26 04:18:19 --> Model "User_model" initialized
INFO - 2025-12-26 04:18:19 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:19 --> Upload Class Initialized
INFO - 2025-12-26 04:18:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:18:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:19 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:19 --> Total execution time: 0.0600
INFO - 2025-12-26 04:18:22 --> Config Class Initialized
INFO - 2025-12-26 04:18:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:22 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:22 --> URI Class Initialized
INFO - 2025-12-26 04:18:22 --> Router Class Initialized
INFO - 2025-12-26 04:18:22 --> Output Class Initialized
INFO - 2025-12-26 04:18:22 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:22 --> CSRF cookie sent
INFO - 2025-12-26 04:18:22 --> Input Class Initialized
INFO - 2025-12-26 04:18:22 --> Language Class Initialized
INFO - 2025-12-26 04:18:22 --> Loader Class Initialized
INFO - 2025-12-26 04:18:22 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:22 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:22 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:22 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:22 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:22 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:22 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:22 --> Controller Class Initialized
INFO - 2025-12-26 04:18:22 --> Model "User_model" initialized
INFO - 2025-12-26 04:18:22 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:22 --> Upload Class Initialized
INFO - 2025-12-26 04:18:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:18:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:22 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:22 --> Total execution time: 0.0579
INFO - 2025-12-26 04:18:30 --> Config Class Initialized
INFO - 2025-12-26 04:18:30 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:30 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:30 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:30 --> URI Class Initialized
INFO - 2025-12-26 04:18:30 --> Router Class Initialized
INFO - 2025-12-26 04:18:30 --> Output Class Initialized
INFO - 2025-12-26 04:18:30 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:30 --> CSRF cookie sent
INFO - 2025-12-26 04:18:30 --> CSRF token verified
INFO - 2025-12-26 04:18:30 --> Input Class Initialized
INFO - 2025-12-26 04:18:30 --> Language Class Initialized
INFO - 2025-12-26 04:18:30 --> Loader Class Initialized
INFO - 2025-12-26 04:18:30 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:30 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:30 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:30 --> Controller Class Initialized
INFO - 2025-12-26 04:18:30 --> Model "User_model" initialized
INFO - 2025-12-26 04:18:30 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:30 --> Upload Class Initialized
INFO - 2025-12-26 04:18:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:18:30 --> Config Class Initialized
INFO - 2025-12-26 04:18:30 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:30 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:30 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:30 --> URI Class Initialized
INFO - 2025-12-26 04:18:30 --> Router Class Initialized
INFO - 2025-12-26 04:18:30 --> Output Class Initialized
INFO - 2025-12-26 04:18:30 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:30 --> CSRF cookie sent
INFO - 2025-12-26 04:18:30 --> Input Class Initialized
INFO - 2025-12-26 04:18:30 --> Language Class Initialized
INFO - 2025-12-26 04:18:30 --> Loader Class Initialized
INFO - 2025-12-26 04:18:30 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:30 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:30 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:30 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:30 --> Controller Class Initialized
INFO - 2025-12-26 04:18:30 --> Model "User_model" initialized
INFO - 2025-12-26 04:18:30 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:30 --> Upload Class Initialized
INFO - 2025-12-26 04:18:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:18:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:18:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:18:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:18:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:18:30 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:30 --> Total execution time: 0.0628
INFO - 2025-12-26 04:18:34 --> Config Class Initialized
INFO - 2025-12-26 04:18:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:34 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:34 --> URI Class Initialized
INFO - 2025-12-26 04:18:34 --> Router Class Initialized
INFO - 2025-12-26 04:18:34 --> Output Class Initialized
INFO - 2025-12-26 04:18:34 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:34 --> CSRF cookie sent
INFO - 2025-12-26 04:18:34 --> Input Class Initialized
INFO - 2025-12-26 04:18:34 --> Language Class Initialized
INFO - 2025-12-26 04:18:34 --> Loader Class Initialized
INFO - 2025-12-26 04:18:34 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:34 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:34 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:34 --> Controller Class Initialized
INFO - 2025-12-26 04:18:34 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:34 --> Config Class Initialized
INFO - 2025-12-26 04:18:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:34 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:34 --> URI Class Initialized
INFO - 2025-12-26 04:18:34 --> Router Class Initialized
INFO - 2025-12-26 04:18:34 --> Output Class Initialized
INFO - 2025-12-26 04:18:34 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:34 --> CSRF cookie sent
INFO - 2025-12-26 04:18:34 --> Input Class Initialized
INFO - 2025-12-26 04:18:34 --> Language Class Initialized
INFO - 2025-12-26 04:18:34 --> Loader Class Initialized
INFO - 2025-12-26 04:18:34 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:34 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:34 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:34 --> Controller Class Initialized
INFO - 2025-12-26 04:18:34 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:18:34 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:34 --> Total execution time: 0.0507
INFO - 2025-12-26 04:18:43 --> Config Class Initialized
INFO - 2025-12-26 04:18:43 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:18:43 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:18:43 --> Utf8 Class Initialized
INFO - 2025-12-26 04:18:43 --> URI Class Initialized
INFO - 2025-12-26 04:18:43 --> Router Class Initialized
INFO - 2025-12-26 04:18:43 --> Output Class Initialized
INFO - 2025-12-26 04:18:43 --> Security Class Initialized
DEBUG - 2025-12-26 04:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:18:43 --> CSRF cookie sent
INFO - 2025-12-26 04:18:43 --> CSRF token verified
INFO - 2025-12-26 04:18:43 --> Input Class Initialized
INFO - 2025-12-26 04:18:43 --> Language Class Initialized
INFO - 2025-12-26 04:18:43 --> Loader Class Initialized
INFO - 2025-12-26 04:18:43 --> Helper loaded: url_helper
INFO - 2025-12-26 04:18:43 --> Helper loaded: form_helper
INFO - 2025-12-26 04:18:43 --> Helper loaded: file_helper
INFO - 2025-12-26 04:18:43 --> Helper loaded: html_helper
INFO - 2025-12-26 04:18:43 --> Helper loaded: security_helper
INFO - 2025-12-26 04:18:43 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:18:43 --> Database Driver Class Initialized
INFO - 2025-12-26 04:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:18:43 --> Form Validation Class Initialized
INFO - 2025-12-26 04:18:43 --> Controller Class Initialized
INFO - 2025-12-26 04:18:43 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:18:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:18:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:18:43 --> Final output sent to browser
DEBUG - 2025-12-26 04:18:43 --> Total execution time: 0.0531
INFO - 2025-12-26 04:20:23 --> Config Class Initialized
INFO - 2025-12-26 04:20:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:23 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:23 --> URI Class Initialized
INFO - 2025-12-26 04:20:23 --> Router Class Initialized
INFO - 2025-12-26 04:20:23 --> Output Class Initialized
INFO - 2025-12-26 04:20:23 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:23 --> CSRF cookie sent
INFO - 2025-12-26 04:20:23 --> CSRF token verified
INFO - 2025-12-26 04:20:23 --> Input Class Initialized
INFO - 2025-12-26 04:20:23 --> Language Class Initialized
INFO - 2025-12-26 04:20:23 --> Loader Class Initialized
INFO - 2025-12-26 04:20:23 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:23 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:23 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:23 --> Controller Class Initialized
INFO - 2025-12-26 04:20:23 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:20:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:20:23 --> Config Class Initialized
INFO - 2025-12-26 04:20:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:23 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:23 --> URI Class Initialized
INFO - 2025-12-26 04:20:23 --> Router Class Initialized
INFO - 2025-12-26 04:20:23 --> Output Class Initialized
INFO - 2025-12-26 04:20:23 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:23 --> CSRF cookie sent
INFO - 2025-12-26 04:20:23 --> Input Class Initialized
INFO - 2025-12-26 04:20:23 --> Language Class Initialized
INFO - 2025-12-26 04:20:23 --> Loader Class Initialized
INFO - 2025-12-26 04:20:23 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:23 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:23 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:23 --> Controller Class Initialized
INFO - 2025-12-26 04:20:23 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:20:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:20:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:23 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:23 --> Total execution time: 0.0573
INFO - 2025-12-26 04:20:29 --> Config Class Initialized
INFO - 2025-12-26 04:20:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:29 --> URI Class Initialized
INFO - 2025-12-26 04:20:29 --> Router Class Initialized
INFO - 2025-12-26 04:20:29 --> Output Class Initialized
INFO - 2025-12-26 04:20:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:29 --> CSRF cookie sent
INFO - 2025-12-26 04:20:29 --> Input Class Initialized
INFO - 2025-12-26 04:20:29 --> Language Class Initialized
INFO - 2025-12-26 04:20:29 --> Loader Class Initialized
INFO - 2025-12-26 04:20:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:29 --> Controller Class Initialized
INFO - 2025-12-26 04:20:29 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:20:29 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:20:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:29 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:29 --> Total execution time: 0.0533
INFO - 2025-12-26 04:20:39 --> Config Class Initialized
INFO - 2025-12-26 04:20:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:39 --> URI Class Initialized
INFO - 2025-12-26 04:20:39 --> Router Class Initialized
INFO - 2025-12-26 04:20:39 --> Output Class Initialized
INFO - 2025-12-26 04:20:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:39 --> CSRF cookie sent
INFO - 2025-12-26 04:20:39 --> Input Class Initialized
INFO - 2025-12-26 04:20:39 --> Language Class Initialized
INFO - 2025-12-26 04:20:39 --> Loader Class Initialized
INFO - 2025-12-26 04:20:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:39 --> Controller Class Initialized
INFO - 2025-12-26 04:20:39 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:20:39 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:20:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-26 04:20:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:39 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:39 --> Total execution time: 0.0572
INFO - 2025-12-26 04:20:40 --> Config Class Initialized
INFO - 2025-12-26 04:20:40 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:40 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:40 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:40 --> URI Class Initialized
INFO - 2025-12-26 04:20:40 --> Router Class Initialized
INFO - 2025-12-26 04:20:40 --> Output Class Initialized
INFO - 2025-12-26 04:20:40 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:40 --> CSRF cookie sent
INFO - 2025-12-26 04:20:40 --> Input Class Initialized
INFO - 2025-12-26 04:20:40 --> Language Class Initialized
INFO - 2025-12-26 04:20:40 --> Loader Class Initialized
INFO - 2025-12-26 04:20:40 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:40 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:40 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:40 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:40 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:40 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:40 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:40 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:40 --> Controller Class Initialized
INFO - 2025-12-26 04:20:40 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:20:40 --> Model "Kategori_model" initialized
ERROR - 2025-12-26 04:20:40 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-26 04:20:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 04:20:43 --> Config Class Initialized
INFO - 2025-12-26 04:20:43 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:43 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:43 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:43 --> URI Class Initialized
INFO - 2025-12-26 04:20:43 --> Router Class Initialized
INFO - 2025-12-26 04:20:43 --> Output Class Initialized
INFO - 2025-12-26 04:20:43 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:43 --> CSRF cookie sent
INFO - 2025-12-26 04:20:43 --> Input Class Initialized
INFO - 2025-12-26 04:20:43 --> Language Class Initialized
INFO - 2025-12-26 04:20:43 --> Loader Class Initialized
INFO - 2025-12-26 04:20:43 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:43 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:43 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:43 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:43 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:43 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:43 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:43 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:43 --> Controller Class Initialized
INFO - 2025-12-26 04:20:43 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:20:43 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:20:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-26 04:20:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:43 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:43 --> Total execution time: 0.0650
INFO - 2025-12-26 04:20:45 --> Config Class Initialized
INFO - 2025-12-26 04:20:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:45 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:45 --> URI Class Initialized
INFO - 2025-12-26 04:20:45 --> Router Class Initialized
INFO - 2025-12-26 04:20:45 --> Output Class Initialized
INFO - 2025-12-26 04:20:45 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:45 --> CSRF cookie sent
INFO - 2025-12-26 04:20:45 --> Input Class Initialized
INFO - 2025-12-26 04:20:45 --> Language Class Initialized
INFO - 2025-12-26 04:20:45 --> Loader Class Initialized
INFO - 2025-12-26 04:20:45 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:45 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:45 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:45 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:45 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:45 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:45 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:45 --> Controller Class Initialized
INFO - 2025-12-26 04:20:45 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:20:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:20:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:45 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:45 --> Total execution time: 0.0722
INFO - 2025-12-26 04:20:47 --> Config Class Initialized
INFO - 2025-12-26 04:20:47 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:47 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:47 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:47 --> URI Class Initialized
INFO - 2025-12-26 04:20:47 --> Router Class Initialized
INFO - 2025-12-26 04:20:47 --> Output Class Initialized
INFO - 2025-12-26 04:20:47 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:47 --> CSRF cookie sent
INFO - 2025-12-26 04:20:47 --> Input Class Initialized
INFO - 2025-12-26 04:20:47 --> Language Class Initialized
INFO - 2025-12-26 04:20:47 --> Loader Class Initialized
INFO - 2025-12-26 04:20:47 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:47 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:47 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:47 --> Controller Class Initialized
INFO - 2025-12-26 04:20:47 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:20:47 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:20:47 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:20:47 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:20:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:47 --> Upload Class Initialized
INFO - 2025-12-26 04:20:47 --> Helper loaded: text_helper
INFO - 2025-12-26 04:20:47 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:20:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:20:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:47 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:47 --> Total execution time: 0.0621
INFO - 2025-12-26 04:20:50 --> Config Class Initialized
INFO - 2025-12-26 04:20:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:50 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:50 --> URI Class Initialized
INFO - 2025-12-26 04:20:50 --> Router Class Initialized
INFO - 2025-12-26 04:20:50 --> Output Class Initialized
INFO - 2025-12-26 04:20:50 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:50 --> CSRF cookie sent
INFO - 2025-12-26 04:20:50 --> Input Class Initialized
INFO - 2025-12-26 04:20:50 --> Language Class Initialized
INFO - 2025-12-26 04:20:50 --> Loader Class Initialized
INFO - 2025-12-26 04:20:50 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:50 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:50 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:50 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:50 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:50 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:50 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:50 --> Controller Class Initialized
INFO - 2025-12-26 04:20:50 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:20:50 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:20:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:20:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:20:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:20:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:20:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:20:50 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:50 --> Total execution time: 0.0736
INFO - 2025-12-26 04:20:55 --> Config Class Initialized
INFO - 2025-12-26 04:20:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:55 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:55 --> URI Class Initialized
INFO - 2025-12-26 04:20:55 --> Router Class Initialized
INFO - 2025-12-26 04:20:55 --> Output Class Initialized
INFO - 2025-12-26 04:20:55 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:55 --> CSRF cookie sent
INFO - 2025-12-26 04:20:55 --> Input Class Initialized
INFO - 2025-12-26 04:20:55 --> Language Class Initialized
INFO - 2025-12-26 04:20:55 --> Loader Class Initialized
INFO - 2025-12-26 04:20:55 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:55 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:55 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:55 --> Controller Class Initialized
INFO - 2025-12-26 04:20:55 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:20:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:55 --> Config Class Initialized
INFO - 2025-12-26 04:20:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:20:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:20:55 --> Utf8 Class Initialized
INFO - 2025-12-26 04:20:55 --> URI Class Initialized
INFO - 2025-12-26 04:20:55 --> Router Class Initialized
INFO - 2025-12-26 04:20:55 --> Output Class Initialized
INFO - 2025-12-26 04:20:55 --> Security Class Initialized
DEBUG - 2025-12-26 04:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:20:55 --> CSRF cookie sent
INFO - 2025-12-26 04:20:55 --> Input Class Initialized
INFO - 2025-12-26 04:20:55 --> Language Class Initialized
INFO - 2025-12-26 04:20:55 --> Loader Class Initialized
INFO - 2025-12-26 04:20:55 --> Helper loaded: url_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: form_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: file_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: html_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: security_helper
INFO - 2025-12-26 04:20:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:20:55 --> Database Driver Class Initialized
INFO - 2025-12-26 04:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:20:55 --> Form Validation Class Initialized
INFO - 2025-12-26 04:20:55 --> Controller Class Initialized
INFO - 2025-12-26 04:20:55 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:20:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:20:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:20:55 --> Final output sent to browser
DEBUG - 2025-12-26 04:20:55 --> Total execution time: 0.0518
INFO - 2025-12-26 04:21:03 --> Config Class Initialized
INFO - 2025-12-26 04:21:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:03 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:03 --> URI Class Initialized
INFO - 2025-12-26 04:21:03 --> Router Class Initialized
INFO - 2025-12-26 04:21:03 --> Output Class Initialized
INFO - 2025-12-26 04:21:03 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:03 --> CSRF cookie sent
INFO - 2025-12-26 04:21:03 --> CSRF token verified
INFO - 2025-12-26 04:21:03 --> Input Class Initialized
INFO - 2025-12-26 04:21:03 --> Language Class Initialized
INFO - 2025-12-26 04:21:03 --> Loader Class Initialized
INFO - 2025-12-26 04:21:03 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:03 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:03 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:03 --> Controller Class Initialized
INFO - 2025-12-26 04:21:03 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:21:03 --> Config Class Initialized
INFO - 2025-12-26 04:21:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:03 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:03 --> URI Class Initialized
INFO - 2025-12-26 04:21:03 --> Router Class Initialized
INFO - 2025-12-26 04:21:03 --> Output Class Initialized
INFO - 2025-12-26 04:21:03 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:03 --> CSRF cookie sent
INFO - 2025-12-26 04:21:03 --> Input Class Initialized
INFO - 2025-12-26 04:21:03 --> Language Class Initialized
INFO - 2025-12-26 04:21:03 --> Loader Class Initialized
INFO - 2025-12-26 04:21:03 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:03 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:03 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:03 --> Controller Class Initialized
INFO - 2025-12-26 04:21:03 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:21:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:21:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:03 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:03 --> Total execution time: 0.0527
INFO - 2025-12-26 04:21:10 --> Config Class Initialized
INFO - 2025-12-26 04:21:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:10 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:10 --> URI Class Initialized
INFO - 2025-12-26 04:21:10 --> Router Class Initialized
INFO - 2025-12-26 04:21:10 --> Output Class Initialized
INFO - 2025-12-26 04:21:10 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:10 --> CSRF cookie sent
INFO - 2025-12-26 04:21:10 --> Input Class Initialized
INFO - 2025-12-26 04:21:10 --> Language Class Initialized
INFO - 2025-12-26 04:21:10 --> Loader Class Initialized
INFO - 2025-12-26 04:21:10 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:10 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:10 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:10 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:10 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:10 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:10 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:10 --> Controller Class Initialized
INFO - 2025-12-26 04:21:10 --> Model "User_model" initialized
INFO - 2025-12-26 04:21:10 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:10 --> Upload Class Initialized
INFO - 2025-12-26 04:21:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:21:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:10 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:10 --> Total execution time: 0.0892
INFO - 2025-12-26 04:21:12 --> Config Class Initialized
INFO - 2025-12-26 04:21:12 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:12 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:12 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:12 --> URI Class Initialized
INFO - 2025-12-26 04:21:12 --> Router Class Initialized
INFO - 2025-12-26 04:21:12 --> Output Class Initialized
INFO - 2025-12-26 04:21:12 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:12 --> CSRF cookie sent
INFO - 2025-12-26 04:21:12 --> Input Class Initialized
INFO - 2025-12-26 04:21:12 --> Language Class Initialized
INFO - 2025-12-26 04:21:12 --> Loader Class Initialized
INFO - 2025-12-26 04:21:12 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:12 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:12 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:12 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:12 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:12 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:12 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:12 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:12 --> Controller Class Initialized
INFO - 2025-12-26 04:21:12 --> Model "User_model" initialized
INFO - 2025-12-26 04:21:12 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:12 --> Upload Class Initialized
INFO - 2025-12-26 04:21:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:21:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:12 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:12 --> Total execution time: 0.0614
INFO - 2025-12-26 04:21:22 --> Config Class Initialized
INFO - 2025-12-26 04:21:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:22 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:22 --> URI Class Initialized
INFO - 2025-12-26 04:21:22 --> Router Class Initialized
INFO - 2025-12-26 04:21:22 --> Output Class Initialized
INFO - 2025-12-26 04:21:22 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:22 --> CSRF cookie sent
INFO - 2025-12-26 04:21:22 --> CSRF token verified
INFO - 2025-12-26 04:21:22 --> Input Class Initialized
INFO - 2025-12-26 04:21:22 --> Language Class Initialized
INFO - 2025-12-26 04:21:22 --> Loader Class Initialized
INFO - 2025-12-26 04:21:22 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:22 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:22 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:22 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:22 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:22 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:22 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:22 --> Controller Class Initialized
INFO - 2025-12-26 04:21:22 --> Model "User_model" initialized
INFO - 2025-12-26 04:21:22 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:22 --> Upload Class Initialized
INFO - 2025-12-26 04:21:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-26 04:21:22 --> Severity: error --> Exception: Undefined constant "MD5" D:\xampp\htdocs\surat_itm\application\controllers\Users.php 109
INFO - 2025-12-26 04:21:27 --> Config Class Initialized
INFO - 2025-12-26 04:21:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:27 --> URI Class Initialized
INFO - 2025-12-26 04:21:27 --> Router Class Initialized
INFO - 2025-12-26 04:21:27 --> Output Class Initialized
INFO - 2025-12-26 04:21:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:27 --> CSRF cookie sent
INFO - 2025-12-26 04:21:27 --> Input Class Initialized
INFO - 2025-12-26 04:21:27 --> Language Class Initialized
INFO - 2025-12-26 04:21:27 --> Loader Class Initialized
INFO - 2025-12-26 04:21:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:27 --> Controller Class Initialized
INFO - 2025-12-26 04:21:27 --> Model "User_model" initialized
INFO - 2025-12-26 04:21:27 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:27 --> Upload Class Initialized
INFO - 2025-12-26 04:21:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:21:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:27 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:27 --> Total execution time: 0.0502
INFO - 2025-12-26 04:21:29 --> Config Class Initialized
INFO - 2025-12-26 04:21:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:29 --> URI Class Initialized
INFO - 2025-12-26 04:21:29 --> Router Class Initialized
INFO - 2025-12-26 04:21:29 --> Output Class Initialized
INFO - 2025-12-26 04:21:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:29 --> CSRF cookie sent
INFO - 2025-12-26 04:21:29 --> Input Class Initialized
INFO - 2025-12-26 04:21:29 --> Language Class Initialized
INFO - 2025-12-26 04:21:29 --> Loader Class Initialized
INFO - 2025-12-26 04:21:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:29 --> Controller Class Initialized
INFO - 2025-12-26 04:21:29 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 04:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 04:21:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:29 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:29 --> Total execution time: 0.0582
INFO - 2025-12-26 04:21:31 --> Config Class Initialized
INFO - 2025-12-26 04:21:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:31 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:31 --> URI Class Initialized
INFO - 2025-12-26 04:21:31 --> Router Class Initialized
INFO - 2025-12-26 04:21:32 --> Output Class Initialized
INFO - 2025-12-26 04:21:32 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:32 --> CSRF cookie sent
INFO - 2025-12-26 04:21:32 --> Input Class Initialized
INFO - 2025-12-26 04:21:32 --> Language Class Initialized
INFO - 2025-12-26 04:21:32 --> Loader Class Initialized
INFO - 2025-12-26 04:21:32 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:32 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:32 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:32 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:32 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:32 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:32 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:32 --> Controller Class Initialized
INFO - 2025-12-26 04:21:32 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 04:21:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:32 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:32 --> Total execution time: 0.0615
INFO - 2025-12-26 04:21:38 --> Config Class Initialized
INFO - 2025-12-26 04:21:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:38 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:38 --> URI Class Initialized
INFO - 2025-12-26 04:21:38 --> Router Class Initialized
INFO - 2025-12-26 04:21:38 --> Output Class Initialized
INFO - 2025-12-26 04:21:38 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:38 --> CSRF cookie sent
INFO - 2025-12-26 04:21:38 --> Input Class Initialized
INFO - 2025-12-26 04:21:38 --> Language Class Initialized
INFO - 2025-12-26 04:21:38 --> Loader Class Initialized
INFO - 2025-12-26 04:21:38 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:38 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:38 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:38 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:38 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:38 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:38 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:38 --> Controller Class Initialized
INFO - 2025-12-26 04:21:38 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/form.php
INFO - 2025-12-26 04:21:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:38 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:38 --> Total execution time: 0.0917
INFO - 2025-12-26 04:21:49 --> Config Class Initialized
INFO - 2025-12-26 04:21:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:49 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:49 --> URI Class Initialized
INFO - 2025-12-26 04:21:49 --> Router Class Initialized
INFO - 2025-12-26 04:21:49 --> Output Class Initialized
INFO - 2025-12-26 04:21:49 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:49 --> CSRF cookie sent
INFO - 2025-12-26 04:21:49 --> Input Class Initialized
INFO - 2025-12-26 04:21:49 --> Language Class Initialized
INFO - 2025-12-26 04:21:49 --> Loader Class Initialized
INFO - 2025-12-26 04:21:49 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:49 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:49 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:49 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:49 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:49 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:49 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:49 --> Controller Class Initialized
INFO - 2025-12-26 04:21:49 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 04:21:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:49 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:49 --> Total execution time: 0.0620
INFO - 2025-12-26 04:21:52 --> Config Class Initialized
INFO - 2025-12-26 04:21:52 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:52 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:52 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:52 --> URI Class Initialized
INFO - 2025-12-26 04:21:52 --> Router Class Initialized
INFO - 2025-12-26 04:21:52 --> Output Class Initialized
INFO - 2025-12-26 04:21:52 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:52 --> CSRF cookie sent
INFO - 2025-12-26 04:21:52 --> Input Class Initialized
INFO - 2025-12-26 04:21:52 --> Language Class Initialized
INFO - 2025-12-26 04:21:52 --> Loader Class Initialized
INFO - 2025-12-26 04:21:52 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:52 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:52 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:52 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:52 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:52 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:52 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:52 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:52 --> Controller Class Initialized
INFO - 2025-12-26 04:21:52 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:21:52 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:21:52 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:21:52 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:52 --> Upload Class Initialized
INFO - 2025-12-26 04:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:52 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:52 --> Total execution time: 0.0581
INFO - 2025-12-26 04:21:53 --> Config Class Initialized
INFO - 2025-12-26 04:21:53 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:53 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:53 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:53 --> URI Class Initialized
INFO - 2025-12-26 04:21:53 --> Router Class Initialized
INFO - 2025-12-26 04:21:53 --> Output Class Initialized
INFO - 2025-12-26 04:21:53 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:53 --> CSRF cookie sent
INFO - 2025-12-26 04:21:53 --> Input Class Initialized
INFO - 2025-12-26 04:21:53 --> Language Class Initialized
INFO - 2025-12-26 04:21:53 --> Loader Class Initialized
INFO - 2025-12-26 04:21:53 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:53 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:53 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:53 --> Controller Class Initialized
INFO - 2025-12-26 04:21:53 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:21:53 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:21:53 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:21:53 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:53 --> Upload Class Initialized
INFO - 2025-12-26 04:21:53 --> Helper loaded: text_helper
INFO - 2025-12-26 04:21:53 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:21:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:21:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:53 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:53 --> Total execution time: 0.0887
INFO - 2025-12-26 04:21:55 --> Config Class Initialized
INFO - 2025-12-26 04:21:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:55 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:55 --> URI Class Initialized
INFO - 2025-12-26 04:21:55 --> Router Class Initialized
INFO - 2025-12-26 04:21:55 --> Output Class Initialized
INFO - 2025-12-26 04:21:55 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:55 --> CSRF cookie sent
INFO - 2025-12-26 04:21:55 --> Input Class Initialized
INFO - 2025-12-26 04:21:55 --> Language Class Initialized
INFO - 2025-12-26 04:21:55 --> Loader Class Initialized
INFO - 2025-12-26 04:21:55 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:55 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:55 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:55 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:55 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:55 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:55 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:55 --> Controller Class Initialized
INFO - 2025-12-26 04:21:55 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:21:55 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:21:55 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:21:55 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:21:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:55 --> Upload Class Initialized
INFO - 2025-12-26 04:21:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:21:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:55 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:55 --> Total execution time: 0.0624
INFO - 2025-12-26 04:21:56 --> Config Class Initialized
INFO - 2025-12-26 04:21:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:56 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:56 --> URI Class Initialized
INFO - 2025-12-26 04:21:56 --> Router Class Initialized
INFO - 2025-12-26 04:21:56 --> Output Class Initialized
INFO - 2025-12-26 04:21:56 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:56 --> CSRF cookie sent
INFO - 2025-12-26 04:21:56 --> Input Class Initialized
INFO - 2025-12-26 04:21:56 --> Language Class Initialized
INFO - 2025-12-26 04:21:56 --> Loader Class Initialized
INFO - 2025-12-26 04:21:56 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:56 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:56 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:56 --> Controller Class Initialized
INFO - 2025-12-26 04:21:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:21:56 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:21:56 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:21:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:21:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:21:56 --> Upload Class Initialized
INFO - 2025-12-26 04:21:56 --> Helper loaded: text_helper
INFO - 2025-12-26 04:21:56 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:21:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:21:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:56 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:56 --> Total execution time: 0.0805
INFO - 2025-12-26 04:21:57 --> Config Class Initialized
INFO - 2025-12-26 04:21:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:21:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:21:57 --> Utf8 Class Initialized
INFO - 2025-12-26 04:21:57 --> URI Class Initialized
INFO - 2025-12-26 04:21:57 --> Router Class Initialized
INFO - 2025-12-26 04:21:57 --> Output Class Initialized
INFO - 2025-12-26 04:21:57 --> Security Class Initialized
DEBUG - 2025-12-26 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:21:57 --> CSRF cookie sent
INFO - 2025-12-26 04:21:57 --> Input Class Initialized
INFO - 2025-12-26 04:21:57 --> Language Class Initialized
INFO - 2025-12-26 04:21:57 --> Loader Class Initialized
INFO - 2025-12-26 04:21:57 --> Helper loaded: url_helper
INFO - 2025-12-26 04:21:57 --> Helper loaded: form_helper
INFO - 2025-12-26 04:21:57 --> Helper loaded: file_helper
INFO - 2025-12-26 04:21:57 --> Helper loaded: html_helper
INFO - 2025-12-26 04:21:57 --> Helper loaded: security_helper
INFO - 2025-12-26 04:21:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:21:57 --> Database Driver Class Initialized
INFO - 2025-12-26 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:21:57 --> Form Validation Class Initialized
INFO - 2025-12-26 04:21:57 --> Controller Class Initialized
INFO - 2025-12-26 04:21:57 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:21:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:21:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:21:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:21:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:21:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:21:57 --> Final output sent to browser
DEBUG - 2025-12-26 04:21:57 --> Total execution time: 0.0758
INFO - 2025-12-26 04:22:02 --> Config Class Initialized
INFO - 2025-12-26 04:22:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:22:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:22:02 --> Utf8 Class Initialized
INFO - 2025-12-26 04:22:02 --> URI Class Initialized
INFO - 2025-12-26 04:22:02 --> Router Class Initialized
INFO - 2025-12-26 04:22:02 --> Output Class Initialized
INFO - 2025-12-26 04:22:02 --> Security Class Initialized
DEBUG - 2025-12-26 04:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:22:02 --> CSRF cookie sent
INFO - 2025-12-26 04:22:02 --> Input Class Initialized
INFO - 2025-12-26 04:22:02 --> Language Class Initialized
INFO - 2025-12-26 04:22:02 --> Loader Class Initialized
INFO - 2025-12-26 04:22:02 --> Helper loaded: url_helper
INFO - 2025-12-26 04:22:02 --> Helper loaded: form_helper
INFO - 2025-12-26 04:22:02 --> Helper loaded: file_helper
INFO - 2025-12-26 04:22:02 --> Helper loaded: html_helper
INFO - 2025-12-26 04:22:02 --> Helper loaded: security_helper
INFO - 2025-12-26 04:22:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:22:02 --> Database Driver Class Initialized
INFO - 2025-12-26 04:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:22:02 --> Form Validation Class Initialized
INFO - 2025-12-26 04:22:02 --> Controller Class Initialized
INFO - 2025-12-26 04:22:02 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:22:02 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:22:02 --> Final output sent to browser
DEBUG - 2025-12-26 04:22:02 --> Total execution time: 0.0504
INFO - 2025-12-26 04:24:24 --> Config Class Initialized
INFO - 2025-12-26 04:24:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:24 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:24 --> URI Class Initialized
INFO - 2025-12-26 04:24:24 --> Router Class Initialized
INFO - 2025-12-26 04:24:25 --> Output Class Initialized
INFO - 2025-12-26 04:24:25 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:25 --> CSRF cookie sent
INFO - 2025-12-26 04:24:25 --> Input Class Initialized
INFO - 2025-12-26 04:24:25 --> Language Class Initialized
INFO - 2025-12-26 04:24:25 --> Config Class Initialized
INFO - 2025-12-26 04:24:25 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:25 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:25 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:25 --> URI Class Initialized
INFO - 2025-12-26 04:24:25 --> Router Class Initialized
INFO - 2025-12-26 04:24:25 --> Output Class Initialized
INFO - 2025-12-26 04:24:25 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:25 --> CSRF cookie sent
INFO - 2025-12-26 04:24:25 --> Input Class Initialized
INFO - 2025-12-26 04:24:25 --> Language Class Initialized
INFO - 2025-12-26 04:24:25 --> Loader Class Initialized
INFO - 2025-12-26 04:24:25 --> Loader Class Initialized
INFO - 2025-12-26 04:24:25 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:25 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:26 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:26 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:26 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:26 --> Controller Class Initialized
INFO - 2025-12-26 04:24:26 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:26 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:27 --> Config Class Initialized
INFO - 2025-12-26 04:24:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:27 --> URI Class Initialized
INFO - 2025-12-26 04:24:27 --> Router Class Initialized
INFO - 2025-12-26 04:24:27 --> Output Class Initialized
INFO - 2025-12-26 04:24:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:27 --> CSRF cookie sent
INFO - 2025-12-26 04:24:27 --> Input Class Initialized
INFO - 2025-12-26 04:24:27 --> Language Class Initialized
INFO - 2025-12-26 04:24:27 --> Loader Class Initialized
INFO - 2025-12-26 04:24:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:27 --> Upload Class Initialized
INFO - 2025-12-26 04:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:24:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:28 --> Total execution time: 3.8802
INFO - 2025-12-26 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:28 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:28 --> Controller Class Initialized
INFO - 2025-12-26 04:24:28 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:28 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:28 --> Upload Class Initialized
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:24:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:28 --> Total execution time: 2.5519
INFO - 2025-12-26 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:28 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:28 --> Controller Class Initialized
INFO - 2025-12-26 04:24:28 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:28 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:28 --> Upload Class Initialized
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:24:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:24:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:28 --> Total execution time: 0.8021
INFO - 2025-12-26 04:24:30 --> Config Class Initialized
INFO - 2025-12-26 04:24:30 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:30 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:30 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:30 --> URI Class Initialized
INFO - 2025-12-26 04:24:30 --> Router Class Initialized
INFO - 2025-12-26 04:24:30 --> Output Class Initialized
INFO - 2025-12-26 04:24:30 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:30 --> CSRF cookie sent
INFO - 2025-12-26 04:24:30 --> Input Class Initialized
INFO - 2025-12-26 04:24:30 --> Language Class Initialized
INFO - 2025-12-26 04:24:30 --> Loader Class Initialized
INFO - 2025-12-26 04:24:30 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:30 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:30 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:30 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:30 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:30 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:30 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:30 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:30 --> Controller Class Initialized
INFO - 2025-12-26 04:24:30 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:30 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:30 --> Upload Class Initialized
INFO - 2025-12-26 04:24:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:24:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:24:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:24:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:24:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:24:30 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:30 --> Total execution time: 0.3750
INFO - 2025-12-26 04:24:39 --> Config Class Initialized
INFO - 2025-12-26 04:24:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:39 --> URI Class Initialized
INFO - 2025-12-26 04:24:39 --> Router Class Initialized
INFO - 2025-12-26 04:24:39 --> Output Class Initialized
INFO - 2025-12-26 04:24:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:39 --> CSRF cookie sent
INFO - 2025-12-26 04:24:39 --> CSRF token verified
INFO - 2025-12-26 04:24:39 --> Input Class Initialized
INFO - 2025-12-26 04:24:39 --> Language Class Initialized
INFO - 2025-12-26 04:24:39 --> Loader Class Initialized
INFO - 2025-12-26 04:24:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:39 --> Controller Class Initialized
INFO - 2025-12-26 04:24:39 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:39 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:39 --> Upload Class Initialized
INFO - 2025-12-26 04:24:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:24:39 --> Config Class Initialized
INFO - 2025-12-26 04:24:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:39 --> URI Class Initialized
INFO - 2025-12-26 04:24:39 --> Router Class Initialized
INFO - 2025-12-26 04:24:39 --> Output Class Initialized
INFO - 2025-12-26 04:24:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:39 --> CSRF cookie sent
INFO - 2025-12-26 04:24:39 --> Input Class Initialized
INFO - 2025-12-26 04:24:39 --> Language Class Initialized
INFO - 2025-12-26 04:24:39 --> Loader Class Initialized
INFO - 2025-12-26 04:24:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:39 --> Controller Class Initialized
INFO - 2025-12-26 04:24:39 --> Model "User_model" initialized
INFO - 2025-12-26 04:24:39 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:39 --> Upload Class Initialized
INFO - 2025-12-26 04:24:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:24:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:24:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:24:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:24:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:24:39 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:39 --> Total execution time: 0.0606
INFO - 2025-12-26 04:24:46 --> Config Class Initialized
INFO - 2025-12-26 04:24:46 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:46 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:46 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:46 --> URI Class Initialized
INFO - 2025-12-26 04:24:46 --> Router Class Initialized
INFO - 2025-12-26 04:24:46 --> Output Class Initialized
INFO - 2025-12-26 04:24:46 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:46 --> CSRF cookie sent
INFO - 2025-12-26 04:24:46 --> Input Class Initialized
INFO - 2025-12-26 04:24:46 --> Language Class Initialized
INFO - 2025-12-26 04:24:46 --> Loader Class Initialized
INFO - 2025-12-26 04:24:46 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:46 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:46 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:46 --> Controller Class Initialized
INFO - 2025-12-26 04:24:46 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:46 --> Config Class Initialized
INFO - 2025-12-26 04:24:46 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:46 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:46 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:46 --> URI Class Initialized
INFO - 2025-12-26 04:24:46 --> Router Class Initialized
INFO - 2025-12-26 04:24:46 --> Output Class Initialized
INFO - 2025-12-26 04:24:46 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:46 --> CSRF cookie sent
INFO - 2025-12-26 04:24:46 --> Input Class Initialized
INFO - 2025-12-26 04:24:46 --> Language Class Initialized
INFO - 2025-12-26 04:24:46 --> Loader Class Initialized
INFO - 2025-12-26 04:24:46 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:46 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:46 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:46 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:46 --> Controller Class Initialized
INFO - 2025-12-26 04:24:46 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:24:46 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:46 --> Total execution time: 0.1512
INFO - 2025-12-26 04:24:56 --> Config Class Initialized
INFO - 2025-12-26 04:24:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:24:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:24:56 --> Utf8 Class Initialized
INFO - 2025-12-26 04:24:56 --> URI Class Initialized
INFO - 2025-12-26 04:24:56 --> Router Class Initialized
INFO - 2025-12-26 04:24:56 --> Output Class Initialized
INFO - 2025-12-26 04:24:56 --> Security Class Initialized
DEBUG - 2025-12-26 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:24:56 --> CSRF cookie sent
INFO - 2025-12-26 04:24:56 --> CSRF token verified
INFO - 2025-12-26 04:24:56 --> Input Class Initialized
INFO - 2025-12-26 04:24:56 --> Language Class Initialized
INFO - 2025-12-26 04:24:56 --> Loader Class Initialized
INFO - 2025-12-26 04:24:56 --> Helper loaded: url_helper
INFO - 2025-12-26 04:24:56 --> Helper loaded: form_helper
INFO - 2025-12-26 04:24:56 --> Helper loaded: file_helper
INFO - 2025-12-26 04:24:56 --> Helper loaded: html_helper
INFO - 2025-12-26 04:24:56 --> Helper loaded: security_helper
INFO - 2025-12-26 04:24:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:24:56 --> Database Driver Class Initialized
INFO - 2025-12-26 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:24:56 --> Form Validation Class Initialized
INFO - 2025-12-26 04:24:56 --> Controller Class Initialized
INFO - 2025-12-26 04:24:56 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:24:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:24:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:24:56 --> Final output sent to browser
DEBUG - 2025-12-26 04:24:56 --> Total execution time: 0.0565
INFO - 2025-12-26 04:26:18 --> Config Class Initialized
INFO - 2025-12-26 04:26:18 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:18 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:18 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:18 --> URI Class Initialized
INFO - 2025-12-26 04:26:18 --> Router Class Initialized
INFO - 2025-12-26 04:26:18 --> Output Class Initialized
INFO - 2025-12-26 04:26:18 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:18 --> CSRF cookie sent
INFO - 2025-12-26 04:26:18 --> CSRF token verified
INFO - 2025-12-26 04:26:18 --> Input Class Initialized
INFO - 2025-12-26 04:26:18 --> Language Class Initialized
INFO - 2025-12-26 04:26:18 --> Loader Class Initialized
INFO - 2025-12-26 04:26:18 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:18 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:18 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:18 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:18 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:18 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:18 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:18 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:18 --> Controller Class Initialized
INFO - 2025-12-26 04:26:18 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:26:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:26:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:26:18 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:18 --> Total execution time: 0.0588
INFO - 2025-12-26 04:26:31 --> Config Class Initialized
INFO - 2025-12-26 04:26:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:31 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:31 --> URI Class Initialized
INFO - 2025-12-26 04:26:31 --> Router Class Initialized
INFO - 2025-12-26 04:26:31 --> Output Class Initialized
INFO - 2025-12-26 04:26:31 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:31 --> CSRF cookie sent
INFO - 2025-12-26 04:26:31 --> CSRF token verified
INFO - 2025-12-26 04:26:31 --> Input Class Initialized
INFO - 2025-12-26 04:26:31 --> Language Class Initialized
INFO - 2025-12-26 04:26:31 --> Loader Class Initialized
INFO - 2025-12-26 04:26:31 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:31 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:31 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:31 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:31 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:31 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:31 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:31 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:31 --> Controller Class Initialized
INFO - 2025-12-26 04:26:31 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:26:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:26:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:26:31 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:31 --> Total execution time: 0.0709
INFO - 2025-12-26 04:26:39 --> Config Class Initialized
INFO - 2025-12-26 04:26:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:39 --> URI Class Initialized
INFO - 2025-12-26 04:26:39 --> Router Class Initialized
INFO - 2025-12-26 04:26:39 --> Output Class Initialized
INFO - 2025-12-26 04:26:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:39 --> CSRF cookie sent
INFO - 2025-12-26 04:26:39 --> CSRF token verified
INFO - 2025-12-26 04:26:39 --> Input Class Initialized
INFO - 2025-12-26 04:26:39 --> Language Class Initialized
INFO - 2025-12-26 04:26:39 --> Loader Class Initialized
INFO - 2025-12-26 04:26:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:39 --> Controller Class Initialized
INFO - 2025-12-26 04:26:39 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:26:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:26:39 --> Config Class Initialized
INFO - 2025-12-26 04:26:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:39 --> URI Class Initialized
INFO - 2025-12-26 04:26:39 --> Router Class Initialized
INFO - 2025-12-26 04:26:39 --> Output Class Initialized
INFO - 2025-12-26 04:26:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:39 --> CSRF cookie sent
INFO - 2025-12-26 04:26:39 --> Input Class Initialized
INFO - 2025-12-26 04:26:39 --> Language Class Initialized
INFO - 2025-12-26 04:26:39 --> Loader Class Initialized
INFO - 2025-12-26 04:26:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:39 --> Controller Class Initialized
INFO - 2025-12-26 04:26:39 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:26:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:26:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:26:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:26:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:26:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:26:39 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:39 --> Total execution time: 0.2286
INFO - 2025-12-26 04:26:45 --> Config Class Initialized
INFO - 2025-12-26 04:26:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:45 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:45 --> URI Class Initialized
INFO - 2025-12-26 04:26:45 --> Router Class Initialized
INFO - 2025-12-26 04:26:45 --> Output Class Initialized
INFO - 2025-12-26 04:26:45 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:45 --> CSRF cookie sent
INFO - 2025-12-26 04:26:45 --> Input Class Initialized
INFO - 2025-12-26 04:26:45 --> Language Class Initialized
INFO - 2025-12-26 04:26:45 --> Loader Class Initialized
INFO - 2025-12-26 04:26:45 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:45 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:45 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:45 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:45 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:45 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:45 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:45 --> Controller Class Initialized
INFO - 2025-12-26 04:26:45 --> Model "User_model" initialized
INFO - 2025-12-26 04:26:45 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:26:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:45 --> Upload Class Initialized
INFO - 2025-12-26 04:26:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:26:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:26:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:26:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:26:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:26:45 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:45 --> Total execution time: 0.0573
INFO - 2025-12-26 04:26:51 --> Config Class Initialized
INFO - 2025-12-26 04:26:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:51 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:51 --> URI Class Initialized
INFO - 2025-12-26 04:26:51 --> Router Class Initialized
INFO - 2025-12-26 04:26:51 --> Output Class Initialized
INFO - 2025-12-26 04:26:51 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:51 --> CSRF cookie sent
INFO - 2025-12-26 04:26:51 --> Input Class Initialized
INFO - 2025-12-26 04:26:51 --> Language Class Initialized
INFO - 2025-12-26 04:26:51 --> Loader Class Initialized
INFO - 2025-12-26 04:26:51 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:51 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:51 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:51 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:51 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:51 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:51 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:51 --> Controller Class Initialized
INFO - 2025-12-26 04:26:51 --> Model "User_model" initialized
INFO - 2025-12-26 04:26:51 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:26:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:51 --> Upload Class Initialized
INFO - 2025-12-26 04:26:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:26:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:26:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:26:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:26:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:26:51 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:51 --> Total execution time: 0.0620
INFO - 2025-12-26 04:26:53 --> Config Class Initialized
INFO - 2025-12-26 04:26:53 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:53 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:53 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:53 --> URI Class Initialized
INFO - 2025-12-26 04:26:53 --> Router Class Initialized
INFO - 2025-12-26 04:26:53 --> Output Class Initialized
INFO - 2025-12-26 04:26:53 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:53 --> CSRF cookie sent
INFO - 2025-12-26 04:26:53 --> Input Class Initialized
INFO - 2025-12-26 04:26:53 --> Language Class Initialized
INFO - 2025-12-26 04:26:53 --> Loader Class Initialized
INFO - 2025-12-26 04:26:53 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:53 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:53 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:53 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:53 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:53 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:53 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:53 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:53 --> Controller Class Initialized
INFO - 2025-12-26 04:26:53 --> Model "User_model" initialized
INFO - 2025-12-26 04:26:53 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:26:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:53 --> Upload Class Initialized
INFO - 2025-12-26 04:26:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:26:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:26:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:26:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:26:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:26:53 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:53 --> Total execution time: 0.0628
INFO - 2025-12-26 04:26:55 --> Config Class Initialized
INFO - 2025-12-26 04:26:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:26:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:26:55 --> Utf8 Class Initialized
INFO - 2025-12-26 04:26:55 --> URI Class Initialized
INFO - 2025-12-26 04:26:55 --> Router Class Initialized
INFO - 2025-12-26 04:26:55 --> Output Class Initialized
INFO - 2025-12-26 04:26:55 --> Security Class Initialized
DEBUG - 2025-12-26 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:26:55 --> CSRF cookie sent
INFO - 2025-12-26 04:26:55 --> Input Class Initialized
INFO - 2025-12-26 04:26:55 --> Language Class Initialized
INFO - 2025-12-26 04:26:55 --> Loader Class Initialized
INFO - 2025-12-26 04:26:55 --> Helper loaded: url_helper
INFO - 2025-12-26 04:26:55 --> Helper loaded: form_helper
INFO - 2025-12-26 04:26:55 --> Helper loaded: file_helper
INFO - 2025-12-26 04:26:55 --> Helper loaded: html_helper
INFO - 2025-12-26 04:26:55 --> Helper loaded: security_helper
INFO - 2025-12-26 04:26:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:26:55 --> Database Driver Class Initialized
INFO - 2025-12-26 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:26:55 --> Form Validation Class Initialized
INFO - 2025-12-26 04:26:55 --> Controller Class Initialized
INFO - 2025-12-26 04:26:55 --> Model "User_model" initialized
INFO - 2025-12-26 04:26:55 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:26:55 --> Upload Class Initialized
INFO - 2025-12-26 04:26:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:26:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:26:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:26:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 04:26:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:26:55 --> Final output sent to browser
DEBUG - 2025-12-26 04:26:55 --> Total execution time: 0.0636
INFO - 2025-12-26 04:27:05 --> Config Class Initialized
INFO - 2025-12-26 04:27:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:05 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:05 --> URI Class Initialized
INFO - 2025-12-26 04:27:05 --> Router Class Initialized
INFO - 2025-12-26 04:27:05 --> Output Class Initialized
INFO - 2025-12-26 04:27:05 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:05 --> CSRF cookie sent
INFO - 2025-12-26 04:27:05 --> CSRF token verified
INFO - 2025-12-26 04:27:05 --> Input Class Initialized
INFO - 2025-12-26 04:27:05 --> Language Class Initialized
INFO - 2025-12-26 04:27:05 --> Loader Class Initialized
INFO - 2025-12-26 04:27:05 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:05 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:05 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:05 --> Controller Class Initialized
INFO - 2025-12-26 04:27:05 --> Model "User_model" initialized
INFO - 2025-12-26 04:27:05 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:27:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:05 --> Upload Class Initialized
INFO - 2025-12-26 04:27:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:27:05 --> Config Class Initialized
INFO - 2025-12-26 04:27:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:05 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:05 --> URI Class Initialized
INFO - 2025-12-26 04:27:05 --> Router Class Initialized
INFO - 2025-12-26 04:27:05 --> Output Class Initialized
INFO - 2025-12-26 04:27:05 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:05 --> CSRF cookie sent
INFO - 2025-12-26 04:27:05 --> Input Class Initialized
INFO - 2025-12-26 04:27:05 --> Language Class Initialized
INFO - 2025-12-26 04:27:05 --> Loader Class Initialized
INFO - 2025-12-26 04:27:05 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:05 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:05 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:05 --> Controller Class Initialized
INFO - 2025-12-26 04:27:05 --> Model "User_model" initialized
INFO - 2025-12-26 04:27:05 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 04:27:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:05 --> Upload Class Initialized
INFO - 2025-12-26 04:27:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 04:27:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:05 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:05 --> Total execution time: 0.0599
INFO - 2025-12-26 04:27:14 --> Config Class Initialized
INFO - 2025-12-26 04:27:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:14 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:14 --> URI Class Initialized
INFO - 2025-12-26 04:27:14 --> Router Class Initialized
INFO - 2025-12-26 04:27:14 --> Output Class Initialized
INFO - 2025-12-26 04:27:14 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:14 --> CSRF cookie sent
INFO - 2025-12-26 04:27:14 --> Input Class Initialized
INFO - 2025-12-26 04:27:14 --> Language Class Initialized
INFO - 2025-12-26 04:27:14 --> Loader Class Initialized
INFO - 2025-12-26 04:27:14 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:14 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:14 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:14 --> Controller Class Initialized
INFO - 2025-12-26 04:27:14 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:14 --> Config Class Initialized
INFO - 2025-12-26 04:27:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:14 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:14 --> URI Class Initialized
INFO - 2025-12-26 04:27:14 --> Router Class Initialized
INFO - 2025-12-26 04:27:14 --> Output Class Initialized
INFO - 2025-12-26 04:27:14 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:14 --> CSRF cookie sent
INFO - 2025-12-26 04:27:14 --> Input Class Initialized
INFO - 2025-12-26 04:27:14 --> Language Class Initialized
INFO - 2025-12-26 04:27:14 --> Loader Class Initialized
INFO - 2025-12-26 04:27:14 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:14 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:14 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:14 --> Controller Class Initialized
INFO - 2025-12-26 04:27:14 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 04:27:14 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:14 --> Total execution time: 0.0520
INFO - 2025-12-26 04:27:22 --> Config Class Initialized
INFO - 2025-12-26 04:27:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:22 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:22 --> URI Class Initialized
INFO - 2025-12-26 04:27:22 --> Router Class Initialized
INFO - 2025-12-26 04:27:22 --> Output Class Initialized
INFO - 2025-12-26 04:27:22 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:22 --> CSRF cookie sent
INFO - 2025-12-26 04:27:22 --> CSRF token verified
INFO - 2025-12-26 04:27:22 --> Input Class Initialized
INFO - 2025-12-26 04:27:22 --> Language Class Initialized
INFO - 2025-12-26 04:27:22 --> Loader Class Initialized
INFO - 2025-12-26 04:27:22 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:22 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:22 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:22 --> Controller Class Initialized
INFO - 2025-12-26 04:27:22 --> Model "User_model" initialized
DEBUG - 2025-12-26 04:27:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 04:27:22 --> Config Class Initialized
INFO - 2025-12-26 04:27:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:22 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:22 --> URI Class Initialized
INFO - 2025-12-26 04:27:22 --> Router Class Initialized
INFO - 2025-12-26 04:27:22 --> Output Class Initialized
INFO - 2025-12-26 04:27:22 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:22 --> CSRF cookie sent
INFO - 2025-12-26 04:27:22 --> Input Class Initialized
INFO - 2025-12-26 04:27:22 --> Language Class Initialized
INFO - 2025-12-26 04:27:22 --> Loader Class Initialized
INFO - 2025-12-26 04:27:22 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:22 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:22 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:22 --> Controller Class Initialized
INFO - 2025-12-26 04:27:22 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:27:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:27:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:22 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:22 --> Total execution time: 0.0577
INFO - 2025-12-26 04:27:25 --> Config Class Initialized
INFO - 2025-12-26 04:27:25 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:25 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:25 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:25 --> URI Class Initialized
INFO - 2025-12-26 04:27:25 --> Router Class Initialized
INFO - 2025-12-26 04:27:25 --> Output Class Initialized
INFO - 2025-12-26 04:27:25 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:25 --> CSRF cookie sent
INFO - 2025-12-26 04:27:25 --> Input Class Initialized
INFO - 2025-12-26 04:27:25 --> Language Class Initialized
INFO - 2025-12-26 04:27:25 --> Loader Class Initialized
INFO - 2025-12-26 04:27:25 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:25 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:25 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:25 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:25 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:25 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:25 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:25 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:25 --> Controller Class Initialized
INFO - 2025-12-26 04:27:25 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:27:25 --> Model "Kategori_model" initialized
ERROR - 2025-12-26 04:27:25 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-26 04:27:25 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 04:27:27 --> Config Class Initialized
INFO - 2025-12-26 04:27:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:27 --> URI Class Initialized
INFO - 2025-12-26 04:27:27 --> Router Class Initialized
INFO - 2025-12-26 04:27:27 --> Output Class Initialized
INFO - 2025-12-26 04:27:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:27 --> CSRF cookie sent
INFO - 2025-12-26 04:27:27 --> Input Class Initialized
INFO - 2025-12-26 04:27:27 --> Language Class Initialized
INFO - 2025-12-26 04:27:27 --> Loader Class Initialized
INFO - 2025-12-26 04:27:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:27 --> Controller Class Initialized
INFO - 2025-12-26 04:27:27 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:27 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:27 --> Total execution time: 0.0639
INFO - 2025-12-26 04:27:28 --> Config Class Initialized
INFO - 2025-12-26 04:27:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:28 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:28 --> URI Class Initialized
INFO - 2025-12-26 04:27:28 --> Router Class Initialized
INFO - 2025-12-26 04:27:28 --> Output Class Initialized
INFO - 2025-12-26 04:27:28 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:28 --> CSRF cookie sent
INFO - 2025-12-26 04:27:28 --> Input Class Initialized
INFO - 2025-12-26 04:27:28 --> Language Class Initialized
INFO - 2025-12-26 04:27:28 --> Loader Class Initialized
INFO - 2025-12-26 04:27:28 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:28 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:28 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:28 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:28 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:28 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:28 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:28 --> Controller Class Initialized
INFO - 2025-12-26 04:27:28 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:27:28 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-26 04:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:28 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:28 --> Total execution time: 0.1575
INFO - 2025-12-26 04:27:35 --> Config Class Initialized
INFO - 2025-12-26 04:27:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:35 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:35 --> URI Class Initialized
INFO - 2025-12-26 04:27:35 --> Router Class Initialized
INFO - 2025-12-26 04:27:35 --> Output Class Initialized
INFO - 2025-12-26 04:27:35 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:35 --> CSRF cookie sent
INFO - 2025-12-26 04:27:35 --> Input Class Initialized
INFO - 2025-12-26 04:27:35 --> Language Class Initialized
INFO - 2025-12-26 04:27:35 --> Loader Class Initialized
INFO - 2025-12-26 04:27:35 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:35 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:35 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:35 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:35 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:35 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:35 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:35 --> Controller Class Initialized
INFO - 2025-12-26 04:27:35 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:35 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:35 --> Total execution time: 0.0563
INFO - 2025-12-26 04:27:39 --> Config Class Initialized
INFO - 2025-12-26 04:27:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:39 --> URI Class Initialized
INFO - 2025-12-26 04:27:39 --> Router Class Initialized
INFO - 2025-12-26 04:27:39 --> Output Class Initialized
INFO - 2025-12-26 04:27:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:39 --> CSRF cookie sent
INFO - 2025-12-26 04:27:39 --> Input Class Initialized
INFO - 2025-12-26 04:27:39 --> Language Class Initialized
INFO - 2025-12-26 04:27:39 --> Loader Class Initialized
INFO - 2025-12-26 04:27:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:39 --> Controller Class Initialized
INFO - 2025-12-26 04:27:39 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:27:39 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:39 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:39 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:27:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:39 --> Upload Class Initialized
INFO - 2025-12-26 04:27:39 --> Helper loaded: text_helper
INFO - 2025-12-26 04:27:39 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:39 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:39 --> Total execution time: 0.3949
INFO - 2025-12-26 04:27:42 --> Config Class Initialized
INFO - 2025-12-26 04:27:42 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:42 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:42 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:42 --> URI Class Initialized
INFO - 2025-12-26 04:27:42 --> Router Class Initialized
INFO - 2025-12-26 04:27:42 --> Output Class Initialized
INFO - 2025-12-26 04:27:42 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:42 --> CSRF cookie sent
INFO - 2025-12-26 04:27:42 --> Input Class Initialized
INFO - 2025-12-26 04:27:42 --> Language Class Initialized
INFO - 2025-12-26 04:27:42 --> Loader Class Initialized
INFO - 2025-12-26 04:27:42 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:42 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:42 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:42 --> Controller Class Initialized
INFO - 2025-12-26 04:27:42 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:27:42 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:42 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:42 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:42 --> Upload Class Initialized
INFO - 2025-12-26 04:27:42 --> Helper loaded: text_helper
INFO - 2025-12-26 04:27:42 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:27:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 04:27:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:42 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:42 --> Total execution time: 0.3344
INFO - 2025-12-26 04:27:45 --> Config Class Initialized
INFO - 2025-12-26 04:27:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:45 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:45 --> URI Class Initialized
INFO - 2025-12-26 04:27:45 --> Router Class Initialized
INFO - 2025-12-26 04:27:45 --> Output Class Initialized
INFO - 2025-12-26 04:27:45 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:45 --> CSRF cookie sent
INFO - 2025-12-26 04:27:45 --> Input Class Initialized
INFO - 2025-12-26 04:27:45 --> Language Class Initialized
INFO - 2025-12-26 04:27:46 --> Loader Class Initialized
INFO - 2025-12-26 04:27:46 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:46 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:46 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:46 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:46 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:46 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:46 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:46 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:46 --> Controller Class Initialized
INFO - 2025-12-26 04:27:46 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:27:46 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:46 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:46 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:46 --> Upload Class Initialized
INFO - 2025-12-26 04:27:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:27:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:46 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:46 --> Total execution time: 0.3744
INFO - 2025-12-26 04:27:48 --> Config Class Initialized
INFO - 2025-12-26 04:27:48 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:48 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:48 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:48 --> URI Class Initialized
INFO - 2025-12-26 04:27:48 --> Router Class Initialized
INFO - 2025-12-26 04:27:48 --> Output Class Initialized
INFO - 2025-12-26 04:27:48 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:48 --> CSRF cookie sent
INFO - 2025-12-26 04:27:48 --> Input Class Initialized
INFO - 2025-12-26 04:27:48 --> Language Class Initialized
INFO - 2025-12-26 04:27:48 --> Loader Class Initialized
INFO - 2025-12-26 04:27:48 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:48 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:48 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:48 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:48 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:48 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:48 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:48 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:48 --> Controller Class Initialized
INFO - 2025-12-26 04:27:48 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:27:48 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:48 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:48 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:48 --> Upload Class Initialized
INFO - 2025-12-26 04:27:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 04:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:49 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:49 --> Total execution time: 0.3490
INFO - 2025-12-26 04:27:51 --> Config Class Initialized
INFO - 2025-12-26 04:27:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:51 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:51 --> URI Class Initialized
INFO - 2025-12-26 04:27:51 --> Router Class Initialized
INFO - 2025-12-26 04:27:51 --> Output Class Initialized
INFO - 2025-12-26 04:27:51 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:51 --> CSRF cookie sent
INFO - 2025-12-26 04:27:51 --> Input Class Initialized
INFO - 2025-12-26 04:27:51 --> Language Class Initialized
INFO - 2025-12-26 04:27:51 --> Loader Class Initialized
INFO - 2025-12-26 04:27:51 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:51 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:51 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:51 --> Controller Class Initialized
INFO - 2025-12-26 04:27:51 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:27:51 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:51 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:51 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:51 --> Upload Class Initialized
INFO - 2025-12-26 04:27:51 --> Helper loaded: text_helper
INFO - 2025-12-26 04:27:51 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:27:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:27:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:51 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:51 --> Total execution time: 0.0632
INFO - 2025-12-26 04:27:53 --> Config Class Initialized
INFO - 2025-12-26 04:27:53 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:27:53 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:27:53 --> Utf8 Class Initialized
INFO - 2025-12-26 04:27:53 --> URI Class Initialized
INFO - 2025-12-26 04:27:53 --> Router Class Initialized
INFO - 2025-12-26 04:27:53 --> Output Class Initialized
INFO - 2025-12-26 04:27:53 --> Security Class Initialized
DEBUG - 2025-12-26 04:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:27:53 --> CSRF cookie sent
INFO - 2025-12-26 04:27:53 --> Input Class Initialized
INFO - 2025-12-26 04:27:53 --> Language Class Initialized
INFO - 2025-12-26 04:27:53 --> Loader Class Initialized
INFO - 2025-12-26 04:27:53 --> Helper loaded: url_helper
INFO - 2025-12-26 04:27:53 --> Helper loaded: form_helper
INFO - 2025-12-26 04:27:53 --> Helper loaded: file_helper
INFO - 2025-12-26 04:27:53 --> Helper loaded: html_helper
INFO - 2025-12-26 04:27:53 --> Helper loaded: security_helper
INFO - 2025-12-26 04:27:53 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:27:53 --> Database Driver Class Initialized
INFO - 2025-12-26 04:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:27:53 --> Form Validation Class Initialized
INFO - 2025-12-26 04:27:53 --> Controller Class Initialized
INFO - 2025-12-26 04:27:53 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:27:53 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:27:53 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:27:53 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:27:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:27:53 --> Upload Class Initialized
INFO - 2025-12-26 04:27:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:27:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:27:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:27:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:27:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:27:53 --> Final output sent to browser
DEBUG - 2025-12-26 04:27:53 --> Total execution time: 0.0805
INFO - 2025-12-26 04:28:02 --> Config Class Initialized
INFO - 2025-12-26 04:28:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:28:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:28:02 --> Utf8 Class Initialized
INFO - 2025-12-26 04:28:02 --> URI Class Initialized
INFO - 2025-12-26 04:28:02 --> Router Class Initialized
INFO - 2025-12-26 04:28:02 --> Output Class Initialized
INFO - 2025-12-26 04:28:02 --> Security Class Initialized
DEBUG - 2025-12-26 04:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:28:02 --> CSRF cookie sent
INFO - 2025-12-26 04:28:02 --> Input Class Initialized
INFO - 2025-12-26 04:28:02 --> Language Class Initialized
INFO - 2025-12-26 04:28:02 --> Loader Class Initialized
INFO - 2025-12-26 04:28:02 --> Helper loaded: url_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: form_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: file_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: html_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: security_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:28:02 --> Database Driver Class Initialized
INFO - 2025-12-26 04:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:28:02 --> Form Validation Class Initialized
INFO - 2025-12-26 04:28:02 --> Controller Class Initialized
INFO - 2025-12-26 04:28:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:28:02 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:28:02 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:28:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:28:02 --> Upload Class Initialized
INFO - 2025-12-26 04:28:02 --> Helper loaded: text_helper
INFO - 2025-12-26 04:28:02 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:28:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:28:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:28:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:28:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:28:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:28:02 --> Final output sent to browser
DEBUG - 2025-12-26 04:28:02 --> Total execution time: 0.0771
INFO - 2025-12-26 04:28:05 --> Config Class Initialized
INFO - 2025-12-26 04:28:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:28:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:28:05 --> Utf8 Class Initialized
INFO - 2025-12-26 04:28:05 --> URI Class Initialized
INFO - 2025-12-26 04:28:05 --> Router Class Initialized
INFO - 2025-12-26 04:28:05 --> Output Class Initialized
INFO - 2025-12-26 04:28:05 --> Security Class Initialized
DEBUG - 2025-12-26 04:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:28:05 --> CSRF cookie sent
INFO - 2025-12-26 04:28:05 --> Input Class Initialized
INFO - 2025-12-26 04:28:05 --> Language Class Initialized
INFO - 2025-12-26 04:28:05 --> Loader Class Initialized
INFO - 2025-12-26 04:28:05 --> Helper loaded: url_helper
INFO - 2025-12-26 04:28:05 --> Helper loaded: form_helper
INFO - 2025-12-26 04:28:05 --> Helper loaded: file_helper
INFO - 2025-12-26 04:28:05 --> Helper loaded: html_helper
INFO - 2025-12-26 04:28:05 --> Helper loaded: security_helper
INFO - 2025-12-26 04:28:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:28:05 --> Database Driver Class Initialized
INFO - 2025-12-26 04:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:28:05 --> Form Validation Class Initialized
INFO - 2025-12-26 04:28:05 --> Controller Class Initialized
INFO - 2025-12-26 04:28:05 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:28:05 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:28:05 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:28:05 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:28:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:28:05 --> Upload Class Initialized
INFO - 2025-12-26 04:28:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:28:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:28:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:28:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:28:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:28:05 --> Final output sent to browser
DEBUG - 2025-12-26 04:28:05 --> Total execution time: 0.0550
INFO - 2025-12-26 04:29:36 --> Config Class Initialized
INFO - 2025-12-26 04:29:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:29:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:29:36 --> Utf8 Class Initialized
INFO - 2025-12-26 04:29:36 --> URI Class Initialized
INFO - 2025-12-26 04:29:36 --> Router Class Initialized
INFO - 2025-12-26 04:29:36 --> Output Class Initialized
INFO - 2025-12-26 04:29:36 --> Security Class Initialized
DEBUG - 2025-12-26 04:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:29:36 --> CSRF cookie sent
INFO - 2025-12-26 04:29:36 --> Input Class Initialized
INFO - 2025-12-26 04:29:36 --> Language Class Initialized
INFO - 2025-12-26 04:29:36 --> Loader Class Initialized
INFO - 2025-12-26 04:29:36 --> Helper loaded: url_helper
INFO - 2025-12-26 04:29:36 --> Helper loaded: form_helper
INFO - 2025-12-26 04:29:36 --> Helper loaded: file_helper
INFO - 2025-12-26 04:29:36 --> Helper loaded: html_helper
INFO - 2025-12-26 04:29:36 --> Helper loaded: security_helper
INFO - 2025-12-26 04:29:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:29:36 --> Database Driver Class Initialized
INFO - 2025-12-26 04:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:29:36 --> Form Validation Class Initialized
INFO - 2025-12-26 04:29:36 --> Controller Class Initialized
INFO - 2025-12-26 04:29:36 --> Model "User_model" initialized
INFO - 2025-12-26 04:29:36 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:29:36 --> Upload Class Initialized
INFO - 2025-12-26 04:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 04:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:29:36 --> Final output sent to browser
DEBUG - 2025-12-26 04:29:36 --> Total execution time: 0.1897
INFO - 2025-12-26 04:29:53 --> Config Class Initialized
INFO - 2025-12-26 04:29:53 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:29:53 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:29:53 --> Utf8 Class Initialized
INFO - 2025-12-26 04:29:53 --> URI Class Initialized
INFO - 2025-12-26 04:29:53 --> Router Class Initialized
INFO - 2025-12-26 04:29:53 --> Output Class Initialized
INFO - 2025-12-26 04:29:53 --> Security Class Initialized
DEBUG - 2025-12-26 04:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:29:53 --> CSRF cookie sent
INFO - 2025-12-26 04:29:53 --> CSRF token verified
INFO - 2025-12-26 04:29:53 --> Input Class Initialized
INFO - 2025-12-26 04:29:53 --> Language Class Initialized
INFO - 2025-12-26 04:29:53 --> Loader Class Initialized
INFO - 2025-12-26 04:29:53 --> Helper loaded: url_helper
INFO - 2025-12-26 04:29:53 --> Helper loaded: form_helper
INFO - 2025-12-26 04:29:53 --> Helper loaded: file_helper
INFO - 2025-12-26 04:29:53 --> Helper loaded: html_helper
INFO - 2025-12-26 04:29:53 --> Helper loaded: security_helper
INFO - 2025-12-26 04:29:53 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:29:53 --> Database Driver Class Initialized
INFO - 2025-12-26 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:29:54 --> Form Validation Class Initialized
INFO - 2025-12-26 04:29:54 --> Controller Class Initialized
INFO - 2025-12-26 04:29:54 --> Model "User_model" initialized
INFO - 2025-12-26 04:29:54 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:29:54 --> Upload Class Initialized
INFO - 2025-12-26 04:29:54 --> Config Class Initialized
INFO - 2025-12-26 04:29:54 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:29:54 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:29:54 --> Utf8 Class Initialized
INFO - 2025-12-26 04:29:54 --> URI Class Initialized
INFO - 2025-12-26 04:29:54 --> Router Class Initialized
INFO - 2025-12-26 04:29:54 --> Output Class Initialized
INFO - 2025-12-26 04:29:54 --> Security Class Initialized
DEBUG - 2025-12-26 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:29:54 --> CSRF cookie sent
INFO - 2025-12-26 04:29:54 --> Input Class Initialized
INFO - 2025-12-26 04:29:54 --> Language Class Initialized
INFO - 2025-12-26 04:29:54 --> Loader Class Initialized
INFO - 2025-12-26 04:29:54 --> Helper loaded: url_helper
INFO - 2025-12-26 04:29:54 --> Helper loaded: form_helper
INFO - 2025-12-26 04:29:54 --> Helper loaded: file_helper
INFO - 2025-12-26 04:29:54 --> Helper loaded: html_helper
INFO - 2025-12-26 04:29:54 --> Helper loaded: security_helper
INFO - 2025-12-26 04:29:54 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:29:54 --> Database Driver Class Initialized
INFO - 2025-12-26 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:29:54 --> Form Validation Class Initialized
INFO - 2025-12-26 04:29:54 --> Controller Class Initialized
INFO - 2025-12-26 04:29:54 --> Model "User_model" initialized
INFO - 2025-12-26 04:29:54 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:29:54 --> Upload Class Initialized
INFO - 2025-12-26 04:29:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:29:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:29:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:29:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 04:29:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:29:54 --> Final output sent to browser
DEBUG - 2025-12-26 04:29:54 --> Total execution time: 0.0965
INFO - 2025-12-26 04:29:57 --> Config Class Initialized
INFO - 2025-12-26 04:29:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:29:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:29:57 --> Utf8 Class Initialized
INFO - 2025-12-26 04:29:57 --> URI Class Initialized
INFO - 2025-12-26 04:29:57 --> Router Class Initialized
INFO - 2025-12-26 04:29:57 --> Output Class Initialized
INFO - 2025-12-26 04:29:57 --> Security Class Initialized
DEBUG - 2025-12-26 04:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:29:57 --> CSRF cookie sent
INFO - 2025-12-26 04:29:57 --> Input Class Initialized
INFO - 2025-12-26 04:29:57 --> Language Class Initialized
INFO - 2025-12-26 04:29:57 --> Loader Class Initialized
INFO - 2025-12-26 04:29:57 --> Helper loaded: url_helper
INFO - 2025-12-26 04:29:57 --> Helper loaded: form_helper
INFO - 2025-12-26 04:29:57 --> Helper loaded: file_helper
INFO - 2025-12-26 04:29:57 --> Helper loaded: html_helper
INFO - 2025-12-26 04:29:57 --> Helper loaded: security_helper
INFO - 2025-12-26 04:29:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:29:57 --> Database Driver Class Initialized
INFO - 2025-12-26 04:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:29:57 --> Form Validation Class Initialized
INFO - 2025-12-26 04:29:57 --> Controller Class Initialized
INFO - 2025-12-26 04:29:57 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:29:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:29:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:29:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:29:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:29:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:29:57 --> Final output sent to browser
DEBUG - 2025-12-26 04:29:57 --> Total execution time: 0.0554
INFO - 2025-12-26 04:30:00 --> Config Class Initialized
INFO - 2025-12-26 04:30:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:30:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:30:00 --> Utf8 Class Initialized
INFO - 2025-12-26 04:30:00 --> URI Class Initialized
INFO - 2025-12-26 04:30:00 --> Router Class Initialized
INFO - 2025-12-26 04:30:00 --> Output Class Initialized
INFO - 2025-12-26 04:30:00 --> Security Class Initialized
DEBUG - 2025-12-26 04:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:30:00 --> CSRF cookie sent
INFO - 2025-12-26 04:30:00 --> Input Class Initialized
INFO - 2025-12-26 04:30:00 --> Language Class Initialized
INFO - 2025-12-26 04:30:00 --> Loader Class Initialized
INFO - 2025-12-26 04:30:00 --> Helper loaded: url_helper
INFO - 2025-12-26 04:30:00 --> Helper loaded: form_helper
INFO - 2025-12-26 04:30:00 --> Helper loaded: file_helper
INFO - 2025-12-26 04:30:00 --> Helper loaded: html_helper
INFO - 2025-12-26 04:30:00 --> Helper loaded: security_helper
INFO - 2025-12-26 04:30:00 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:30:00 --> Database Driver Class Initialized
INFO - 2025-12-26 04:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:30:00 --> Form Validation Class Initialized
INFO - 2025-12-26 04:30:00 --> Controller Class Initialized
INFO - 2025-12-26 04:30:00 --> Model "User_model" initialized
INFO - 2025-12-26 04:30:00 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:30:00 --> Upload Class Initialized
INFO - 2025-12-26 04:30:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:30:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:30:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:30:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 04:30:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:30:00 --> Final output sent to browser
DEBUG - 2025-12-26 04:30:00 --> Total execution time: 0.0913
INFO - 2025-12-26 04:30:05 --> Config Class Initialized
INFO - 2025-12-26 04:30:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:30:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:30:05 --> Utf8 Class Initialized
INFO - 2025-12-26 04:30:05 --> URI Class Initialized
INFO - 2025-12-26 04:30:05 --> Router Class Initialized
INFO - 2025-12-26 04:30:05 --> Output Class Initialized
INFO - 2025-12-26 04:30:05 --> Security Class Initialized
DEBUG - 2025-12-26 04:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:30:05 --> CSRF cookie sent
INFO - 2025-12-26 04:30:05 --> Input Class Initialized
INFO - 2025-12-26 04:30:05 --> Language Class Initialized
INFO - 2025-12-26 04:30:05 --> Loader Class Initialized
INFO - 2025-12-26 04:30:05 --> Helper loaded: url_helper
INFO - 2025-12-26 04:30:05 --> Helper loaded: form_helper
INFO - 2025-12-26 04:30:05 --> Helper loaded: file_helper
INFO - 2025-12-26 04:30:05 --> Helper loaded: html_helper
INFO - 2025-12-26 04:30:05 --> Helper loaded: security_helper
INFO - 2025-12-26 04:30:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:30:05 --> Database Driver Class Initialized
INFO - 2025-12-26 04:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:30:05 --> Form Validation Class Initialized
INFO - 2025-12-26 04:30:05 --> Controller Class Initialized
INFO - 2025-12-26 04:30:05 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:30:05 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:30:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:30:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:30:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:30:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:30:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:30:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:30:05 --> Final output sent to browser
DEBUG - 2025-12-26 04:30:05 --> Total execution time: 0.1036
INFO - 2025-12-26 04:30:06 --> Config Class Initialized
INFO - 2025-12-26 04:30:06 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:30:06 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:30:06 --> Utf8 Class Initialized
INFO - 2025-12-26 04:30:06 --> URI Class Initialized
INFO - 2025-12-26 04:30:06 --> Router Class Initialized
INFO - 2025-12-26 04:30:06 --> Output Class Initialized
INFO - 2025-12-26 04:30:06 --> Security Class Initialized
DEBUG - 2025-12-26 04:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:30:06 --> CSRF cookie sent
INFO - 2025-12-26 04:30:06 --> Input Class Initialized
INFO - 2025-12-26 04:30:06 --> Language Class Initialized
INFO - 2025-12-26 04:30:06 --> Loader Class Initialized
INFO - 2025-12-26 04:30:06 --> Helper loaded: url_helper
INFO - 2025-12-26 04:30:06 --> Helper loaded: form_helper
INFO - 2025-12-26 04:30:06 --> Helper loaded: file_helper
INFO - 2025-12-26 04:30:06 --> Helper loaded: html_helper
INFO - 2025-12-26 04:30:06 --> Helper loaded: security_helper
INFO - 2025-12-26 04:30:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:30:06 --> Database Driver Class Initialized
INFO - 2025-12-26 04:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:30:06 --> Form Validation Class Initialized
INFO - 2025-12-26 04:30:06 --> Controller Class Initialized
INFO - 2025-12-26 04:30:06 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:30:06 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:30:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:30:06 --> Final output sent to browser
DEBUG - 2025-12-26 04:30:06 --> Total execution time: 0.0549
INFO - 2025-12-26 04:30:07 --> Config Class Initialized
INFO - 2025-12-26 04:30:07 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:30:07 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:30:07 --> Utf8 Class Initialized
INFO - 2025-12-26 04:30:07 --> URI Class Initialized
INFO - 2025-12-26 04:30:07 --> Router Class Initialized
INFO - 2025-12-26 04:30:07 --> Output Class Initialized
INFO - 2025-12-26 04:30:07 --> Security Class Initialized
DEBUG - 2025-12-26 04:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:30:07 --> CSRF cookie sent
INFO - 2025-12-26 04:30:07 --> Input Class Initialized
INFO - 2025-12-26 04:30:07 --> Language Class Initialized
INFO - 2025-12-26 04:30:07 --> Loader Class Initialized
INFO - 2025-12-26 04:30:07 --> Helper loaded: url_helper
INFO - 2025-12-26 04:30:07 --> Helper loaded: form_helper
INFO - 2025-12-26 04:30:07 --> Helper loaded: file_helper
INFO - 2025-12-26 04:30:07 --> Helper loaded: html_helper
INFO - 2025-12-26 04:30:07 --> Helper loaded: security_helper
INFO - 2025-12-26 04:30:07 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:30:07 --> Database Driver Class Initialized
INFO - 2025-12-26 04:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:30:07 --> Form Validation Class Initialized
INFO - 2025-12-26 04:30:07 --> Controller Class Initialized
INFO - 2025-12-26 04:30:07 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:30:07 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:30:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:30:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:30:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:30:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-26 04:30:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:30:07 --> Final output sent to browser
DEBUG - 2025-12-26 04:30:07 --> Total execution time: 0.0644
INFO - 2025-12-26 04:30:08 --> Config Class Initialized
INFO - 2025-12-26 04:30:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:30:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:30:08 --> Utf8 Class Initialized
INFO - 2025-12-26 04:30:08 --> URI Class Initialized
INFO - 2025-12-26 04:30:08 --> Router Class Initialized
INFO - 2025-12-26 04:30:08 --> Output Class Initialized
INFO - 2025-12-26 04:30:08 --> Security Class Initialized
DEBUG - 2025-12-26 04:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:30:08 --> CSRF cookie sent
INFO - 2025-12-26 04:30:08 --> Input Class Initialized
INFO - 2025-12-26 04:30:08 --> Language Class Initialized
INFO - 2025-12-26 04:30:08 --> Loader Class Initialized
INFO - 2025-12-26 04:30:08 --> Helper loaded: url_helper
INFO - 2025-12-26 04:30:08 --> Helper loaded: form_helper
INFO - 2025-12-26 04:30:08 --> Helper loaded: file_helper
INFO - 2025-12-26 04:30:08 --> Helper loaded: html_helper
INFO - 2025-12-26 04:30:08 --> Helper loaded: security_helper
INFO - 2025-12-26 04:30:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:30:08 --> Database Driver Class Initialized
INFO - 2025-12-26 04:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:30:08 --> Form Validation Class Initialized
INFO - 2025-12-26 04:30:08 --> Controller Class Initialized
INFO - 2025-12-26 04:30:08 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:30:08 --> Model "Kategori_model" initialized
ERROR - 2025-12-26 04:30:08 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-26 04:30:08 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 04:33:34 --> Config Class Initialized
INFO - 2025-12-26 04:33:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:33:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:33:34 --> Utf8 Class Initialized
INFO - 2025-12-26 04:33:34 --> URI Class Initialized
INFO - 2025-12-26 04:33:34 --> Router Class Initialized
INFO - 2025-12-26 04:33:34 --> Output Class Initialized
INFO - 2025-12-26 04:33:34 --> Security Class Initialized
DEBUG - 2025-12-26 04:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:33:34 --> CSRF cookie sent
INFO - 2025-12-26 04:33:34 --> Input Class Initialized
INFO - 2025-12-26 04:33:34 --> Language Class Initialized
INFO - 2025-12-26 04:33:34 --> Loader Class Initialized
INFO - 2025-12-26 04:33:34 --> Helper loaded: url_helper
INFO - 2025-12-26 04:33:34 --> Helper loaded: form_helper
INFO - 2025-12-26 04:33:34 --> Helper loaded: file_helper
INFO - 2025-12-26 04:33:34 --> Helper loaded: html_helper
INFO - 2025-12-26 04:33:34 --> Helper loaded: security_helper
INFO - 2025-12-26 04:33:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:33:34 --> Database Driver Class Initialized
INFO - 2025-12-26 04:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:33:34 --> Form Validation Class Initialized
INFO - 2025-12-26 04:33:34 --> Controller Class Initialized
INFO - 2025-12-26 04:33:34 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:33:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:33:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:33:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:33:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:33:34 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 123
INFO - 2025-12-26 04:33:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_keluar.php
INFO - 2025-12-26 04:33:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:33:34 --> Final output sent to browser
DEBUG - 2025-12-26 04:33:34 --> Total execution time: 0.2665
INFO - 2025-12-26 04:37:04 --> Config Class Initialized
INFO - 2025-12-26 04:37:04 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:37:04 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:37:04 --> Utf8 Class Initialized
INFO - 2025-12-26 04:37:04 --> URI Class Initialized
INFO - 2025-12-26 04:37:04 --> Router Class Initialized
INFO - 2025-12-26 04:37:04 --> Output Class Initialized
INFO - 2025-12-26 04:37:04 --> Security Class Initialized
DEBUG - 2025-12-26 04:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:37:04 --> CSRF cookie sent
INFO - 2025-12-26 04:37:04 --> Input Class Initialized
INFO - 2025-12-26 04:37:04 --> Language Class Initialized
INFO - 2025-12-26 04:37:04 --> Loader Class Initialized
INFO - 2025-12-26 04:37:04 --> Helper loaded: url_helper
INFO - 2025-12-26 04:37:04 --> Helper loaded: form_helper
INFO - 2025-12-26 04:37:04 --> Helper loaded: file_helper
INFO - 2025-12-26 04:37:04 --> Helper loaded: html_helper
INFO - 2025-12-26 04:37:04 --> Helper loaded: security_helper
INFO - 2025-12-26 04:37:04 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:37:04 --> Database Driver Class Initialized
INFO - 2025-12-26 04:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:37:04 --> Form Validation Class Initialized
INFO - 2025-12-26 04:37:04 --> Controller Class Initialized
INFO - 2025-12-26 04:37:04 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:37:04 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:37:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:37:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:37:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 62
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 63
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 64
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 65
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 77
ERROR - 2025-12-26 04:37:04 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 81
INFO - 2025-12-26 04:37:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_keluar.php
INFO - 2025-12-26 04:37:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:37:04 --> Final output sent to browser
DEBUG - 2025-12-26 04:37:04 --> Total execution time: 0.2002
INFO - 2025-12-26 04:37:24 --> Config Class Initialized
INFO - 2025-12-26 04:37:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:37:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:37:24 --> Utf8 Class Initialized
INFO - 2025-12-26 04:37:27 --> Config Class Initialized
INFO - 2025-12-26 04:37:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:37:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:37:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:37:27 --> URI Class Initialized
INFO - 2025-12-26 04:37:27 --> Router Class Initialized
INFO - 2025-12-26 04:37:27 --> Output Class Initialized
INFO - 2025-12-26 04:37:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:37:27 --> CSRF cookie sent
INFO - 2025-12-26 04:37:27 --> Input Class Initialized
INFO - 2025-12-26 04:37:27 --> Language Class Initialized
INFO - 2025-12-26 04:37:27 --> Loader Class Initialized
INFO - 2025-12-26 04:37:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:37:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:37:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:37:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:37:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:37:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:37:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:37:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:37:27 --> Controller Class Initialized
INFO - 2025-12-26 04:37:27 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:37:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:37:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:37:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:37:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 62
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 63
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 64
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 65
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 77
ERROR - 2025-12-26 04:37:27 --> Severity: Warning --> Undefined variable $status_pengesahan D:\xampp\htdocs\surat_itm\application\views\laporan\surat_keluar.php 81
INFO - 2025-12-26 04:37:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_keluar.php
INFO - 2025-12-26 04:37:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:37:27 --> Final output sent to browser
DEBUG - 2025-12-26 04:37:27 --> Total execution time: 0.0609
INFO - 2025-12-26 04:39:26 --> Config Class Initialized
INFO - 2025-12-26 04:39:26 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:39:26 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:39:26 --> Utf8 Class Initialized
INFO - 2025-12-26 04:39:26 --> URI Class Initialized
INFO - 2025-12-26 04:39:26 --> Router Class Initialized
INFO - 2025-12-26 04:39:26 --> Output Class Initialized
INFO - 2025-12-26 04:39:26 --> Security Class Initialized
DEBUG - 2025-12-26 04:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:39:26 --> CSRF cookie sent
INFO - 2025-12-26 04:39:26 --> Input Class Initialized
INFO - 2025-12-26 04:39:26 --> Language Class Initialized
INFO - 2025-12-26 04:39:26 --> Loader Class Initialized
INFO - 2025-12-26 04:39:26 --> Helper loaded: url_helper
INFO - 2025-12-26 04:39:26 --> Helper loaded: form_helper
INFO - 2025-12-26 04:39:26 --> Helper loaded: file_helper
INFO - 2025-12-26 04:39:26 --> Helper loaded: html_helper
INFO - 2025-12-26 04:39:26 --> Helper loaded: security_helper
INFO - 2025-12-26 04:39:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:39:26 --> Database Driver Class Initialized
INFO - 2025-12-26 04:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:39:26 --> Form Validation Class Initialized
INFO - 2025-12-26 04:39:26 --> Controller Class Initialized
INFO - 2025-12-26 04:39:26 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:39:26 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:39:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:39:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:39:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:39:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_keluar.php
INFO - 2025-12-26 04:39:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:39:26 --> Final output sent to browser
DEBUG - 2025-12-26 04:39:26 --> Total execution time: 0.1118
INFO - 2025-12-26 04:39:29 --> Config Class Initialized
INFO - 2025-12-26 04:39:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:39:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:39:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:39:29 --> URI Class Initialized
INFO - 2025-12-26 04:39:29 --> Router Class Initialized
INFO - 2025-12-26 04:39:29 --> Output Class Initialized
INFO - 2025-12-26 04:39:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:39:29 --> CSRF cookie sent
INFO - 2025-12-26 04:39:29 --> Input Class Initialized
INFO - 2025-12-26 04:39:29 --> Language Class Initialized
INFO - 2025-12-26 04:39:29 --> Loader Class Initialized
INFO - 2025-12-26 04:39:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:39:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:39:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:39:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:39:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:39:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:39:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:39:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:39:29 --> Controller Class Initialized
INFO - 2025-12-26 04:39:29 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:39:29 --> Model "Kategori_model" initialized
ERROR - 2025-12-26 04:39:29 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\laporan\print_keluar.php 117
INFO - 2025-12-26 04:39:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_keluar.php
INFO - 2025-12-26 04:39:29 --> Final output sent to browser
DEBUG - 2025-12-26 04:39:29 --> Total execution time: 0.1361
INFO - 2025-12-26 04:39:29 --> Config Class Initialized
INFO - 2025-12-26 04:39:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:39:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:39:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:39:29 --> URI Class Initialized
INFO - 2025-12-26 04:39:29 --> Router Class Initialized
INFO - 2025-12-26 04:39:29 --> Output Class Initialized
INFO - 2025-12-26 04:39:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:39:29 --> CSRF cookie sent
INFO - 2025-12-26 04:39:29 --> Input Class Initialized
INFO - 2025-12-26 04:39:29 --> Language Class Initialized
ERROR - 2025-12-26 04:39:29 --> 404 Page Not Found: Assets/img
INFO - 2025-12-26 04:41:12 --> Config Class Initialized
INFO - 2025-12-26 04:41:12 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:41:12 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:41:12 --> Utf8 Class Initialized
INFO - 2025-12-26 04:41:12 --> URI Class Initialized
INFO - 2025-12-26 04:41:12 --> Router Class Initialized
INFO - 2025-12-26 04:41:12 --> Output Class Initialized
INFO - 2025-12-26 04:41:12 --> Security Class Initialized
DEBUG - 2025-12-26 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:41:12 --> CSRF cookie sent
INFO - 2025-12-26 04:41:12 --> Input Class Initialized
INFO - 2025-12-26 04:41:12 --> Language Class Initialized
INFO - 2025-12-26 04:41:12 --> Loader Class Initialized
INFO - 2025-12-26 04:41:12 --> Helper loaded: url_helper
INFO - 2025-12-26 04:41:12 --> Helper loaded: form_helper
INFO - 2025-12-26 04:41:12 --> Helper loaded: file_helper
INFO - 2025-12-26 04:41:12 --> Helper loaded: html_helper
INFO - 2025-12-26 04:41:12 --> Helper loaded: security_helper
INFO - 2025-12-26 04:41:12 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:41:12 --> Database Driver Class Initialized
INFO - 2025-12-26 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:41:12 --> Form Validation Class Initialized
INFO - 2025-12-26 04:41:12 --> Controller Class Initialized
INFO - 2025-12-26 04:41:12 --> Model "Laporan_model" initialized
INFO - 2025-12-26 04:41:12 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:41:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_keluar.php
INFO - 2025-12-26 04:41:12 --> Final output sent to browser
DEBUG - 2025-12-26 04:41:12 --> Total execution time: 0.1005
INFO - 2025-12-26 04:41:26 --> Config Class Initialized
INFO - 2025-12-26 04:41:26 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:41:26 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:41:26 --> Utf8 Class Initialized
INFO - 2025-12-26 04:41:26 --> URI Class Initialized
INFO - 2025-12-26 04:41:26 --> Router Class Initialized
INFO - 2025-12-26 04:41:26 --> Output Class Initialized
INFO - 2025-12-26 04:41:26 --> Security Class Initialized
DEBUG - 2025-12-26 04:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:41:26 --> CSRF cookie sent
INFO - 2025-12-26 04:41:26 --> Input Class Initialized
INFO - 2025-12-26 04:41:26 --> Language Class Initialized
INFO - 2025-12-26 04:41:26 --> Loader Class Initialized
INFO - 2025-12-26 04:41:26 --> Helper loaded: url_helper
INFO - 2025-12-26 04:41:26 --> Helper loaded: form_helper
INFO - 2025-12-26 04:41:26 --> Helper loaded: file_helper
INFO - 2025-12-26 04:41:26 --> Helper loaded: html_helper
INFO - 2025-12-26 04:41:26 --> Helper loaded: security_helper
INFO - 2025-12-26 04:41:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:41:26 --> Database Driver Class Initialized
INFO - 2025-12-26 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:41:26 --> Form Validation Class Initialized
INFO - 2025-12-26 04:41:26 --> Controller Class Initialized
INFO - 2025-12-26 04:41:26 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:41:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:41:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:41:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:41:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:41:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:41:26 --> Final output sent to browser
DEBUG - 2025-12-26 04:41:26 --> Total execution time: 0.0743
INFO - 2025-12-26 04:41:29 --> Config Class Initialized
INFO - 2025-12-26 04:41:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:41:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:41:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:41:29 --> URI Class Initialized
INFO - 2025-12-26 04:41:29 --> Router Class Initialized
INFO - 2025-12-26 04:41:29 --> Output Class Initialized
INFO - 2025-12-26 04:41:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:41:29 --> CSRF cookie sent
INFO - 2025-12-26 04:41:29 --> Input Class Initialized
INFO - 2025-12-26 04:41:29 --> Language Class Initialized
INFO - 2025-12-26 04:41:29 --> Loader Class Initialized
INFO - 2025-12-26 04:41:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:41:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:41:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:41:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:41:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:41:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:41:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:41:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:41:29 --> Controller Class Initialized
INFO - 2025-12-26 04:41:29 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:41:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:41:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:41:29 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:41:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:41:29 --> Upload Class Initialized
INFO - 2025-12-26 04:41:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:41:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:41:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:41:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:41:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:41:29 --> Final output sent to browser
DEBUG - 2025-12-26 04:41:29 --> Total execution time: 0.0584
INFO - 2025-12-26 04:41:33 --> Config Class Initialized
INFO - 2025-12-26 04:41:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:41:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:41:33 --> Utf8 Class Initialized
INFO - 2025-12-26 04:41:33 --> URI Class Initialized
INFO - 2025-12-26 04:41:33 --> Router Class Initialized
INFO - 2025-12-26 04:41:33 --> Output Class Initialized
INFO - 2025-12-26 04:41:33 --> Security Class Initialized
DEBUG - 2025-12-26 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:41:33 --> CSRF cookie sent
INFO - 2025-12-26 04:41:33 --> Input Class Initialized
INFO - 2025-12-26 04:41:33 --> Language Class Initialized
INFO - 2025-12-26 04:41:33 --> Loader Class Initialized
INFO - 2025-12-26 04:41:33 --> Helper loaded: url_helper
INFO - 2025-12-26 04:41:33 --> Helper loaded: form_helper
INFO - 2025-12-26 04:41:33 --> Helper loaded: file_helper
INFO - 2025-12-26 04:41:33 --> Helper loaded: html_helper
INFO - 2025-12-26 04:41:33 --> Helper loaded: security_helper
INFO - 2025-12-26 04:41:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:41:33 --> Database Driver Class Initialized
INFO - 2025-12-26 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:41:33 --> Form Validation Class Initialized
INFO - 2025-12-26 04:41:33 --> Controller Class Initialized
INFO - 2025-12-26 04:41:33 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:41:33 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:41:33 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:41:33 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:41:33 --> Upload Class Initialized
INFO - 2025-12-26 04:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 04:41:33 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\detail.php 60
ERROR - 2025-12-26 04:41:33 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\detail.php 62
ERROR - 2025-12-26 04:41:33 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\detail.php 64
INFO - 2025-12-26 04:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-26 04:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:41:33 --> Final output sent to browser
DEBUG - 2025-12-26 04:41:33 --> Total execution time: 0.1172
INFO - 2025-12-26 04:43:19 --> Config Class Initialized
INFO - 2025-12-26 04:43:19 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:19 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:19 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:19 --> URI Class Initialized
INFO - 2025-12-26 04:43:19 --> Router Class Initialized
INFO - 2025-12-26 04:43:19 --> Output Class Initialized
INFO - 2025-12-26 04:43:19 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:19 --> CSRF cookie sent
INFO - 2025-12-26 04:43:19 --> Input Class Initialized
INFO - 2025-12-26 04:43:19 --> Language Class Initialized
INFO - 2025-12-26 04:43:19 --> Loader Class Initialized
INFO - 2025-12-26 04:43:19 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:19 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:19 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:19 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:19 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:19 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:19 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:19 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:19 --> Controller Class Initialized
INFO - 2025-12-26 04:43:19 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:43:19 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:19 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:19 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:43:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:19 --> Upload Class Initialized
INFO - 2025-12-26 04:43:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-26 04:43:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:19 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:19 --> Total execution time: 0.1276
INFO - 2025-12-26 04:43:25 --> Config Class Initialized
INFO - 2025-12-26 04:43:25 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:25 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:25 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:25 --> URI Class Initialized
INFO - 2025-12-26 04:43:25 --> Router Class Initialized
INFO - 2025-12-26 04:43:25 --> Output Class Initialized
INFO - 2025-12-26 04:43:25 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:25 --> CSRF cookie sent
INFO - 2025-12-26 04:43:25 --> Input Class Initialized
INFO - 2025-12-26 04:43:25 --> Language Class Initialized
INFO - 2025-12-26 04:43:25 --> Loader Class Initialized
INFO - 2025-12-26 04:43:25 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:25 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:25 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:25 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:25 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:25 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:25 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:25 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:25 --> Controller Class Initialized
INFO - 2025-12-26 04:43:25 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 04:43:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 04:43:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:25 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:25 --> Total execution time: 0.0751
INFO - 2025-12-26 04:43:27 --> Config Class Initialized
INFO - 2025-12-26 04:43:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:27 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:27 --> URI Class Initialized
INFO - 2025-12-26 04:43:27 --> Router Class Initialized
INFO - 2025-12-26 04:43:27 --> Output Class Initialized
INFO - 2025-12-26 04:43:27 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:27 --> CSRF cookie sent
INFO - 2025-12-26 04:43:27 --> Input Class Initialized
INFO - 2025-12-26 04:43:27 --> Language Class Initialized
INFO - 2025-12-26 04:43:27 --> Loader Class Initialized
INFO - 2025-12-26 04:43:27 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:27 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:27 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:27 --> Controller Class Initialized
INFO - 2025-12-26 04:43:27 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:43:27 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:27 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:43:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:27 --> Upload Class Initialized
INFO - 2025-12-26 04:43:27 --> Helper loaded: text_helper
INFO - 2025-12-26 04:43:27 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:43:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:43:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:27 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:27 --> Total execution time: 0.0684
INFO - 2025-12-26 04:43:29 --> Config Class Initialized
INFO - 2025-12-26 04:43:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:29 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:29 --> URI Class Initialized
INFO - 2025-12-26 04:43:29 --> Router Class Initialized
INFO - 2025-12-26 04:43:29 --> Output Class Initialized
INFO - 2025-12-26 04:43:29 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:29 --> CSRF cookie sent
INFO - 2025-12-26 04:43:29 --> Input Class Initialized
INFO - 2025-12-26 04:43:29 --> Language Class Initialized
INFO - 2025-12-26 04:43:29 --> Loader Class Initialized
INFO - 2025-12-26 04:43:29 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:29 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:29 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:29 --> Controller Class Initialized
INFO - 2025-12-26 04:43:29 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:43:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:29 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:43:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:29 --> Upload Class Initialized
INFO - 2025-12-26 04:43:29 --> Helper loaded: text_helper
INFO - 2025-12-26 04:43:29 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:43:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:32 --> Config Class Initialized
INFO - 2025-12-26 04:43:32 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:32 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:32 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:32 --> URI Class Initialized
INFO - 2025-12-26 04:43:32 --> Router Class Initialized
INFO - 2025-12-26 04:43:32 --> Output Class Initialized
INFO - 2025-12-26 04:43:32 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:32 --> CSRF cookie sent
INFO - 2025-12-26 04:43:32 --> Input Class Initialized
INFO - 2025-12-26 04:43:32 --> Language Class Initialized
INFO - 2025-12-26 04:43:32 --> Loader Class Initialized
INFO - 2025-12-26 04:43:32 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:32 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:32 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:32 --> Controller Class Initialized
INFO - 2025-12-26 04:43:32 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:43:32 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:32 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:32 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:43:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:32 --> Upload Class Initialized
INFO - 2025-12-26 04:43:32 --> Helper loaded: text_helper
INFO - 2025-12-26 04:43:32 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:43:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:43:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:32 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:32 --> Total execution time: 0.0702
INFO - 2025-12-26 04:43:35 --> Config Class Initialized
INFO - 2025-12-26 04:43:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:35 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:35 --> URI Class Initialized
INFO - 2025-12-26 04:43:35 --> Router Class Initialized
INFO - 2025-12-26 04:43:35 --> Output Class Initialized
INFO - 2025-12-26 04:43:35 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:35 --> CSRF cookie sent
INFO - 2025-12-26 04:43:35 --> Input Class Initialized
INFO - 2025-12-26 04:43:35 --> Language Class Initialized
INFO - 2025-12-26 04:43:35 --> Loader Class Initialized
INFO - 2025-12-26 04:43:35 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:35 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:35 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:35 --> Controller Class Initialized
INFO - 2025-12-26 04:43:35 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:43:35 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:35 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:35 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:43:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:35 --> Upload Class Initialized
INFO - 2025-12-26 04:43:35 --> Helper loaded: text_helper
INFO - 2025-12-26 04:43:35 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:43:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 04:43:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:35 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:35 --> Total execution time: 0.0660
INFO - 2025-12-26 04:43:36 --> Config Class Initialized
INFO - 2025-12-26 04:43:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:36 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:36 --> URI Class Initialized
INFO - 2025-12-26 04:43:36 --> Router Class Initialized
INFO - 2025-12-26 04:43:36 --> Output Class Initialized
INFO - 2025-12-26 04:43:36 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:36 --> CSRF cookie sent
INFO - 2025-12-26 04:43:36 --> Input Class Initialized
INFO - 2025-12-26 04:43:36 --> Language Class Initialized
INFO - 2025-12-26 04:43:36 --> Loader Class Initialized
INFO - 2025-12-26 04:43:36 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:36 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:36 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:36 --> Controller Class Initialized
INFO - 2025-12-26 04:43:36 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 04:43:36 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:36 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:36 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 04:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:36 --> Upload Class Initialized
INFO - 2025-12-26 04:43:36 --> Helper loaded: text_helper
INFO - 2025-12-26 04:43:36 --> Helper loaded: custom_helper
INFO - 2025-12-26 04:43:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 04:43:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:36 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:36 --> Total execution time: 0.0687
INFO - 2025-12-26 04:43:37 --> Config Class Initialized
INFO - 2025-12-26 04:43:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:37 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:37 --> URI Class Initialized
INFO - 2025-12-26 04:43:37 --> Router Class Initialized
INFO - 2025-12-26 04:43:38 --> Output Class Initialized
INFO - 2025-12-26 04:43:38 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:38 --> CSRF cookie sent
INFO - 2025-12-26 04:43:38 --> Input Class Initialized
INFO - 2025-12-26 04:43:38 --> Language Class Initialized
INFO - 2025-12-26 04:43:38 --> Loader Class Initialized
INFO - 2025-12-26 04:43:38 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:38 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:38 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:38 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:38 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:38 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:38 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:38 --> Controller Class Initialized
INFO - 2025-12-26 04:43:38 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:43:38 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:43:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:38 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:38 --> Total execution time: 0.0738
INFO - 2025-12-26 04:43:39 --> Config Class Initialized
INFO - 2025-12-26 04:43:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:39 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:39 --> URI Class Initialized
INFO - 2025-12-26 04:43:39 --> Router Class Initialized
INFO - 2025-12-26 04:43:39 --> Output Class Initialized
INFO - 2025-12-26 04:43:39 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:39 --> CSRF cookie sent
INFO - 2025-12-26 04:43:39 --> Input Class Initialized
INFO - 2025-12-26 04:43:39 --> Language Class Initialized
INFO - 2025-12-26 04:43:39 --> Loader Class Initialized
INFO - 2025-12-26 04:43:39 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:39 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:39 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:39 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:39 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:39 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:39 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:39 --> Controller Class Initialized
INFO - 2025-12-26 04:43:39 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:43:39 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:39 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:39 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:43:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:39 --> Upload Class Initialized
INFO - 2025-12-26 04:43:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:43:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:40 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:40 --> Total execution time: 0.3054
INFO - 2025-12-26 04:43:51 --> Config Class Initialized
INFO - 2025-12-26 04:43:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:51 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:51 --> URI Class Initialized
INFO - 2025-12-26 04:43:51 --> Router Class Initialized
INFO - 2025-12-26 04:43:51 --> Output Class Initialized
INFO - 2025-12-26 04:43:51 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:51 --> CSRF cookie sent
INFO - 2025-12-26 04:43:51 --> Input Class Initialized
INFO - 2025-12-26 04:43:51 --> Language Class Initialized
INFO - 2025-12-26 04:43:51 --> Loader Class Initialized
INFO - 2025-12-26 04:43:51 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:51 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:51 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:51 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:51 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:51 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:51 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:51 --> Controller Class Initialized
INFO - 2025-12-26 04:43:51 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 04:43:51 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 04:43:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 04:43:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:51 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:51 --> Total execution time: 0.0509
INFO - 2025-12-26 04:43:56 --> Config Class Initialized
INFO - 2025-12-26 04:43:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 04:43:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 04:43:56 --> Utf8 Class Initialized
INFO - 2025-12-26 04:43:56 --> URI Class Initialized
INFO - 2025-12-26 04:43:56 --> Router Class Initialized
INFO - 2025-12-26 04:43:56 --> Output Class Initialized
INFO - 2025-12-26 04:43:56 --> Security Class Initialized
DEBUG - 2025-12-26 04:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 04:43:56 --> CSRF cookie sent
INFO - 2025-12-26 04:43:56 --> Input Class Initialized
INFO - 2025-12-26 04:43:56 --> Language Class Initialized
INFO - 2025-12-26 04:43:56 --> Loader Class Initialized
INFO - 2025-12-26 04:43:56 --> Helper loaded: url_helper
INFO - 2025-12-26 04:43:56 --> Helper loaded: form_helper
INFO - 2025-12-26 04:43:56 --> Helper loaded: file_helper
INFO - 2025-12-26 04:43:56 --> Helper loaded: html_helper
INFO - 2025-12-26 04:43:56 --> Helper loaded: security_helper
INFO - 2025-12-26 04:43:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 04:43:56 --> Database Driver Class Initialized
INFO - 2025-12-26 04:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 04:43:56 --> Form Validation Class Initialized
INFO - 2025-12-26 04:43:56 --> Controller Class Initialized
INFO - 2025-12-26 04:43:56 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 04:43:56 --> Model "Bagian_model" initialized
INFO - 2025-12-26 04:43:56 --> Model "Kategori_model" initialized
INFO - 2025-12-26 04:43:56 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 04:43:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 04:43:56 --> Upload Class Initialized
INFO - 2025-12-26 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 04:43:56 --> Final output sent to browser
DEBUG - 2025-12-26 04:43:56 --> Total execution time: 0.0612
INFO - 2025-12-26 05:08:46 --> Config Class Initialized
INFO - 2025-12-26 05:08:46 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:08:46 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:08:46 --> Utf8 Class Initialized
INFO - 2025-12-26 05:08:46 --> URI Class Initialized
INFO - 2025-12-26 05:08:46 --> Router Class Initialized
INFO - 2025-12-26 05:08:46 --> Output Class Initialized
INFO - 2025-12-26 05:08:46 --> Security Class Initialized
DEBUG - 2025-12-26 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:08:46 --> CSRF cookie sent
INFO - 2025-12-26 05:08:46 --> Input Class Initialized
INFO - 2025-12-26 05:08:46 --> Language Class Initialized
INFO - 2025-12-26 05:08:46 --> Loader Class Initialized
INFO - 2025-12-26 05:08:46 --> Helper loaded: url_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: form_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: file_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: html_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: security_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:08:46 --> Database Driver Class Initialized
INFO - 2025-12-26 05:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:08:46 --> Form Validation Class Initialized
INFO - 2025-12-26 05:08:46 --> Controller Class Initialized
INFO - 2025-12-26 05:08:46 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 05:08:46 --> Model "Bagian_model" initialized
INFO - 2025-12-26 05:08:46 --> Model "Kategori_model" initialized
INFO - 2025-12-26 05:08:46 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 05:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 05:08:46 --> Upload Class Initialized
INFO - 2025-12-26 05:08:46 --> Helper loaded: text_helper
INFO - 2025-12-26 05:08:46 --> Helper loaded: custom_helper
INFO - 2025-12-26 05:08:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 05:08:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 05:08:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 05:08:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 05:08:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 05:08:46 --> Final output sent to browser
DEBUG - 2025-12-26 05:08:46 --> Total execution time: 0.0718
INFO - 2025-12-26 05:08:48 --> Config Class Initialized
INFO - 2025-12-26 05:08:48 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:08:48 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:08:48 --> Utf8 Class Initialized
INFO - 2025-12-26 05:08:48 --> URI Class Initialized
INFO - 2025-12-26 05:08:48 --> Router Class Initialized
INFO - 2025-12-26 05:08:48 --> Output Class Initialized
INFO - 2025-12-26 05:08:48 --> Security Class Initialized
DEBUG - 2025-12-26 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:08:48 --> CSRF cookie sent
INFO - 2025-12-26 05:08:48 --> Input Class Initialized
INFO - 2025-12-26 05:08:48 --> Language Class Initialized
INFO - 2025-12-26 05:08:48 --> Loader Class Initialized
INFO - 2025-12-26 05:08:48 --> Helper loaded: url_helper
INFO - 2025-12-26 05:08:48 --> Helper loaded: form_helper
INFO - 2025-12-26 05:08:48 --> Helper loaded: file_helper
INFO - 2025-12-26 05:08:48 --> Helper loaded: html_helper
INFO - 2025-12-26 05:08:48 --> Helper loaded: security_helper
INFO - 2025-12-26 05:08:48 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:08:48 --> Database Driver Class Initialized
INFO - 2025-12-26 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:08:48 --> Form Validation Class Initialized
INFO - 2025-12-26 05:08:48 --> Controller Class Initialized
INFO - 2025-12-26 05:08:48 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 05:08:48 --> Model "Bagian_model" initialized
INFO - 2025-12-26 05:08:48 --> Model "Kategori_model" initialized
INFO - 2025-12-26 05:08:48 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 05:08:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 05:08:48 --> Upload Class Initialized
INFO - 2025-12-26 05:08:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 05:08:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 05:08:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 05:08:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 05:08:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 05:08:48 --> Final output sent to browser
DEBUG - 2025-12-26 05:08:48 --> Total execution time: 0.0615
INFO - 2025-12-26 05:08:49 --> Config Class Initialized
INFO - 2025-12-26 05:08:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:08:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:08:49 --> Utf8 Class Initialized
INFO - 2025-12-26 05:08:49 --> URI Class Initialized
INFO - 2025-12-26 05:08:49 --> Router Class Initialized
INFO - 2025-12-26 05:08:49 --> Output Class Initialized
INFO - 2025-12-26 05:08:49 --> Security Class Initialized
DEBUG - 2025-12-26 05:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:08:49 --> CSRF cookie sent
INFO - 2025-12-26 05:08:49 --> Input Class Initialized
INFO - 2025-12-26 05:08:49 --> Language Class Initialized
INFO - 2025-12-26 05:08:49 --> Loader Class Initialized
INFO - 2025-12-26 05:08:49 --> Helper loaded: url_helper
INFO - 2025-12-26 05:08:49 --> Helper loaded: form_helper
INFO - 2025-12-26 05:08:49 --> Helper loaded: file_helper
INFO - 2025-12-26 05:08:49 --> Helper loaded: html_helper
INFO - 2025-12-26 05:08:49 --> Helper loaded: security_helper
INFO - 2025-12-26 05:08:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:08:49 --> Database Driver Class Initialized
INFO - 2025-12-26 05:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:08:49 --> Form Validation Class Initialized
INFO - 2025-12-26 05:08:49 --> Controller Class Initialized
INFO - 2025-12-26 05:08:49 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 05:08:49 --> Model "Bagian_model" initialized
INFO - 2025-12-26 05:08:49 --> Model "Kategori_model" initialized
INFO - 2025-12-26 05:08:49 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 05:08:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 05:08:49 --> Upload Class Initialized
INFO - 2025-12-26 05:08:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 05:08:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 05:08:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 05:08:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 05:08:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 05:08:49 --> Final output sent to browser
DEBUG - 2025-12-26 05:08:49 --> Total execution time: 0.4065
INFO - 2025-12-26 05:09:01 --> Config Class Initialized
INFO - 2025-12-26 05:09:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:09:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:09:01 --> Utf8 Class Initialized
INFO - 2025-12-26 05:09:01 --> URI Class Initialized
INFO - 2025-12-26 05:09:01 --> Router Class Initialized
INFO - 2025-12-26 05:09:01 --> Output Class Initialized
INFO - 2025-12-26 05:09:01 --> Security Class Initialized
DEBUG - 2025-12-26 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:09:01 --> CSRF cookie sent
INFO - 2025-12-26 05:09:01 --> CSRF token verified
INFO - 2025-12-26 05:09:01 --> Input Class Initialized
INFO - 2025-12-26 05:09:01 --> Language Class Initialized
INFO - 2025-12-26 05:09:01 --> Loader Class Initialized
INFO - 2025-12-26 05:09:01 --> Helper loaded: url_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: form_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: file_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: html_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: security_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:09:01 --> Database Driver Class Initialized
INFO - 2025-12-26 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:09:01 --> Form Validation Class Initialized
INFO - 2025-12-26 05:09:01 --> Controller Class Initialized
INFO - 2025-12-26 05:09:01 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Bagian_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Kategori_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 05:09:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 05:09:01 --> Upload Class Initialized
INFO - 2025-12-26 05:09:01 --> Config Class Initialized
INFO - 2025-12-26 05:09:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:09:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:09:01 --> Utf8 Class Initialized
INFO - 2025-12-26 05:09:01 --> URI Class Initialized
INFO - 2025-12-26 05:09:01 --> Router Class Initialized
INFO - 2025-12-26 05:09:01 --> Output Class Initialized
INFO - 2025-12-26 05:09:01 --> Security Class Initialized
DEBUG - 2025-12-26 05:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:09:01 --> CSRF cookie sent
INFO - 2025-12-26 05:09:01 --> Input Class Initialized
INFO - 2025-12-26 05:09:01 --> Language Class Initialized
INFO - 2025-12-26 05:09:01 --> Loader Class Initialized
INFO - 2025-12-26 05:09:01 --> Helper loaded: url_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: form_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: file_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: html_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: security_helper
INFO - 2025-12-26 05:09:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:09:01 --> Database Driver Class Initialized
INFO - 2025-12-26 05:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:09:01 --> Form Validation Class Initialized
INFO - 2025-12-26 05:09:01 --> Controller Class Initialized
INFO - 2025-12-26 05:09:01 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Bagian_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Kategori_model" initialized
INFO - 2025-12-26 05:09:01 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 05:09:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 05:09:01 --> Upload Class Initialized
INFO - 2025-12-26 05:09:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 05:09:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 05:09:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 05:09:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 05:09:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 05:09:01 --> Final output sent to browser
DEBUG - 2025-12-26 05:09:01 --> Total execution time: 0.1476
INFO - 2025-12-26 05:09:11 --> Config Class Initialized
INFO - 2025-12-26 05:09:11 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:09:11 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:09:11 --> Utf8 Class Initialized
INFO - 2025-12-26 05:09:11 --> URI Class Initialized
INFO - 2025-12-26 05:09:11 --> Router Class Initialized
INFO - 2025-12-26 05:09:11 --> Output Class Initialized
INFO - 2025-12-26 05:09:11 --> Security Class Initialized
DEBUG - 2025-12-26 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:09:11 --> CSRF cookie sent
INFO - 2025-12-26 05:09:11 --> Input Class Initialized
INFO - 2025-12-26 05:09:11 --> Language Class Initialized
INFO - 2025-12-26 05:09:11 --> Loader Class Initialized
INFO - 2025-12-26 05:09:11 --> Helper loaded: url_helper
INFO - 2025-12-26 05:09:11 --> Helper loaded: form_helper
INFO - 2025-12-26 05:09:11 --> Helper loaded: file_helper
INFO - 2025-12-26 05:09:11 --> Helper loaded: html_helper
INFO - 2025-12-26 05:09:11 --> Helper loaded: security_helper
INFO - 2025-12-26 05:09:11 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:09:11 --> Database Driver Class Initialized
INFO - 2025-12-26 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:09:11 --> Form Validation Class Initialized
INFO - 2025-12-26 05:09:11 --> Controller Class Initialized
INFO - 2025-12-26 05:09:11 --> Final output sent to browser
DEBUG - 2025-12-26 05:09:11 --> Total execution time: 0.1390
INFO - 2025-12-26 05:09:19 --> Config Class Initialized
INFO - 2025-12-26 05:09:19 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:09:19 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:09:19 --> Utf8 Class Initialized
INFO - 2025-12-26 05:09:19 --> URI Class Initialized
INFO - 2025-12-26 05:09:19 --> Router Class Initialized
INFO - 2025-12-26 05:09:19 --> Output Class Initialized
INFO - 2025-12-26 05:09:19 --> Security Class Initialized
DEBUG - 2025-12-26 05:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:09:19 --> Input Class Initialized
INFO - 2025-12-26 05:09:19 --> Language Class Initialized
INFO - 2025-12-26 05:09:19 --> Loader Class Initialized
INFO - 2025-12-26 05:09:19 --> Helper loaded: url_helper
INFO - 2025-12-26 05:09:19 --> Helper loaded: form_helper
INFO - 2025-12-26 05:09:19 --> Helper loaded: file_helper
INFO - 2025-12-26 05:09:19 --> Helper loaded: html_helper
INFO - 2025-12-26 05:09:19 --> Helper loaded: security_helper
INFO - 2025-12-26 05:09:19 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:09:19 --> Database Driver Class Initialized
INFO - 2025-12-26 05:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:09:19 --> Form Validation Class Initialized
INFO - 2025-12-26 05:09:19 --> Controller Class Initialized
INFO - 2025-12-26 05:09:19 --> Final output sent to browser
DEBUG - 2025-12-26 05:09:19 --> Total execution time: 0.0657
INFO - 2025-12-26 05:10:29 --> Config Class Initialized
INFO - 2025-12-26 05:10:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:10:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:10:29 --> Utf8 Class Initialized
INFO - 2025-12-26 05:10:29 --> URI Class Initialized
INFO - 2025-12-26 05:10:29 --> Router Class Initialized
INFO - 2025-12-26 05:10:29 --> Output Class Initialized
INFO - 2025-12-26 05:10:29 --> Security Class Initialized
DEBUG - 2025-12-26 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:10:29 --> Input Class Initialized
INFO - 2025-12-26 05:10:29 --> Language Class Initialized
INFO - 2025-12-26 05:10:29 --> Loader Class Initialized
INFO - 2025-12-26 05:10:29 --> Helper loaded: url_helper
INFO - 2025-12-26 05:10:29 --> Helper loaded: form_helper
INFO - 2025-12-26 05:10:29 --> Helper loaded: file_helper
INFO - 2025-12-26 05:10:29 --> Helper loaded: html_helper
INFO - 2025-12-26 05:10:29 --> Helper loaded: security_helper
INFO - 2025-12-26 05:10:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:10:29 --> Database Driver Class Initialized
INFO - 2025-12-26 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:10:29 --> Form Validation Class Initialized
INFO - 2025-12-26 05:10:29 --> Controller Class Initialized
INFO - 2025-12-26 05:10:31 --> Final output sent to browser
DEBUG - 2025-12-26 05:10:31 --> Total execution time: 1.6999
INFO - 2025-12-26 05:10:47 --> Config Class Initialized
INFO - 2025-12-26 05:10:47 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:10:47 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:10:47 --> Utf8 Class Initialized
INFO - 2025-12-26 05:10:47 --> URI Class Initialized
INFO - 2025-12-26 05:10:47 --> Router Class Initialized
INFO - 2025-12-26 05:10:47 --> Output Class Initialized
INFO - 2025-12-26 05:10:47 --> Security Class Initialized
DEBUG - 2025-12-26 05:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:10:47 --> Input Class Initialized
INFO - 2025-12-26 05:10:47 --> Language Class Initialized
INFO - 2025-12-26 05:10:47 --> Loader Class Initialized
INFO - 2025-12-26 05:10:47 --> Helper loaded: url_helper
INFO - 2025-12-26 05:10:47 --> Helper loaded: form_helper
INFO - 2025-12-26 05:10:47 --> Helper loaded: file_helper
INFO - 2025-12-26 05:10:47 --> Helper loaded: html_helper
INFO - 2025-12-26 05:10:47 --> Helper loaded: security_helper
INFO - 2025-12-26 05:10:47 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:10:47 --> Database Driver Class Initialized
INFO - 2025-12-26 05:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 05:10:47 --> Form Validation Class Initialized
INFO - 2025-12-26 05:10:47 --> Controller Class Initialized
ERROR - 2025-12-26 05:10:47 --> Severity: error --> Exception: Call to undefined method Document_extractor::_extract_image() D:\xampp\htdocs\surat_itm\application\libraries\Document_extractor.php 84
INFO - 2025-12-26 05:26:57 --> Config Class Initialized
INFO - 2025-12-26 05:26:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:26:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:26:57 --> Utf8 Class Initialized
INFO - 2025-12-26 05:26:57 --> URI Class Initialized
INFO - 2025-12-26 05:26:57 --> Router Class Initialized
INFO - 2025-12-26 05:26:57 --> Output Class Initialized
INFO - 2025-12-26 05:26:57 --> Security Class Initialized
DEBUG - 2025-12-26 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:26:57 --> Input Class Initialized
INFO - 2025-12-26 05:26:57 --> Language Class Initialized
INFO - 2025-12-26 05:26:57 --> Loader Class Initialized
INFO - 2025-12-26 05:26:57 --> Helper loaded: url_helper
INFO - 2025-12-26 05:26:57 --> Helper loaded: form_helper
INFO - 2025-12-26 05:26:57 --> Helper loaded: file_helper
INFO - 2025-12-26 05:26:57 --> Helper loaded: html_helper
INFO - 2025-12-26 05:26:57 --> Helper loaded: security_helper
INFO - 2025-12-26 05:26:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:26:57 --> Database Driver Class Initialized
INFO - 2025-12-26 05:29:05 --> Config Class Initialized
INFO - 2025-12-26 05:29:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:29:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:29:05 --> Utf8 Class Initialized
INFO - 2025-12-26 05:29:05 --> URI Class Initialized
INFO - 2025-12-26 05:29:05 --> Router Class Initialized
INFO - 2025-12-26 05:29:05 --> Output Class Initialized
INFO - 2025-12-26 05:29:05 --> Security Class Initialized
DEBUG - 2025-12-26 05:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:29:05 --> Input Class Initialized
INFO - 2025-12-26 05:29:05 --> Language Class Initialized
INFO - 2025-12-26 05:29:05 --> Loader Class Initialized
INFO - 2025-12-26 05:29:05 --> Helper loaded: url_helper
INFO - 2025-12-26 05:29:05 --> Helper loaded: form_helper
INFO - 2025-12-26 05:29:05 --> Helper loaded: file_helper
INFO - 2025-12-26 05:29:05 --> Helper loaded: html_helper
INFO - 2025-12-26 05:29:05 --> Helper loaded: security_helper
INFO - 2025-12-26 05:29:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:29:05 --> Database Driver Class Initialized
INFO - 2025-12-26 05:29:20 --> Config Class Initialized
INFO - 2025-12-26 05:29:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:29:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:29:20 --> Utf8 Class Initialized
INFO - 2025-12-26 05:29:20 --> URI Class Initialized
INFO - 2025-12-26 05:29:20 --> Router Class Initialized
INFO - 2025-12-26 05:29:20 --> Output Class Initialized
INFO - 2025-12-26 05:29:20 --> Security Class Initialized
DEBUG - 2025-12-26 05:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:29:20 --> Input Class Initialized
INFO - 2025-12-26 05:29:20 --> Language Class Initialized
INFO - 2025-12-26 05:29:20 --> Loader Class Initialized
INFO - 2025-12-26 05:29:20 --> Helper loaded: url_helper
INFO - 2025-12-26 05:29:20 --> Helper loaded: form_helper
INFO - 2025-12-26 05:29:20 --> Helper loaded: file_helper
INFO - 2025-12-26 05:29:20 --> Helper loaded: html_helper
INFO - 2025-12-26 05:29:20 --> Helper loaded: security_helper
INFO - 2025-12-26 05:29:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:29:20 --> Database Driver Class Initialized
ERROR - 2025-12-26 05:29:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:29:24 --> Unable to connect to the database
INFO - 2025-12-26 05:29:24 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:29:35 --> Config Class Initialized
INFO - 2025-12-26 05:29:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:29:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:29:35 --> Utf8 Class Initialized
INFO - 2025-12-26 05:29:35 --> URI Class Initialized
INFO - 2025-12-26 05:29:35 --> Router Class Initialized
INFO - 2025-12-26 05:29:35 --> Output Class Initialized
INFO - 2025-12-26 05:29:35 --> Security Class Initialized
DEBUG - 2025-12-26 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:29:35 --> Input Class Initialized
INFO - 2025-12-26 05:29:35 --> Language Class Initialized
INFO - 2025-12-26 05:29:35 --> Loader Class Initialized
INFO - 2025-12-26 05:29:35 --> Helper loaded: url_helper
INFO - 2025-12-26 05:29:35 --> Helper loaded: form_helper
INFO - 2025-12-26 05:29:35 --> Helper loaded: file_helper
INFO - 2025-12-26 05:29:35 --> Helper loaded: html_helper
INFO - 2025-12-26 05:29:35 --> Helper loaded: security_helper
INFO - 2025-12-26 05:29:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:29:35 --> Database Driver Class Initialized
ERROR - 2025-12-26 05:29:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:29:39 --> Unable to connect to the database
INFO - 2025-12-26 05:29:39 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:29:45 --> Config Class Initialized
INFO - 2025-12-26 05:29:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:29:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:29:45 --> Utf8 Class Initialized
INFO - 2025-12-26 05:29:45 --> URI Class Initialized
INFO - 2025-12-26 05:29:45 --> Router Class Initialized
INFO - 2025-12-26 05:29:45 --> Output Class Initialized
INFO - 2025-12-26 05:29:45 --> Security Class Initialized
DEBUG - 2025-12-26 05:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:29:45 --> Input Class Initialized
INFO - 2025-12-26 05:29:45 --> Language Class Initialized
INFO - 2025-12-26 05:29:45 --> Loader Class Initialized
INFO - 2025-12-26 05:29:45 --> Helper loaded: url_helper
INFO - 2025-12-26 05:29:45 --> Helper loaded: form_helper
INFO - 2025-12-26 05:29:45 --> Helper loaded: file_helper
INFO - 2025-12-26 05:29:45 --> Helper loaded: html_helper
INFO - 2025-12-26 05:29:45 --> Helper loaded: security_helper
INFO - 2025-12-26 05:29:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:29:45 --> Database Driver Class Initialized
ERROR - 2025-12-26 05:29:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:29:49 --> Unable to connect to the database
INFO - 2025-12-26 05:29:49 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:30:01 --> Config Class Initialized
INFO - 2025-12-26 05:30:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:30:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:30:01 --> Utf8 Class Initialized
INFO - 2025-12-26 05:30:01 --> URI Class Initialized
INFO - 2025-12-26 05:30:01 --> Router Class Initialized
INFO - 2025-12-26 05:30:01 --> Output Class Initialized
INFO - 2025-12-26 05:30:01 --> Security Class Initialized
DEBUG - 2025-12-26 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:30:01 --> Input Class Initialized
INFO - 2025-12-26 05:30:01 --> Language Class Initialized
INFO - 2025-12-26 05:30:01 --> Loader Class Initialized
INFO - 2025-12-26 05:30:01 --> Helper loaded: url_helper
INFO - 2025-12-26 05:30:01 --> Helper loaded: form_helper
INFO - 2025-12-26 05:30:01 --> Helper loaded: file_helper
INFO - 2025-12-26 05:30:01 --> Helper loaded: html_helper
INFO - 2025-12-26 05:30:01 --> Helper loaded: security_helper
INFO - 2025-12-26 05:30:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:30:01 --> Database Driver Class Initialized
INFO - 2025-12-26 05:30:34 --> Config Class Initialized
INFO - 2025-12-26 05:30:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:30:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:30:34 --> Utf8 Class Initialized
INFO - 2025-12-26 05:30:34 --> URI Class Initialized
INFO - 2025-12-26 05:30:34 --> Router Class Initialized
INFO - 2025-12-26 05:30:34 --> Output Class Initialized
INFO - 2025-12-26 05:30:34 --> Security Class Initialized
DEBUG - 2025-12-26 05:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:30:34 --> CSRF cookie sent
INFO - 2025-12-26 05:30:34 --> Input Class Initialized
INFO - 2025-12-26 05:30:34 --> Language Class Initialized
INFO - 2025-12-26 05:30:34 --> Loader Class Initialized
INFO - 2025-12-26 05:30:34 --> Helper loaded: url_helper
INFO - 2025-12-26 05:30:34 --> Helper loaded: form_helper
INFO - 2025-12-26 05:30:34 --> Helper loaded: file_helper
INFO - 2025-12-26 05:30:34 --> Helper loaded: html_helper
INFO - 2025-12-26 05:30:34 --> Helper loaded: security_helper
INFO - 2025-12-26 05:30:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:30:34 --> Database Driver Class Initialized
INFO - 2025-12-26 05:31:04 --> Config Class Initialized
INFO - 2025-12-26 05:31:04 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:31:04 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:31:04 --> Utf8 Class Initialized
INFO - 2025-12-26 05:31:04 --> URI Class Initialized
INFO - 2025-12-26 05:31:04 --> Router Class Initialized
INFO - 2025-12-26 05:31:04 --> Output Class Initialized
INFO - 2025-12-26 05:31:04 --> Security Class Initialized
DEBUG - 2025-12-26 05:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:31:04 --> Input Class Initialized
INFO - 2025-12-26 05:31:04 --> Language Class Initialized
INFO - 2025-12-26 05:31:04 --> Loader Class Initialized
INFO - 2025-12-26 05:31:04 --> Helper loaded: url_helper
INFO - 2025-12-26 05:31:04 --> Helper loaded: form_helper
INFO - 2025-12-26 05:31:04 --> Helper loaded: file_helper
INFO - 2025-12-26 05:31:04 --> Helper loaded: html_helper
INFO - 2025-12-26 05:31:04 --> Helper loaded: security_helper
INFO - 2025-12-26 05:31:04 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:31:04 --> Database Driver Class Initialized
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=27840 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=27840 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=27840 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 05:31:18 --> Unable to connect to the database
ERROR - 2025-12-26 05:31:18 --> Unable to connect to the database
ERROR - 2025-12-26 05:31:18 --> Unable to connect to the database
INFO - 2025-12-26 05:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 05:31:31 --> Config Class Initialized
INFO - 2025-12-26 05:31:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:31:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:31:31 --> Utf8 Class Initialized
INFO - 2025-12-26 05:31:31 --> URI Class Initialized
INFO - 2025-12-26 05:31:31 --> Router Class Initialized
INFO - 2025-12-26 05:31:31 --> Output Class Initialized
INFO - 2025-12-26 05:31:31 --> Security Class Initialized
DEBUG - 2025-12-26 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:31:31 --> CSRF cookie sent
INFO - 2025-12-26 05:31:31 --> Input Class Initialized
INFO - 2025-12-26 05:31:31 --> Language Class Initialized
INFO - 2025-12-26 05:31:31 --> Loader Class Initialized
INFO - 2025-12-26 05:31:31 --> Helper loaded: url_helper
INFO - 2025-12-26 05:31:31 --> Helper loaded: form_helper
INFO - 2025-12-26 05:31:31 --> Helper loaded: file_helper
INFO - 2025-12-26 05:31:31 --> Helper loaded: html_helper
INFO - 2025-12-26 05:31:31 --> Helper loaded: security_helper
INFO - 2025-12-26 05:31:31 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:31:31 --> Database Driver Class Initialized
INFO - 2025-12-26 05:31:34 --> Config Class Initialized
INFO - 2025-12-26 05:31:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 05:31:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 05:31:34 --> Utf8 Class Initialized
INFO - 2025-12-26 05:31:34 --> URI Class Initialized
INFO - 2025-12-26 05:31:34 --> Router Class Initialized
INFO - 2025-12-26 05:31:34 --> Output Class Initialized
INFO - 2025-12-26 05:31:34 --> Security Class Initialized
DEBUG - 2025-12-26 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 05:31:34 --> Input Class Initialized
INFO - 2025-12-26 05:31:34 --> Language Class Initialized
INFO - 2025-12-26 05:31:34 --> Loader Class Initialized
INFO - 2025-12-26 05:31:34 --> Helper loaded: url_helper
INFO - 2025-12-26 05:31:34 --> Helper loaded: form_helper
INFO - 2025-12-26 05:31:34 --> Helper loaded: file_helper
INFO - 2025-12-26 05:31:34 --> Helper loaded: html_helper
INFO - 2025-12-26 05:31:34 --> Helper loaded: security_helper
INFO - 2025-12-26 05:31:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 05:31:34 --> Database Driver Class Initialized
INFO - 2025-12-26 06:16:08 --> Config Class Initialized
INFO - 2025-12-26 06:16:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:16:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:16:08 --> Utf8 Class Initialized
INFO - 2025-12-26 06:16:08 --> URI Class Initialized
INFO - 2025-12-26 06:16:08 --> Router Class Initialized
INFO - 2025-12-26 06:16:08 --> Output Class Initialized
INFO - 2025-12-26 06:16:08 --> Security Class Initialized
DEBUG - 2025-12-26 06:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:16:08 --> CSRF cookie sent
INFO - 2025-12-26 06:16:08 --> Input Class Initialized
INFO - 2025-12-26 06:16:08 --> Language Class Initialized
INFO - 2025-12-26 06:16:08 --> Loader Class Initialized
INFO - 2025-12-26 06:16:08 --> Helper loaded: url_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: form_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: file_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: html_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: security_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:16:08 --> Database Driver Class Initialized
INFO - 2025-12-26 06:16:08 --> Config Class Initialized
INFO - 2025-12-26 06:16:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:16:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:16:08 --> Utf8 Class Initialized
INFO - 2025-12-26 06:16:08 --> URI Class Initialized
INFO - 2025-12-26 06:16:08 --> Router Class Initialized
INFO - 2025-12-26 06:16:08 --> Output Class Initialized
INFO - 2025-12-26 06:16:08 --> Security Class Initialized
DEBUG - 2025-12-26 06:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:16:08 --> CSRF cookie sent
INFO - 2025-12-26 06:16:08 --> Input Class Initialized
INFO - 2025-12-26 06:16:08 --> Language Class Initialized
INFO - 2025-12-26 06:16:08 --> Loader Class Initialized
INFO - 2025-12-26 06:16:08 --> Helper loaded: url_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: form_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: file_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: html_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: security_helper
INFO - 2025-12-26 06:16:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:16:08 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:16:40 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=8788 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:16:40 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=8788 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:16:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:16:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:16:40 --> Unable to connect to the database
ERROR - 2025-12-26 06:16:40 --> Unable to connect to the database
INFO - 2025-12-26 06:16:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:16:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2025-12-26 06:16:40 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\surat_itm\system\core\Common.php 598
ERROR - 2025-12-26 06:16:40 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\surat_itm\system\core\Common.php 598
INFO - 2025-12-26 06:17:00 --> Config Class Initialized
INFO - 2025-12-26 06:17:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:17:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:17:00 --> Utf8 Class Initialized
INFO - 2025-12-26 06:17:00 --> URI Class Initialized
INFO - 2025-12-26 06:17:00 --> Router Class Initialized
INFO - 2025-12-26 06:17:00 --> Output Class Initialized
INFO - 2025-12-26 06:17:00 --> Security Class Initialized
DEBUG - 2025-12-26 06:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:17:00 --> CSRF cookie sent
INFO - 2025-12-26 06:17:00 --> Input Class Initialized
INFO - 2025-12-26 06:17:00 --> Language Class Initialized
INFO - 2025-12-26 06:17:00 --> Loader Class Initialized
INFO - 2025-12-26 06:17:00 --> Helper loaded: url_helper
INFO - 2025-12-26 06:17:00 --> Helper loaded: form_helper
INFO - 2025-12-26 06:17:00 --> Helper loaded: file_helper
INFO - 2025-12-26 06:17:00 --> Helper loaded: html_helper
INFO - 2025-12-26 06:17:00 --> Helper loaded: security_helper
INFO - 2025-12-26 06:17:00 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:17:00 --> Database Driver Class Initialized
INFO - 2025-12-26 06:17:07 --> Config Class Initialized
INFO - 2025-12-26 06:17:07 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:17:07 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:17:07 --> Utf8 Class Initialized
INFO - 2025-12-26 06:17:07 --> URI Class Initialized
INFO - 2025-12-26 06:17:07 --> Router Class Initialized
INFO - 2025-12-26 06:17:07 --> Output Class Initialized
INFO - 2025-12-26 06:17:07 --> Security Class Initialized
DEBUG - 2025-12-26 06:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:17:07 --> Input Class Initialized
INFO - 2025-12-26 06:17:07 --> Language Class Initialized
INFO - 2025-12-26 06:17:07 --> Loader Class Initialized
INFO - 2025-12-26 06:17:07 --> Helper loaded: url_helper
INFO - 2025-12-26 06:17:07 --> Helper loaded: form_helper
INFO - 2025-12-26 06:17:07 --> Helper loaded: file_helper
INFO - 2025-12-26 06:17:07 --> Helper loaded: html_helper
INFO - 2025-12-26 06:17:07 --> Helper loaded: security_helper
INFO - 2025-12-26 06:17:07 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:17:07 --> Database Driver Class Initialized
INFO - 2025-12-26 06:18:09 --> Config Class Initialized
INFO - 2025-12-26 06:18:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:18:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:18:09 --> Utf8 Class Initialized
INFO - 2025-12-26 06:18:09 --> URI Class Initialized
INFO - 2025-12-26 06:18:09 --> Router Class Initialized
INFO - 2025-12-26 06:18:09 --> Output Class Initialized
INFO - 2025-12-26 06:18:09 --> Security Class Initialized
DEBUG - 2025-12-26 06:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:18:09 --> Input Class Initialized
INFO - 2025-12-26 06:18:09 --> Language Class Initialized
INFO - 2025-12-26 06:18:09 --> Loader Class Initialized
INFO - 2025-12-26 06:18:09 --> Helper loaded: url_helper
INFO - 2025-12-26 06:18:09 --> Helper loaded: form_helper
INFO - 2025-12-26 06:18:09 --> Helper loaded: file_helper
INFO - 2025-12-26 06:18:09 --> Helper loaded: html_helper
INFO - 2025-12-26 06:18:09 --> Helper loaded: security_helper
INFO - 2025-12-26 06:18:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:18:09 --> Database Driver Class Initialized
INFO - 2025-12-26 06:18:31 --> Config Class Initialized
INFO - 2025-12-26 06:18:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:18:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:18:31 --> Utf8 Class Initialized
INFO - 2025-12-26 06:18:31 --> URI Class Initialized
INFO - 2025-12-26 06:18:31 --> Router Class Initialized
INFO - 2025-12-26 06:18:31 --> Output Class Initialized
INFO - 2025-12-26 06:18:31 --> Security Class Initialized
DEBUG - 2025-12-26 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:18:31 --> CSRF cookie sent
INFO - 2025-12-26 06:18:31 --> Input Class Initialized
INFO - 2025-12-26 06:18:31 --> Language Class Initialized
INFO - 2025-12-26 06:18:31 --> Loader Class Initialized
INFO - 2025-12-26 06:18:31 --> Helper loaded: url_helper
INFO - 2025-12-26 06:18:31 --> Helper loaded: form_helper
INFO - 2025-12-26 06:18:31 --> Helper loaded: file_helper
INFO - 2025-12-26 06:18:31 --> Helper loaded: html_helper
INFO - 2025-12-26 06:18:31 --> Helper loaded: security_helper
INFO - 2025-12-26 06:18:31 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:18:31 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:19:35 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=17164 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:19:35 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=17164 D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:19:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:19:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:19:35 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\surat_itm\system\core\Common.php 598
ERROR - 2025-12-26 06:19:35 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\surat_itm\system\core\Common.php 598
ERROR - 2025-12-26 06:19:35 --> Unable to connect to the database
ERROR - 2025-12-26 06:19:35 --> Unable to connect to the database
INFO - 2025-12-26 06:19:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:19:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:20:13 --> Config Class Initialized
INFO - 2025-12-26 06:20:13 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:20:13 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:20:13 --> Utf8 Class Initialized
INFO - 2025-12-26 06:20:13 --> URI Class Initialized
INFO - 2025-12-26 06:20:13 --> Router Class Initialized
INFO - 2025-12-26 06:20:13 --> Output Class Initialized
INFO - 2025-12-26 06:20:13 --> Security Class Initialized
DEBUG - 2025-12-26 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:20:13 --> CSRF cookie sent
INFO - 2025-12-26 06:20:13 --> Input Class Initialized
INFO - 2025-12-26 06:20:13 --> Language Class Initialized
INFO - 2025-12-26 06:20:13 --> Loader Class Initialized
INFO - 2025-12-26 06:20:13 --> Helper loaded: url_helper
INFO - 2025-12-26 06:20:13 --> Helper loaded: form_helper
INFO - 2025-12-26 06:20:13 --> Helper loaded: file_helper
INFO - 2025-12-26 06:20:13 --> Helper loaded: html_helper
INFO - 2025-12-26 06:20:13 --> Helper loaded: security_helper
INFO - 2025-12-26 06:20:13 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:20:13 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:20:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'surat_itm' D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:20:16 --> Unable to connect to the database
INFO - 2025-12-26 06:20:16 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:22:45 --> Config Class Initialized
INFO - 2025-12-26 06:22:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:22:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:22:45 --> Utf8 Class Initialized
INFO - 2025-12-26 06:22:45 --> URI Class Initialized
INFO - 2025-12-26 06:22:45 --> Router Class Initialized
INFO - 2025-12-26 06:22:45 --> Output Class Initialized
INFO - 2025-12-26 06:22:45 --> Security Class Initialized
DEBUG - 2025-12-26 06:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:22:45 --> CSRF cookie sent
INFO - 2025-12-26 06:22:45 --> Input Class Initialized
INFO - 2025-12-26 06:22:45 --> Language Class Initialized
INFO - 2025-12-26 06:22:45 --> Loader Class Initialized
INFO - 2025-12-26 06:22:45 --> Helper loaded: url_helper
INFO - 2025-12-26 06:22:45 --> Helper loaded: form_helper
INFO - 2025-12-26 06:22:45 --> Helper loaded: file_helper
INFO - 2025-12-26 06:22:45 --> Helper loaded: html_helper
INFO - 2025-12-26 06:22:45 --> Helper loaded: security_helper
INFO - 2025-12-26 06:22:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:22:45 --> Database Driver Class Initialized
INFO - 2025-12-26 06:24:20 --> Config Class Initialized
INFO - 2025-12-26 06:24:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:24:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:24:20 --> Utf8 Class Initialized
INFO - 2025-12-26 06:24:20 --> URI Class Initialized
INFO - 2025-12-26 06:24:20 --> Router Class Initialized
INFO - 2025-12-26 06:24:20 --> Output Class Initialized
INFO - 2025-12-26 06:24:20 --> Security Class Initialized
DEBUG - 2025-12-26 06:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:24:20 --> CSRF cookie sent
INFO - 2025-12-26 06:24:20 --> Input Class Initialized
INFO - 2025-12-26 06:24:20 --> Language Class Initialized
INFO - 2025-12-26 06:24:20 --> Loader Class Initialized
INFO - 2025-12-26 06:24:20 --> Helper loaded: url_helper
INFO - 2025-12-26 06:24:20 --> Helper loaded: form_helper
INFO - 2025-12-26 06:24:20 --> Helper loaded: file_helper
INFO - 2025-12-26 06:24:20 --> Helper loaded: html_helper
INFO - 2025-12-26 06:24:20 --> Helper loaded: security_helper
INFO - 2025-12-26 06:24:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:24:20 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:24:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:24:24 --> Unable to connect to the database
INFO - 2025-12-26 06:24:24 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:24:39 --> Config Class Initialized
INFO - 2025-12-26 06:24:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:24:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:24:39 --> Utf8 Class Initialized
INFO - 2025-12-26 06:24:39 --> URI Class Initialized
INFO - 2025-12-26 06:24:39 --> Router Class Initialized
INFO - 2025-12-26 06:24:39 --> Output Class Initialized
INFO - 2025-12-26 06:24:39 --> Security Class Initialized
DEBUG - 2025-12-26 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:24:39 --> CSRF cookie sent
INFO - 2025-12-26 06:24:39 --> Input Class Initialized
INFO - 2025-12-26 06:24:39 --> Language Class Initialized
INFO - 2025-12-26 06:24:39 --> Loader Class Initialized
INFO - 2025-12-26 06:24:39 --> Helper loaded: url_helper
INFO - 2025-12-26 06:24:39 --> Helper loaded: form_helper
INFO - 2025-12-26 06:24:39 --> Helper loaded: file_helper
INFO - 2025-12-26 06:24:39 --> Helper loaded: html_helper
INFO - 2025-12-26 06:24:39 --> Helper loaded: security_helper
INFO - 2025-12-26 06:24:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:24:39 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:24:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:24:43 --> Unable to connect to the database
INFO - 2025-12-26 06:24:43 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:24:50 --> Config Class Initialized
INFO - 2025-12-26 06:24:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:24:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:24:50 --> Utf8 Class Initialized
INFO - 2025-12-26 06:24:50 --> URI Class Initialized
INFO - 2025-12-26 06:24:50 --> Router Class Initialized
INFO - 2025-12-26 06:24:50 --> Output Class Initialized
INFO - 2025-12-26 06:24:50 --> Security Class Initialized
DEBUG - 2025-12-26 06:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:24:50 --> CSRF cookie sent
INFO - 2025-12-26 06:24:50 --> Input Class Initialized
INFO - 2025-12-26 06:24:50 --> Language Class Initialized
INFO - 2025-12-26 06:24:50 --> Loader Class Initialized
INFO - 2025-12-26 06:24:50 --> Helper loaded: url_helper
INFO - 2025-12-26 06:24:50 --> Helper loaded: form_helper
INFO - 2025-12-26 06:24:50 --> Helper loaded: file_helper
INFO - 2025-12-26 06:24:50 --> Helper loaded: html_helper
INFO - 2025-12-26 06:24:50 --> Helper loaded: security_helper
INFO - 2025-12-26 06:24:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:24:50 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:24:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:24:54 --> Unable to connect to the database
INFO - 2025-12-26 06:24:54 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:27:34 --> Config Class Initialized
INFO - 2025-12-26 06:27:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:27:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:27:34 --> Utf8 Class Initialized
INFO - 2025-12-26 06:27:34 --> URI Class Initialized
INFO - 2025-12-26 06:27:34 --> Router Class Initialized
INFO - 2025-12-26 06:27:34 --> Output Class Initialized
INFO - 2025-12-26 06:27:34 --> Security Class Initialized
DEBUG - 2025-12-26 06:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:27:34 --> CSRF cookie sent
INFO - 2025-12-26 06:27:34 --> Input Class Initialized
INFO - 2025-12-26 06:27:34 --> Language Class Initialized
INFO - 2025-12-26 06:27:34 --> Loader Class Initialized
INFO - 2025-12-26 06:27:34 --> Helper loaded: url_helper
INFO - 2025-12-26 06:27:34 --> Helper loaded: form_helper
INFO - 2025-12-26 06:27:34 --> Helper loaded: file_helper
INFO - 2025-12-26 06:27:34 --> Helper loaded: html_helper
INFO - 2025-12-26 06:27:34 --> Helper loaded: security_helper
INFO - 2025-12-26 06:27:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:27:34 --> Database Driver Class Initialized
INFO - 2025-12-26 06:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:27:34 --> Form Validation Class Initialized
INFO - 2025-12-26 06:27:34 --> Controller Class Initialized
INFO - 2025-12-26 06:27:34 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:27:34 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:27:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:27:34 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:27:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:27:34 --> Upload Class Initialized
INFO - 2025-12-26 06:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:27:34 --> Final output sent to browser
DEBUG - 2025-12-26 06:27:34 --> Total execution time: 0.1114
INFO - 2025-12-26 06:27:44 --> Config Class Initialized
INFO - 2025-12-26 06:27:44 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:27:44 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:27:44 --> Utf8 Class Initialized
INFO - 2025-12-26 06:27:44 --> URI Class Initialized
INFO - 2025-12-26 06:27:44 --> Router Class Initialized
INFO - 2025-12-26 06:27:44 --> Output Class Initialized
INFO - 2025-12-26 06:27:44 --> Security Class Initialized
DEBUG - 2025-12-26 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:27:44 --> CSRF cookie sent
INFO - 2025-12-26 06:27:44 --> Input Class Initialized
INFO - 2025-12-26 06:27:44 --> Language Class Initialized
INFO - 2025-12-26 06:27:44 --> Loader Class Initialized
INFO - 2025-12-26 06:27:44 --> Helper loaded: url_helper
INFO - 2025-12-26 06:27:44 --> Helper loaded: form_helper
INFO - 2025-12-26 06:27:44 --> Helper loaded: file_helper
INFO - 2025-12-26 06:27:44 --> Helper loaded: html_helper
INFO - 2025-12-26 06:27:44 --> Helper loaded: security_helper
INFO - 2025-12-26 06:27:44 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:27:44 --> Database Driver Class Initialized
ERROR - 2025-12-26 06:27:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it D:\xampp\htdocs\surat_itm\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-26 06:27:48 --> Unable to connect to the database
INFO - 2025-12-26 06:27:48 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 06:27:57 --> Config Class Initialized
INFO - 2025-12-26 06:27:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:27:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:27:57 --> Utf8 Class Initialized
INFO - 2025-12-26 06:27:57 --> URI Class Initialized
INFO - 2025-12-26 06:27:57 --> Router Class Initialized
INFO - 2025-12-26 06:27:57 --> Output Class Initialized
INFO - 2025-12-26 06:27:57 --> Security Class Initialized
DEBUG - 2025-12-26 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:27:57 --> CSRF cookie sent
INFO - 2025-12-26 06:27:57 --> Input Class Initialized
INFO - 2025-12-26 06:27:57 --> Language Class Initialized
INFO - 2025-12-26 06:27:57 --> Loader Class Initialized
INFO - 2025-12-26 06:27:57 --> Helper loaded: url_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: form_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: file_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: html_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: security_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:27:57 --> Database Driver Class Initialized
INFO - 2025-12-26 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:27:57 --> Form Validation Class Initialized
INFO - 2025-12-26 06:27:57 --> Controller Class Initialized
INFO - 2025-12-26 06:27:57 --> Model "User_model" initialized
DEBUG - 2025-12-26 06:27:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:27:57 --> Config Class Initialized
INFO - 2025-12-26 06:27:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:27:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:27:57 --> Utf8 Class Initialized
INFO - 2025-12-26 06:27:57 --> URI Class Initialized
INFO - 2025-12-26 06:27:57 --> Router Class Initialized
INFO - 2025-12-26 06:27:57 --> Output Class Initialized
INFO - 2025-12-26 06:27:57 --> Security Class Initialized
DEBUG - 2025-12-26 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:27:57 --> CSRF cookie sent
INFO - 2025-12-26 06:27:57 --> Input Class Initialized
INFO - 2025-12-26 06:27:57 --> Language Class Initialized
INFO - 2025-12-26 06:27:57 --> Loader Class Initialized
INFO - 2025-12-26 06:27:57 --> Helper loaded: url_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: form_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: file_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: html_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: security_helper
INFO - 2025-12-26 06:27:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:27:57 --> Database Driver Class Initialized
INFO - 2025-12-26 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:27:57 --> Form Validation Class Initialized
INFO - 2025-12-26 06:27:57 --> Controller Class Initialized
INFO - 2025-12-26 06:27:57 --> Model "User_model" initialized
DEBUG - 2025-12-26 06:27:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:27:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 06:27:57 --> Final output sent to browser
DEBUG - 2025-12-26 06:27:57 --> Total execution time: 0.0581
INFO - 2025-12-26 06:28:08 --> Config Class Initialized
INFO - 2025-12-26 06:28:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:28:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:28:08 --> Utf8 Class Initialized
INFO - 2025-12-26 06:28:08 --> URI Class Initialized
INFO - 2025-12-26 06:28:08 --> Router Class Initialized
INFO - 2025-12-26 06:28:08 --> Output Class Initialized
INFO - 2025-12-26 06:28:08 --> Security Class Initialized
DEBUG - 2025-12-26 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:28:08 --> CSRF cookie sent
INFO - 2025-12-26 06:28:08 --> CSRF token verified
INFO - 2025-12-26 06:28:08 --> Input Class Initialized
INFO - 2025-12-26 06:28:08 --> Language Class Initialized
INFO - 2025-12-26 06:28:08 --> Loader Class Initialized
INFO - 2025-12-26 06:28:08 --> Helper loaded: url_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: form_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: file_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: html_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: security_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:28:08 --> Database Driver Class Initialized
INFO - 2025-12-26 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:28:08 --> Form Validation Class Initialized
INFO - 2025-12-26 06:28:08 --> Controller Class Initialized
INFO - 2025-12-26 06:28:08 --> Model "User_model" initialized
DEBUG - 2025-12-26 06:28:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:28:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 06:28:08 --> Config Class Initialized
INFO - 2025-12-26 06:28:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:28:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:28:08 --> Utf8 Class Initialized
INFO - 2025-12-26 06:28:08 --> URI Class Initialized
INFO - 2025-12-26 06:28:08 --> Router Class Initialized
INFO - 2025-12-26 06:28:08 --> Output Class Initialized
INFO - 2025-12-26 06:28:08 --> Security Class Initialized
DEBUG - 2025-12-26 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:28:08 --> CSRF cookie sent
INFO - 2025-12-26 06:28:08 --> Input Class Initialized
INFO - 2025-12-26 06:28:08 --> Language Class Initialized
INFO - 2025-12-26 06:28:08 --> Loader Class Initialized
INFO - 2025-12-26 06:28:08 --> Helper loaded: url_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: form_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: file_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: html_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: security_helper
INFO - 2025-12-26 06:28:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:28:08 --> Database Driver Class Initialized
INFO - 2025-12-26 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:28:08 --> Form Validation Class Initialized
INFO - 2025-12-26 06:28:08 --> Controller Class Initialized
INFO - 2025-12-26 06:28:08 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:28:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:28:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:28:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:28:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:28:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:28:08 --> Final output sent to browser
DEBUG - 2025-12-26 06:28:08 --> Total execution time: 0.0664
INFO - 2025-12-26 06:28:23 --> Config Class Initialized
INFO - 2025-12-26 06:28:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:28:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:28:23 --> Utf8 Class Initialized
INFO - 2025-12-26 06:28:23 --> URI Class Initialized
INFO - 2025-12-26 06:28:23 --> Router Class Initialized
INFO - 2025-12-26 06:28:23 --> Output Class Initialized
INFO - 2025-12-26 06:28:23 --> Security Class Initialized
DEBUG - 2025-12-26 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:28:23 --> CSRF cookie sent
INFO - 2025-12-26 06:28:23 --> Input Class Initialized
INFO - 2025-12-26 06:28:23 --> Language Class Initialized
INFO - 2025-12-26 06:28:23 --> Loader Class Initialized
INFO - 2025-12-26 06:28:23 --> Helper loaded: url_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: form_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: file_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: html_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: security_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:28:23 --> Database Driver Class Initialized
INFO - 2025-12-26 06:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:28:23 --> Form Validation Class Initialized
INFO - 2025-12-26 06:28:23 --> Controller Class Initialized
INFO - 2025-12-26 06:28:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:28:23 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:28:23 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:28:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:28:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:28:23 --> Upload Class Initialized
INFO - 2025-12-26 06:28:23 --> Helper loaded: text_helper
INFO - 2025-12-26 06:28:23 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:28:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:28:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:28:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:28:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 06:28:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:28:23 --> Final output sent to browser
DEBUG - 2025-12-26 06:28:23 --> Total execution time: 0.1179
INFO - 2025-12-26 06:28:38 --> Config Class Initialized
INFO - 2025-12-26 06:28:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:28:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:28:38 --> Utf8 Class Initialized
INFO - 2025-12-26 06:28:38 --> URI Class Initialized
INFO - 2025-12-26 06:28:38 --> Router Class Initialized
INFO - 2025-12-26 06:28:38 --> Output Class Initialized
INFO - 2025-12-26 06:28:38 --> Security Class Initialized
DEBUG - 2025-12-26 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:28:38 --> CSRF cookie sent
INFO - 2025-12-26 06:28:38 --> Input Class Initialized
INFO - 2025-12-26 06:28:38 --> Language Class Initialized
INFO - 2025-12-26 06:28:38 --> Loader Class Initialized
INFO - 2025-12-26 06:28:38 --> Helper loaded: url_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: form_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: file_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: html_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: security_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:28:38 --> Database Driver Class Initialized
INFO - 2025-12-26 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:28:38 --> Form Validation Class Initialized
INFO - 2025-12-26 06:28:38 --> Controller Class Initialized
INFO - 2025-12-26 06:28:38 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:28:38 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:28:38 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:28:38 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:28:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:28:38 --> Upload Class Initialized
INFO - 2025-12-26 06:28:38 --> Helper loaded: text_helper
INFO - 2025-12-26 06:28:38 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:28:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:28:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:28:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:28:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 06:28:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:28:38 --> Final output sent to browser
DEBUG - 2025-12-26 06:28:38 --> Total execution time: 0.0687
INFO - 2025-12-26 06:28:55 --> Config Class Initialized
INFO - 2025-12-26 06:28:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:28:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:28:55 --> Utf8 Class Initialized
INFO - 2025-12-26 06:28:55 --> URI Class Initialized
INFO - 2025-12-26 06:28:55 --> Router Class Initialized
INFO - 2025-12-26 06:28:55 --> Output Class Initialized
INFO - 2025-12-26 06:28:55 --> Security Class Initialized
DEBUG - 2025-12-26 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:28:55 --> CSRF cookie sent
INFO - 2025-12-26 06:28:55 --> Input Class Initialized
INFO - 2025-12-26 06:28:55 --> Language Class Initialized
INFO - 2025-12-26 06:28:55 --> Loader Class Initialized
INFO - 2025-12-26 06:28:55 --> Helper loaded: url_helper
INFO - 2025-12-26 06:28:55 --> Helper loaded: form_helper
INFO - 2025-12-26 06:28:55 --> Helper loaded: file_helper
INFO - 2025-12-26 06:28:55 --> Helper loaded: html_helper
INFO - 2025-12-26 06:28:55 --> Helper loaded: security_helper
INFO - 2025-12-26 06:28:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:28:55 --> Database Driver Class Initialized
INFO - 2025-12-26 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:28:55 --> Form Validation Class Initialized
INFO - 2025-12-26 06:28:55 --> Controller Class Initialized
INFO - 2025-12-26 06:28:55 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:28:55 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:28:55 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:28:55 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:28:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:28:55 --> Upload Class Initialized
INFO - 2025-12-26 06:28:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:28:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:28:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:28:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:28:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:28:55 --> Final output sent to browser
DEBUG - 2025-12-26 06:28:55 --> Total execution time: 0.0715
INFO - 2025-12-26 06:29:06 --> Config Class Initialized
INFO - 2025-12-26 06:29:06 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:06 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:06 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:06 --> URI Class Initialized
INFO - 2025-12-26 06:29:06 --> Router Class Initialized
INFO - 2025-12-26 06:29:06 --> Output Class Initialized
INFO - 2025-12-26 06:29:06 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:06 --> CSRF cookie sent
INFO - 2025-12-26 06:29:06 --> Input Class Initialized
INFO - 2025-12-26 06:29:06 --> Language Class Initialized
INFO - 2025-12-26 06:29:06 --> Loader Class Initialized
INFO - 2025-12-26 06:29:06 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:06 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:06 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:06 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:06 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:06 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:06 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:06 --> Controller Class Initialized
INFO - 2025-12-26 06:29:06 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:29:06 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:29:06 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:29:06 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:29:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:06 --> Upload Class Initialized
INFO - 2025-12-26 06:29:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 06:29:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:06 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:06 --> Total execution time: 0.0620
INFO - 2025-12-26 06:29:13 --> Config Class Initialized
INFO - 2025-12-26 06:29:13 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:13 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:13 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:13 --> URI Class Initialized
INFO - 2025-12-26 06:29:13 --> Router Class Initialized
INFO - 2025-12-26 06:29:13 --> Output Class Initialized
INFO - 2025-12-26 06:29:13 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:13 --> CSRF cookie sent
INFO - 2025-12-26 06:29:13 --> Input Class Initialized
INFO - 2025-12-26 06:29:13 --> Language Class Initialized
INFO - 2025-12-26 06:29:13 --> Loader Class Initialized
INFO - 2025-12-26 06:29:13 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:13 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:13 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:13 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:14 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:14 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:14 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:14 --> Controller Class Initialized
INFO - 2025-12-26 06:29:14 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 06:29:14 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 06:29:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 06:29:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:14 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:14 --> Total execution time: 0.0879
INFO - 2025-12-26 06:29:23 --> Config Class Initialized
INFO - 2025-12-26 06:29:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:23 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:23 --> URI Class Initialized
INFO - 2025-12-26 06:29:23 --> Router Class Initialized
INFO - 2025-12-26 06:29:23 --> Output Class Initialized
INFO - 2025-12-26 06:29:23 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:23 --> CSRF cookie sent
INFO - 2025-12-26 06:29:23 --> Input Class Initialized
INFO - 2025-12-26 06:29:23 --> Language Class Initialized
INFO - 2025-12-26 06:29:23 --> Loader Class Initialized
INFO - 2025-12-26 06:29:23 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:23 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:23 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:23 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:23 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:23 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:23 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:23 --> Controller Class Initialized
INFO - 2025-12-26 06:29:23 --> Model "User_model" initialized
INFO - 2025-12-26 06:29:23 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 06:29:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:23 --> Upload Class Initialized
INFO - 2025-12-26 06:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 06:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:23 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:23 --> Total execution time: 0.0912
INFO - 2025-12-26 06:29:33 --> Config Class Initialized
INFO - 2025-12-26 06:29:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:33 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:33 --> URI Class Initialized
INFO - 2025-12-26 06:29:33 --> Router Class Initialized
INFO - 2025-12-26 06:29:33 --> Output Class Initialized
INFO - 2025-12-26 06:29:33 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:33 --> CSRF cookie sent
INFO - 2025-12-26 06:29:33 --> Input Class Initialized
INFO - 2025-12-26 06:29:33 --> Language Class Initialized
INFO - 2025-12-26 06:29:33 --> Loader Class Initialized
INFO - 2025-12-26 06:29:33 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:33 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:33 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:33 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:33 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:33 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:33 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:33 --> Controller Class Initialized
INFO - 2025-12-26 06:29:33 --> Model "User_model" initialized
INFO - 2025-12-26 06:29:33 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 06:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:33 --> Upload Class Initialized
INFO - 2025-12-26 06:29:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 06:29:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:33 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:33 --> Total execution time: 0.1012
INFO - 2025-12-26 06:29:45 --> Config Class Initialized
INFO - 2025-12-26 06:29:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:45 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:45 --> URI Class Initialized
INFO - 2025-12-26 06:29:45 --> Router Class Initialized
INFO - 2025-12-26 06:29:45 --> Output Class Initialized
INFO - 2025-12-26 06:29:45 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:45 --> CSRF cookie sent
INFO - 2025-12-26 06:29:45 --> Input Class Initialized
INFO - 2025-12-26 06:29:45 --> Language Class Initialized
INFO - 2025-12-26 06:29:45 --> Loader Class Initialized
INFO - 2025-12-26 06:29:45 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:45 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:45 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:45 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:45 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:45 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:45 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:45 --> Controller Class Initialized
INFO - 2025-12-26 06:29:45 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 06:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 06:29:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:45 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:45 --> Total execution time: 0.1217
INFO - 2025-12-26 06:29:58 --> Config Class Initialized
INFO - 2025-12-26 06:29:58 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:29:58 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:29:58 --> Utf8 Class Initialized
INFO - 2025-12-26 06:29:58 --> URI Class Initialized
INFO - 2025-12-26 06:29:58 --> Router Class Initialized
INFO - 2025-12-26 06:29:58 --> Output Class Initialized
INFO - 2025-12-26 06:29:58 --> Security Class Initialized
DEBUG - 2025-12-26 06:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:29:58 --> CSRF cookie sent
INFO - 2025-12-26 06:29:58 --> Input Class Initialized
INFO - 2025-12-26 06:29:58 --> Language Class Initialized
INFO - 2025-12-26 06:29:58 --> Loader Class Initialized
INFO - 2025-12-26 06:29:58 --> Helper loaded: url_helper
INFO - 2025-12-26 06:29:58 --> Helper loaded: form_helper
INFO - 2025-12-26 06:29:58 --> Helper loaded: file_helper
INFO - 2025-12-26 06:29:58 --> Helper loaded: html_helper
INFO - 2025-12-26 06:29:58 --> Helper loaded: security_helper
INFO - 2025-12-26 06:29:58 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:29:58 --> Database Driver Class Initialized
INFO - 2025-12-26 06:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:29:58 --> Form Validation Class Initialized
INFO - 2025-12-26 06:29:58 --> Controller Class Initialized
INFO - 2025-12-26 06:29:58 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 06:29:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:29:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:29:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:29:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:29:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/form.php
INFO - 2025-12-26 06:29:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:29:58 --> Final output sent to browser
DEBUG - 2025-12-26 06:29:58 --> Total execution time: 0.1577
INFO - 2025-12-26 06:30:05 --> Config Class Initialized
INFO - 2025-12-26 06:30:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:30:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:30:05 --> Utf8 Class Initialized
INFO - 2025-12-26 06:30:05 --> URI Class Initialized
INFO - 2025-12-26 06:30:05 --> Router Class Initialized
INFO - 2025-12-26 06:30:05 --> Output Class Initialized
INFO - 2025-12-26 06:30:06 --> Security Class Initialized
DEBUG - 2025-12-26 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:30:06 --> CSRF cookie sent
INFO - 2025-12-26 06:30:06 --> Input Class Initialized
INFO - 2025-12-26 06:30:06 --> Language Class Initialized
INFO - 2025-12-26 06:30:06 --> Loader Class Initialized
INFO - 2025-12-26 06:30:06 --> Helper loaded: url_helper
INFO - 2025-12-26 06:30:06 --> Helper loaded: form_helper
INFO - 2025-12-26 06:30:06 --> Helper loaded: file_helper
INFO - 2025-12-26 06:30:06 --> Helper loaded: html_helper
INFO - 2025-12-26 06:30:06 --> Helper loaded: security_helper
INFO - 2025-12-26 06:30:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:30:06 --> Database Driver Class Initialized
INFO - 2025-12-26 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:30:06 --> Form Validation Class Initialized
INFO - 2025-12-26 06:30:06 --> Controller Class Initialized
INFO - 2025-12-26 06:30:06 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 06:30:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 06:30:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:30:06 --> Final output sent to browser
DEBUG - 2025-12-26 06:30:06 --> Total execution time: 0.1509
INFO - 2025-12-26 06:30:14 --> Config Class Initialized
INFO - 2025-12-26 06:30:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:30:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:30:14 --> Utf8 Class Initialized
INFO - 2025-12-26 06:30:14 --> URI Class Initialized
INFO - 2025-12-26 06:30:14 --> Router Class Initialized
INFO - 2025-12-26 06:30:14 --> Output Class Initialized
INFO - 2025-12-26 06:30:14 --> Security Class Initialized
DEBUG - 2025-12-26 06:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:30:14 --> CSRF cookie sent
INFO - 2025-12-26 06:30:14 --> Input Class Initialized
INFO - 2025-12-26 06:30:14 --> Language Class Initialized
INFO - 2025-12-26 06:30:14 --> Loader Class Initialized
INFO - 2025-12-26 06:30:14 --> Helper loaded: url_helper
INFO - 2025-12-26 06:30:14 --> Helper loaded: form_helper
INFO - 2025-12-26 06:30:14 --> Helper loaded: file_helper
INFO - 2025-12-26 06:30:14 --> Helper loaded: html_helper
INFO - 2025-12-26 06:30:14 --> Helper loaded: security_helper
INFO - 2025-12-26 06:30:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:30:14 --> Database Driver Class Initialized
INFO - 2025-12-26 06:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:30:14 --> Form Validation Class Initialized
INFO - 2025-12-26 06:30:14 --> Controller Class Initialized
INFO - 2025-12-26 06:30:14 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 06:30:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:30:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:30:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:30:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:30:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/form.php
INFO - 2025-12-26 06:30:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:30:14 --> Final output sent to browser
DEBUG - 2025-12-26 06:30:14 --> Total execution time: 0.2395
INFO - 2025-12-26 06:30:20 --> Config Class Initialized
INFO - 2025-12-26 06:30:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:30:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:30:20 --> Utf8 Class Initialized
INFO - 2025-12-26 06:30:20 --> URI Class Initialized
INFO - 2025-12-26 06:30:20 --> Router Class Initialized
INFO - 2025-12-26 06:30:20 --> Output Class Initialized
INFO - 2025-12-26 06:30:20 --> Security Class Initialized
DEBUG - 2025-12-26 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:30:20 --> CSRF cookie sent
INFO - 2025-12-26 06:30:20 --> Input Class Initialized
INFO - 2025-12-26 06:30:20 --> Language Class Initialized
INFO - 2025-12-26 06:30:20 --> Loader Class Initialized
INFO - 2025-12-26 06:30:20 --> Helper loaded: url_helper
INFO - 2025-12-26 06:30:20 --> Helper loaded: form_helper
INFO - 2025-12-26 06:30:20 --> Helper loaded: file_helper
INFO - 2025-12-26 06:30:20 --> Helper loaded: html_helper
INFO - 2025-12-26 06:30:20 --> Helper loaded: security_helper
INFO - 2025-12-26 06:30:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:30:20 --> Database Driver Class Initialized
INFO - 2025-12-26 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:30:20 --> Form Validation Class Initialized
INFO - 2025-12-26 06:30:20 --> Controller Class Initialized
INFO - 2025-12-26 06:30:20 --> Model "Laporan_model" initialized
INFO - 2025-12-26 06:30:20 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:30:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:30:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:30:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:30:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-26 06:30:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:30:20 --> Final output sent to browser
DEBUG - 2025-12-26 06:30:20 --> Total execution time: 0.0941
INFO - 2025-12-26 06:30:27 --> Config Class Initialized
INFO - 2025-12-26 06:30:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:30:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:30:27 --> Utf8 Class Initialized
INFO - 2025-12-26 06:30:27 --> URI Class Initialized
INFO - 2025-12-26 06:30:27 --> Router Class Initialized
INFO - 2025-12-26 06:30:27 --> Output Class Initialized
INFO - 2025-12-26 06:30:27 --> Security Class Initialized
DEBUG - 2025-12-26 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:30:27 --> CSRF cookie sent
INFO - 2025-12-26 06:30:27 --> Input Class Initialized
INFO - 2025-12-26 06:30:27 --> Language Class Initialized
INFO - 2025-12-26 06:30:27 --> Loader Class Initialized
INFO - 2025-12-26 06:30:27 --> Helper loaded: url_helper
INFO - 2025-12-26 06:30:27 --> Helper loaded: form_helper
INFO - 2025-12-26 06:30:27 --> Helper loaded: file_helper
INFO - 2025-12-26 06:30:27 --> Helper loaded: html_helper
INFO - 2025-12-26 06:30:27 --> Helper loaded: security_helper
INFO - 2025-12-26 06:30:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:30:27 --> Database Driver Class Initialized
INFO - 2025-12-26 06:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:30:27 --> Form Validation Class Initialized
INFO - 2025-12-26 06:30:27 --> Controller Class Initialized
INFO - 2025-12-26 06:30:27 --> Model "Laporan_model" initialized
INFO - 2025-12-26 06:30:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:30:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:30:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:30:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:30:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_keluar.php
INFO - 2025-12-26 06:30:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:30:27 --> Final output sent to browser
DEBUG - 2025-12-26 06:30:27 --> Total execution time: 0.2410
INFO - 2025-12-26 06:30:39 --> Config Class Initialized
INFO - 2025-12-26 06:30:39 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:30:39 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:30:39 --> Utf8 Class Initialized
INFO - 2025-12-26 06:30:39 --> URI Class Initialized
INFO - 2025-12-26 06:30:39 --> Router Class Initialized
INFO - 2025-12-26 06:30:39 --> Output Class Initialized
INFO - 2025-12-26 06:30:39 --> Security Class Initialized
DEBUG - 2025-12-26 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:30:39 --> CSRF cookie sent
INFO - 2025-12-26 06:30:39 --> Input Class Initialized
INFO - 2025-12-26 06:30:39 --> Language Class Initialized
INFO - 2025-12-26 06:30:39 --> Loader Class Initialized
INFO - 2025-12-26 06:30:39 --> Helper loaded: url_helper
INFO - 2025-12-26 06:30:39 --> Helper loaded: form_helper
INFO - 2025-12-26 06:30:39 --> Helper loaded: file_helper
INFO - 2025-12-26 06:30:39 --> Helper loaded: html_helper
INFO - 2025-12-26 06:30:39 --> Helper loaded: security_helper
INFO - 2025-12-26 06:30:39 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:30:39 --> Database Driver Class Initialized
INFO - 2025-12-26 06:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:30:40 --> Form Validation Class Initialized
INFO - 2025-12-26 06:30:40 --> Controller Class Initialized
INFO - 2025-12-26 06:30:40 --> Model "User_model" initialized
INFO - 2025-12-26 06:30:40 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:30:40 --> Upload Class Initialized
INFO - 2025-12-26 06:30:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:30:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:30:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:30:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:30:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:30:40 --> Final output sent to browser
DEBUG - 2025-12-26 06:30:40 --> Total execution time: 0.0630
INFO - 2025-12-26 06:40:31 --> Config Class Initialized
INFO - 2025-12-26 06:40:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:40:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:40:31 --> Utf8 Class Initialized
INFO - 2025-12-26 06:40:31 --> URI Class Initialized
INFO - 2025-12-26 06:40:31 --> Router Class Initialized
INFO - 2025-12-26 06:40:31 --> Output Class Initialized
INFO - 2025-12-26 06:40:31 --> Security Class Initialized
DEBUG - 2025-12-26 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:40:31 --> CSRF cookie sent
INFO - 2025-12-26 06:40:31 --> Input Class Initialized
INFO - 2025-12-26 06:40:31 --> Language Class Initialized
INFO - 2025-12-26 06:40:31 --> Loader Class Initialized
INFO - 2025-12-26 06:40:31 --> Helper loaded: url_helper
INFO - 2025-12-26 06:40:31 --> Helper loaded: form_helper
INFO - 2025-12-26 06:40:31 --> Helper loaded: file_helper
INFO - 2025-12-26 06:40:31 --> Helper loaded: html_helper
INFO - 2025-12-26 06:40:31 --> Helper loaded: security_helper
INFO - 2025-12-26 06:40:31 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:40:31 --> Database Driver Class Initialized
INFO - 2025-12-26 06:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:40:31 --> Form Validation Class Initialized
INFO - 2025-12-26 06:40:31 --> Controller Class Initialized
INFO - 2025-12-26 06:40:31 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:40:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:40:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:40:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:40:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:40:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:40:31 --> Final output sent to browser
DEBUG - 2025-12-26 06:40:31 --> Total execution time: 0.0735
INFO - 2025-12-26 06:40:36 --> Config Class Initialized
INFO - 2025-12-26 06:40:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:40:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:40:36 --> Utf8 Class Initialized
INFO - 2025-12-26 06:40:36 --> URI Class Initialized
INFO - 2025-12-26 06:40:36 --> Router Class Initialized
INFO - 2025-12-26 06:40:36 --> Output Class Initialized
INFO - 2025-12-26 06:40:36 --> Security Class Initialized
DEBUG - 2025-12-26 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:40:36 --> CSRF cookie sent
INFO - 2025-12-26 06:40:36 --> Input Class Initialized
INFO - 2025-12-26 06:40:36 --> Language Class Initialized
INFO - 2025-12-26 06:40:36 --> Loader Class Initialized
INFO - 2025-12-26 06:40:36 --> Helper loaded: url_helper
INFO - 2025-12-26 06:40:36 --> Helper loaded: form_helper
INFO - 2025-12-26 06:40:36 --> Helper loaded: file_helper
INFO - 2025-12-26 06:40:36 --> Helper loaded: html_helper
INFO - 2025-12-26 06:40:36 --> Helper loaded: security_helper
INFO - 2025-12-26 06:40:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:40:36 --> Database Driver Class Initialized
INFO - 2025-12-26 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:40:36 --> Form Validation Class Initialized
INFO - 2025-12-26 06:40:36 --> Controller Class Initialized
INFO - 2025-12-26 06:40:36 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:40:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:40:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:40:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:40:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:40:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:40:36 --> Final output sent to browser
DEBUG - 2025-12-26 06:40:36 --> Total execution time: 0.0822
INFO - 2025-12-26 06:46:30 --> Config Class Initialized
INFO - 2025-12-26 06:46:30 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:46:30 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:46:30 --> Utf8 Class Initialized
INFO - 2025-12-26 06:46:30 --> URI Class Initialized
INFO - 2025-12-26 06:46:30 --> Router Class Initialized
INFO - 2025-12-26 06:46:30 --> Output Class Initialized
INFO - 2025-12-26 06:46:30 --> Security Class Initialized
DEBUG - 2025-12-26 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:46:30 --> CSRF cookie sent
INFO - 2025-12-26 06:46:30 --> Input Class Initialized
INFO - 2025-12-26 06:46:30 --> Language Class Initialized
INFO - 2025-12-26 06:46:30 --> Loader Class Initialized
INFO - 2025-12-26 06:46:30 --> Helper loaded: url_helper
INFO - 2025-12-26 06:46:30 --> Helper loaded: form_helper
INFO - 2025-12-26 06:46:30 --> Helper loaded: file_helper
INFO - 2025-12-26 06:46:30 --> Helper loaded: html_helper
INFO - 2025-12-26 06:46:30 --> Helper loaded: security_helper
INFO - 2025-12-26 06:46:30 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:46:30 --> Database Driver Class Initialized
INFO - 2025-12-26 06:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:46:30 --> Form Validation Class Initialized
INFO - 2025-12-26 06:46:30 --> Controller Class Initialized
INFO - 2025-12-26 06:46:30 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:46:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:46:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:46:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:46:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:46:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:46:30 --> Final output sent to browser
DEBUG - 2025-12-26 06:46:30 --> Total execution time: 0.1137
INFO - 2025-12-26 06:46:32 --> Config Class Initialized
INFO - 2025-12-26 06:46:32 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:46:32 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:46:32 --> Utf8 Class Initialized
INFO - 2025-12-26 06:46:32 --> URI Class Initialized
INFO - 2025-12-26 06:46:32 --> Router Class Initialized
INFO - 2025-12-26 06:46:32 --> Output Class Initialized
INFO - 2025-12-26 06:46:32 --> Security Class Initialized
DEBUG - 2025-12-26 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:46:32 --> CSRF cookie sent
INFO - 2025-12-26 06:46:32 --> Input Class Initialized
INFO - 2025-12-26 06:46:32 --> Language Class Initialized
INFO - 2025-12-26 06:46:32 --> Loader Class Initialized
INFO - 2025-12-26 06:46:32 --> Helper loaded: url_helper
INFO - 2025-12-26 06:46:32 --> Helper loaded: form_helper
INFO - 2025-12-26 06:46:32 --> Helper loaded: file_helper
INFO - 2025-12-26 06:46:32 --> Helper loaded: html_helper
INFO - 2025-12-26 06:46:32 --> Helper loaded: security_helper
INFO - 2025-12-26 06:46:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:46:32 --> Database Driver Class Initialized
INFO - 2025-12-26 06:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:46:32 --> Form Validation Class Initialized
INFO - 2025-12-26 06:46:32 --> Controller Class Initialized
INFO - 2025-12-26 06:46:32 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:46:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:46:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:46:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:46:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:46:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:46:32 --> Final output sent to browser
DEBUG - 2025-12-26 06:46:32 --> Total execution time: 0.0554
INFO - 2025-12-26 06:46:34 --> Config Class Initialized
INFO - 2025-12-26 06:46:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:46:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:46:34 --> Utf8 Class Initialized
INFO - 2025-12-26 06:46:34 --> URI Class Initialized
INFO - 2025-12-26 06:46:34 --> Router Class Initialized
INFO - 2025-12-26 06:46:34 --> Output Class Initialized
INFO - 2025-12-26 06:46:34 --> Security Class Initialized
DEBUG - 2025-12-26 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:46:34 --> CSRF cookie sent
INFO - 2025-12-26 06:46:34 --> Input Class Initialized
INFO - 2025-12-26 06:46:34 --> Language Class Initialized
INFO - 2025-12-26 06:46:34 --> Loader Class Initialized
INFO - 2025-12-26 06:46:34 --> Helper loaded: url_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: form_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: file_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: html_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: security_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:46:34 --> Database Driver Class Initialized
INFO - 2025-12-26 06:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:46:34 --> Form Validation Class Initialized
INFO - 2025-12-26 06:46:34 --> Controller Class Initialized
INFO - 2025-12-26 06:46:34 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:46:34 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:46:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:46:34 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:46:34 --> Upload Class Initialized
INFO - 2025-12-26 06:46:34 --> Helper loaded: text_helper
INFO - 2025-12-26 06:46:34 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:46:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:46:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:46:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:46:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 06:46:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:46:34 --> Final output sent to browser
DEBUG - 2025-12-26 06:46:34 --> Total execution time: 0.1270
INFO - 2025-12-26 06:46:35 --> Config Class Initialized
INFO - 2025-12-26 06:46:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:46:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:46:35 --> Utf8 Class Initialized
INFO - 2025-12-26 06:46:35 --> URI Class Initialized
INFO - 2025-12-26 06:46:35 --> Router Class Initialized
INFO - 2025-12-26 06:46:35 --> Output Class Initialized
INFO - 2025-12-26 06:46:35 --> Security Class Initialized
DEBUG - 2025-12-26 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:46:35 --> CSRF cookie sent
INFO - 2025-12-26 06:46:35 --> Input Class Initialized
INFO - 2025-12-26 06:46:35 --> Language Class Initialized
INFO - 2025-12-26 06:46:35 --> Loader Class Initialized
INFO - 2025-12-26 06:46:35 --> Helper loaded: url_helper
INFO - 2025-12-26 06:46:35 --> Helper loaded: form_helper
INFO - 2025-12-26 06:46:35 --> Helper loaded: file_helper
INFO - 2025-12-26 06:46:35 --> Helper loaded: html_helper
INFO - 2025-12-26 06:46:35 --> Helper loaded: security_helper
INFO - 2025-12-26 06:46:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:46:35 --> Database Driver Class Initialized
INFO - 2025-12-26 06:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:46:35 --> Form Validation Class Initialized
INFO - 2025-12-26 06:46:35 --> Controller Class Initialized
INFO - 2025-12-26 06:46:35 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:46:35 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:46:35 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:46:35 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:46:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:46:35 --> Upload Class Initialized
INFO - 2025-12-26 06:46:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:46:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:46:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:46:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:46:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:46:35 --> Final output sent to browser
DEBUG - 2025-12-26 06:46:35 --> Total execution time: 0.0890
INFO - 2025-12-26 06:46:40 --> Config Class Initialized
INFO - 2025-12-26 06:46:40 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:46:40 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:46:40 --> Utf8 Class Initialized
INFO - 2025-12-26 06:46:40 --> URI Class Initialized
INFO - 2025-12-26 06:46:40 --> Router Class Initialized
INFO - 2025-12-26 06:46:40 --> Output Class Initialized
INFO - 2025-12-26 06:46:40 --> Security Class Initialized
DEBUG - 2025-12-26 06:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:46:40 --> CSRF cookie sent
INFO - 2025-12-26 06:46:40 --> Input Class Initialized
INFO - 2025-12-26 06:46:40 --> Language Class Initialized
INFO - 2025-12-26 06:46:40 --> Loader Class Initialized
INFO - 2025-12-26 06:46:40 --> Helper loaded: url_helper
INFO - 2025-12-26 06:46:40 --> Helper loaded: form_helper
INFO - 2025-12-26 06:46:40 --> Helper loaded: file_helper
INFO - 2025-12-26 06:46:40 --> Helper loaded: html_helper
INFO - 2025-12-26 06:46:40 --> Helper loaded: security_helper
INFO - 2025-12-26 06:46:40 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:46:40 --> Database Driver Class Initialized
INFO - 2025-12-26 06:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:46:40 --> Form Validation Class Initialized
INFO - 2025-12-26 06:46:40 --> Controller Class Initialized
INFO - 2025-12-26 06:46:40 --> Model "User_model" initialized
INFO - 2025-12-26 06:46:40 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:46:40 --> Upload Class Initialized
INFO - 2025-12-26 06:46:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:46:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:46:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:46:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:46:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:46:40 --> Final output sent to browser
DEBUG - 2025-12-26 06:46:40 --> Total execution time: 0.0575
INFO - 2025-12-26 06:48:28 --> Config Class Initialized
INFO - 2025-12-26 06:48:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:48:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:48:28 --> Utf8 Class Initialized
INFO - 2025-12-26 06:48:28 --> URI Class Initialized
INFO - 2025-12-26 06:48:28 --> Router Class Initialized
INFO - 2025-12-26 06:48:28 --> Output Class Initialized
INFO - 2025-12-26 06:48:28 --> Security Class Initialized
DEBUG - 2025-12-26 06:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:48:28 --> CSRF cookie sent
INFO - 2025-12-26 06:48:28 --> Input Class Initialized
INFO - 2025-12-26 06:48:28 --> Language Class Initialized
INFO - 2025-12-26 06:48:28 --> Loader Class Initialized
INFO - 2025-12-26 06:48:28 --> Helper loaded: url_helper
INFO - 2025-12-26 06:48:28 --> Helper loaded: form_helper
INFO - 2025-12-26 06:48:28 --> Helper loaded: file_helper
INFO - 2025-12-26 06:48:28 --> Helper loaded: html_helper
INFO - 2025-12-26 06:48:28 --> Helper loaded: security_helper
INFO - 2025-12-26 06:48:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:48:28 --> Database Driver Class Initialized
INFO - 2025-12-26 06:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:48:28 --> Form Validation Class Initialized
INFO - 2025-12-26 06:48:28 --> Controller Class Initialized
INFO - 2025-12-26 06:48:28 --> Model "User_model" initialized
INFO - 2025-12-26 06:48:28 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:48:28 --> Upload Class Initialized
INFO - 2025-12-26 06:48:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:48:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:48:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:48:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:48:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:48:28 --> Final output sent to browser
DEBUG - 2025-12-26 06:48:28 --> Total execution time: 0.0936
INFO - 2025-12-26 06:50:08 --> Config Class Initialized
INFO - 2025-12-26 06:50:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:08 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:08 --> URI Class Initialized
INFO - 2025-12-26 06:50:08 --> Router Class Initialized
INFO - 2025-12-26 06:50:08 --> Output Class Initialized
INFO - 2025-12-26 06:50:08 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:08 --> CSRF cookie sent
INFO - 2025-12-26 06:50:08 --> Input Class Initialized
INFO - 2025-12-26 06:50:08 --> Language Class Initialized
INFO - 2025-12-26 06:50:08 --> Loader Class Initialized
INFO - 2025-12-26 06:50:08 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:08 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:08 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:08 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:08 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:08 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:08 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:08 --> Controller Class Initialized
INFO - 2025-12-26 06:50:08 --> Model "User_model" initialized
INFO - 2025-12-26 06:50:08 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:08 --> Upload Class Initialized
INFO - 2025-12-26 06:50:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:50:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:08 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:08 --> Total execution time: 0.0829
INFO - 2025-12-26 06:50:09 --> Config Class Initialized
INFO - 2025-12-26 06:50:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:09 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:09 --> URI Class Initialized
INFO - 2025-12-26 06:50:09 --> Router Class Initialized
INFO - 2025-12-26 06:50:09 --> Output Class Initialized
INFO - 2025-12-26 06:50:09 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:09 --> CSRF cookie sent
INFO - 2025-12-26 06:50:09 --> Input Class Initialized
INFO - 2025-12-26 06:50:09 --> Language Class Initialized
INFO - 2025-12-26 06:50:09 --> Loader Class Initialized
INFO - 2025-12-26 06:50:09 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:09 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:09 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:09 --> Controller Class Initialized
INFO - 2025-12-26 06:50:09 --> Model "User_model" initialized
INFO - 2025-12-26 06:50:09 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:09 --> Upload Class Initialized
INFO - 2025-12-26 06:50:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:50:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:09 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:09 --> Total execution time: 0.0832
INFO - 2025-12-26 06:50:09 --> Config Class Initialized
INFO - 2025-12-26 06:50:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:09 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:09 --> URI Class Initialized
INFO - 2025-12-26 06:50:09 --> Router Class Initialized
INFO - 2025-12-26 06:50:09 --> Output Class Initialized
INFO - 2025-12-26 06:50:09 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:09 --> CSRF cookie sent
INFO - 2025-12-26 06:50:09 --> Input Class Initialized
INFO - 2025-12-26 06:50:09 --> Language Class Initialized
INFO - 2025-12-26 06:50:09 --> Loader Class Initialized
INFO - 2025-12-26 06:50:09 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:09 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:09 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:09 --> Controller Class Initialized
INFO - 2025-12-26 06:50:09 --> Model "User_model" initialized
INFO - 2025-12-26 06:50:10 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:10 --> Upload Class Initialized
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:10 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:10 --> Total execution time: 0.0830
INFO - 2025-12-26 06:50:10 --> Config Class Initialized
INFO - 2025-12-26 06:50:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:10 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:10 --> URI Class Initialized
INFO - 2025-12-26 06:50:10 --> Router Class Initialized
INFO - 2025-12-26 06:50:10 --> Output Class Initialized
INFO - 2025-12-26 06:50:10 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:10 --> CSRF cookie sent
INFO - 2025-12-26 06:50:10 --> Input Class Initialized
INFO - 2025-12-26 06:50:10 --> Language Class Initialized
INFO - 2025-12-26 06:50:10 --> Loader Class Initialized
INFO - 2025-12-26 06:50:10 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:10 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:10 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:10 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:10 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:10 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:10 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:10 --> Controller Class Initialized
INFO - 2025-12-26 06:50:10 --> Model "User_model" initialized
INFO - 2025-12-26 06:50:10 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:10 --> Upload Class Initialized
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-26 06:50:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:10 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:10 --> Total execution time: 0.1299
INFO - 2025-12-26 06:50:11 --> Config Class Initialized
INFO - 2025-12-26 06:50:11 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:11 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:11 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:11 --> URI Class Initialized
INFO - 2025-12-26 06:50:11 --> Router Class Initialized
INFO - 2025-12-26 06:50:11 --> Output Class Initialized
INFO - 2025-12-26 06:50:11 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:11 --> CSRF cookie sent
INFO - 2025-12-26 06:50:11 --> Input Class Initialized
INFO - 2025-12-26 06:50:11 --> Language Class Initialized
INFO - 2025-12-26 06:50:11 --> Loader Class Initialized
INFO - 2025-12-26 06:50:11 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:11 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:11 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:11 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:11 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:11 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:11 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:11 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:11 --> Controller Class Initialized
INFO - 2025-12-26 06:50:11 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:50:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:50:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:11 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:11 --> Total execution time: 0.0813
INFO - 2025-12-26 06:50:12 --> Config Class Initialized
INFO - 2025-12-26 06:50:12 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:12 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:12 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:12 --> URI Class Initialized
INFO - 2025-12-26 06:50:12 --> Router Class Initialized
INFO - 2025-12-26 06:50:12 --> Output Class Initialized
INFO - 2025-12-26 06:50:12 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:12 --> CSRF cookie sent
INFO - 2025-12-26 06:50:12 --> Input Class Initialized
INFO - 2025-12-26 06:50:12 --> Language Class Initialized
INFO - 2025-12-26 06:50:12 --> Loader Class Initialized
INFO - 2025-12-26 06:50:12 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:12 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:12 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:12 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:12 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:12 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:12 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:12 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:12 --> Controller Class Initialized
INFO - 2025-12-26 06:50:12 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 06:50:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 06:50:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:12 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:12 --> Total execution time: 0.0667
INFO - 2025-12-26 06:50:13 --> Config Class Initialized
INFO - 2025-12-26 06:50:13 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:13 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:13 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:13 --> URI Class Initialized
INFO - 2025-12-26 06:50:13 --> Router Class Initialized
INFO - 2025-12-26 06:50:13 --> Output Class Initialized
INFO - 2025-12-26 06:50:13 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:13 --> CSRF cookie sent
INFO - 2025-12-26 06:50:13 --> Input Class Initialized
INFO - 2025-12-26 06:50:13 --> Language Class Initialized
INFO - 2025-12-26 06:50:13 --> Loader Class Initialized
INFO - 2025-12-26 06:50:13 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:13 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:13 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:13 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:13 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:13 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:13 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:13 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:13 --> Controller Class Initialized
INFO - 2025-12-26 06:50:13 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:50:13 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:13 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:50:13 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:50:13 --> Upload Class Initialized
INFO - 2025-12-26 06:50:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:50:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:13 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:13 --> Total execution time: 0.0730
INFO - 2025-12-26 06:50:15 --> Config Class Initialized
INFO - 2025-12-26 06:50:15 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:15 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:15 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:15 --> URI Class Initialized
INFO - 2025-12-26 06:50:15 --> Router Class Initialized
INFO - 2025-12-26 06:50:15 --> Output Class Initialized
INFO - 2025-12-26 06:50:15 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:15 --> CSRF cookie sent
INFO - 2025-12-26 06:50:15 --> Input Class Initialized
INFO - 2025-12-26 06:50:15 --> Language Class Initialized
INFO - 2025-12-26 06:50:15 --> Loader Class Initialized
INFO - 2025-12-26 06:50:15 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:15 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:15 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:15 --> Controller Class Initialized
INFO - 2025-12-26 06:50:15 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:50:15 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:15 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:50:15 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:50:15 --> Upload Class Initialized
INFO - 2025-12-26 06:50:15 --> Helper loaded: text_helper
INFO - 2025-12-26 06:50:15 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:50:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 06:50:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:15 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:15 --> Total execution time: 0.0812
INFO - 2025-12-26 06:50:17 --> Config Class Initialized
INFO - 2025-12-26 06:50:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:50:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:50:17 --> Utf8 Class Initialized
INFO - 2025-12-26 06:50:17 --> URI Class Initialized
INFO - 2025-12-26 06:50:17 --> Router Class Initialized
INFO - 2025-12-26 06:50:17 --> Output Class Initialized
INFO - 2025-12-26 06:50:17 --> Security Class Initialized
DEBUG - 2025-12-26 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:50:17 --> CSRF cookie sent
INFO - 2025-12-26 06:50:17 --> Input Class Initialized
INFO - 2025-12-26 06:50:17 --> Language Class Initialized
INFO - 2025-12-26 06:50:17 --> Loader Class Initialized
INFO - 2025-12-26 06:50:17 --> Helper loaded: url_helper
INFO - 2025-12-26 06:50:17 --> Helper loaded: form_helper
INFO - 2025-12-26 06:50:17 --> Helper loaded: file_helper
INFO - 2025-12-26 06:50:17 --> Helper loaded: html_helper
INFO - 2025-12-26 06:50:17 --> Helper loaded: security_helper
INFO - 2025-12-26 06:50:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:50:17 --> Database Driver Class Initialized
INFO - 2025-12-26 06:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:50:17 --> Form Validation Class Initialized
INFO - 2025-12-26 06:50:17 --> Controller Class Initialized
INFO - 2025-12-26 06:50:17 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:50:17 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:50:17 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:50:17 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:50:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:50:17 --> Upload Class Initialized
INFO - 2025-12-26 06:50:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:50:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:50:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:50:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:50:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:50:17 --> Final output sent to browser
DEBUG - 2025-12-26 06:50:17 --> Total execution time: 0.0612
INFO - 2025-12-26 06:52:29 --> Config Class Initialized
INFO - 2025-12-26 06:52:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:52:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:52:29 --> Utf8 Class Initialized
INFO - 2025-12-26 06:52:29 --> URI Class Initialized
INFO - 2025-12-26 06:52:29 --> Router Class Initialized
INFO - 2025-12-26 06:52:29 --> Output Class Initialized
INFO - 2025-12-26 06:52:29 --> Security Class Initialized
DEBUG - 2025-12-26 06:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:52:29 --> CSRF cookie sent
INFO - 2025-12-26 06:52:29 --> Input Class Initialized
INFO - 2025-12-26 06:52:29 --> Language Class Initialized
INFO - 2025-12-26 06:52:29 --> Loader Class Initialized
INFO - 2025-12-26 06:52:29 --> Helper loaded: url_helper
INFO - 2025-12-26 06:52:29 --> Helper loaded: form_helper
INFO - 2025-12-26 06:52:29 --> Helper loaded: file_helper
INFO - 2025-12-26 06:52:29 --> Helper loaded: html_helper
INFO - 2025-12-26 06:52:29 --> Helper loaded: security_helper
INFO - 2025-12-26 06:52:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:52:29 --> Database Driver Class Initialized
INFO - 2025-12-26 06:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:52:29 --> Form Validation Class Initialized
INFO - 2025-12-26 06:52:29 --> Controller Class Initialized
INFO - 2025-12-26 06:52:29 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:52:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:52:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:52:29 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:52:29 --> Upload Class Initialized
INFO - 2025-12-26 06:52:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:52:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:52:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:52:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:52:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:52:29 --> Final output sent to browser
DEBUG - 2025-12-26 06:52:29 --> Total execution time: 0.0797
INFO - 2025-12-26 06:52:30 --> Config Class Initialized
INFO - 2025-12-26 06:52:30 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:52:30 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:52:30 --> Utf8 Class Initialized
INFO - 2025-12-26 06:52:30 --> URI Class Initialized
INFO - 2025-12-26 06:52:30 --> Router Class Initialized
INFO - 2025-12-26 06:52:30 --> Output Class Initialized
INFO - 2025-12-26 06:52:30 --> Security Class Initialized
DEBUG - 2025-12-26 06:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:52:30 --> CSRF cookie sent
INFO - 2025-12-26 06:52:30 --> Input Class Initialized
INFO - 2025-12-26 06:52:30 --> Language Class Initialized
INFO - 2025-12-26 06:52:30 --> Loader Class Initialized
INFO - 2025-12-26 06:52:30 --> Helper loaded: url_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: form_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: file_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: html_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: security_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:52:30 --> Database Driver Class Initialized
INFO - 2025-12-26 06:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:52:30 --> Form Validation Class Initialized
INFO - 2025-12-26 06:52:30 --> Controller Class Initialized
INFO - 2025-12-26 06:52:30 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:52:30 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:52:30 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:52:30 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:52:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:52:30 --> Upload Class Initialized
INFO - 2025-12-26 06:52:30 --> Helper loaded: text_helper
INFO - 2025-12-26 06:52:30 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:52:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:52:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:52:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:52:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 06:52:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:52:30 --> Final output sent to browser
DEBUG - 2025-12-26 06:52:30 --> Total execution time: 0.0792
INFO - 2025-12-26 06:52:32 --> Config Class Initialized
INFO - 2025-12-26 06:52:32 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:52:32 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:52:32 --> Utf8 Class Initialized
INFO - 2025-12-26 06:52:32 --> URI Class Initialized
INFO - 2025-12-26 06:52:32 --> Router Class Initialized
INFO - 2025-12-26 06:52:32 --> Output Class Initialized
INFO - 2025-12-26 06:52:32 --> Security Class Initialized
DEBUG - 2025-12-26 06:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:52:32 --> CSRF cookie sent
INFO - 2025-12-26 06:52:32 --> Input Class Initialized
INFO - 2025-12-26 06:52:32 --> Language Class Initialized
INFO - 2025-12-26 06:52:32 --> Loader Class Initialized
INFO - 2025-12-26 06:52:32 --> Helper loaded: url_helper
INFO - 2025-12-26 06:52:32 --> Helper loaded: form_helper
INFO - 2025-12-26 06:52:32 --> Helper loaded: file_helper
INFO - 2025-12-26 06:52:32 --> Helper loaded: html_helper
INFO - 2025-12-26 06:52:32 --> Helper loaded: security_helper
INFO - 2025-12-26 06:52:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:52:32 --> Database Driver Class Initialized
INFO - 2025-12-26 06:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:52:32 --> Form Validation Class Initialized
INFO - 2025-12-26 06:52:32 --> Controller Class Initialized
INFO - 2025-12-26 06:52:32 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 06:52:32 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:52:32 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:52:32 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 06:52:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:52:32 --> Upload Class Initialized
INFO - 2025-12-26 06:52:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:52:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:52:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:52:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 06:52:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:52:32 --> Final output sent to browser
DEBUG - 2025-12-26 06:52:32 --> Total execution time: 0.0769
INFO - 2025-12-26 06:52:34 --> Config Class Initialized
INFO - 2025-12-26 06:52:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 06:52:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 06:52:34 --> Utf8 Class Initialized
INFO - 2025-12-26 06:52:34 --> URI Class Initialized
INFO - 2025-12-26 06:52:34 --> Router Class Initialized
INFO - 2025-12-26 06:52:34 --> Output Class Initialized
INFO - 2025-12-26 06:52:34 --> Security Class Initialized
DEBUG - 2025-12-26 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 06:52:34 --> CSRF cookie sent
INFO - 2025-12-26 06:52:34 --> Input Class Initialized
INFO - 2025-12-26 06:52:34 --> Language Class Initialized
INFO - 2025-12-26 06:52:34 --> Loader Class Initialized
INFO - 2025-12-26 06:52:34 --> Helper loaded: url_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: form_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: file_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: html_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: security_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 06:52:34 --> Database Driver Class Initialized
INFO - 2025-12-26 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 06:52:34 --> Form Validation Class Initialized
INFO - 2025-12-26 06:52:34 --> Controller Class Initialized
INFO - 2025-12-26 06:52:34 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 06:52:34 --> Model "Bagian_model" initialized
INFO - 2025-12-26 06:52:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 06:52:34 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 06:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 06:52:34 --> Upload Class Initialized
INFO - 2025-12-26 06:52:34 --> Helper loaded: text_helper
INFO - 2025-12-26 06:52:34 --> Helper loaded: custom_helper
INFO - 2025-12-26 06:52:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 06:52:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 06:52:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 06:52:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 06:52:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 06:52:34 --> Final output sent to browser
DEBUG - 2025-12-26 06:52:34 --> Total execution time: 0.0749
INFO - 2025-12-26 07:00:03 --> Config Class Initialized
INFO - 2025-12-26 07:00:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:00:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:00:03 --> Utf8 Class Initialized
INFO - 2025-12-26 07:00:03 --> URI Class Initialized
INFO - 2025-12-26 07:00:03 --> Router Class Initialized
INFO - 2025-12-26 07:00:03 --> Output Class Initialized
INFO - 2025-12-26 07:00:03 --> Security Class Initialized
DEBUG - 2025-12-26 07:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:00:03 --> CSRF cookie sent
INFO - 2025-12-26 07:00:03 --> Input Class Initialized
INFO - 2025-12-26 07:00:03 --> Language Class Initialized
INFO - 2025-12-26 07:00:03 --> Loader Class Initialized
INFO - 2025-12-26 07:00:03 --> Helper loaded: url_helper
INFO - 2025-12-26 07:00:03 --> Helper loaded: form_helper
INFO - 2025-12-26 07:00:03 --> Helper loaded: file_helper
INFO - 2025-12-26 07:00:03 --> Helper loaded: html_helper
INFO - 2025-12-26 07:00:03 --> Helper loaded: security_helper
INFO - 2025-12-26 07:00:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:00:03 --> Database Driver Class Initialized
INFO - 2025-12-26 07:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:00:03 --> Form Validation Class Initialized
INFO - 2025-12-26 07:00:03 --> Controller Class Initialized
ERROR - 2025-12-26 07:00:03 --> Severity: Compile Error --> Cannot redeclare Surat_keluar_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_keluar_model.php 53
INFO - 2025-12-26 07:01:43 --> Config Class Initialized
INFO - 2025-12-26 07:01:43 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:01:43 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:01:43 --> Utf8 Class Initialized
INFO - 2025-12-26 07:01:43 --> URI Class Initialized
INFO - 2025-12-26 07:01:43 --> Router Class Initialized
INFO - 2025-12-26 07:01:43 --> Output Class Initialized
INFO - 2025-12-26 07:01:43 --> Security Class Initialized
DEBUG - 2025-12-26 07:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:01:43 --> CSRF cookie sent
INFO - 2025-12-26 07:01:43 --> Input Class Initialized
INFO - 2025-12-26 07:01:43 --> Language Class Initialized
INFO - 2025-12-26 07:01:43 --> Loader Class Initialized
INFO - 2025-12-26 07:01:43 --> Helper loaded: url_helper
INFO - 2025-12-26 07:01:43 --> Helper loaded: form_helper
INFO - 2025-12-26 07:01:43 --> Helper loaded: file_helper
INFO - 2025-12-26 07:01:43 --> Helper loaded: html_helper
INFO - 2025-12-26 07:01:43 --> Helper loaded: security_helper
INFO - 2025-12-26 07:01:43 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:01:43 --> Database Driver Class Initialized
INFO - 2025-12-26 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:01:43 --> Form Validation Class Initialized
INFO - 2025-12-26 07:01:43 --> Controller Class Initialized
INFO - 2025-12-26 07:01:43 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:01:43 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:01:43 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:01:43 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:01:43 --> Upload Class Initialized
INFO - 2025-12-26 07:01:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:01:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:01:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:01:44 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 55
ERROR - 2025-12-26 07:01:44 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 55
INFO - 2025-12-26 07:01:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:01:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:01:44 --> Final output sent to browser
DEBUG - 2025-12-26 07:01:44 --> Total execution time: 0.3336
INFO - 2025-12-26 07:03:58 --> Config Class Initialized
INFO - 2025-12-26 07:03:58 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:03:58 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:03:58 --> Utf8 Class Initialized
INFO - 2025-12-26 07:03:58 --> URI Class Initialized
INFO - 2025-12-26 07:03:58 --> Router Class Initialized
INFO - 2025-12-26 07:03:58 --> Output Class Initialized
INFO - 2025-12-26 07:03:58 --> Security Class Initialized
DEBUG - 2025-12-26 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:03:58 --> CSRF cookie sent
INFO - 2025-12-26 07:03:58 --> Input Class Initialized
INFO - 2025-12-26 07:03:58 --> Language Class Initialized
INFO - 2025-12-26 07:03:58 --> Loader Class Initialized
INFO - 2025-12-26 07:03:58 --> Helper loaded: url_helper
INFO - 2025-12-26 07:03:58 --> Helper loaded: form_helper
INFO - 2025-12-26 07:03:58 --> Helper loaded: file_helper
INFO - 2025-12-26 07:03:58 --> Helper loaded: html_helper
INFO - 2025-12-26 07:03:58 --> Helper loaded: security_helper
INFO - 2025-12-26 07:03:58 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:03:58 --> Database Driver Class Initialized
INFO - 2025-12-26 07:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:03:58 --> Form Validation Class Initialized
INFO - 2025-12-26 07:03:58 --> Controller Class Initialized
INFO - 2025-12-26 07:03:58 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:03:58 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:03:58 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:03:58 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:03:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:03:58 --> Upload Class Initialized
INFO - 2025-12-26 07:03:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:03:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:03:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:03:58 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 42
ERROR - 2025-12-26 07:03:58 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 42
INFO - 2025-12-26 07:03:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:03:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:03:58 --> Final output sent to browser
DEBUG - 2025-12-26 07:03:58 --> Total execution time: 0.3247
INFO - 2025-12-26 07:04:36 --> Config Class Initialized
INFO - 2025-12-26 07:04:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:04:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:04:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:04:36 --> URI Class Initialized
INFO - 2025-12-26 07:04:36 --> Router Class Initialized
INFO - 2025-12-26 07:04:36 --> Output Class Initialized
INFO - 2025-12-26 07:04:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:04:36 --> CSRF cookie sent
INFO - 2025-12-26 07:04:36 --> Input Class Initialized
INFO - 2025-12-26 07:04:36 --> Language Class Initialized
INFO - 2025-12-26 07:04:36 --> Loader Class Initialized
INFO - 2025-12-26 07:04:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:04:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:04:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:04:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:04:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:04:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:04:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:04:37 --> Form Validation Class Initialized
INFO - 2025-12-26 07:04:37 --> Controller Class Initialized
INFO - 2025-12-26 07:04:37 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:04:37 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:04:37 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:04:37 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:04:37 --> Upload Class Initialized
INFO - 2025-12-26 07:04:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:04:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:04:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:04:37 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
ERROR - 2025-12-26 07:04:37 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
INFO - 2025-12-26 07:04:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:04:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:04:37 --> Final output sent to browser
DEBUG - 2025-12-26 07:04:37 --> Total execution time: 0.2760
INFO - 2025-12-26 07:04:38 --> Config Class Initialized
INFO - 2025-12-26 07:04:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:04:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:04:38 --> Utf8 Class Initialized
INFO - 2025-12-26 07:04:38 --> URI Class Initialized
INFO - 2025-12-26 07:04:38 --> Router Class Initialized
INFO - 2025-12-26 07:04:38 --> Output Class Initialized
INFO - 2025-12-26 07:04:38 --> Security Class Initialized
DEBUG - 2025-12-26 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:04:38 --> CSRF cookie sent
INFO - 2025-12-26 07:04:38 --> Input Class Initialized
INFO - 2025-12-26 07:04:38 --> Language Class Initialized
INFO - 2025-12-26 07:04:38 --> Loader Class Initialized
INFO - 2025-12-26 07:04:38 --> Helper loaded: url_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: form_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: file_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: html_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: security_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:04:38 --> Database Driver Class Initialized
INFO - 2025-12-26 07:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:04:38 --> Form Validation Class Initialized
INFO - 2025-12-26 07:04:38 --> Controller Class Initialized
INFO - 2025-12-26 07:04:38 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:04:38 --> Upload Class Initialized
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:04:38 --> Final output sent to browser
DEBUG - 2025-12-26 07:04:38 --> Total execution time: 0.0809
INFO - 2025-12-26 07:04:38 --> Config Class Initialized
INFO - 2025-12-26 07:04:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:04:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:04:38 --> Utf8 Class Initialized
INFO - 2025-12-26 07:04:38 --> URI Class Initialized
INFO - 2025-12-26 07:04:38 --> Router Class Initialized
INFO - 2025-12-26 07:04:38 --> Output Class Initialized
INFO - 2025-12-26 07:04:38 --> Security Class Initialized
DEBUG - 2025-12-26 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:04:38 --> CSRF cookie sent
INFO - 2025-12-26 07:04:38 --> Input Class Initialized
INFO - 2025-12-26 07:04:38 --> Language Class Initialized
INFO - 2025-12-26 07:04:38 --> Loader Class Initialized
INFO - 2025-12-26 07:04:38 --> Helper loaded: url_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: form_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: file_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: html_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: security_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:04:38 --> Database Driver Class Initialized
INFO - 2025-12-26 07:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:04:38 --> Form Validation Class Initialized
INFO - 2025-12-26 07:04:38 --> Controller Class Initialized
INFO - 2025-12-26 07:04:38 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:04:38 --> Upload Class Initialized
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:04:38 --> Final output sent to browser
DEBUG - 2025-12-26 07:04:38 --> Total execution time: 0.0923
INFO - 2025-12-26 07:04:38 --> Config Class Initialized
INFO - 2025-12-26 07:04:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:04:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:04:38 --> Utf8 Class Initialized
INFO - 2025-12-26 07:04:38 --> URI Class Initialized
INFO - 2025-12-26 07:04:38 --> Router Class Initialized
INFO - 2025-12-26 07:04:38 --> Output Class Initialized
INFO - 2025-12-26 07:04:38 --> Security Class Initialized
DEBUG - 2025-12-26 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:04:38 --> CSRF cookie sent
INFO - 2025-12-26 07:04:38 --> Input Class Initialized
INFO - 2025-12-26 07:04:38 --> Language Class Initialized
INFO - 2025-12-26 07:04:38 --> Loader Class Initialized
INFO - 2025-12-26 07:04:38 --> Helper loaded: url_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: form_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: file_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: html_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: security_helper
INFO - 2025-12-26 07:04:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:04:38 --> Database Driver Class Initialized
INFO - 2025-12-26 07:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:04:38 --> Form Validation Class Initialized
INFO - 2025-12-26 07:04:38 --> Controller Class Initialized
INFO - 2025-12-26 07:04:38 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:04:38 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:04:38 --> Upload Class Initialized
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
ERROR - 2025-12-26 07:04:38 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 45
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:04:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:04:38 --> Final output sent to browser
DEBUG - 2025-12-26 07:04:38 --> Total execution time: 0.1318
INFO - 2025-12-26 07:04:55 --> Config Class Initialized
INFO - 2025-12-26 07:04:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:04:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:04:55 --> Utf8 Class Initialized
INFO - 2025-12-26 07:04:55 --> URI Class Initialized
INFO - 2025-12-26 07:04:55 --> Router Class Initialized
INFO - 2025-12-26 07:04:55 --> Output Class Initialized
INFO - 2025-12-26 07:04:55 --> Security Class Initialized
DEBUG - 2025-12-26 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:04:55 --> CSRF cookie sent
INFO - 2025-12-26 07:04:55 --> Input Class Initialized
INFO - 2025-12-26 07:04:55 --> Language Class Initialized
INFO - 2025-12-26 07:04:55 --> Loader Class Initialized
INFO - 2025-12-26 07:04:55 --> Helper loaded: url_helper
INFO - 2025-12-26 07:04:55 --> Helper loaded: form_helper
INFO - 2025-12-26 07:04:55 --> Helper loaded: file_helper
INFO - 2025-12-26 07:04:55 --> Helper loaded: html_helper
INFO - 2025-12-26 07:04:55 --> Helper loaded: security_helper
INFO - 2025-12-26 07:04:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:04:55 --> Database Driver Class Initialized
INFO - 2025-12-26 07:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:04:55 --> Form Validation Class Initialized
INFO - 2025-12-26 07:04:55 --> Controller Class Initialized
INFO - 2025-12-26 07:04:55 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:04:55 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:04:55 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:04:55 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:04:55 --> Upload Class Initialized
INFO - 2025-12-26 07:04:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:04:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:04:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:04:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:04:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:04:55 --> Final output sent to browser
DEBUG - 2025-12-26 07:04:55 --> Total execution time: 0.2869
INFO - 2025-12-26 07:05:14 --> Config Class Initialized
INFO - 2025-12-26 07:05:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:05:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:05:14 --> Utf8 Class Initialized
INFO - 2025-12-26 07:05:14 --> URI Class Initialized
INFO - 2025-12-26 07:05:14 --> Router Class Initialized
INFO - 2025-12-26 07:05:14 --> Output Class Initialized
INFO - 2025-12-26 07:05:14 --> Security Class Initialized
DEBUG - 2025-12-26 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:05:14 --> CSRF cookie sent
INFO - 2025-12-26 07:05:14 --> Input Class Initialized
INFO - 2025-12-26 07:05:14 --> Language Class Initialized
INFO - 2025-12-26 07:05:14 --> Loader Class Initialized
INFO - 2025-12-26 07:05:14 --> Helper loaded: url_helper
INFO - 2025-12-26 07:05:14 --> Helper loaded: form_helper
INFO - 2025-12-26 07:05:14 --> Helper loaded: file_helper
INFO - 2025-12-26 07:05:14 --> Helper loaded: html_helper
INFO - 2025-12-26 07:05:14 --> Helper loaded: security_helper
INFO - 2025-12-26 07:05:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:05:14 --> Database Driver Class Initialized
INFO - 2025-12-26 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:05:14 --> Form Validation Class Initialized
INFO - 2025-12-26 07:05:14 --> Controller Class Initialized
INFO - 2025-12-26 07:05:14 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:05:14 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:05:14 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:05:14 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:05:14 --> Upload Class Initialized
INFO - 2025-12-26 07:05:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:05:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:05:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:05:14 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:05:14 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
INFO - 2025-12-26 07:05:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:05:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:05:14 --> Final output sent to browser
DEBUG - 2025-12-26 07:05:14 --> Total execution time: 0.2955
INFO - 2025-12-26 07:06:22 --> Config Class Initialized
INFO - 2025-12-26 07:06:22 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:06:22 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:06:22 --> Utf8 Class Initialized
INFO - 2025-12-26 07:06:22 --> URI Class Initialized
INFO - 2025-12-26 07:06:22 --> Router Class Initialized
INFO - 2025-12-26 07:06:22 --> Output Class Initialized
INFO - 2025-12-26 07:06:22 --> Security Class Initialized
DEBUG - 2025-12-26 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:06:22 --> CSRF cookie sent
INFO - 2025-12-26 07:06:22 --> Input Class Initialized
INFO - 2025-12-26 07:06:22 --> Language Class Initialized
INFO - 2025-12-26 07:06:22 --> Loader Class Initialized
INFO - 2025-12-26 07:06:22 --> Helper loaded: url_helper
INFO - 2025-12-26 07:06:22 --> Helper loaded: form_helper
INFO - 2025-12-26 07:06:22 --> Helper loaded: file_helper
INFO - 2025-12-26 07:06:22 --> Helper loaded: html_helper
INFO - 2025-12-26 07:06:22 --> Helper loaded: security_helper
INFO - 2025-12-26 07:06:22 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:06:22 --> Database Driver Class Initialized
INFO - 2025-12-26 07:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:06:22 --> Form Validation Class Initialized
INFO - 2025-12-26 07:06:22 --> Controller Class Initialized
INFO - 2025-12-26 07:06:22 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:06:22 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:06:22 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:06:22 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:06:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:06:22 --> Upload Class Initialized
INFO - 2025-12-26 07:06:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:06:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:06:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
INFO - 2025-12-26 07:06:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:06:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:06:23 --> Final output sent to browser
DEBUG - 2025-12-26 07:06:23 --> Total execution time: 0.2042
INFO - 2025-12-26 07:06:24 --> Config Class Initialized
INFO - 2025-12-26 07:06:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:06:24 --> Utf8 Class Initialized
INFO - 2025-12-26 07:06:24 --> URI Class Initialized
INFO - 2025-12-26 07:06:24 --> Router Class Initialized
INFO - 2025-12-26 07:06:24 --> Output Class Initialized
INFO - 2025-12-26 07:06:24 --> Security Class Initialized
DEBUG - 2025-12-26 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:06:24 --> CSRF cookie sent
INFO - 2025-12-26 07:06:24 --> Input Class Initialized
INFO - 2025-12-26 07:06:24 --> Language Class Initialized
INFO - 2025-12-26 07:06:24 --> Loader Class Initialized
INFO - 2025-12-26 07:06:24 --> Helper loaded: url_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: form_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: file_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: html_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: security_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:06:24 --> Database Driver Class Initialized
INFO - 2025-12-26 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:06:24 --> Form Validation Class Initialized
INFO - 2025-12-26 07:06:24 --> Controller Class Initialized
INFO - 2025-12-26 07:06:24 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:06:24 --> Upload Class Initialized
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:06:24 --> Final output sent to browser
DEBUG - 2025-12-26 07:06:24 --> Total execution time: 0.1038
INFO - 2025-12-26 07:06:24 --> Config Class Initialized
INFO - 2025-12-26 07:06:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:06:24 --> Utf8 Class Initialized
INFO - 2025-12-26 07:06:24 --> URI Class Initialized
INFO - 2025-12-26 07:06:24 --> Router Class Initialized
INFO - 2025-12-26 07:06:24 --> Output Class Initialized
INFO - 2025-12-26 07:06:24 --> Security Class Initialized
DEBUG - 2025-12-26 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:06:24 --> CSRF cookie sent
INFO - 2025-12-26 07:06:24 --> Input Class Initialized
INFO - 2025-12-26 07:06:24 --> Language Class Initialized
INFO - 2025-12-26 07:06:24 --> Loader Class Initialized
INFO - 2025-12-26 07:06:24 --> Helper loaded: url_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: form_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: file_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: html_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: security_helper
INFO - 2025-12-26 07:06:24 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:06:24 --> Database Driver Class Initialized
INFO - 2025-12-26 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:06:24 --> Form Validation Class Initialized
INFO - 2025-12-26 07:06:24 --> Controller Class Initialized
INFO - 2025-12-26 07:06:24 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:06:24 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:06:24 --> Upload Class Initialized
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 23
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 46
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 63
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
ERROR - 2025-12-26 07:06:24 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 77
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:06:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:06:24 --> Final output sent to browser
DEBUG - 2025-12-26 07:06:24 --> Total execution time: 0.1408
INFO - 2025-12-26 07:07:36 --> Config Class Initialized
INFO - 2025-12-26 07:07:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:07:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:07:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:07:36 --> URI Class Initialized
INFO - 2025-12-26 07:07:36 --> Router Class Initialized
INFO - 2025-12-26 07:07:36 --> Output Class Initialized
INFO - 2025-12-26 07:07:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:07:36 --> CSRF cookie sent
INFO - 2025-12-26 07:07:36 --> Input Class Initialized
INFO - 2025-12-26 07:07:36 --> Language Class Initialized
INFO - 2025-12-26 07:07:36 --> Loader Class Initialized
INFO - 2025-12-26 07:07:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:07:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:07:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:07:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:07:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:07:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:07:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:07:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:07:36 --> Controller Class Initialized
INFO - 2025-12-26 07:07:36 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:07:36 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:07:36 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:07:36 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:07:36 --> Upload Class Initialized
INFO - 2025-12-26 07:07:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:07:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:07:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:07:36 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 56
ERROR - 2025-12-26 07:07:36 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 56
INFO - 2025-12-26 07:07:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:07:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:07:36 --> Final output sent to browser
DEBUG - 2025-12-26 07:07:36 --> Total execution time: 0.3441
INFO - 2025-12-26 07:07:37 --> Config Class Initialized
INFO - 2025-12-26 07:07:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:07:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:07:37 --> Utf8 Class Initialized
INFO - 2025-12-26 07:07:37 --> URI Class Initialized
INFO - 2025-12-26 07:07:37 --> Router Class Initialized
INFO - 2025-12-26 07:07:37 --> Output Class Initialized
INFO - 2025-12-26 07:07:37 --> Security Class Initialized
DEBUG - 2025-12-26 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:07:37 --> CSRF cookie sent
INFO - 2025-12-26 07:07:37 --> Input Class Initialized
INFO - 2025-12-26 07:07:37 --> Language Class Initialized
INFO - 2025-12-26 07:07:37 --> Loader Class Initialized
INFO - 2025-12-26 07:07:37 --> Helper loaded: url_helper
INFO - 2025-12-26 07:07:37 --> Helper loaded: form_helper
INFO - 2025-12-26 07:07:37 --> Helper loaded: file_helper
INFO - 2025-12-26 07:07:37 --> Helper loaded: html_helper
INFO - 2025-12-26 07:07:37 --> Helper loaded: security_helper
INFO - 2025-12-26 07:07:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:07:37 --> Database Driver Class Initialized
INFO - 2025-12-26 07:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:07:37 --> Form Validation Class Initialized
INFO - 2025-12-26 07:07:37 --> Controller Class Initialized
INFO - 2025-12-26 07:07:37 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:07:37 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:07:37 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:07:37 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:07:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:07:37 --> Upload Class Initialized
INFO - 2025-12-26 07:07:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:07:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:07:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:07:37 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 56
ERROR - 2025-12-26 07:07:37 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 56
INFO - 2025-12-26 07:07:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:07:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:07:37 --> Final output sent to browser
DEBUG - 2025-12-26 07:07:37 --> Total execution time: 0.0670
INFO - 2025-12-26 07:08:02 --> Config Class Initialized
INFO - 2025-12-26 07:08:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:08:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:08:02 --> Utf8 Class Initialized
INFO - 2025-12-26 07:08:02 --> URI Class Initialized
INFO - 2025-12-26 07:08:02 --> Router Class Initialized
INFO - 2025-12-26 07:08:02 --> Output Class Initialized
INFO - 2025-12-26 07:08:02 --> Security Class Initialized
DEBUG - 2025-12-26 07:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:08:02 --> CSRF cookie sent
INFO - 2025-12-26 07:08:02 --> Input Class Initialized
INFO - 2025-12-26 07:08:02 --> Language Class Initialized
INFO - 2025-12-26 07:08:02 --> Loader Class Initialized
INFO - 2025-12-26 07:08:02 --> Helper loaded: url_helper
INFO - 2025-12-26 07:08:02 --> Helper loaded: form_helper
INFO - 2025-12-26 07:08:02 --> Helper loaded: file_helper
INFO - 2025-12-26 07:08:02 --> Helper loaded: html_helper
INFO - 2025-12-26 07:08:02 --> Helper loaded: security_helper
INFO - 2025-12-26 07:08:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:08:02 --> Database Driver Class Initialized
INFO - 2025-12-26 07:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:08:02 --> Form Validation Class Initialized
INFO - 2025-12-26 07:08:02 --> Controller Class Initialized
INFO - 2025-12-26 07:08:02 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:08:02 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:08:02 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:08:02 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:08:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:08:02 --> Upload Class Initialized
INFO - 2025-12-26 07:08:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:08:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:08:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-26 07:08:02 --> Severity: Warning --> Undefined variable $filter D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
ERROR - 2025-12-26 07:08:02 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 53
INFO - 2025-12-26 07:08:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:08:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:08:02 --> Final output sent to browser
DEBUG - 2025-12-26 07:08:02 --> Total execution time: 0.3005
INFO - 2025-12-26 07:09:20 --> Config Class Initialized
INFO - 2025-12-26 07:09:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:09:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:09:20 --> Utf8 Class Initialized
INFO - 2025-12-26 07:09:20 --> URI Class Initialized
INFO - 2025-12-26 07:09:20 --> Router Class Initialized
INFO - 2025-12-26 07:09:20 --> Output Class Initialized
INFO - 2025-12-26 07:09:20 --> Security Class Initialized
DEBUG - 2025-12-26 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:09:20 --> CSRF cookie sent
INFO - 2025-12-26 07:09:20 --> Input Class Initialized
INFO - 2025-12-26 07:09:20 --> Language Class Initialized
INFO - 2025-12-26 07:09:20 --> Loader Class Initialized
INFO - 2025-12-26 07:09:20 --> Helper loaded: url_helper
INFO - 2025-12-26 07:09:20 --> Helper loaded: form_helper
INFO - 2025-12-26 07:09:20 --> Helper loaded: file_helper
INFO - 2025-12-26 07:09:20 --> Helper loaded: html_helper
INFO - 2025-12-26 07:09:20 --> Helper loaded: security_helper
INFO - 2025-12-26 07:09:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:09:20 --> Database Driver Class Initialized
INFO - 2025-12-26 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:09:20 --> Form Validation Class Initialized
INFO - 2025-12-26 07:09:20 --> Controller Class Initialized
INFO - 2025-12-26 07:09:20 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:09:20 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:09:20 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:09:20 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:09:20 --> Upload Class Initialized
INFO - 2025-12-26 07:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:09:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:09:20 --> Final output sent to browser
DEBUG - 2025-12-26 07:09:20 --> Total execution time: 0.1620
INFO - 2025-12-26 07:09:23 --> Config Class Initialized
INFO - 2025-12-26 07:09:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:09:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:09:23 --> Utf8 Class Initialized
INFO - 2025-12-26 07:09:23 --> URI Class Initialized
INFO - 2025-12-26 07:09:23 --> Router Class Initialized
INFO - 2025-12-26 07:09:23 --> Output Class Initialized
INFO - 2025-12-26 07:09:23 --> Security Class Initialized
DEBUG - 2025-12-26 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:09:23 --> CSRF cookie sent
INFO - 2025-12-26 07:09:23 --> Input Class Initialized
INFO - 2025-12-26 07:09:23 --> Language Class Initialized
INFO - 2025-12-26 07:09:23 --> Loader Class Initialized
INFO - 2025-12-26 07:09:23 --> Helper loaded: url_helper
INFO - 2025-12-26 07:09:23 --> Helper loaded: form_helper
INFO - 2025-12-26 07:09:23 --> Helper loaded: file_helper
INFO - 2025-12-26 07:09:23 --> Helper loaded: html_helper
INFO - 2025-12-26 07:09:23 --> Helper loaded: security_helper
INFO - 2025-12-26 07:09:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:09:23 --> Database Driver Class Initialized
INFO - 2025-12-26 07:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:09:23 --> Form Validation Class Initialized
INFO - 2025-12-26 07:09:23 --> Controller Class Initialized
INFO - 2025-12-26 07:09:23 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:09:23 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:09:23 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:09:23 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:09:23 --> Upload Class Initialized
INFO - 2025-12-26 07:09:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:09:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:09:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:09:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:09:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:09:23 --> Final output sent to browser
DEBUG - 2025-12-26 07:09:23 --> Total execution time: 0.0651
INFO - 2025-12-26 07:10:19 --> Config Class Initialized
INFO - 2025-12-26 07:10:19 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:10:19 --> Utf8 Class Initialized
INFO - 2025-12-26 07:10:19 --> URI Class Initialized
INFO - 2025-12-26 07:10:19 --> Router Class Initialized
INFO - 2025-12-26 07:10:19 --> Output Class Initialized
INFO - 2025-12-26 07:10:19 --> Security Class Initialized
DEBUG - 2025-12-26 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:10:19 --> CSRF cookie sent
INFO - 2025-12-26 07:10:19 --> Input Class Initialized
INFO - 2025-12-26 07:10:19 --> Language Class Initialized
INFO - 2025-12-26 07:10:19 --> Loader Class Initialized
INFO - 2025-12-26 07:10:19 --> Helper loaded: url_helper
INFO - 2025-12-26 07:10:20 --> Helper loaded: form_helper
INFO - 2025-12-26 07:10:20 --> Helper loaded: file_helper
INFO - 2025-12-26 07:10:20 --> Helper loaded: html_helper
INFO - 2025-12-26 07:10:20 --> Helper loaded: security_helper
INFO - 2025-12-26 07:10:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:10:20 --> Database Driver Class Initialized
INFO - 2025-12-26 07:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:10:20 --> Form Validation Class Initialized
INFO - 2025-12-26 07:10:20 --> Controller Class Initialized
INFO - 2025-12-26 07:10:20 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:10:20 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:10:20 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:10:20 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:10:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:10:20 --> Upload Class Initialized
INFO - 2025-12-26 07:10:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:10:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:10:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:10:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:10:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:10:20 --> Final output sent to browser
DEBUG - 2025-12-26 07:10:20 --> Total execution time: 0.1740
INFO - 2025-12-26 07:10:42 --> Config Class Initialized
INFO - 2025-12-26 07:10:42 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:10:42 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:10:42 --> Utf8 Class Initialized
INFO - 2025-12-26 07:10:42 --> URI Class Initialized
INFO - 2025-12-26 07:10:42 --> Router Class Initialized
INFO - 2025-12-26 07:10:42 --> Output Class Initialized
INFO - 2025-12-26 07:10:42 --> Security Class Initialized
DEBUG - 2025-12-26 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:10:42 --> CSRF cookie sent
INFO - 2025-12-26 07:10:42 --> Input Class Initialized
INFO - 2025-12-26 07:10:42 --> Language Class Initialized
INFO - 2025-12-26 07:10:42 --> Loader Class Initialized
INFO - 2025-12-26 07:10:42 --> Helper loaded: url_helper
INFO - 2025-12-26 07:10:42 --> Helper loaded: form_helper
INFO - 2025-12-26 07:10:42 --> Helper loaded: file_helper
INFO - 2025-12-26 07:10:42 --> Helper loaded: html_helper
INFO - 2025-12-26 07:10:42 --> Helper loaded: security_helper
INFO - 2025-12-26 07:10:42 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:10:42 --> Database Driver Class Initialized
INFO - 2025-12-26 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:10:42 --> Form Validation Class Initialized
INFO - 2025-12-26 07:10:42 --> Controller Class Initialized
INFO - 2025-12-26 07:10:42 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:10:42 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:10:42 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:10:42 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:10:42 --> Upload Class Initialized
INFO - 2025-12-26 07:10:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:10:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:10:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:10:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:10:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:10:42 --> Final output sent to browser
DEBUG - 2025-12-26 07:10:42 --> Total execution time: 0.2598
INFO - 2025-12-26 07:12:12 --> Config Class Initialized
INFO - 2025-12-26 07:12:12 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:12 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:12 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:12 --> URI Class Initialized
INFO - 2025-12-26 07:12:12 --> Router Class Initialized
INFO - 2025-12-26 07:12:12 --> Output Class Initialized
INFO - 2025-12-26 07:12:12 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:12 --> CSRF cookie sent
INFO - 2025-12-26 07:12:12 --> Input Class Initialized
INFO - 2025-12-26 07:12:12 --> Language Class Initialized
INFO - 2025-12-26 07:12:12 --> Loader Class Initialized
INFO - 2025-12-26 07:12:12 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:12 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:12 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:12 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:12 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:12 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:12 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:12 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:12 --> Controller Class Initialized
INFO - 2025-12-26 07:12:12 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:12:12 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:12:12 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:12:12 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:12:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:12:12 --> Upload Class Initialized
INFO - 2025-12-26 07:12:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:12:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:12 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:12 --> Total execution time: 0.3283
INFO - 2025-12-26 07:12:23 --> Config Class Initialized
INFO - 2025-12-26 07:12:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:23 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:23 --> URI Class Initialized
DEBUG - 2025-12-26 07:12:23 --> No URI present. Default controller set.
INFO - 2025-12-26 07:12:23 --> Router Class Initialized
INFO - 2025-12-26 07:12:23 --> Output Class Initialized
INFO - 2025-12-26 07:12:23 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:23 --> CSRF cookie sent
INFO - 2025-12-26 07:12:23 --> Input Class Initialized
INFO - 2025-12-26 07:12:23 --> Language Class Initialized
INFO - 2025-12-26 07:12:23 --> Loader Class Initialized
INFO - 2025-12-26 07:12:23 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:23 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:23 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:23 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:23 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:23 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:23 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:23 --> Controller Class Initialized
INFO - 2025-12-26 07:12:23 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 07:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 07:12:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:23 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:23 --> Total execution time: 0.0657
INFO - 2025-12-26 07:12:26 --> Config Class Initialized
INFO - 2025-12-26 07:12:26 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:26 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:26 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:26 --> URI Class Initialized
INFO - 2025-12-26 07:12:26 --> Router Class Initialized
INFO - 2025-12-26 07:12:26 --> Output Class Initialized
INFO - 2025-12-26 07:12:26 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:26 --> CSRF cookie sent
INFO - 2025-12-26 07:12:26 --> Input Class Initialized
INFO - 2025-12-26 07:12:26 --> Language Class Initialized
INFO - 2025-12-26 07:12:26 --> Loader Class Initialized
INFO - 2025-12-26 07:12:26 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:26 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:26 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:26 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:26 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:26 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:26 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:26 --> Controller Class Initialized
INFO - 2025-12-26 07:12:26 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:12:26 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:12:26 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:12:26 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:12:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:12:26 --> Upload Class Initialized
INFO - 2025-12-26 07:12:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:12:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:26 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:26 --> Total execution time: 0.0698
INFO - 2025-12-26 07:12:42 --> Config Class Initialized
INFO - 2025-12-26 07:12:42 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:42 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:42 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:42 --> URI Class Initialized
INFO - 2025-12-26 07:12:42 --> Router Class Initialized
INFO - 2025-12-26 07:12:42 --> Output Class Initialized
INFO - 2025-12-26 07:12:42 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:42 --> CSRF cookie sent
INFO - 2025-12-26 07:12:42 --> Input Class Initialized
INFO - 2025-12-26 07:12:42 --> Language Class Initialized
INFO - 2025-12-26 07:12:42 --> Loader Class Initialized
INFO - 2025-12-26 07:12:42 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:42 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:42 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:42 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:42 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:42 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:42 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:42 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:42 --> Controller Class Initialized
INFO - 2025-12-26 07:12:42 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:12:42 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:12:42 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:12:42 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:12:42 --> Upload Class Initialized
INFO - 2025-12-26 07:12:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:12:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:42 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:42 --> Total execution time: 0.0669
INFO - 2025-12-26 07:12:44 --> Config Class Initialized
INFO - 2025-12-26 07:12:44 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:44 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:44 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:44 --> URI Class Initialized
INFO - 2025-12-26 07:12:44 --> Router Class Initialized
INFO - 2025-12-26 07:12:44 --> Output Class Initialized
INFO - 2025-12-26 07:12:44 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:44 --> CSRF cookie sent
INFO - 2025-12-26 07:12:44 --> Input Class Initialized
INFO - 2025-12-26 07:12:44 --> Language Class Initialized
INFO - 2025-12-26 07:12:44 --> Loader Class Initialized
INFO - 2025-12-26 07:12:44 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:44 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:44 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:44 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:44 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:44 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:44 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:44 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:44 --> Controller Class Initialized
INFO - 2025-12-26 07:12:44 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:12:44 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:12:44 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:12:44 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:12:44 --> Upload Class Initialized
INFO - 2025-12-26 07:12:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:12:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:44 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:44 --> Total execution time: 0.0620
INFO - 2025-12-26 07:12:45 --> Config Class Initialized
INFO - 2025-12-26 07:12:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:45 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:45 --> URI Class Initialized
INFO - 2025-12-26 07:12:45 --> Router Class Initialized
INFO - 2025-12-26 07:12:45 --> Output Class Initialized
INFO - 2025-12-26 07:12:45 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:45 --> CSRF cookie sent
INFO - 2025-12-26 07:12:45 --> Input Class Initialized
INFO - 2025-12-26 07:12:45 --> Language Class Initialized
INFO - 2025-12-26 07:12:45 --> Loader Class Initialized
INFO - 2025-12-26 07:12:45 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:45 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:45 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:45 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:45 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:45 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:45 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:45 --> Controller Class Initialized
INFO - 2025-12-26 07:12:45 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:12:45 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:12:45 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:12:45 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:12:45 --> Upload Class Initialized
INFO - 2025-12-26 07:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:12:45 --> Final output sent to browser
DEBUG - 2025-12-26 07:12:45 --> Total execution time: 0.0670
INFO - 2025-12-26 07:12:49 --> Config Class Initialized
INFO - 2025-12-26 07:12:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:12:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:12:49 --> Utf8 Class Initialized
INFO - 2025-12-26 07:12:49 --> URI Class Initialized
INFO - 2025-12-26 07:12:49 --> Router Class Initialized
INFO - 2025-12-26 07:12:49 --> Output Class Initialized
INFO - 2025-12-26 07:12:49 --> Security Class Initialized
DEBUG - 2025-12-26 07:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:12:49 --> CSRF cookie sent
INFO - 2025-12-26 07:12:49 --> Input Class Initialized
INFO - 2025-12-26 07:12:49 --> Language Class Initialized
INFO - 2025-12-26 07:12:49 --> Loader Class Initialized
INFO - 2025-12-26 07:12:49 --> Helper loaded: url_helper
INFO - 2025-12-26 07:12:49 --> Helper loaded: form_helper
INFO - 2025-12-26 07:12:49 --> Helper loaded: file_helper
INFO - 2025-12-26 07:12:49 --> Helper loaded: html_helper
INFO - 2025-12-26 07:12:49 --> Helper loaded: security_helper
INFO - 2025-12-26 07:12:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:12:49 --> Database Driver Class Initialized
INFO - 2025-12-26 07:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:12:49 --> Form Validation Class Initialized
INFO - 2025-12-26 07:12:49 --> Controller Class Initialized
ERROR - 2025-12-26 07:12:49 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 197
INFO - 2025-12-26 07:15:34 --> Config Class Initialized
INFO - 2025-12-26 07:15:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:34 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:34 --> URI Class Initialized
INFO - 2025-12-26 07:15:34 --> Router Class Initialized
INFO - 2025-12-26 07:15:34 --> Output Class Initialized
INFO - 2025-12-26 07:15:34 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:34 --> CSRF cookie sent
INFO - 2025-12-26 07:15:34 --> Input Class Initialized
INFO - 2025-12-26 07:15:34 --> Language Class Initialized
INFO - 2025-12-26 07:15:34 --> Loader Class Initialized
INFO - 2025-12-26 07:15:34 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:34 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:34 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:34 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:34 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:34 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:34 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:34 --> Controller Class Initialized
INFO - 2025-12-26 07:15:34 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:34 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:34 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:34 --> Upload Class Initialized
INFO - 2025-12-26 07:15:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:34 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:34 --> Total execution time: 0.3096
INFO - 2025-12-26 07:15:36 --> Config Class Initialized
INFO - 2025-12-26 07:15:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:36 --> URI Class Initialized
INFO - 2025-12-26 07:15:36 --> Router Class Initialized
INFO - 2025-12-26 07:15:36 --> Output Class Initialized
INFO - 2025-12-26 07:15:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:36 --> CSRF cookie sent
INFO - 2025-12-26 07:15:36 --> Input Class Initialized
INFO - 2025-12-26 07:15:36 --> Language Class Initialized
INFO - 2025-12-26 07:15:36 --> Loader Class Initialized
INFO - 2025-12-26 07:15:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:36 --> Controller Class Initialized
INFO - 2025-12-26 07:15:36 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:36 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:36 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:36 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:36 --> Upload Class Initialized
INFO - 2025-12-26 07:15:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:36 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:36 --> Total execution time: 0.0767
INFO - 2025-12-26 07:15:47 --> Config Class Initialized
INFO - 2025-12-26 07:15:47 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:47 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:47 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:47 --> URI Class Initialized
INFO - 2025-12-26 07:15:47 --> Router Class Initialized
INFO - 2025-12-26 07:15:47 --> Output Class Initialized
INFO - 2025-12-26 07:15:47 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:47 --> CSRF cookie sent
INFO - 2025-12-26 07:15:47 --> Input Class Initialized
INFO - 2025-12-26 07:15:47 --> Language Class Initialized
INFO - 2025-12-26 07:15:47 --> Loader Class Initialized
INFO - 2025-12-26 07:15:47 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:47 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:47 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:47 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:47 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:47 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:47 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:47 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:47 --> Controller Class Initialized
INFO - 2025-12-26 07:15:47 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:47 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:47 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:47 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:47 --> Upload Class Initialized
INFO - 2025-12-26 07:15:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:47 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:47 --> Total execution time: 0.0615
INFO - 2025-12-26 07:15:48 --> Config Class Initialized
INFO - 2025-12-26 07:15:48 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:48 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:48 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:48 --> URI Class Initialized
INFO - 2025-12-26 07:15:48 --> Router Class Initialized
INFO - 2025-12-26 07:15:48 --> Output Class Initialized
INFO - 2025-12-26 07:15:48 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:48 --> CSRF cookie sent
INFO - 2025-12-26 07:15:48 --> Input Class Initialized
INFO - 2025-12-26 07:15:48 --> Language Class Initialized
INFO - 2025-12-26 07:15:48 --> Loader Class Initialized
INFO - 2025-12-26 07:15:48 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:48 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:48 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:48 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:48 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:48 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:48 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:48 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:48 --> Controller Class Initialized
INFO - 2025-12-26 07:15:48 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:48 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:48 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:48 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:48 --> Upload Class Initialized
INFO - 2025-12-26 07:15:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:48 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:48 --> Total execution time: 0.0557
INFO - 2025-12-26 07:15:49 --> Config Class Initialized
INFO - 2025-12-26 07:15:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:49 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:49 --> URI Class Initialized
INFO - 2025-12-26 07:15:49 --> Router Class Initialized
INFO - 2025-12-26 07:15:49 --> Output Class Initialized
INFO - 2025-12-26 07:15:49 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:49 --> CSRF cookie sent
INFO - 2025-12-26 07:15:49 --> Input Class Initialized
INFO - 2025-12-26 07:15:49 --> Language Class Initialized
INFO - 2025-12-26 07:15:49 --> Loader Class Initialized
INFO - 2025-12-26 07:15:49 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:49 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:49 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:49 --> Controller Class Initialized
INFO - 2025-12-26 07:15:49 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:49 --> Upload Class Initialized
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:49 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:49 --> Total execution time: 0.0587
INFO - 2025-12-26 07:15:49 --> Config Class Initialized
INFO - 2025-12-26 07:15:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:49 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:49 --> URI Class Initialized
INFO - 2025-12-26 07:15:49 --> Router Class Initialized
INFO - 2025-12-26 07:15:49 --> Output Class Initialized
INFO - 2025-12-26 07:15:49 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:49 --> CSRF cookie sent
INFO - 2025-12-26 07:15:49 --> Input Class Initialized
INFO - 2025-12-26 07:15:49 --> Language Class Initialized
INFO - 2025-12-26 07:15:49 --> Loader Class Initialized
INFO - 2025-12-26 07:15:49 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:49 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:49 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:49 --> Controller Class Initialized
INFO - 2025-12-26 07:15:49 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:49 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:49 --> Upload Class Initialized
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:49 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:49 --> Total execution time: 0.0792
INFO - 2025-12-26 07:15:50 --> Config Class Initialized
INFO - 2025-12-26 07:15:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:50 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:50 --> URI Class Initialized
INFO - 2025-12-26 07:15:50 --> Router Class Initialized
INFO - 2025-12-26 07:15:50 --> Output Class Initialized
INFO - 2025-12-26 07:15:50 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:50 --> CSRF cookie sent
INFO - 2025-12-26 07:15:50 --> Input Class Initialized
INFO - 2025-12-26 07:15:50 --> Language Class Initialized
INFO - 2025-12-26 07:15:50 --> Loader Class Initialized
INFO - 2025-12-26 07:15:50 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:50 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:50 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:50 --> Controller Class Initialized
INFO - 2025-12-26 07:15:50 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:50 --> Upload Class Initialized
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:50 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:50 --> Total execution time: 0.0905
INFO - 2025-12-26 07:15:50 --> Config Class Initialized
INFO - 2025-12-26 07:15:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:50 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:50 --> URI Class Initialized
INFO - 2025-12-26 07:15:50 --> Router Class Initialized
INFO - 2025-12-26 07:15:50 --> Output Class Initialized
INFO - 2025-12-26 07:15:50 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:50 --> CSRF cookie sent
INFO - 2025-12-26 07:15:50 --> Input Class Initialized
INFO - 2025-12-26 07:15:50 --> Language Class Initialized
INFO - 2025-12-26 07:15:50 --> Loader Class Initialized
INFO - 2025-12-26 07:15:50 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:50 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:50 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:50 --> Controller Class Initialized
INFO - 2025-12-26 07:15:50 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:50 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:50 --> Upload Class Initialized
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:50 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:50 --> Total execution time: 0.1134
INFO - 2025-12-26 07:15:51 --> Config Class Initialized
INFO - 2025-12-26 07:15:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:51 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:51 --> URI Class Initialized
INFO - 2025-12-26 07:15:51 --> Router Class Initialized
INFO - 2025-12-26 07:15:51 --> Output Class Initialized
INFO - 2025-12-26 07:15:51 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:51 --> CSRF cookie sent
INFO - 2025-12-26 07:15:51 --> Input Class Initialized
INFO - 2025-12-26 07:15:51 --> Language Class Initialized
INFO - 2025-12-26 07:15:51 --> Loader Class Initialized
INFO - 2025-12-26 07:15:51 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:51 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:51 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:51 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:51 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:51 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:51 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:51 --> Controller Class Initialized
INFO - 2025-12-26 07:15:51 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:51 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:51 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:51 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:51 --> Upload Class Initialized
INFO - 2025-12-26 07:15:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:51 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:51 --> Total execution time: 0.0710
INFO - 2025-12-26 07:15:56 --> Config Class Initialized
INFO - 2025-12-26 07:15:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:15:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:15:56 --> Utf8 Class Initialized
INFO - 2025-12-26 07:15:56 --> URI Class Initialized
INFO - 2025-12-26 07:15:56 --> Router Class Initialized
INFO - 2025-12-26 07:15:56 --> Output Class Initialized
INFO - 2025-12-26 07:15:56 --> Security Class Initialized
DEBUG - 2025-12-26 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:15:56 --> CSRF cookie sent
INFO - 2025-12-26 07:15:56 --> Input Class Initialized
INFO - 2025-12-26 07:15:56 --> Language Class Initialized
INFO - 2025-12-26 07:15:56 --> Loader Class Initialized
INFO - 2025-12-26 07:15:56 --> Helper loaded: url_helper
INFO - 2025-12-26 07:15:56 --> Helper loaded: form_helper
INFO - 2025-12-26 07:15:57 --> Helper loaded: file_helper
INFO - 2025-12-26 07:15:57 --> Helper loaded: html_helper
INFO - 2025-12-26 07:15:57 --> Helper loaded: security_helper
INFO - 2025-12-26 07:15:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:15:57 --> Database Driver Class Initialized
INFO - 2025-12-26 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:15:57 --> Form Validation Class Initialized
INFO - 2025-12-26 07:15:57 --> Controller Class Initialized
INFO - 2025-12-26 07:15:57 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:15:57 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:15:57 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:15:57 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:15:57 --> Upload Class Initialized
INFO - 2025-12-26 07:15:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:15:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:15:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:15:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:15:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:15:57 --> Final output sent to browser
DEBUG - 2025-12-26 07:15:57 --> Total execution time: 0.0571
INFO - 2025-12-26 07:16:16 --> Config Class Initialized
INFO - 2025-12-26 07:16:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:16:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:16:16 --> Utf8 Class Initialized
INFO - 2025-12-26 07:16:16 --> URI Class Initialized
INFO - 2025-12-26 07:16:16 --> Router Class Initialized
INFO - 2025-12-26 07:16:16 --> Output Class Initialized
INFO - 2025-12-26 07:16:16 --> Security Class Initialized
DEBUG - 2025-12-26 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:16:16 --> CSRF cookie sent
INFO - 2025-12-26 07:16:16 --> Input Class Initialized
INFO - 2025-12-26 07:16:16 --> Language Class Initialized
INFO - 2025-12-26 07:16:16 --> Loader Class Initialized
INFO - 2025-12-26 07:16:16 --> Helper loaded: url_helper
INFO - 2025-12-26 07:16:16 --> Helper loaded: form_helper
INFO - 2025-12-26 07:16:16 --> Helper loaded: file_helper
INFO - 2025-12-26 07:16:16 --> Helper loaded: html_helper
INFO - 2025-12-26 07:16:16 --> Helper loaded: security_helper
INFO - 2025-12-26 07:16:16 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:16:16 --> Database Driver Class Initialized
INFO - 2025-12-26 07:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:16:16 --> Form Validation Class Initialized
INFO - 2025-12-26 07:16:16 --> Controller Class Initialized
ERROR - 2025-12-26 07:16:16 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 197
INFO - 2025-12-26 07:19:07 --> Config Class Initialized
INFO - 2025-12-26 07:19:07 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:19:07 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:19:07 --> Utf8 Class Initialized
INFO - 2025-12-26 07:19:07 --> URI Class Initialized
INFO - 2025-12-26 07:19:07 --> Router Class Initialized
INFO - 2025-12-26 07:19:07 --> Output Class Initialized
INFO - 2025-12-26 07:19:07 --> Security Class Initialized
DEBUG - 2025-12-26 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:19:07 --> CSRF cookie sent
INFO - 2025-12-26 07:19:07 --> Input Class Initialized
INFO - 2025-12-26 07:19:07 --> Language Class Initialized
INFO - 2025-12-26 07:19:07 --> Loader Class Initialized
INFO - 2025-12-26 07:19:07 --> Helper loaded: url_helper
INFO - 2025-12-26 07:19:07 --> Helper loaded: form_helper
INFO - 2025-12-26 07:19:07 --> Helper loaded: file_helper
INFO - 2025-12-26 07:19:07 --> Helper loaded: html_helper
INFO - 2025-12-26 07:19:07 --> Helper loaded: security_helper
INFO - 2025-12-26 07:19:07 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:19:07 --> Database Driver Class Initialized
INFO - 2025-12-26 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:19:07 --> Form Validation Class Initialized
INFO - 2025-12-26 07:19:07 --> Controller Class Initialized
ERROR - 2025-12-26 07:19:07 --> Severity: error --> Exception: syntax error, unexpected token "{", expecting "function" or "const" D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 197
INFO - 2025-12-26 07:20:06 --> Config Class Initialized
INFO - 2025-12-26 07:20:06 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:20:06 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:20:06 --> Utf8 Class Initialized
INFO - 2025-12-26 07:20:06 --> URI Class Initialized
INFO - 2025-12-26 07:20:06 --> Router Class Initialized
INFO - 2025-12-26 07:20:06 --> Output Class Initialized
INFO - 2025-12-26 07:20:06 --> Security Class Initialized
DEBUG - 2025-12-26 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:20:06 --> CSRF cookie sent
INFO - 2025-12-26 07:20:06 --> Input Class Initialized
INFO - 2025-12-26 07:20:06 --> Language Class Initialized
INFO - 2025-12-26 07:20:06 --> Loader Class Initialized
INFO - 2025-12-26 07:20:06 --> Helper loaded: url_helper
INFO - 2025-12-26 07:20:06 --> Helper loaded: form_helper
INFO - 2025-12-26 07:20:06 --> Helper loaded: file_helper
INFO - 2025-12-26 07:20:06 --> Helper loaded: html_helper
INFO - 2025-12-26 07:20:06 --> Helper loaded: security_helper
INFO - 2025-12-26 07:20:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:20:06 --> Database Driver Class Initialized
INFO - 2025-12-26 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:20:06 --> Form Validation Class Initialized
INFO - 2025-12-26 07:20:06 --> Controller Class Initialized
ERROR - 2025-12-26 07:20:06 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 196
INFO - 2025-12-26 07:21:33 --> Config Class Initialized
INFO - 2025-12-26 07:21:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:33 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:33 --> URI Class Initialized
INFO - 2025-12-26 07:21:33 --> Router Class Initialized
INFO - 2025-12-26 07:21:33 --> Output Class Initialized
INFO - 2025-12-26 07:21:33 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:33 --> CSRF cookie sent
INFO - 2025-12-26 07:21:33 --> Input Class Initialized
INFO - 2025-12-26 07:21:33 --> Language Class Initialized
INFO - 2025-12-26 07:21:33 --> Loader Class Initialized
INFO - 2025-12-26 07:21:33 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:33 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:33 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:33 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:33 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:33 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:33 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:33 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:33 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:34 --> Config Class Initialized
INFO - 2025-12-26 07:21:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:34 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:34 --> URI Class Initialized
INFO - 2025-12-26 07:21:34 --> Router Class Initialized
INFO - 2025-12-26 07:21:34 --> Output Class Initialized
INFO - 2025-12-26 07:21:34 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:34 --> CSRF cookie sent
INFO - 2025-12-26 07:21:34 --> Input Class Initialized
INFO - 2025-12-26 07:21:34 --> Language Class Initialized
INFO - 2025-12-26 07:21:34 --> Loader Class Initialized
INFO - 2025-12-26 07:21:34 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:34 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:34 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:34 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:34 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:34 --> Config Class Initialized
INFO - 2025-12-26 07:21:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:34 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:34 --> URI Class Initialized
INFO - 2025-12-26 07:21:34 --> Router Class Initialized
INFO - 2025-12-26 07:21:34 --> Output Class Initialized
INFO - 2025-12-26 07:21:34 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:34 --> CSRF cookie sent
INFO - 2025-12-26 07:21:34 --> Input Class Initialized
INFO - 2025-12-26 07:21:34 --> Language Class Initialized
INFO - 2025-12-26 07:21:34 --> Loader Class Initialized
INFO - 2025-12-26 07:21:34 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:34 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:34 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:34 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:34 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:35 --> Config Class Initialized
INFO - 2025-12-26 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:35 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:35 --> URI Class Initialized
INFO - 2025-12-26 07:21:35 --> Router Class Initialized
INFO - 2025-12-26 07:21:35 --> Output Class Initialized
INFO - 2025-12-26 07:21:35 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:35 --> CSRF cookie sent
INFO - 2025-12-26 07:21:35 --> Input Class Initialized
INFO - 2025-12-26 07:21:35 --> Language Class Initialized
INFO - 2025-12-26 07:21:35 --> Loader Class Initialized
INFO - 2025-12-26 07:21:35 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:35 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:35 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:35 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:35 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:35 --> Config Class Initialized
INFO - 2025-12-26 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:35 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:35 --> URI Class Initialized
INFO - 2025-12-26 07:21:35 --> Router Class Initialized
INFO - 2025-12-26 07:21:35 --> Output Class Initialized
INFO - 2025-12-26 07:21:35 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:35 --> CSRF cookie sent
INFO - 2025-12-26 07:21:35 --> Input Class Initialized
INFO - 2025-12-26 07:21:35 --> Language Class Initialized
INFO - 2025-12-26 07:21:35 --> Loader Class Initialized
INFO - 2025-12-26 07:21:35 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:35 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:35 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:35 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:35 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:35 --> Config Class Initialized
INFO - 2025-12-26 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:35 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:35 --> URI Class Initialized
INFO - 2025-12-26 07:21:35 --> Router Class Initialized
INFO - 2025-12-26 07:21:35 --> Output Class Initialized
INFO - 2025-12-26 07:21:35 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:35 --> CSRF cookie sent
INFO - 2025-12-26 07:21:35 --> Input Class Initialized
INFO - 2025-12-26 07:21:35 --> Language Class Initialized
INFO - 2025-12-26 07:21:35 --> Loader Class Initialized
INFO - 2025-12-26 07:21:35 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:36 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:36 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:36 --> Config Class Initialized
INFO - 2025-12-26 07:21:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:36 --> URI Class Initialized
INFO - 2025-12-26 07:21:36 --> Router Class Initialized
INFO - 2025-12-26 07:21:36 --> Output Class Initialized
INFO - 2025-12-26 07:21:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:36 --> CSRF cookie sent
INFO - 2025-12-26 07:21:36 --> Input Class Initialized
INFO - 2025-12-26 07:21:36 --> Language Class Initialized
INFO - 2025-12-26 07:21:36 --> Loader Class Initialized
INFO - 2025-12-26 07:21:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:36 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:36 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:36 --> Config Class Initialized
INFO - 2025-12-26 07:21:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:36 --> URI Class Initialized
INFO - 2025-12-26 07:21:36 --> Router Class Initialized
INFO - 2025-12-26 07:21:36 --> Output Class Initialized
INFO - 2025-12-26 07:21:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:36 --> CSRF cookie sent
INFO - 2025-12-26 07:21:36 --> Input Class Initialized
INFO - 2025-12-26 07:21:36 --> Language Class Initialized
INFO - 2025-12-26 07:21:36 --> Loader Class Initialized
INFO - 2025-12-26 07:21:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:36 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:36 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:36 --> Config Class Initialized
INFO - 2025-12-26 07:21:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:36 --> URI Class Initialized
INFO - 2025-12-26 07:21:36 --> Router Class Initialized
INFO - 2025-12-26 07:21:36 --> Output Class Initialized
INFO - 2025-12-26 07:21:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:36 --> CSRF cookie sent
INFO - 2025-12-26 07:21:36 --> Input Class Initialized
INFO - 2025-12-26 07:21:36 --> Language Class Initialized
INFO - 2025-12-26 07:21:36 --> Loader Class Initialized
INFO - 2025-12-26 07:21:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:36 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:36 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:21:36 --> Config Class Initialized
INFO - 2025-12-26 07:21:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:21:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:21:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:21:36 --> URI Class Initialized
INFO - 2025-12-26 07:21:36 --> Router Class Initialized
INFO - 2025-12-26 07:21:36 --> Output Class Initialized
INFO - 2025-12-26 07:21:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:21:36 --> CSRF cookie sent
INFO - 2025-12-26 07:21:37 --> Input Class Initialized
INFO - 2025-12-26 07:21:37 --> Language Class Initialized
INFO - 2025-12-26 07:21:37 --> Loader Class Initialized
INFO - 2025-12-26 07:21:37 --> Helper loaded: url_helper
INFO - 2025-12-26 07:21:37 --> Helper loaded: form_helper
INFO - 2025-12-26 07:21:37 --> Helper loaded: file_helper
INFO - 2025-12-26 07:21:37 --> Helper loaded: html_helper
INFO - 2025-12-26 07:21:37 --> Helper loaded: security_helper
INFO - 2025-12-26 07:21:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:21:37 --> Database Driver Class Initialized
INFO - 2025-12-26 07:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:21:37 --> Form Validation Class Initialized
INFO - 2025-12-26 07:21:37 --> Controller Class Initialized
ERROR - 2025-12-26 07:21:37 --> Severity: Compile Error --> Cannot redeclare Surat_masuk_model::get_all() D:\xampp\htdocs\surat_itm\application\models\Surat_masuk_model.php 52
INFO - 2025-12-26 07:22:08 --> Config Class Initialized
INFO - 2025-12-26 07:22:08 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:22:08 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:22:08 --> Utf8 Class Initialized
INFO - 2025-12-26 07:22:08 --> URI Class Initialized
INFO - 2025-12-26 07:22:08 --> Router Class Initialized
INFO - 2025-12-26 07:22:08 --> Output Class Initialized
INFO - 2025-12-26 07:22:08 --> Security Class Initialized
DEBUG - 2025-12-26 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:22:08 --> CSRF cookie sent
INFO - 2025-12-26 07:22:08 --> Input Class Initialized
INFO - 2025-12-26 07:22:08 --> Language Class Initialized
INFO - 2025-12-26 07:22:08 --> Loader Class Initialized
INFO - 2025-12-26 07:22:08 --> Helper loaded: url_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: form_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: file_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: html_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: security_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:22:08 --> Database Driver Class Initialized
INFO - 2025-12-26 07:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:22:08 --> Form Validation Class Initialized
INFO - 2025-12-26 07:22:08 --> Controller Class Initialized
INFO - 2025-12-26 07:22:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:22:08 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:22:08 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:22:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:22:08 --> Upload Class Initialized
INFO - 2025-12-26 07:22:08 --> Helper loaded: text_helper
INFO - 2025-12-26 07:22:08 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:22:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:22:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:22:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:22:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:22:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:22:08 --> Final output sent to browser
DEBUG - 2025-12-26 07:22:08 --> Total execution time: 0.1002
INFO - 2025-12-26 07:22:16 --> Config Class Initialized
INFO - 2025-12-26 07:22:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:22:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:22:16 --> Utf8 Class Initialized
INFO - 2025-12-26 07:22:16 --> URI Class Initialized
INFO - 2025-12-26 07:22:16 --> Router Class Initialized
INFO - 2025-12-26 07:22:16 --> Output Class Initialized
INFO - 2025-12-26 07:22:16 --> Security Class Initialized
DEBUG - 2025-12-26 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:22:16 --> CSRF cookie sent
INFO - 2025-12-26 07:22:16 --> Input Class Initialized
INFO - 2025-12-26 07:22:16 --> Language Class Initialized
INFO - 2025-12-26 07:22:16 --> Loader Class Initialized
INFO - 2025-12-26 07:22:16 --> Helper loaded: url_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: form_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: file_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: html_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: security_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:22:16 --> Database Driver Class Initialized
INFO - 2025-12-26 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:22:16 --> Form Validation Class Initialized
INFO - 2025-12-26 07:22:16 --> Controller Class Initialized
INFO - 2025-12-26 07:22:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:22:16 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:22:16 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:22:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:22:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:22:16 --> Upload Class Initialized
INFO - 2025-12-26 07:22:16 --> Helper loaded: text_helper
INFO - 2025-12-26 07:22:16 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:22:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:22:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:22:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:22:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-26 07:22:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:22:16 --> Final output sent to browser
DEBUG - 2025-12-26 07:22:16 --> Total execution time: 0.1691
INFO - 2025-12-26 07:22:21 --> Config Class Initialized
INFO - 2025-12-26 07:22:21 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:22:21 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:22:21 --> Utf8 Class Initialized
INFO - 2025-12-26 07:22:21 --> URI Class Initialized
INFO - 2025-12-26 07:22:21 --> Router Class Initialized
INFO - 2025-12-26 07:22:21 --> Output Class Initialized
INFO - 2025-12-26 07:22:21 --> Security Class Initialized
DEBUG - 2025-12-26 07:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:22:21 --> CSRF cookie sent
INFO - 2025-12-26 07:22:21 --> Input Class Initialized
INFO - 2025-12-26 07:22:21 --> Language Class Initialized
INFO - 2025-12-26 07:22:21 --> Loader Class Initialized
INFO - 2025-12-26 07:22:21 --> Helper loaded: url_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: form_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: file_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: html_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: security_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:22:21 --> Database Driver Class Initialized
INFO - 2025-12-26 07:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:22:21 --> Form Validation Class Initialized
INFO - 2025-12-26 07:22:21 --> Controller Class Initialized
INFO - 2025-12-26 07:22:21 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:22:21 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:22:21 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:22:21 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:22:21 --> Upload Class Initialized
INFO - 2025-12-26 07:22:21 --> Helper loaded: text_helper
INFO - 2025-12-26 07:22:21 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:22:21 --> Final output sent to browser
DEBUG - 2025-12-26 07:22:21 --> Total execution time: 0.0610
INFO - 2025-12-26 07:24:02 --> Config Class Initialized
INFO - 2025-12-26 07:24:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:02 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:02 --> URI Class Initialized
INFO - 2025-12-26 07:24:02 --> Router Class Initialized
INFO - 2025-12-26 07:24:02 --> Output Class Initialized
INFO - 2025-12-26 07:24:02 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:02 --> CSRF cookie sent
INFO - 2025-12-26 07:24:02 --> Input Class Initialized
INFO - 2025-12-26 07:24:02 --> Language Class Initialized
INFO - 2025-12-26 07:24:02 --> Loader Class Initialized
INFO - 2025-12-26 07:24:02 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:02 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:02 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:02 --> Controller Class Initialized
INFO - 2025-12-26 07:24:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:24:02 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:02 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:02 --> Upload Class Initialized
INFO - 2025-12-26 07:24:02 --> Helper loaded: text_helper
INFO - 2025-12-26 07:24:02 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:24:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:24:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:02 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:02 --> Total execution time: 0.2605
INFO - 2025-12-26 07:24:05 --> Config Class Initialized
INFO - 2025-12-26 07:24:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:05 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:05 --> URI Class Initialized
INFO - 2025-12-26 07:24:05 --> Router Class Initialized
INFO - 2025-12-26 07:24:05 --> Output Class Initialized
INFO - 2025-12-26 07:24:05 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:05 --> CSRF cookie sent
INFO - 2025-12-26 07:24:05 --> Input Class Initialized
INFO - 2025-12-26 07:24:05 --> Language Class Initialized
INFO - 2025-12-26 07:24:05 --> Loader Class Initialized
INFO - 2025-12-26 07:24:05 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:05 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:05 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:05 --> Controller Class Initialized
INFO - 2025-12-26 07:24:05 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:24:05 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:05 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:05 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:05 --> Upload Class Initialized
INFO - 2025-12-26 07:24:05 --> Helper loaded: text_helper
INFO - 2025-12-26 07:24:05 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:24:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:24:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:05 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:05 --> Total execution time: 0.0552
INFO - 2025-12-26 07:24:14 --> Config Class Initialized
INFO - 2025-12-26 07:24:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:14 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:14 --> URI Class Initialized
INFO - 2025-12-26 07:24:14 --> Router Class Initialized
INFO - 2025-12-26 07:24:14 --> Output Class Initialized
INFO - 2025-12-26 07:24:14 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:14 --> CSRF cookie sent
INFO - 2025-12-26 07:24:14 --> Input Class Initialized
INFO - 2025-12-26 07:24:14 --> Language Class Initialized
INFO - 2025-12-26 07:24:14 --> Loader Class Initialized
INFO - 2025-12-26 07:24:14 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:14 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:14 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:14 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:14 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:14 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:14 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:14 --> Controller Class Initialized
INFO - 2025-12-26 07:24:14 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:14 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:14 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:14 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:14 --> Upload Class Initialized
INFO - 2025-12-26 07:24:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:14 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:14 --> Total execution time: 0.0636
INFO - 2025-12-26 07:24:16 --> Config Class Initialized
INFO - 2025-12-26 07:24:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:16 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:16 --> URI Class Initialized
INFO - 2025-12-26 07:24:16 --> Router Class Initialized
INFO - 2025-12-26 07:24:16 --> Output Class Initialized
INFO - 2025-12-26 07:24:16 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:16 --> CSRF cookie sent
INFO - 2025-12-26 07:24:16 --> Input Class Initialized
INFO - 2025-12-26 07:24:16 --> Language Class Initialized
INFO - 2025-12-26 07:24:16 --> Loader Class Initialized
INFO - 2025-12-26 07:24:16 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:16 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:16 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:16 --> Controller Class Initialized
INFO - 2025-12-26 07:24:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:24:16 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:16 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:16 --> Upload Class Initialized
INFO - 2025-12-26 07:24:16 --> Helper loaded: text_helper
INFO - 2025-12-26 07:24:16 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:24:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:24:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:16 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:16 --> Total execution time: 0.0731
INFO - 2025-12-26 07:24:18 --> Config Class Initialized
INFO - 2025-12-26 07:24:18 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:18 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:18 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:18 --> URI Class Initialized
INFO - 2025-12-26 07:24:18 --> Router Class Initialized
INFO - 2025-12-26 07:24:18 --> Output Class Initialized
INFO - 2025-12-26 07:24:18 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:18 --> CSRF cookie sent
INFO - 2025-12-26 07:24:18 --> Input Class Initialized
INFO - 2025-12-26 07:24:18 --> Language Class Initialized
INFO - 2025-12-26 07:24:18 --> Loader Class Initialized
INFO - 2025-12-26 07:24:18 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:18 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:18 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:18 --> Controller Class Initialized
INFO - 2025-12-26 07:24:18 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:24:18 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:18 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:18 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:18 --> Upload Class Initialized
INFO - 2025-12-26 07:24:18 --> Helper loaded: text_helper
INFO - 2025-12-26 07:24:18 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:24:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:24:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:18 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:18 --> Total execution time: 0.0618
INFO - 2025-12-26 07:24:20 --> Config Class Initialized
INFO - 2025-12-26 07:24:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:20 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:20 --> URI Class Initialized
INFO - 2025-12-26 07:24:20 --> Router Class Initialized
INFO - 2025-12-26 07:24:20 --> Output Class Initialized
INFO - 2025-12-26 07:24:20 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:20 --> CSRF cookie sent
INFO - 2025-12-26 07:24:20 --> Input Class Initialized
INFO - 2025-12-26 07:24:20 --> Language Class Initialized
INFO - 2025-12-26 07:24:20 --> Loader Class Initialized
INFO - 2025-12-26 07:24:20 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:20 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:20 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:20 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:20 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:20 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:20 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:20 --> Controller Class Initialized
INFO - 2025-12-26 07:24:20 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:20 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:20 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:20 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:20 --> Upload Class Initialized
INFO - 2025-12-26 07:24:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:20 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:20 --> Total execution time: 0.0595
INFO - 2025-12-26 07:24:25 --> Config Class Initialized
INFO - 2025-12-26 07:24:25 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:25 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:25 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:25 --> URI Class Initialized
INFO - 2025-12-26 07:24:25 --> Router Class Initialized
INFO - 2025-12-26 07:24:25 --> Output Class Initialized
INFO - 2025-12-26 07:24:25 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:25 --> CSRF cookie sent
INFO - 2025-12-26 07:24:25 --> Input Class Initialized
INFO - 2025-12-26 07:24:25 --> Language Class Initialized
INFO - 2025-12-26 07:24:25 --> Loader Class Initialized
INFO - 2025-12-26 07:24:25 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:25 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:25 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:25 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:25 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:25 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:25 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:25 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:25 --> Controller Class Initialized
INFO - 2025-12-26 07:24:25 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:25 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:25 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:25 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:25 --> Upload Class Initialized
INFO - 2025-12-26 07:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:25 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:25 --> Total execution time: 0.0643
INFO - 2025-12-26 07:24:27 --> Config Class Initialized
INFO - 2025-12-26 07:24:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:27 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:27 --> URI Class Initialized
INFO - 2025-12-26 07:24:27 --> Router Class Initialized
INFO - 2025-12-26 07:24:27 --> Output Class Initialized
INFO - 2025-12-26 07:24:27 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:27 --> CSRF cookie sent
INFO - 2025-12-26 07:24:27 --> Input Class Initialized
INFO - 2025-12-26 07:24:27 --> Language Class Initialized
INFO - 2025-12-26 07:24:27 --> Loader Class Initialized
INFO - 2025-12-26 07:24:27 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:27 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:27 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:27 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:27 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:27 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:27 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:27 --> Controller Class Initialized
INFO - 2025-12-26 07:24:27 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:27 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:27 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:27 --> Upload Class Initialized
INFO - 2025-12-26 07:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:27 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:27 --> Total execution time: 0.0552
INFO - 2025-12-26 07:24:33 --> Config Class Initialized
INFO - 2025-12-26 07:24:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:33 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:33 --> URI Class Initialized
INFO - 2025-12-26 07:24:33 --> Router Class Initialized
INFO - 2025-12-26 07:24:33 --> Output Class Initialized
INFO - 2025-12-26 07:24:33 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:33 --> CSRF cookie sent
INFO - 2025-12-26 07:24:33 --> Input Class Initialized
INFO - 2025-12-26 07:24:33 --> Language Class Initialized
INFO - 2025-12-26 07:24:33 --> Loader Class Initialized
INFO - 2025-12-26 07:24:33 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:33 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:33 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:33 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:33 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:33 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:33 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:33 --> Controller Class Initialized
INFO - 2025-12-26 07:24:33 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:33 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:33 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:33 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:33 --> Upload Class Initialized
INFO - 2025-12-26 07:24:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:33 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:33 --> Total execution time: 0.0559
INFO - 2025-12-26 07:24:38 --> Config Class Initialized
INFO - 2025-12-26 07:24:38 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:38 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:38 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:38 --> URI Class Initialized
INFO - 2025-12-26 07:24:38 --> Router Class Initialized
INFO - 2025-12-26 07:24:38 --> Output Class Initialized
INFO - 2025-12-26 07:24:38 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:38 --> CSRF cookie sent
INFO - 2025-12-26 07:24:38 --> Input Class Initialized
INFO - 2025-12-26 07:24:38 --> Language Class Initialized
INFO - 2025-12-26 07:24:38 --> Loader Class Initialized
INFO - 2025-12-26 07:24:38 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:38 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:38 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:38 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:38 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:38 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:38 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:38 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:38 --> Controller Class Initialized
INFO - 2025-12-26 07:24:38 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:38 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:38 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:38 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:38 --> Upload Class Initialized
INFO - 2025-12-26 07:24:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:38 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:38 --> Total execution time: 0.0566
INFO - 2025-12-26 07:24:44 --> Config Class Initialized
INFO - 2025-12-26 07:24:44 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:24:44 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:24:44 --> Utf8 Class Initialized
INFO - 2025-12-26 07:24:44 --> URI Class Initialized
INFO - 2025-12-26 07:24:44 --> Router Class Initialized
INFO - 2025-12-26 07:24:44 --> Output Class Initialized
INFO - 2025-12-26 07:24:44 --> Security Class Initialized
DEBUG - 2025-12-26 07:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:24:44 --> CSRF cookie sent
INFO - 2025-12-26 07:24:44 --> Input Class Initialized
INFO - 2025-12-26 07:24:44 --> Language Class Initialized
INFO - 2025-12-26 07:24:44 --> Loader Class Initialized
INFO - 2025-12-26 07:24:44 --> Helper loaded: url_helper
INFO - 2025-12-26 07:24:44 --> Helper loaded: form_helper
INFO - 2025-12-26 07:24:44 --> Helper loaded: file_helper
INFO - 2025-12-26 07:24:44 --> Helper loaded: html_helper
INFO - 2025-12-26 07:24:44 --> Helper loaded: security_helper
INFO - 2025-12-26 07:24:44 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:24:44 --> Database Driver Class Initialized
INFO - 2025-12-26 07:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:24:44 --> Form Validation Class Initialized
INFO - 2025-12-26 07:24:44 --> Controller Class Initialized
INFO - 2025-12-26 07:24:44 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:24:44 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:24:44 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:24:44 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:24:44 --> Upload Class Initialized
INFO - 2025-12-26 07:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:24:44 --> Final output sent to browser
DEBUG - 2025-12-26 07:24:44 --> Total execution time: 0.0602
INFO - 2025-12-26 07:27:10 --> Config Class Initialized
INFO - 2025-12-26 07:27:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:10 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:10 --> URI Class Initialized
INFO - 2025-12-26 07:27:10 --> Router Class Initialized
INFO - 2025-12-26 07:27:10 --> Output Class Initialized
INFO - 2025-12-26 07:27:10 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:10 --> CSRF cookie sent
INFO - 2025-12-26 07:27:10 --> Input Class Initialized
INFO - 2025-12-26 07:27:10 --> Language Class Initialized
INFO - 2025-12-26 07:27:10 --> Loader Class Initialized
INFO - 2025-12-26 07:27:10 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:10 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:10 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:10 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:10 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:11 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:11 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:11 --> Controller Class Initialized
INFO - 2025-12-26 07:27:11 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:11 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:11 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:11 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:11 --> Upload Class Initialized
INFO - 2025-12-26 07:27:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:11 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:11 --> Total execution time: 0.2803
INFO - 2025-12-26 07:27:15 --> Config Class Initialized
INFO - 2025-12-26 07:27:15 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:15 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:15 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:15 --> URI Class Initialized
INFO - 2025-12-26 07:27:15 --> Router Class Initialized
INFO - 2025-12-26 07:27:15 --> Output Class Initialized
INFO - 2025-12-26 07:27:15 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:15 --> CSRF cookie sent
INFO - 2025-12-26 07:27:15 --> Input Class Initialized
INFO - 2025-12-26 07:27:15 --> Language Class Initialized
INFO - 2025-12-26 07:27:15 --> Loader Class Initialized
INFO - 2025-12-26 07:27:15 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:15 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:15 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:15 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:15 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:15 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:15 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:15 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:15 --> Controller Class Initialized
INFO - 2025-12-26 07:27:15 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:15 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:15 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:15 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:15 --> Upload Class Initialized
INFO - 2025-12-26 07:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:15 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:15 --> Total execution time: 0.0807
INFO - 2025-12-26 07:27:26 --> Config Class Initialized
INFO - 2025-12-26 07:27:26 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:26 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:26 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:26 --> URI Class Initialized
INFO - 2025-12-26 07:27:26 --> Router Class Initialized
INFO - 2025-12-26 07:27:26 --> Output Class Initialized
INFO - 2025-12-26 07:27:26 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:26 --> CSRF cookie sent
INFO - 2025-12-26 07:27:26 --> Input Class Initialized
INFO - 2025-12-26 07:27:26 --> Language Class Initialized
INFO - 2025-12-26 07:27:26 --> Loader Class Initialized
INFO - 2025-12-26 07:27:26 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:26 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:26 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:26 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:26 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:26 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:26 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:26 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:26 --> Controller Class Initialized
INFO - 2025-12-26 07:27:26 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:26 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:26 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:26 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:26 --> Upload Class Initialized
INFO - 2025-12-26 07:27:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:27 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:27 --> Total execution time: 0.0691
INFO - 2025-12-26 07:27:28 --> Config Class Initialized
INFO - 2025-12-26 07:27:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:28 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:28 --> URI Class Initialized
INFO - 2025-12-26 07:27:28 --> Router Class Initialized
INFO - 2025-12-26 07:27:28 --> Output Class Initialized
INFO - 2025-12-26 07:27:28 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:28 --> CSRF cookie sent
INFO - 2025-12-26 07:27:28 --> Input Class Initialized
INFO - 2025-12-26 07:27:28 --> Language Class Initialized
INFO - 2025-12-26 07:27:28 --> Loader Class Initialized
INFO - 2025-12-26 07:27:28 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:28 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:28 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:28 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:28 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:28 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:28 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:28 --> Controller Class Initialized
INFO - 2025-12-26 07:27:28 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:28 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:28 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:28 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:28 --> Upload Class Initialized
INFO - 2025-12-26 07:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:28 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:28 --> Total execution time: 0.0596
INFO - 2025-12-26 07:27:28 --> Config Class Initialized
INFO - 2025-12-26 07:27:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:28 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:28 --> URI Class Initialized
INFO - 2025-12-26 07:27:28 --> Router Class Initialized
INFO - 2025-12-26 07:27:28 --> Output Class Initialized
INFO - 2025-12-26 07:27:28 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:28 --> CSRF cookie sent
INFO - 2025-12-26 07:27:28 --> Input Class Initialized
INFO - 2025-12-26 07:27:28 --> Language Class Initialized
INFO - 2025-12-26 07:27:28 --> Loader Class Initialized
INFO - 2025-12-26 07:27:29 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:29 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:29 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:29 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:29 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:29 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:29 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:29 --> Controller Class Initialized
INFO - 2025-12-26 07:27:29 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:29 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:29 --> Upload Class Initialized
INFO - 2025-12-26 07:27:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:29 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:29 --> Total execution time: 0.0695
INFO - 2025-12-26 07:27:34 --> Config Class Initialized
INFO - 2025-12-26 07:27:34 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:34 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:34 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:34 --> URI Class Initialized
INFO - 2025-12-26 07:27:34 --> Router Class Initialized
INFO - 2025-12-26 07:27:34 --> Output Class Initialized
INFO - 2025-12-26 07:27:34 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:34 --> CSRF cookie sent
INFO - 2025-12-26 07:27:34 --> Input Class Initialized
INFO - 2025-12-26 07:27:34 --> Language Class Initialized
INFO - 2025-12-26 07:27:34 --> Loader Class Initialized
INFO - 2025-12-26 07:27:34 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:34 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:34 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:34 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:34 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:34 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:34 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:34 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:34 --> Controller Class Initialized
INFO - 2025-12-26 07:27:34 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:34 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:34 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:34 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:35 --> Upload Class Initialized
INFO - 2025-12-26 07:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:35 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:35 --> Total execution time: 0.0745
INFO - 2025-12-26 07:27:45 --> Config Class Initialized
INFO - 2025-12-26 07:27:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:45 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:45 --> URI Class Initialized
INFO - 2025-12-26 07:27:45 --> Router Class Initialized
INFO - 2025-12-26 07:27:45 --> Output Class Initialized
INFO - 2025-12-26 07:27:45 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:45 --> CSRF cookie sent
INFO - 2025-12-26 07:27:45 --> Input Class Initialized
INFO - 2025-12-26 07:27:45 --> Language Class Initialized
INFO - 2025-12-26 07:27:45 --> Loader Class Initialized
INFO - 2025-12-26 07:27:45 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:45 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:45 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:45 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:45 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:45 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:45 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:45 --> Controller Class Initialized
INFO - 2025-12-26 07:27:45 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:45 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:45 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:45 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:45 --> Upload Class Initialized
INFO - 2025-12-26 07:27:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:45 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:45 --> Total execution time: 0.0680
INFO - 2025-12-26 07:27:50 --> Config Class Initialized
INFO - 2025-12-26 07:27:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:50 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:50 --> URI Class Initialized
INFO - 2025-12-26 07:27:50 --> Router Class Initialized
INFO - 2025-12-26 07:27:50 --> Output Class Initialized
INFO - 2025-12-26 07:27:50 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:50 --> CSRF cookie sent
INFO - 2025-12-26 07:27:50 --> Input Class Initialized
INFO - 2025-12-26 07:27:50 --> Language Class Initialized
INFO - 2025-12-26 07:27:50 --> Loader Class Initialized
INFO - 2025-12-26 07:27:50 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:50 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:50 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:50 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:50 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:50 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:50 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:50 --> Controller Class Initialized
INFO - 2025-12-26 07:27:50 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:50 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:50 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:50 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:50 --> Upload Class Initialized
INFO - 2025-12-26 07:27:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:50 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:50 --> Total execution time: 0.0632
INFO - 2025-12-26 07:27:54 --> Config Class Initialized
INFO - 2025-12-26 07:27:54 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:27:54 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:27:54 --> Utf8 Class Initialized
INFO - 2025-12-26 07:27:54 --> URI Class Initialized
INFO - 2025-12-26 07:27:54 --> Router Class Initialized
INFO - 2025-12-26 07:27:54 --> Output Class Initialized
INFO - 2025-12-26 07:27:54 --> Security Class Initialized
DEBUG - 2025-12-26 07:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:27:54 --> CSRF cookie sent
INFO - 2025-12-26 07:27:54 --> Input Class Initialized
INFO - 2025-12-26 07:27:54 --> Language Class Initialized
INFO - 2025-12-26 07:27:54 --> Loader Class Initialized
INFO - 2025-12-26 07:27:54 --> Helper loaded: url_helper
INFO - 2025-12-26 07:27:54 --> Helper loaded: form_helper
INFO - 2025-12-26 07:27:54 --> Helper loaded: file_helper
INFO - 2025-12-26 07:27:54 --> Helper loaded: html_helper
INFO - 2025-12-26 07:27:54 --> Helper loaded: security_helper
INFO - 2025-12-26 07:27:54 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:27:54 --> Database Driver Class Initialized
INFO - 2025-12-26 07:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:27:54 --> Form Validation Class Initialized
INFO - 2025-12-26 07:27:54 --> Controller Class Initialized
INFO - 2025-12-26 07:27:54 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:27:54 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:27:54 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:27:54 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:27:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:27:54 --> Upload Class Initialized
INFO - 2025-12-26 07:27:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:27:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:27:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:27:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:27:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:27:54 --> Final output sent to browser
DEBUG - 2025-12-26 07:27:54 --> Total execution time: 0.0751
INFO - 2025-12-26 07:28:52 --> Config Class Initialized
INFO - 2025-12-26 07:28:52 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:28:52 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:28:52 --> Utf8 Class Initialized
INFO - 2025-12-26 07:28:52 --> URI Class Initialized
INFO - 2025-12-26 07:28:52 --> Router Class Initialized
INFO - 2025-12-26 07:28:52 --> Output Class Initialized
INFO - 2025-12-26 07:28:52 --> Security Class Initialized
DEBUG - 2025-12-26 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:28:52 --> CSRF cookie sent
INFO - 2025-12-26 07:28:52 --> Input Class Initialized
INFO - 2025-12-26 07:28:52 --> Language Class Initialized
INFO - 2025-12-26 07:28:52 --> Loader Class Initialized
INFO - 2025-12-26 07:28:52 --> Helper loaded: url_helper
INFO - 2025-12-26 07:28:52 --> Helper loaded: form_helper
INFO - 2025-12-26 07:28:52 --> Helper loaded: file_helper
INFO - 2025-12-26 07:28:52 --> Helper loaded: html_helper
INFO - 2025-12-26 07:28:52 --> Helper loaded: security_helper
INFO - 2025-12-26 07:28:52 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:28:52 --> Database Driver Class Initialized
INFO - 2025-12-26 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:28:52 --> Form Validation Class Initialized
INFO - 2025-12-26 07:28:52 --> Controller Class Initialized
INFO - 2025-12-26 07:28:52 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:28:52 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:28:52 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:28:52 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:28:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:28:52 --> Upload Class Initialized
INFO - 2025-12-26 07:28:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:28:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:28:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:28:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:28:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:28:52 --> Final output sent to browser
DEBUG - 2025-12-26 07:28:52 --> Total execution time: 0.1366
INFO - 2025-12-26 07:28:56 --> Config Class Initialized
INFO - 2025-12-26 07:28:56 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:28:56 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:28:56 --> Utf8 Class Initialized
INFO - 2025-12-26 07:28:56 --> URI Class Initialized
INFO - 2025-12-26 07:28:56 --> Router Class Initialized
INFO - 2025-12-26 07:28:56 --> Output Class Initialized
INFO - 2025-12-26 07:28:56 --> Security Class Initialized
DEBUG - 2025-12-26 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:28:56 --> CSRF cookie sent
INFO - 2025-12-26 07:28:56 --> Input Class Initialized
INFO - 2025-12-26 07:28:56 --> Language Class Initialized
INFO - 2025-12-26 07:28:56 --> Loader Class Initialized
INFO - 2025-12-26 07:28:56 --> Helper loaded: url_helper
INFO - 2025-12-26 07:28:56 --> Helper loaded: form_helper
INFO - 2025-12-26 07:28:56 --> Helper loaded: file_helper
INFO - 2025-12-26 07:28:56 --> Helper loaded: html_helper
INFO - 2025-12-26 07:28:56 --> Helper loaded: security_helper
INFO - 2025-12-26 07:28:56 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:28:56 --> Database Driver Class Initialized
INFO - 2025-12-26 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:28:56 --> Form Validation Class Initialized
INFO - 2025-12-26 07:28:56 --> Controller Class Initialized
INFO - 2025-12-26 07:28:56 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:28:56 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:28:56 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:28:56 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:28:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:28:56 --> Upload Class Initialized
INFO - 2025-12-26 07:28:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:28:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:28:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:28:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:28:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:28:56 --> Final output sent to browser
DEBUG - 2025-12-26 07:28:56 --> Total execution time: 0.0536
INFO - 2025-12-26 07:28:58 --> Config Class Initialized
INFO - 2025-12-26 07:28:58 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:28:58 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:28:58 --> Utf8 Class Initialized
INFO - 2025-12-26 07:28:58 --> URI Class Initialized
INFO - 2025-12-26 07:28:58 --> Router Class Initialized
INFO - 2025-12-26 07:28:58 --> Output Class Initialized
INFO - 2025-12-26 07:28:58 --> Security Class Initialized
DEBUG - 2025-12-26 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:28:58 --> CSRF cookie sent
INFO - 2025-12-26 07:28:58 --> Input Class Initialized
INFO - 2025-12-26 07:28:58 --> Language Class Initialized
INFO - 2025-12-26 07:28:58 --> Loader Class Initialized
INFO - 2025-12-26 07:28:58 --> Helper loaded: url_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: form_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: file_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: html_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: security_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:28:58 --> Database Driver Class Initialized
INFO - 2025-12-26 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:28:58 --> Form Validation Class Initialized
INFO - 2025-12-26 07:28:58 --> Controller Class Initialized
INFO - 2025-12-26 07:28:58 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:28:58 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:28:58 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:28:58 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:28:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:28:58 --> Upload Class Initialized
INFO - 2025-12-26 07:28:58 --> Helper loaded: text_helper
INFO - 2025-12-26 07:28:58 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:28:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:28:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:28:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:28:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:28:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:28:58 --> Final output sent to browser
DEBUG - 2025-12-26 07:28:58 --> Total execution time: 0.0959
INFO - 2025-12-26 07:29:09 --> Config Class Initialized
INFO - 2025-12-26 07:29:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:09 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:09 --> URI Class Initialized
INFO - 2025-12-26 07:29:09 --> Router Class Initialized
INFO - 2025-12-26 07:29:09 --> Output Class Initialized
INFO - 2025-12-26 07:29:09 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:09 --> CSRF cookie sent
INFO - 2025-12-26 07:29:09 --> Input Class Initialized
INFO - 2025-12-26 07:29:09 --> Language Class Initialized
INFO - 2025-12-26 07:29:09 --> Loader Class Initialized
INFO - 2025-12-26 07:29:09 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:09 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:09 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:09 --> Controller Class Initialized
INFO - 2025-12-26 07:29:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:09 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:09 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:09 --> Upload Class Initialized
INFO - 2025-12-26 07:29:09 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:09 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:29:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:09 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:09 --> Total execution time: 0.0551
INFO - 2025-12-26 07:29:17 --> Config Class Initialized
INFO - 2025-12-26 07:29:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:17 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:17 --> URI Class Initialized
INFO - 2025-12-26 07:29:17 --> Router Class Initialized
INFO - 2025-12-26 07:29:17 --> Output Class Initialized
INFO - 2025-12-26 07:29:17 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:17 --> CSRF cookie sent
INFO - 2025-12-26 07:29:17 --> Input Class Initialized
INFO - 2025-12-26 07:29:17 --> Language Class Initialized
INFO - 2025-12-26 07:29:17 --> Loader Class Initialized
INFO - 2025-12-26 07:29:17 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:17 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:17 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:17 --> Controller Class Initialized
INFO - 2025-12-26 07:29:17 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:17 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:17 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:17 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:17 --> Upload Class Initialized
INFO - 2025-12-26 07:29:17 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:17 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:29:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:17 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:17 --> Total execution time: 0.0912
INFO - 2025-12-26 07:29:23 --> Config Class Initialized
INFO - 2025-12-26 07:29:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:23 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:23 --> URI Class Initialized
INFO - 2025-12-26 07:29:23 --> Router Class Initialized
INFO - 2025-12-26 07:29:23 --> Output Class Initialized
INFO - 2025-12-26 07:29:23 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:23 --> CSRF cookie sent
INFO - 2025-12-26 07:29:23 --> Input Class Initialized
INFO - 2025-12-26 07:29:23 --> Language Class Initialized
INFO - 2025-12-26 07:29:23 --> Loader Class Initialized
INFO - 2025-12-26 07:29:23 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:23 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:23 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:23 --> Controller Class Initialized
INFO - 2025-12-26 07:29:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:23 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:23 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:23 --> Upload Class Initialized
INFO - 2025-12-26 07:29:23 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:23 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:29:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:23 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:23 --> Total execution time: 0.0986
INFO - 2025-12-26 07:29:27 --> Config Class Initialized
INFO - 2025-12-26 07:29:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:27 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:27 --> URI Class Initialized
INFO - 2025-12-26 07:29:27 --> Router Class Initialized
INFO - 2025-12-26 07:29:27 --> Output Class Initialized
INFO - 2025-12-26 07:29:27 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:27 --> CSRF cookie sent
INFO - 2025-12-26 07:29:27 --> Input Class Initialized
INFO - 2025-12-26 07:29:27 --> Language Class Initialized
INFO - 2025-12-26 07:29:27 --> Loader Class Initialized
INFO - 2025-12-26 07:29:27 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:27 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:27 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:27 --> Controller Class Initialized
INFO - 2025-12-26 07:29:27 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:27 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:27 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:27 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:27 --> Upload Class Initialized
INFO - 2025-12-26 07:29:27 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:27 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:29:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:27 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:27 --> Total execution time: 0.0797
INFO - 2025-12-26 07:29:33 --> Config Class Initialized
INFO - 2025-12-26 07:29:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:33 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:33 --> URI Class Initialized
INFO - 2025-12-26 07:29:33 --> Router Class Initialized
INFO - 2025-12-26 07:29:33 --> Output Class Initialized
INFO - 2025-12-26 07:29:33 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:33 --> CSRF cookie sent
INFO - 2025-12-26 07:29:33 --> CSRF token verified
INFO - 2025-12-26 07:29:33 --> Input Class Initialized
INFO - 2025-12-26 07:29:33 --> Language Class Initialized
INFO - 2025-12-26 07:29:33 --> Loader Class Initialized
INFO - 2025-12-26 07:29:33 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:33 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:33 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:33 --> Controller Class Initialized
INFO - 2025-12-26 07:29:33 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:33 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:33 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:33 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:33 --> Upload Class Initialized
INFO - 2025-12-26 07:29:33 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:33 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:35 --> Config Class Initialized
INFO - 2025-12-26 07:29:35 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:35 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:35 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:35 --> URI Class Initialized
INFO - 2025-12-26 07:29:35 --> Router Class Initialized
INFO - 2025-12-26 07:29:35 --> Output Class Initialized
INFO - 2025-12-26 07:29:35 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:35 --> CSRF cookie sent
INFO - 2025-12-26 07:29:35 --> Input Class Initialized
INFO - 2025-12-26 07:29:35 --> Language Class Initialized
INFO - 2025-12-26 07:29:35 --> Loader Class Initialized
INFO - 2025-12-26 07:29:35 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:35 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:35 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:35 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:35 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:35 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:35 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:36 --> Controller Class Initialized
INFO - 2025-12-26 07:29:36 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:29:36 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:29:36 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:29:36 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:36 --> Upload Class Initialized
INFO - 2025-12-26 07:29:36 --> Helper loaded: text_helper
INFO - 2025-12-26 07:29:36 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:29:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:36 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:36 --> Total execution time: 0.1044
INFO - 2025-12-26 07:29:48 --> Config Class Initialized
INFO - 2025-12-26 07:29:48 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:48 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:48 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:48 --> URI Class Initialized
INFO - 2025-12-26 07:29:48 --> Router Class Initialized
INFO - 2025-12-26 07:29:48 --> Output Class Initialized
INFO - 2025-12-26 07:29:48 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:48 --> CSRF cookie sent
INFO - 2025-12-26 07:29:48 --> Input Class Initialized
INFO - 2025-12-26 07:29:48 --> Language Class Initialized
INFO - 2025-12-26 07:29:48 --> Loader Class Initialized
INFO - 2025-12-26 07:29:49 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:49 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:49 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:49 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:49 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:49 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:49 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:49 --> Controller Class Initialized
INFO - 2025-12-26 07:29:49 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:29:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:29:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:29:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:29:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:29:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:29:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:29:49 --> Final output sent to browser
DEBUG - 2025-12-26 07:29:49 --> Total execution time: 0.0504
INFO - 2025-12-26 07:29:53 --> Config Class Initialized
INFO - 2025-12-26 07:29:53 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:29:53 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:29:53 --> Utf8 Class Initialized
INFO - 2025-12-26 07:29:53 --> URI Class Initialized
INFO - 2025-12-26 07:29:53 --> Router Class Initialized
INFO - 2025-12-26 07:29:53 --> Output Class Initialized
INFO - 2025-12-26 07:29:53 --> Security Class Initialized
DEBUG - 2025-12-26 07:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:29:53 --> CSRF cookie sent
INFO - 2025-12-26 07:29:53 --> Input Class Initialized
INFO - 2025-12-26 07:29:53 --> Language Class Initialized
INFO - 2025-12-26 07:29:53 --> Loader Class Initialized
INFO - 2025-12-26 07:29:53 --> Helper loaded: url_helper
INFO - 2025-12-26 07:29:53 --> Helper loaded: form_helper
INFO - 2025-12-26 07:29:53 --> Helper loaded: file_helper
INFO - 2025-12-26 07:29:53 --> Helper loaded: html_helper
INFO - 2025-12-26 07:29:53 --> Helper loaded: security_helper
INFO - 2025-12-26 07:29:53 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:29:53 --> Database Driver Class Initialized
INFO - 2025-12-26 07:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:29:53 --> Form Validation Class Initialized
INFO - 2025-12-26 07:29:53 --> Controller Class Initialized
INFO - 2025-12-26 07:29:53 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:29:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-12-26 07:29:53 --> Query error: Unknown column 'kategori' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE `kategori` = '16'
INFO - 2025-12-26 07:29:53 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 07:34:49 --> Config Class Initialized
INFO - 2025-12-26 07:34:49 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:34:49 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:34:49 --> Utf8 Class Initialized
INFO - 2025-12-26 07:34:49 --> URI Class Initialized
INFO - 2025-12-26 07:34:49 --> Router Class Initialized
INFO - 2025-12-26 07:34:49 --> Output Class Initialized
INFO - 2025-12-26 07:34:49 --> Security Class Initialized
DEBUG - 2025-12-26 07:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:34:49 --> CSRF cookie sent
INFO - 2025-12-26 07:34:49 --> Input Class Initialized
INFO - 2025-12-26 07:34:49 --> Language Class Initialized
INFO - 2025-12-26 07:34:49 --> Loader Class Initialized
INFO - 2025-12-26 07:34:49 --> Helper loaded: url_helper
INFO - 2025-12-26 07:34:49 --> Helper loaded: form_helper
INFO - 2025-12-26 07:34:49 --> Helper loaded: file_helper
INFO - 2025-12-26 07:34:49 --> Helper loaded: html_helper
INFO - 2025-12-26 07:34:49 --> Helper loaded: security_helper
INFO - 2025-12-26 07:34:49 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:34:49 --> Database Driver Class Initialized
INFO - 2025-12-26 07:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:34:49 --> Form Validation Class Initialized
INFO - 2025-12-26 07:34:49 --> Controller Class Initialized
INFO - 2025-12-26 07:34:49 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:34:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:34:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:34:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:34:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:34:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:34:49 --> Final output sent to browser
DEBUG - 2025-12-26 07:34:49 --> Total execution time: 0.0830
INFO - 2025-12-26 07:34:51 --> Config Class Initialized
INFO - 2025-12-26 07:34:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:34:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:34:51 --> Utf8 Class Initialized
INFO - 2025-12-26 07:34:51 --> URI Class Initialized
INFO - 2025-12-26 07:34:51 --> Router Class Initialized
INFO - 2025-12-26 07:34:51 --> Output Class Initialized
INFO - 2025-12-26 07:34:51 --> Security Class Initialized
DEBUG - 2025-12-26 07:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:34:51 --> CSRF cookie sent
INFO - 2025-12-26 07:34:51 --> Input Class Initialized
INFO - 2025-12-26 07:34:51 --> Language Class Initialized
INFO - 2025-12-26 07:34:51 --> Loader Class Initialized
INFO - 2025-12-26 07:34:51 --> Helper loaded: url_helper
INFO - 2025-12-26 07:34:51 --> Helper loaded: form_helper
INFO - 2025-12-26 07:34:51 --> Helper loaded: file_helper
INFO - 2025-12-26 07:34:51 --> Helper loaded: html_helper
INFO - 2025-12-26 07:34:51 --> Helper loaded: security_helper
INFO - 2025-12-26 07:34:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:34:51 --> Database Driver Class Initialized
INFO - 2025-12-26 07:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:34:51 --> Form Validation Class Initialized
INFO - 2025-12-26 07:34:51 --> Controller Class Initialized
INFO - 2025-12-26 07:34:51 --> Model "User_model" initialized
INFO - 2025-12-26 07:34:51 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:34:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:34:51 --> Upload Class Initialized
INFO - 2025-12-26 07:34:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:34:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:34:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:34:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 07:34:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:34:51 --> Final output sent to browser
DEBUG - 2025-12-26 07:34:51 --> Total execution time: 0.0636
INFO - 2025-12-26 07:34:55 --> Config Class Initialized
INFO - 2025-12-26 07:34:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:34:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:34:55 --> Utf8 Class Initialized
INFO - 2025-12-26 07:34:55 --> URI Class Initialized
INFO - 2025-12-26 07:34:55 --> Router Class Initialized
INFO - 2025-12-26 07:34:55 --> Output Class Initialized
INFO - 2025-12-26 07:34:55 --> Security Class Initialized
DEBUG - 2025-12-26 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:34:55 --> CSRF cookie sent
INFO - 2025-12-26 07:34:55 --> Input Class Initialized
INFO - 2025-12-26 07:34:55 --> Language Class Initialized
INFO - 2025-12-26 07:34:55 --> Loader Class Initialized
INFO - 2025-12-26 07:34:55 --> Helper loaded: url_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: form_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: file_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: html_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: security_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:34:55 --> Database Driver Class Initialized
INFO - 2025-12-26 07:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:34:55 --> Form Validation Class Initialized
INFO - 2025-12-26 07:34:55 --> Controller Class Initialized
INFO - 2025-12-26 07:34:55 --> Model "User_model" initialized
INFO - 2025-12-26 07:34:55 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:34:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:34:55 --> Upload Class Initialized
INFO - 2025-12-26 07:34:55 --> Config Class Initialized
INFO - 2025-12-26 07:34:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:34:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:34:55 --> Utf8 Class Initialized
INFO - 2025-12-26 07:34:55 --> URI Class Initialized
INFO - 2025-12-26 07:34:55 --> Router Class Initialized
INFO - 2025-12-26 07:34:55 --> Output Class Initialized
INFO - 2025-12-26 07:34:55 --> Security Class Initialized
DEBUG - 2025-12-26 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:34:55 --> CSRF cookie sent
INFO - 2025-12-26 07:34:55 --> Input Class Initialized
INFO - 2025-12-26 07:34:55 --> Language Class Initialized
INFO - 2025-12-26 07:34:55 --> Loader Class Initialized
INFO - 2025-12-26 07:34:55 --> Helper loaded: url_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: form_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: file_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: html_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: security_helper
INFO - 2025-12-26 07:34:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:34:55 --> Database Driver Class Initialized
INFO - 2025-12-26 07:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:34:55 --> Form Validation Class Initialized
INFO - 2025-12-26 07:34:55 --> Controller Class Initialized
INFO - 2025-12-26 07:34:55 --> Model "User_model" initialized
INFO - 2025-12-26 07:34:55 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:34:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:34:55 --> Upload Class Initialized
INFO - 2025-12-26 07:34:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:34:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:34:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:34:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 07:34:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:34:55 --> Final output sent to browser
DEBUG - 2025-12-26 07:34:55 --> Total execution time: 0.0668
INFO - 2025-12-26 07:34:57 --> Config Class Initialized
INFO - 2025-12-26 07:34:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:34:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:34:57 --> Utf8 Class Initialized
INFO - 2025-12-26 07:34:57 --> URI Class Initialized
INFO - 2025-12-26 07:34:57 --> Router Class Initialized
INFO - 2025-12-26 07:34:57 --> Output Class Initialized
INFO - 2025-12-26 07:34:57 --> Security Class Initialized
DEBUG - 2025-12-26 07:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:34:57 --> CSRF cookie sent
INFO - 2025-12-26 07:34:57 --> Input Class Initialized
INFO - 2025-12-26 07:34:57 --> Language Class Initialized
INFO - 2025-12-26 07:34:57 --> Loader Class Initialized
INFO - 2025-12-26 07:34:57 --> Helper loaded: url_helper
INFO - 2025-12-26 07:34:57 --> Helper loaded: form_helper
INFO - 2025-12-26 07:34:57 --> Helper loaded: file_helper
INFO - 2025-12-26 07:34:57 --> Helper loaded: html_helper
INFO - 2025-12-26 07:34:57 --> Helper loaded: security_helper
INFO - 2025-12-26 07:34:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:34:57 --> Database Driver Class Initialized
INFO - 2025-12-26 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:34:57 --> Form Validation Class Initialized
INFO - 2025-12-26 07:34:57 --> Controller Class Initialized
INFO - 2025-12-26 07:34:57 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:34:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:34:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:34:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:34:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:34:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 07:34:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:34:57 --> Final output sent to browser
DEBUG - 2025-12-26 07:34:57 --> Total execution time: 0.0591
INFO - 2025-12-26 07:35:03 --> Config Class Initialized
INFO - 2025-12-26 07:35:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:35:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:35:03 --> Utf8 Class Initialized
INFO - 2025-12-26 07:35:03 --> URI Class Initialized
INFO - 2025-12-26 07:35:03 --> Router Class Initialized
INFO - 2025-12-26 07:35:03 --> Output Class Initialized
INFO - 2025-12-26 07:35:03 --> Security Class Initialized
DEBUG - 2025-12-26 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:35:03 --> CSRF cookie sent
INFO - 2025-12-26 07:35:03 --> Input Class Initialized
INFO - 2025-12-26 07:35:03 --> Language Class Initialized
INFO - 2025-12-26 07:35:03 --> Loader Class Initialized
INFO - 2025-12-26 07:35:03 --> Helper loaded: url_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: form_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: file_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: html_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: security_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:35:03 --> Database Driver Class Initialized
INFO - 2025-12-26 07:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:35:03 --> Form Validation Class Initialized
INFO - 2025-12-26 07:35:03 --> Controller Class Initialized
INFO - 2025-12-26 07:35:03 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:35:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:35:03 --> Config Class Initialized
INFO - 2025-12-26 07:35:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:35:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:35:03 --> Utf8 Class Initialized
INFO - 2025-12-26 07:35:03 --> URI Class Initialized
INFO - 2025-12-26 07:35:03 --> Router Class Initialized
INFO - 2025-12-26 07:35:03 --> Output Class Initialized
INFO - 2025-12-26 07:35:03 --> Security Class Initialized
DEBUG - 2025-12-26 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:35:03 --> CSRF cookie sent
INFO - 2025-12-26 07:35:03 --> Input Class Initialized
INFO - 2025-12-26 07:35:03 --> Language Class Initialized
INFO - 2025-12-26 07:35:03 --> Loader Class Initialized
INFO - 2025-12-26 07:35:03 --> Helper loaded: url_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: form_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: file_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: html_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: security_helper
INFO - 2025-12-26 07:35:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:35:03 --> Database Driver Class Initialized
INFO - 2025-12-26 07:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:35:03 --> Form Validation Class Initialized
INFO - 2025-12-26 07:35:03 --> Controller Class Initialized
INFO - 2025-12-26 07:35:03 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:35:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:35:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:35:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:35:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:35:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 07:35:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:35:03 --> Final output sent to browser
DEBUG - 2025-12-26 07:35:03 --> Total execution time: 0.1006
INFO - 2025-12-26 07:35:05 --> Config Class Initialized
INFO - 2025-12-26 07:35:05 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:35:05 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:35:05 --> Utf8 Class Initialized
INFO - 2025-12-26 07:35:05 --> URI Class Initialized
INFO - 2025-12-26 07:35:05 --> Router Class Initialized
INFO - 2025-12-26 07:35:05 --> Output Class Initialized
INFO - 2025-12-26 07:35:05 --> Security Class Initialized
DEBUG - 2025-12-26 07:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:35:05 --> CSRF cookie sent
INFO - 2025-12-26 07:35:05 --> Input Class Initialized
INFO - 2025-12-26 07:35:05 --> Language Class Initialized
INFO - 2025-12-26 07:35:05 --> Loader Class Initialized
INFO - 2025-12-26 07:35:05 --> Helper loaded: url_helper
INFO - 2025-12-26 07:35:05 --> Helper loaded: form_helper
INFO - 2025-12-26 07:35:05 --> Helper loaded: file_helper
INFO - 2025-12-26 07:35:05 --> Helper loaded: html_helper
INFO - 2025-12-26 07:35:05 --> Helper loaded: security_helper
INFO - 2025-12-26 07:35:05 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:35:05 --> Database Driver Class Initialized
INFO - 2025-12-26 07:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:35:05 --> Form Validation Class Initialized
INFO - 2025-12-26 07:35:05 --> Controller Class Initialized
INFO - 2025-12-26 07:35:05 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:35:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:35:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:35:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:35:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:35:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:35:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:35:05 --> Final output sent to browser
DEBUG - 2025-12-26 07:35:05 --> Total execution time: 0.1011
INFO - 2025-12-26 07:39:20 --> Config Class Initialized
INFO - 2025-12-26 07:39:20 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:39:20 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:39:20 --> Utf8 Class Initialized
INFO - 2025-12-26 07:39:20 --> URI Class Initialized
INFO - 2025-12-26 07:39:20 --> Router Class Initialized
INFO - 2025-12-26 07:39:20 --> Output Class Initialized
INFO - 2025-12-26 07:39:20 --> Security Class Initialized
DEBUG - 2025-12-26 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:39:20 --> CSRF cookie sent
INFO - 2025-12-26 07:39:20 --> Input Class Initialized
INFO - 2025-12-26 07:39:20 --> Language Class Initialized
INFO - 2025-12-26 07:39:20 --> Loader Class Initialized
INFO - 2025-12-26 07:39:20 --> Helper loaded: url_helper
INFO - 2025-12-26 07:39:20 --> Helper loaded: form_helper
INFO - 2025-12-26 07:39:20 --> Helper loaded: file_helper
INFO - 2025-12-26 07:39:20 --> Helper loaded: html_helper
INFO - 2025-12-26 07:39:20 --> Helper loaded: security_helper
INFO - 2025-12-26 07:39:20 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:39:20 --> Database Driver Class Initialized
INFO - 2025-12-26 07:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:39:20 --> Form Validation Class Initialized
INFO - 2025-12-26 07:39:20 --> Controller Class Initialized
INFO - 2025-12-26 07:39:20 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:39:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:39:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:39:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:39:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:39:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:39:20 --> Final output sent to browser
DEBUG - 2025-12-26 07:39:20 --> Total execution time: 0.1309
INFO - 2025-12-26 07:39:25 --> Config Class Initialized
INFO - 2025-12-26 07:39:25 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:39:25 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:39:25 --> Utf8 Class Initialized
INFO - 2025-12-26 07:39:25 --> URI Class Initialized
INFO - 2025-12-26 07:39:25 --> Router Class Initialized
INFO - 2025-12-26 07:39:25 --> Output Class Initialized
INFO - 2025-12-26 07:39:25 --> Security Class Initialized
DEBUG - 2025-12-26 07:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:39:25 --> CSRF cookie sent
INFO - 2025-12-26 07:39:25 --> Input Class Initialized
INFO - 2025-12-26 07:39:25 --> Language Class Initialized
INFO - 2025-12-26 07:39:25 --> Loader Class Initialized
INFO - 2025-12-26 07:39:25 --> Helper loaded: url_helper
INFO - 2025-12-26 07:39:25 --> Helper loaded: form_helper
INFO - 2025-12-26 07:39:25 --> Helper loaded: file_helper
INFO - 2025-12-26 07:39:25 --> Helper loaded: html_helper
INFO - 2025-12-26 07:39:25 --> Helper loaded: security_helper
INFO - 2025-12-26 07:39:25 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:39:25 --> Database Driver Class Initialized
INFO - 2025-12-26 07:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:39:25 --> Form Validation Class Initialized
INFO - 2025-12-26 07:39:25 --> Controller Class Initialized
INFO - 2025-12-26 07:39:25 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:39:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-12-26 07:39:25 --> Query error: Unknown column 'kategori' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE `kategori` = '16'
INFO - 2025-12-26 07:39:25 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 07:40:40 --> Config Class Initialized
INFO - 2025-12-26 07:40:40 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:40:40 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:40:40 --> Utf8 Class Initialized
INFO - 2025-12-26 07:40:40 --> URI Class Initialized
INFO - 2025-12-26 07:40:40 --> Router Class Initialized
INFO - 2025-12-26 07:40:40 --> Output Class Initialized
INFO - 2025-12-26 07:40:40 --> Security Class Initialized
DEBUG - 2025-12-26 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:40:40 --> CSRF cookie sent
INFO - 2025-12-26 07:40:40 --> Input Class Initialized
INFO - 2025-12-26 07:40:40 --> Language Class Initialized
INFO - 2025-12-26 07:40:40 --> Loader Class Initialized
INFO - 2025-12-26 07:40:40 --> Helper loaded: url_helper
INFO - 2025-12-26 07:40:40 --> Helper loaded: form_helper
INFO - 2025-12-26 07:40:40 --> Helper loaded: file_helper
INFO - 2025-12-26 07:40:40 --> Helper loaded: html_helper
INFO - 2025-12-26 07:40:40 --> Helper loaded: security_helper
INFO - 2025-12-26 07:40:40 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:40:40 --> Database Driver Class Initialized
INFO - 2025-12-26 07:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:40:40 --> Form Validation Class Initialized
INFO - 2025-12-26 07:40:40 --> Controller Class Initialized
INFO - 2025-12-26 07:40:40 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:40:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:40:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:40:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:40:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:40:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:40:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:40:40 --> Final output sent to browser
DEBUG - 2025-12-26 07:40:40 --> Total execution time: 0.0961
INFO - 2025-12-26 07:40:41 --> Config Class Initialized
INFO - 2025-12-26 07:40:41 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:40:41 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:40:41 --> Utf8 Class Initialized
INFO - 2025-12-26 07:40:41 --> URI Class Initialized
INFO - 2025-12-26 07:40:41 --> Router Class Initialized
INFO - 2025-12-26 07:40:41 --> Output Class Initialized
INFO - 2025-12-26 07:40:41 --> Security Class Initialized
DEBUG - 2025-12-26 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:40:41 --> CSRF cookie sent
INFO - 2025-12-26 07:40:41 --> Input Class Initialized
INFO - 2025-12-26 07:40:41 --> Language Class Initialized
INFO - 2025-12-26 07:40:41 --> Loader Class Initialized
INFO - 2025-12-26 07:40:41 --> Helper loaded: url_helper
INFO - 2025-12-26 07:40:41 --> Helper loaded: form_helper
INFO - 2025-12-26 07:40:41 --> Helper loaded: file_helper
INFO - 2025-12-26 07:40:41 --> Helper loaded: html_helper
INFO - 2025-12-26 07:40:41 --> Helper loaded: security_helper
INFO - 2025-12-26 07:40:41 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:40:41 --> Database Driver Class Initialized
INFO - 2025-12-26 07:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:40:41 --> Form Validation Class Initialized
INFO - 2025-12-26 07:40:41 --> Controller Class Initialized
INFO - 2025-12-26 07:40:41 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:40:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:40:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:40:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:40:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:40:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:40:41 --> Final output sent to browser
DEBUG - 2025-12-26 07:40:41 --> Total execution time: 0.0628
INFO - 2025-12-26 07:40:45 --> Config Class Initialized
INFO - 2025-12-26 07:40:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:40:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:40:45 --> Utf8 Class Initialized
INFO - 2025-12-26 07:40:45 --> URI Class Initialized
INFO - 2025-12-26 07:40:45 --> Router Class Initialized
INFO - 2025-12-26 07:40:45 --> Output Class Initialized
INFO - 2025-12-26 07:40:45 --> Security Class Initialized
DEBUG - 2025-12-26 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:40:45 --> CSRF cookie sent
INFO - 2025-12-26 07:40:45 --> Input Class Initialized
INFO - 2025-12-26 07:40:45 --> Language Class Initialized
INFO - 2025-12-26 07:40:45 --> Loader Class Initialized
INFO - 2025-12-26 07:40:45 --> Helper loaded: url_helper
INFO - 2025-12-26 07:40:45 --> Helper loaded: form_helper
INFO - 2025-12-26 07:40:45 --> Helper loaded: file_helper
INFO - 2025-12-26 07:40:45 --> Helper loaded: html_helper
INFO - 2025-12-26 07:40:45 --> Helper loaded: security_helper
INFO - 2025-12-26 07:40:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:40:45 --> Database Driver Class Initialized
INFO - 2025-12-26 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:40:45 --> Form Validation Class Initialized
INFO - 2025-12-26 07:40:45 --> Controller Class Initialized
INFO - 2025-12-26 07:40:45 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:40:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-12-26 07:40:45 --> Query error: Unknown column 'id_kategori' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE `id_kategori` = '16'
INFO - 2025-12-26 07:40:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-26 07:41:31 --> Config Class Initialized
INFO - 2025-12-26 07:41:31 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:41:31 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:41:31 --> Utf8 Class Initialized
INFO - 2025-12-26 07:41:31 --> URI Class Initialized
INFO - 2025-12-26 07:41:31 --> Router Class Initialized
INFO - 2025-12-26 07:41:31 --> Output Class Initialized
INFO - 2025-12-26 07:41:31 --> Security Class Initialized
DEBUG - 2025-12-26 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:41:31 --> CSRF cookie sent
INFO - 2025-12-26 07:41:31 --> Input Class Initialized
INFO - 2025-12-26 07:41:31 --> Language Class Initialized
INFO - 2025-12-26 07:41:31 --> Loader Class Initialized
INFO - 2025-12-26 07:41:31 --> Helper loaded: url_helper
INFO - 2025-12-26 07:41:31 --> Helper loaded: form_helper
INFO - 2025-12-26 07:41:31 --> Helper loaded: file_helper
INFO - 2025-12-26 07:41:31 --> Helper loaded: html_helper
INFO - 2025-12-26 07:41:31 --> Helper loaded: security_helper
INFO - 2025-12-26 07:41:31 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:41:31 --> Database Driver Class Initialized
INFO - 2025-12-26 07:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:41:31 --> Form Validation Class Initialized
INFO - 2025-12-26 07:41:31 --> Controller Class Initialized
INFO - 2025-12-26 07:41:31 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:41:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:41:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:41:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:41:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:41:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:41:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:41:31 --> Final output sent to browser
DEBUG - 2025-12-26 07:41:31 --> Total execution time: 0.1036
INFO - 2025-12-26 07:41:36 --> Config Class Initialized
INFO - 2025-12-26 07:41:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:41:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:41:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:41:36 --> URI Class Initialized
INFO - 2025-12-26 07:41:36 --> Router Class Initialized
INFO - 2025-12-26 07:41:36 --> Output Class Initialized
INFO - 2025-12-26 07:41:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:41:36 --> CSRF cookie sent
INFO - 2025-12-26 07:41:36 --> Input Class Initialized
INFO - 2025-12-26 07:41:36 --> Language Class Initialized
INFO - 2025-12-26 07:41:36 --> Loader Class Initialized
INFO - 2025-12-26 07:41:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:41:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:41:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:41:36 --> Controller Class Initialized
INFO - 2025-12-26 07:41:36 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:41:36 --> Config Class Initialized
INFO - 2025-12-26 07:41:36 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:41:36 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:41:36 --> Utf8 Class Initialized
INFO - 2025-12-26 07:41:36 --> URI Class Initialized
INFO - 2025-12-26 07:41:36 --> Router Class Initialized
INFO - 2025-12-26 07:41:36 --> Output Class Initialized
INFO - 2025-12-26 07:41:36 --> Security Class Initialized
DEBUG - 2025-12-26 07:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:41:36 --> CSRF cookie sent
INFO - 2025-12-26 07:41:36 --> Input Class Initialized
INFO - 2025-12-26 07:41:36 --> Language Class Initialized
INFO - 2025-12-26 07:41:36 --> Loader Class Initialized
INFO - 2025-12-26 07:41:36 --> Helper loaded: url_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: form_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: file_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: html_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: security_helper
INFO - 2025-12-26 07:41:36 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:41:36 --> Database Driver Class Initialized
INFO - 2025-12-26 07:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:41:36 --> Form Validation Class Initialized
INFO - 2025-12-26 07:41:36 --> Controller Class Initialized
INFO - 2025-12-26 07:41:36 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:41:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:41:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:41:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:41:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:41:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:41:36 --> Final output sent to browser
DEBUG - 2025-12-26 07:41:36 --> Total execution time: 0.0794
INFO - 2025-12-26 07:41:42 --> Config Class Initialized
INFO - 2025-12-26 07:41:42 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:41:42 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:41:42 --> Utf8 Class Initialized
INFO - 2025-12-26 07:41:42 --> URI Class Initialized
INFO - 2025-12-26 07:41:42 --> Router Class Initialized
INFO - 2025-12-26 07:41:42 --> Output Class Initialized
INFO - 2025-12-26 07:41:42 --> Security Class Initialized
DEBUG - 2025-12-26 07:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:41:42 --> CSRF cookie sent
INFO - 2025-12-26 07:41:42 --> Input Class Initialized
INFO - 2025-12-26 07:41:42 --> Language Class Initialized
INFO - 2025-12-26 07:41:42 --> Loader Class Initialized
INFO - 2025-12-26 07:41:42 --> Helper loaded: url_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: form_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: file_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: html_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: security_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:41:42 --> Database Driver Class Initialized
INFO - 2025-12-26 07:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:41:42 --> Form Validation Class Initialized
INFO - 2025-12-26 07:41:42 --> Controller Class Initialized
INFO - 2025-12-26 07:41:42 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:41:42 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:41:42 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:41:42 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:41:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:41:42 --> Upload Class Initialized
INFO - 2025-12-26 07:41:42 --> Helper loaded: text_helper
INFO - 2025-12-26 07:41:42 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:41:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:41:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:41:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:41:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:41:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:41:42 --> Final output sent to browser
DEBUG - 2025-12-26 07:41:42 --> Total execution time: 0.0913
INFO - 2025-12-26 07:41:51 --> Config Class Initialized
INFO - 2025-12-26 07:41:51 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:41:51 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:41:51 --> Utf8 Class Initialized
INFO - 2025-12-26 07:41:51 --> URI Class Initialized
INFO - 2025-12-26 07:41:51 --> Router Class Initialized
INFO - 2025-12-26 07:41:51 --> Output Class Initialized
INFO - 2025-12-26 07:41:51 --> Security Class Initialized
DEBUG - 2025-12-26 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:41:51 --> CSRF cookie sent
INFO - 2025-12-26 07:41:51 --> Input Class Initialized
INFO - 2025-12-26 07:41:51 --> Language Class Initialized
INFO - 2025-12-26 07:41:51 --> Loader Class Initialized
INFO - 2025-12-26 07:41:51 --> Helper loaded: url_helper
INFO - 2025-12-26 07:41:51 --> Helper loaded: form_helper
INFO - 2025-12-26 07:41:51 --> Helper loaded: file_helper
INFO - 2025-12-26 07:41:51 --> Helper loaded: html_helper
INFO - 2025-12-26 07:41:51 --> Helper loaded: security_helper
INFO - 2025-12-26 07:41:51 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:41:51 --> Database Driver Class Initialized
INFO - 2025-12-26 07:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:41:51 --> Form Validation Class Initialized
INFO - 2025-12-26 07:41:51 --> Controller Class Initialized
INFO - 2025-12-26 07:41:51 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:41:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:41:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:41:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:41:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:41:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:41:51 --> Final output sent to browser
DEBUG - 2025-12-26 07:41:51 --> Total execution time: 0.0613
INFO - 2025-12-26 07:42:01 --> Config Class Initialized
INFO - 2025-12-26 07:42:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:01 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:01 --> URI Class Initialized
INFO - 2025-12-26 07:42:01 --> Router Class Initialized
INFO - 2025-12-26 07:42:01 --> Output Class Initialized
INFO - 2025-12-26 07:42:01 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:01 --> CSRF cookie sent
INFO - 2025-12-26 07:42:01 --> Input Class Initialized
INFO - 2025-12-26 07:42:01 --> Language Class Initialized
INFO - 2025-12-26 07:42:01 --> Loader Class Initialized
INFO - 2025-12-26 07:42:01 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:01 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:01 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:01 --> Controller Class Initialized
INFO - 2025-12-26 07:42:01 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:01 --> Config Class Initialized
INFO - 2025-12-26 07:42:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:01 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:01 --> URI Class Initialized
INFO - 2025-12-26 07:42:01 --> Router Class Initialized
INFO - 2025-12-26 07:42:01 --> Output Class Initialized
INFO - 2025-12-26 07:42:01 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:01 --> CSRF cookie sent
INFO - 2025-12-26 07:42:01 --> Input Class Initialized
INFO - 2025-12-26 07:42:01 --> Language Class Initialized
INFO - 2025-12-26 07:42:01 --> Loader Class Initialized
INFO - 2025-12-26 07:42:01 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:01 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:01 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:01 --> Controller Class Initialized
INFO - 2025-12-26 07:42:01 --> Model "Kategori_model" initialized
DEBUG - 2025-12-26 07:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-26 07:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:01 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:01 --> Total execution time: 0.0770
INFO - 2025-12-26 07:42:14 --> Config Class Initialized
INFO - 2025-12-26 07:42:14 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:14 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:14 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:14 --> URI Class Initialized
INFO - 2025-12-26 07:42:14 --> Router Class Initialized
INFO - 2025-12-26 07:42:14 --> Output Class Initialized
INFO - 2025-12-26 07:42:14 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:14 --> CSRF cookie sent
INFO - 2025-12-26 07:42:14 --> Input Class Initialized
INFO - 2025-12-26 07:42:14 --> Language Class Initialized
INFO - 2025-12-26 07:42:14 --> Loader Class Initialized
INFO - 2025-12-26 07:42:14 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:14 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:14 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:14 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:14 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:14 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:14 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:14 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:14 --> Controller Class Initialized
INFO - 2025-12-26 07:42:14 --> Model "User_model" initialized
INFO - 2025-12-26 07:42:14 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:14 --> Upload Class Initialized
INFO - 2025-12-26 07:42:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 07:42:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:14 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:14 --> Total execution time: 0.0579
INFO - 2025-12-26 07:42:16 --> Config Class Initialized
INFO - 2025-12-26 07:42:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:16 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:16 --> URI Class Initialized
INFO - 2025-12-26 07:42:16 --> Router Class Initialized
INFO - 2025-12-26 07:42:16 --> Output Class Initialized
INFO - 2025-12-26 07:42:16 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:16 --> CSRF cookie sent
INFO - 2025-12-26 07:42:16 --> Input Class Initialized
INFO - 2025-12-26 07:42:16 --> Language Class Initialized
INFO - 2025-12-26 07:42:16 --> Loader Class Initialized
INFO - 2025-12-26 07:42:16 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:16 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:16 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:16 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:16 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:16 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:16 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:16 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:16 --> Controller Class Initialized
INFO - 2025-12-26 07:42:16 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 07:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-26 07:42:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:16 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:16 --> Total execution time: 0.0722
INFO - 2025-12-26 07:42:23 --> Config Class Initialized
INFO - 2025-12-26 07:42:23 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:23 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:23 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:23 --> URI Class Initialized
INFO - 2025-12-26 07:42:23 --> Router Class Initialized
INFO - 2025-12-26 07:42:23 --> Output Class Initialized
INFO - 2025-12-26 07:42:23 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:23 --> CSRF cookie sent
INFO - 2025-12-26 07:42:23 --> Input Class Initialized
INFO - 2025-12-26 07:42:23 --> Language Class Initialized
INFO - 2025-12-26 07:42:23 --> Loader Class Initialized
INFO - 2025-12-26 07:42:23 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:23 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:23 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:23 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:23 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:23 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:23 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:23 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:23 --> Controller Class Initialized
INFO - 2025-12-26 07:42:23 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 07:42:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 07:42:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:23 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:23 --> Total execution time: 0.0728
INFO - 2025-12-26 07:42:29 --> Config Class Initialized
INFO - 2025-12-26 07:42:29 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:29 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:29 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:29 --> URI Class Initialized
INFO - 2025-12-26 07:42:29 --> Router Class Initialized
INFO - 2025-12-26 07:42:29 --> Output Class Initialized
INFO - 2025-12-26 07:42:29 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:29 --> CSRF cookie sent
INFO - 2025-12-26 07:42:29 --> Input Class Initialized
INFO - 2025-12-26 07:42:29 --> Language Class Initialized
INFO - 2025-12-26 07:42:29 --> Loader Class Initialized
INFO - 2025-12-26 07:42:29 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:29 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:29 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:29 --> Controller Class Initialized
INFO - 2025-12-26 07:42:29 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:42:29 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:42:29 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:42:29 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:29 --> Upload Class Initialized
INFO - 2025-12-26 07:42:29 --> Helper loaded: text_helper
INFO - 2025-12-26 07:42:29 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:42:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 07:42:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:29 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:29 --> Total execution time: 0.0731
INFO - 2025-12-26 07:42:32 --> Config Class Initialized
INFO - 2025-12-26 07:42:32 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:42:32 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:42:32 --> Utf8 Class Initialized
INFO - 2025-12-26 07:42:32 --> URI Class Initialized
INFO - 2025-12-26 07:42:32 --> Router Class Initialized
INFO - 2025-12-26 07:42:32 --> Output Class Initialized
INFO - 2025-12-26 07:42:32 --> Security Class Initialized
DEBUG - 2025-12-26 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:42:32 --> CSRF cookie sent
INFO - 2025-12-26 07:42:32 --> Input Class Initialized
INFO - 2025-12-26 07:42:32 --> Language Class Initialized
INFO - 2025-12-26 07:42:32 --> Loader Class Initialized
INFO - 2025-12-26 07:42:32 --> Helper loaded: url_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: form_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: file_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: html_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: security_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:42:32 --> Database Driver Class Initialized
INFO - 2025-12-26 07:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:42:32 --> Form Validation Class Initialized
INFO - 2025-12-26 07:42:32 --> Controller Class Initialized
INFO - 2025-12-26 07:42:32 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:42:32 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:42:32 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:42:32 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:42:32 --> Upload Class Initialized
INFO - 2025-12-26 07:42:32 --> Helper loaded: text_helper
INFO - 2025-12-26 07:42:32 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:42:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:42:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:42:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:42:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:42:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:42:32 --> Final output sent to browser
DEBUG - 2025-12-26 07:42:32 --> Total execution time: 0.0660
INFO - 2025-12-26 07:46:57 --> Config Class Initialized
INFO - 2025-12-26 07:46:57 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:46:57 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:46:57 --> Utf8 Class Initialized
INFO - 2025-12-26 07:46:57 --> URI Class Initialized
INFO - 2025-12-26 07:46:57 --> Router Class Initialized
INFO - 2025-12-26 07:46:57 --> Output Class Initialized
INFO - 2025-12-26 07:46:57 --> Security Class Initialized
DEBUG - 2025-12-26 07:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:46:57 --> CSRF cookie sent
INFO - 2025-12-26 07:46:57 --> Input Class Initialized
INFO - 2025-12-26 07:46:57 --> Language Class Initialized
INFO - 2025-12-26 07:46:57 --> Loader Class Initialized
INFO - 2025-12-26 07:46:57 --> Helper loaded: url_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: form_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: file_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: html_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: security_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:46:57 --> Database Driver Class Initialized
INFO - 2025-12-26 07:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:46:57 --> Form Validation Class Initialized
INFO - 2025-12-26 07:46:57 --> Controller Class Initialized
INFO - 2025-12-26 07:46:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:46:57 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:46:57 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:46:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:46:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:46:57 --> Upload Class Initialized
INFO - 2025-12-26 07:46:57 --> Helper loaded: text_helper
INFO - 2025-12-26 07:46:57 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:46:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:46:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:46:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:46:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:46:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:46:57 --> Final output sent to browser
DEBUG - 2025-12-26 07:46:57 --> Total execution time: 0.0910
INFO - 2025-12-26 07:48:58 --> Config Class Initialized
INFO - 2025-12-26 07:48:58 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:48:58 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:48:58 --> Utf8 Class Initialized
INFO - 2025-12-26 07:48:58 --> URI Class Initialized
INFO - 2025-12-26 07:48:58 --> Router Class Initialized
INFO - 2025-12-26 07:48:58 --> Output Class Initialized
INFO - 2025-12-26 07:48:58 --> Security Class Initialized
DEBUG - 2025-12-26 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:48:58 --> CSRF cookie sent
INFO - 2025-12-26 07:48:58 --> Input Class Initialized
INFO - 2025-12-26 07:48:58 --> Language Class Initialized
INFO - 2025-12-26 07:48:58 --> Loader Class Initialized
INFO - 2025-12-26 07:48:58 --> Helper loaded: url_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: form_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: file_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: html_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: security_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:48:58 --> Database Driver Class Initialized
INFO - 2025-12-26 07:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:48:58 --> Form Validation Class Initialized
INFO - 2025-12-26 07:48:58 --> Controller Class Initialized
INFO - 2025-12-26 07:48:58 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:48:58 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:48:58 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:48:58 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:48:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:48:58 --> Upload Class Initialized
INFO - 2025-12-26 07:48:58 --> Helper loaded: text_helper
INFO - 2025-12-26 07:48:58 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:48:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:48:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:48:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:48:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:48:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:48:58 --> Final output sent to browser
DEBUG - 2025-12-26 07:48:58 --> Total execution time: 0.0797
INFO - 2025-12-26 07:49:00 --> Config Class Initialized
INFO - 2025-12-26 07:49:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:49:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:49:00 --> Utf8 Class Initialized
INFO - 2025-12-26 07:49:00 --> URI Class Initialized
INFO - 2025-12-26 07:49:00 --> Router Class Initialized
INFO - 2025-12-26 07:49:00 --> Output Class Initialized
INFO - 2025-12-26 07:49:00 --> Security Class Initialized
DEBUG - 2025-12-26 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:49:00 --> CSRF cookie sent
INFO - 2025-12-26 07:49:00 --> Input Class Initialized
INFO - 2025-12-26 07:49:00 --> Language Class Initialized
INFO - 2025-12-26 07:49:00 --> Loader Class Initialized
INFO - 2025-12-26 07:49:00 --> Helper loaded: url_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: form_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: file_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: html_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: security_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:49:00 --> Database Driver Class Initialized
INFO - 2025-12-26 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:49:00 --> Form Validation Class Initialized
INFO - 2025-12-26 07:49:00 --> Controller Class Initialized
INFO - 2025-12-26 07:49:00 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:49:00 --> Upload Class Initialized
INFO - 2025-12-26 07:49:00 --> Helper loaded: text_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:49:00 --> Final output sent to browser
DEBUG - 2025-12-26 07:49:00 --> Total execution time: 0.0895
INFO - 2025-12-26 07:49:00 --> Config Class Initialized
INFO - 2025-12-26 07:49:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:49:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:49:00 --> Utf8 Class Initialized
INFO - 2025-12-26 07:49:00 --> URI Class Initialized
INFO - 2025-12-26 07:49:00 --> Router Class Initialized
INFO - 2025-12-26 07:49:00 --> Output Class Initialized
INFO - 2025-12-26 07:49:00 --> Security Class Initialized
DEBUG - 2025-12-26 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:49:00 --> CSRF cookie sent
INFO - 2025-12-26 07:49:00 --> Input Class Initialized
INFO - 2025-12-26 07:49:00 --> Language Class Initialized
INFO - 2025-12-26 07:49:00 --> Loader Class Initialized
INFO - 2025-12-26 07:49:00 --> Helper loaded: url_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: form_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: file_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: html_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: security_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:49:00 --> Database Driver Class Initialized
INFO - 2025-12-26 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:49:00 --> Form Validation Class Initialized
INFO - 2025-12-26 07:49:00 --> Controller Class Initialized
INFO - 2025-12-26 07:49:00 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:49:00 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 07:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:49:00 --> Upload Class Initialized
INFO - 2025-12-26 07:49:00 --> Helper loaded: text_helper
INFO - 2025-12-26 07:49:00 --> Helper loaded: custom_helper
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-26 07:49:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:49:00 --> Final output sent to browser
DEBUG - 2025-12-26 07:49:00 --> Total execution time: 0.1188
INFO - 2025-12-26 07:49:03 --> Config Class Initialized
INFO - 2025-12-26 07:49:03 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:49:03 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:49:03 --> Utf8 Class Initialized
INFO - 2025-12-26 07:49:03 --> URI Class Initialized
INFO - 2025-12-26 07:49:03 --> Router Class Initialized
INFO - 2025-12-26 07:49:03 --> Output Class Initialized
INFO - 2025-12-26 07:49:03 --> Security Class Initialized
DEBUG - 2025-12-26 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:49:03 --> CSRF cookie sent
INFO - 2025-12-26 07:49:03 --> Input Class Initialized
INFO - 2025-12-26 07:49:03 --> Language Class Initialized
INFO - 2025-12-26 07:49:03 --> Loader Class Initialized
INFO - 2025-12-26 07:49:03 --> Helper loaded: url_helper
INFO - 2025-12-26 07:49:03 --> Helper loaded: form_helper
INFO - 2025-12-26 07:49:03 --> Helper loaded: file_helper
INFO - 2025-12-26 07:49:03 --> Helper loaded: html_helper
INFO - 2025-12-26 07:49:03 --> Helper loaded: security_helper
INFO - 2025-12-26 07:49:03 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:49:03 --> Database Driver Class Initialized
INFO - 2025-12-26 07:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:49:03 --> Form Validation Class Initialized
INFO - 2025-12-26 07:49:03 --> Controller Class Initialized
INFO - 2025-12-26 07:49:03 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:49:03 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:49:03 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:49:03 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:49:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:49:03 --> Upload Class Initialized
INFO - 2025-12-26 07:49:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:49:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:49:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:49:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 07:49:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:49:03 --> Final output sent to browser
DEBUG - 2025-12-26 07:49:03 --> Total execution time: 0.0774
INFO - 2025-12-26 07:49:06 --> Config Class Initialized
INFO - 2025-12-26 07:49:06 --> Hooks Class Initialized
DEBUG - 2025-12-26 07:49:06 --> UTF-8 Support Enabled
INFO - 2025-12-26 07:49:06 --> Utf8 Class Initialized
INFO - 2025-12-26 07:49:06 --> URI Class Initialized
INFO - 2025-12-26 07:49:06 --> Router Class Initialized
INFO - 2025-12-26 07:49:06 --> Output Class Initialized
INFO - 2025-12-26 07:49:06 --> Security Class Initialized
DEBUG - 2025-12-26 07:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 07:49:06 --> CSRF cookie sent
INFO - 2025-12-26 07:49:06 --> Input Class Initialized
INFO - 2025-12-26 07:49:06 --> Language Class Initialized
INFO - 2025-12-26 07:49:06 --> Loader Class Initialized
INFO - 2025-12-26 07:49:06 --> Helper loaded: url_helper
INFO - 2025-12-26 07:49:06 --> Helper loaded: form_helper
INFO - 2025-12-26 07:49:06 --> Helper loaded: file_helper
INFO - 2025-12-26 07:49:06 --> Helper loaded: html_helper
INFO - 2025-12-26 07:49:06 --> Helper loaded: security_helper
INFO - 2025-12-26 07:49:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 07:49:06 --> Database Driver Class Initialized
INFO - 2025-12-26 07:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 07:49:06 --> Form Validation Class Initialized
INFO - 2025-12-26 07:49:06 --> Controller Class Initialized
INFO - 2025-12-26 07:49:06 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 07:49:06 --> Model "Bagian_model" initialized
INFO - 2025-12-26 07:49:06 --> Model "Kategori_model" initialized
INFO - 2025-12-26 07:49:06 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 07:49:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 07:49:06 --> Upload Class Initialized
INFO - 2025-12-26 07:49:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 07:49:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 07:49:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 07:49:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-26 07:49:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 07:49:07 --> Final output sent to browser
DEBUG - 2025-12-26 07:49:07 --> Total execution time: 0.4907
INFO - 2025-12-26 10:10:16 --> Config Class Initialized
INFO - 2025-12-26 10:10:16 --> Hooks Class Initialized
DEBUG - 2025-12-26 10:10:16 --> UTF-8 Support Enabled
INFO - 2025-12-26 10:10:16 --> Utf8 Class Initialized
INFO - 2025-12-26 10:10:16 --> URI Class Initialized
DEBUG - 2025-12-26 10:10:16 --> No URI present. Default controller set.
INFO - 2025-12-26 10:10:16 --> Router Class Initialized
INFO - 2025-12-26 10:10:16 --> Output Class Initialized
INFO - 2025-12-26 10:10:16 --> Security Class Initialized
DEBUG - 2025-12-26 10:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 10:10:16 --> CSRF cookie sent
INFO - 2025-12-26 10:10:16 --> Input Class Initialized
INFO - 2025-12-26 10:10:16 --> Language Class Initialized
INFO - 2025-12-26 10:10:16 --> Loader Class Initialized
INFO - 2025-12-26 10:10:16 --> Helper loaded: url_helper
INFO - 2025-12-26 10:10:16 --> Helper loaded: form_helper
INFO - 2025-12-26 10:10:16 --> Helper loaded: file_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: html_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: security_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 10:10:17 --> Database Driver Class Initialized
INFO - 2025-12-26 10:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 10:10:17 --> Form Validation Class Initialized
INFO - 2025-12-26 10:10:17 --> Controller Class Initialized
INFO - 2025-12-26 10:10:17 --> Config Class Initialized
INFO - 2025-12-26 10:10:17 --> Hooks Class Initialized
DEBUG - 2025-12-26 10:10:17 --> UTF-8 Support Enabled
INFO - 2025-12-26 10:10:17 --> Utf8 Class Initialized
INFO - 2025-12-26 10:10:17 --> URI Class Initialized
INFO - 2025-12-26 10:10:17 --> Router Class Initialized
INFO - 2025-12-26 10:10:17 --> Output Class Initialized
INFO - 2025-12-26 10:10:17 --> Security Class Initialized
DEBUG - 2025-12-26 10:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 10:10:17 --> CSRF cookie sent
INFO - 2025-12-26 10:10:17 --> Input Class Initialized
INFO - 2025-12-26 10:10:17 --> Language Class Initialized
INFO - 2025-12-26 10:10:17 --> Loader Class Initialized
INFO - 2025-12-26 10:10:17 --> Helper loaded: url_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: form_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: file_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: html_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: security_helper
INFO - 2025-12-26 10:10:17 --> Helper loaded: surat_helper
INFO - 2025-12-26 10:10:17 --> Database Driver Class Initialized
INFO - 2025-12-26 10:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 10:10:17 --> Form Validation Class Initialized
INFO - 2025-12-26 10:10:17 --> Controller Class Initialized
INFO - 2025-12-26 10:10:17 --> Model "User_model" initialized
DEBUG - 2025-12-26 10:10:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 10:10:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 10:10:17 --> Final output sent to browser
DEBUG - 2025-12-26 10:10:17 --> Total execution time: 0.2427
INFO - 2025-12-26 11:40:45 --> Config Class Initialized
INFO - 2025-12-26 11:40:45 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:40:45 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:40:45 --> Utf8 Class Initialized
INFO - 2025-12-26 11:40:45 --> URI Class Initialized
INFO - 2025-12-26 11:40:45 --> Router Class Initialized
INFO - 2025-12-26 11:40:45 --> Output Class Initialized
INFO - 2025-12-26 11:40:45 --> Security Class Initialized
DEBUG - 2025-12-26 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:40:45 --> CSRF cookie sent
INFO - 2025-12-26 11:40:45 --> CSRF token verified
INFO - 2025-12-26 11:40:45 --> Input Class Initialized
INFO - 2025-12-26 11:40:45 --> Language Class Initialized
INFO - 2025-12-26 11:40:45 --> Loader Class Initialized
INFO - 2025-12-26 11:40:45 --> Helper loaded: url_helper
INFO - 2025-12-26 11:40:45 --> Helper loaded: form_helper
INFO - 2025-12-26 11:40:45 --> Helper loaded: file_helper
INFO - 2025-12-26 11:40:45 --> Helper loaded: html_helper
INFO - 2025-12-26 11:40:45 --> Helper loaded: security_helper
INFO - 2025-12-26 11:40:45 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:40:45 --> Database Driver Class Initialized
INFO - 2025-12-26 11:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:40:45 --> Form Validation Class Initialized
INFO - 2025-12-26 11:40:45 --> Controller Class Initialized
INFO - 2025-12-26 11:40:45 --> Model "User_model" initialized
DEBUG - 2025-12-26 11:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:40:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 11:40:46 --> Config Class Initialized
INFO - 2025-12-26 11:40:46 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:40:46 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:40:46 --> Utf8 Class Initialized
INFO - 2025-12-26 11:40:46 --> URI Class Initialized
INFO - 2025-12-26 11:40:46 --> Router Class Initialized
INFO - 2025-12-26 11:40:46 --> Output Class Initialized
INFO - 2025-12-26 11:40:46 --> Security Class Initialized
DEBUG - 2025-12-26 11:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:40:46 --> CSRF cookie sent
INFO - 2025-12-26 11:40:46 --> Input Class Initialized
INFO - 2025-12-26 11:40:46 --> Language Class Initialized
INFO - 2025-12-26 11:40:46 --> Loader Class Initialized
INFO - 2025-12-26 11:40:46 --> Helper loaded: url_helper
INFO - 2025-12-26 11:40:46 --> Helper loaded: form_helper
INFO - 2025-12-26 11:40:46 --> Helper loaded: file_helper
INFO - 2025-12-26 11:40:46 --> Helper loaded: html_helper
INFO - 2025-12-26 11:40:46 --> Helper loaded: security_helper
INFO - 2025-12-26 11:40:46 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:40:46 --> Database Driver Class Initialized
INFO - 2025-12-26 11:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:40:46 --> Form Validation Class Initialized
INFO - 2025-12-26 11:40:46 --> Controller Class Initialized
INFO - 2025-12-26 11:40:46 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 11:40:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:40:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:40:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:40:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 11:40:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:40:46 --> Final output sent to browser
DEBUG - 2025-12-26 11:40:46 --> Total execution time: 0.3283
INFO - 2025-12-26 11:40:55 --> Config Class Initialized
INFO - 2025-12-26 11:40:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:40:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:40:55 --> Utf8 Class Initialized
INFO - 2025-12-26 11:40:55 --> URI Class Initialized
INFO - 2025-12-26 11:40:55 --> Router Class Initialized
INFO - 2025-12-26 11:40:55 --> Output Class Initialized
INFO - 2025-12-26 11:40:55 --> Security Class Initialized
DEBUG - 2025-12-26 11:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:40:55 --> CSRF cookie sent
INFO - 2025-12-26 11:40:55 --> Input Class Initialized
INFO - 2025-12-26 11:40:55 --> Language Class Initialized
INFO - 2025-12-26 11:40:55 --> Loader Class Initialized
INFO - 2025-12-26 11:40:55 --> Helper loaded: url_helper
INFO - 2025-12-26 11:40:55 --> Helper loaded: form_helper
INFO - 2025-12-26 11:40:55 --> Helper loaded: file_helper
INFO - 2025-12-26 11:40:55 --> Helper loaded: html_helper
INFO - 2025-12-26 11:40:55 --> Helper loaded: security_helper
INFO - 2025-12-26 11:40:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:40:55 --> Database Driver Class Initialized
INFO - 2025-12-26 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:40:55 --> Form Validation Class Initialized
INFO - 2025-12-26 11:40:55 --> Controller Class Initialized
INFO - 2025-12-26 11:40:55 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 11:40:55 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 11:40:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:40:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:40:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:40:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:40:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 11:40:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:40:56 --> Final output sent to browser
DEBUG - 2025-12-26 11:40:56 --> Total execution time: 0.1380
INFO - 2025-12-26 11:41:00 --> Config Class Initialized
INFO - 2025-12-26 11:41:00 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:00 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:00 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:00 --> URI Class Initialized
INFO - 2025-12-26 11:41:00 --> Router Class Initialized
INFO - 2025-12-26 11:41:00 --> Output Class Initialized
INFO - 2025-12-26 11:41:00 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:00 --> CSRF cookie sent
INFO - 2025-12-26 11:41:00 --> Input Class Initialized
INFO - 2025-12-26 11:41:00 --> Language Class Initialized
INFO - 2025-12-26 11:41:00 --> Loader Class Initialized
INFO - 2025-12-26 11:41:00 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:00 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:00 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:00 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:00 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:00 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:00 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:00 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:00 --> Controller Class Initialized
INFO - 2025-12-26 11:41:00 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:00 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:00 --> Upload Class Initialized
INFO - 2025-12-26 11:41:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 11:41:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:00 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:00 --> Total execution time: 0.2003
INFO - 2025-12-26 11:41:02 --> Config Class Initialized
INFO - 2025-12-26 11:41:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:02 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:02 --> URI Class Initialized
INFO - 2025-12-26 11:41:02 --> Router Class Initialized
INFO - 2025-12-26 11:41:02 --> Output Class Initialized
INFO - 2025-12-26 11:41:02 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:02 --> CSRF cookie sent
INFO - 2025-12-26 11:41:02 --> Input Class Initialized
INFO - 2025-12-26 11:41:02 --> Language Class Initialized
INFO - 2025-12-26 11:41:02 --> Loader Class Initialized
INFO - 2025-12-26 11:41:02 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:02 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:02 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:02 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:02 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:02 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:02 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:02 --> Controller Class Initialized
INFO - 2025-12-26 11:41:02 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:02 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:02 --> Upload Class Initialized
INFO - 2025-12-26 11:41:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 11:41:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:02 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:02 --> Total execution time: 0.2641
INFO - 2025-12-26 11:41:27 --> Config Class Initialized
INFO - 2025-12-26 11:41:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:28 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:28 --> URI Class Initialized
INFO - 2025-12-26 11:41:28 --> Router Class Initialized
INFO - 2025-12-26 11:41:28 --> Output Class Initialized
INFO - 2025-12-26 11:41:28 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:28 --> CSRF cookie sent
INFO - 2025-12-26 11:41:28 --> CSRF token verified
INFO - 2025-12-26 11:41:28 --> Input Class Initialized
INFO - 2025-12-26 11:41:28 --> Language Class Initialized
INFO - 2025-12-26 11:41:28 --> Loader Class Initialized
INFO - 2025-12-26 11:41:28 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:28 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:28 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:28 --> Controller Class Initialized
INFO - 2025-12-26 11:41:28 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:28 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:28 --> Upload Class Initialized
INFO - 2025-12-26 11:41:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 11:41:28 --> Config Class Initialized
INFO - 2025-12-26 11:41:28 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:28 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:28 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:28 --> URI Class Initialized
INFO - 2025-12-26 11:41:28 --> Router Class Initialized
INFO - 2025-12-26 11:41:28 --> Output Class Initialized
INFO - 2025-12-26 11:41:28 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:28 --> CSRF cookie sent
INFO - 2025-12-26 11:41:28 --> Input Class Initialized
INFO - 2025-12-26 11:41:28 --> Language Class Initialized
INFO - 2025-12-26 11:41:28 --> Loader Class Initialized
INFO - 2025-12-26 11:41:28 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:28 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:28 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:28 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:28 --> Controller Class Initialized
INFO - 2025-12-26 11:41:28 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:28 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:28 --> Upload Class Initialized
INFO - 2025-12-26 11:41:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 11:41:28 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:28 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:28 --> Total execution time: 0.0493
INFO - 2025-12-26 11:41:32 --> Config Class Initialized
INFO - 2025-12-26 11:41:32 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:32 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:32 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:32 --> URI Class Initialized
INFO - 2025-12-26 11:41:32 --> Router Class Initialized
INFO - 2025-12-26 11:41:32 --> Output Class Initialized
INFO - 2025-12-26 11:41:32 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:32 --> CSRF cookie sent
INFO - 2025-12-26 11:41:32 --> Input Class Initialized
INFO - 2025-12-26 11:41:32 --> Language Class Initialized
INFO - 2025-12-26 11:41:32 --> Loader Class Initialized
INFO - 2025-12-26 11:41:32 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:32 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:32 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:32 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:32 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:32 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:32 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:32 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:32 --> Controller Class Initialized
INFO - 2025-12-26 11:41:32 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:32 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:32 --> Upload Class Initialized
INFO - 2025-12-26 11:41:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-26 11:41:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:32 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:32 --> Total execution time: 0.0510
INFO - 2025-12-26 11:41:33 --> Config Class Initialized
INFO - 2025-12-26 11:41:33 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:33 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:33 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:33 --> URI Class Initialized
INFO - 2025-12-26 11:41:33 --> Router Class Initialized
INFO - 2025-12-26 11:41:33 --> Output Class Initialized
INFO - 2025-12-26 11:41:33 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:33 --> CSRF cookie sent
INFO - 2025-12-26 11:41:33 --> Input Class Initialized
INFO - 2025-12-26 11:41:33 --> Language Class Initialized
INFO - 2025-12-26 11:41:33 --> Loader Class Initialized
INFO - 2025-12-26 11:41:33 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:33 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:33 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:33 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:33 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:33 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:33 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:33 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:33 --> Controller Class Initialized
INFO - 2025-12-26 11:41:33 --> Model "User_model" initialized
INFO - 2025-12-26 11:41:33 --> Model "Bagian_model" initialized
DEBUG - 2025-12-26 11:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:33 --> Upload Class Initialized
INFO - 2025-12-26 11:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-26 11:41:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:33 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:33 --> Total execution time: 0.0491
INFO - 2025-12-26 11:41:37 --> Config Class Initialized
INFO - 2025-12-26 11:41:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:37 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:37 --> URI Class Initialized
INFO - 2025-12-26 11:41:37 --> Router Class Initialized
INFO - 2025-12-26 11:41:37 --> Output Class Initialized
INFO - 2025-12-26 11:41:37 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:37 --> CSRF cookie sent
INFO - 2025-12-26 11:41:37 --> Input Class Initialized
INFO - 2025-12-26 11:41:37 --> Language Class Initialized
INFO - 2025-12-26 11:41:37 --> Loader Class Initialized
INFO - 2025-12-26 11:41:37 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:37 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:37 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:37 --> Controller Class Initialized
INFO - 2025-12-26 11:41:37 --> Model "User_model" initialized
DEBUG - 2025-12-26 11:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:37 --> Config Class Initialized
INFO - 2025-12-26 11:41:37 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:37 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:37 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:37 --> URI Class Initialized
INFO - 2025-12-26 11:41:37 --> Router Class Initialized
INFO - 2025-12-26 11:41:37 --> Output Class Initialized
INFO - 2025-12-26 11:41:37 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:37 --> CSRF cookie sent
INFO - 2025-12-26 11:41:37 --> Input Class Initialized
INFO - 2025-12-26 11:41:37 --> Language Class Initialized
INFO - 2025-12-26 11:41:37 --> Loader Class Initialized
INFO - 2025-12-26 11:41:37 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:37 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:37 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:37 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:37 --> Controller Class Initialized
INFO - 2025-12-26 11:41:37 --> Model "User_model" initialized
DEBUG - 2025-12-26 11:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-26 11:41:37 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:37 --> Total execution time: 0.0414
INFO - 2025-12-26 11:41:50 --> Config Class Initialized
INFO - 2025-12-26 11:41:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:50 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:50 --> URI Class Initialized
INFO - 2025-12-26 11:41:50 --> Router Class Initialized
INFO - 2025-12-26 11:41:50 --> Output Class Initialized
INFO - 2025-12-26 11:41:50 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:50 --> CSRF cookie sent
INFO - 2025-12-26 11:41:50 --> CSRF token verified
INFO - 2025-12-26 11:41:50 --> Input Class Initialized
INFO - 2025-12-26 11:41:50 --> Language Class Initialized
INFO - 2025-12-26 11:41:50 --> Loader Class Initialized
INFO - 2025-12-26 11:41:50 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:50 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:50 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:50 --> Controller Class Initialized
INFO - 2025-12-26 11:41:50 --> Model "User_model" initialized
DEBUG - 2025-12-26 11:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-26 11:41:50 --> Config Class Initialized
INFO - 2025-12-26 11:41:50 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:50 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:50 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:50 --> URI Class Initialized
INFO - 2025-12-26 11:41:50 --> Router Class Initialized
INFO - 2025-12-26 11:41:50 --> Output Class Initialized
INFO - 2025-12-26 11:41:50 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:50 --> CSRF cookie sent
INFO - 2025-12-26 11:41:50 --> Input Class Initialized
INFO - 2025-12-26 11:41:50 --> Language Class Initialized
INFO - 2025-12-26 11:41:50 --> Loader Class Initialized
INFO - 2025-12-26 11:41:50 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:50 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:50 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:50 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:50 --> Controller Class Initialized
INFO - 2025-12-26 11:41:50 --> Model "Dashboard_model" initialized
INFO - 2025-12-26 11:41:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-26 11:41:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:50 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:50 --> Total execution time: 0.0489
INFO - 2025-12-26 11:41:54 --> Config Class Initialized
INFO - 2025-12-26 11:41:54 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:54 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:54 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:54 --> URI Class Initialized
INFO - 2025-12-26 11:41:54 --> Router Class Initialized
INFO - 2025-12-26 11:41:54 --> Output Class Initialized
INFO - 2025-12-26 11:41:54 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:54 --> CSRF cookie sent
INFO - 2025-12-26 11:41:54 --> Input Class Initialized
INFO - 2025-12-26 11:41:54 --> Language Class Initialized
INFO - 2025-12-26 11:41:54 --> Loader Class Initialized
INFO - 2025-12-26 11:41:54 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:54 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:54 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:54 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:54 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:54 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:54 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:54 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:54 --> Controller Class Initialized
INFO - 2025-12-26 11:41:54 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 11:41:54 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:41:54 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:41:54 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 11:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:54 --> Upload Class Initialized
INFO - 2025-12-26 11:41:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 11:41:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:54 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:54 --> Total execution time: 0.2683
INFO - 2025-12-26 11:41:55 --> Config Class Initialized
INFO - 2025-12-26 11:41:55 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:55 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:55 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:55 --> URI Class Initialized
INFO - 2025-12-26 11:41:55 --> Router Class Initialized
INFO - 2025-12-26 11:41:55 --> Output Class Initialized
INFO - 2025-12-26 11:41:55 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:55 --> CSRF cookie sent
INFO - 2025-12-26 11:41:55 --> Input Class Initialized
INFO - 2025-12-26 11:41:55 --> Language Class Initialized
INFO - 2025-12-26 11:41:55 --> Loader Class Initialized
INFO - 2025-12-26 11:41:55 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:55 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:55 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:55 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:55 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:55 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:55 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:55 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:55 --> Controller Class Initialized
INFO - 2025-12-26 11:41:55 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 11:41:55 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 11:41:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 11:41:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:55 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:55 --> Total execution time: 0.0484
INFO - 2025-12-26 11:41:59 --> Config Class Initialized
INFO - 2025-12-26 11:41:59 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:41:59 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:41:59 --> Utf8 Class Initialized
INFO - 2025-12-26 11:41:59 --> URI Class Initialized
INFO - 2025-12-26 11:41:59 --> Router Class Initialized
INFO - 2025-12-26 11:41:59 --> Output Class Initialized
INFO - 2025-12-26 11:41:59 --> Security Class Initialized
DEBUG - 2025-12-26 11:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:41:59 --> CSRF cookie sent
INFO - 2025-12-26 11:41:59 --> Input Class Initialized
INFO - 2025-12-26 11:41:59 --> Language Class Initialized
INFO - 2025-12-26 11:41:59 --> Loader Class Initialized
INFO - 2025-12-26 11:41:59 --> Helper loaded: url_helper
INFO - 2025-12-26 11:41:59 --> Helper loaded: form_helper
INFO - 2025-12-26 11:41:59 --> Helper loaded: file_helper
INFO - 2025-12-26 11:41:59 --> Helper loaded: html_helper
INFO - 2025-12-26 11:41:59 --> Helper loaded: security_helper
INFO - 2025-12-26 11:41:59 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:41:59 --> Database Driver Class Initialized
INFO - 2025-12-26 11:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:41:59 --> Form Validation Class Initialized
INFO - 2025-12-26 11:41:59 --> Controller Class Initialized
INFO - 2025-12-26 11:41:59 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 11:41:59 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:41:59 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:41:59 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 11:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:41:59 --> Upload Class Initialized
INFO - 2025-12-26 11:41:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:41:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:41:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:41:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 11:41:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:41:59 --> Final output sent to browser
DEBUG - 2025-12-26 11:41:59 --> Total execution time: 0.0533
INFO - 2025-12-26 11:42:01 --> Config Class Initialized
INFO - 2025-12-26 11:42:01 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:01 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:01 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:01 --> URI Class Initialized
INFO - 2025-12-26 11:42:01 --> Router Class Initialized
INFO - 2025-12-26 11:42:01 --> Output Class Initialized
INFO - 2025-12-26 11:42:01 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:01 --> CSRF cookie sent
INFO - 2025-12-26 11:42:01 --> Input Class Initialized
INFO - 2025-12-26 11:42:01 --> Language Class Initialized
INFO - 2025-12-26 11:42:01 --> Loader Class Initialized
INFO - 2025-12-26 11:42:01 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:01 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:01 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:01 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:01 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:01 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:01 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:01 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:01 --> Controller Class Initialized
INFO - 2025-12-26 11:42:01 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 11:42:01 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:01 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:01 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 11:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:01 --> Upload Class Initialized
INFO - 2025-12-26 11:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 11:42:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:01 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:01 --> Total execution time: 0.0547
INFO - 2025-12-26 11:42:02 --> Config Class Initialized
INFO - 2025-12-26 11:42:02 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:02 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:02 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:02 --> URI Class Initialized
INFO - 2025-12-26 11:42:02 --> Router Class Initialized
INFO - 2025-12-26 11:42:02 --> Output Class Initialized
INFO - 2025-12-26 11:42:02 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:02 --> CSRF cookie sent
INFO - 2025-12-26 11:42:02 --> Input Class Initialized
INFO - 2025-12-26 11:42:02 --> Language Class Initialized
INFO - 2025-12-26 11:42:02 --> Loader Class Initialized
INFO - 2025-12-26 11:42:02 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:02 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:02 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:02 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:02 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:02 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:02 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:02 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:02 --> Controller Class Initialized
INFO - 2025-12-26 11:42:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 11:42:02 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:02 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 11:42:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:02 --> Upload Class Initialized
INFO - 2025-12-26 11:42:03 --> Helper loaded: text_helper
INFO - 2025-12-26 11:42:03 --> Helper loaded: custom_helper
INFO - 2025-12-26 11:42:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 11:42:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:03 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:03 --> Total execution time: 0.2600
INFO - 2025-12-26 11:42:06 --> Config Class Initialized
INFO - 2025-12-26 11:42:06 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:06 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:06 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:06 --> URI Class Initialized
INFO - 2025-12-26 11:42:06 --> Router Class Initialized
INFO - 2025-12-26 11:42:06 --> Output Class Initialized
INFO - 2025-12-26 11:42:06 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:06 --> CSRF cookie sent
INFO - 2025-12-26 11:42:06 --> Input Class Initialized
INFO - 2025-12-26 11:42:06 --> Language Class Initialized
INFO - 2025-12-26 11:42:06 --> Loader Class Initialized
INFO - 2025-12-26 11:42:06 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:06 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:06 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:06 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:06 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:06 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:06 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:06 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:06 --> Controller Class Initialized
INFO - 2025-12-26 11:42:06 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 11:42:06 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:06 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:06 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 11:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:06 --> Upload Class Initialized
INFO - 2025-12-26 11:42:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 11:42:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:06 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:06 --> Total execution time: 0.0525
INFO - 2025-12-26 11:42:07 --> Config Class Initialized
INFO - 2025-12-26 11:42:07 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:07 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:07 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:07 --> URI Class Initialized
INFO - 2025-12-26 11:42:07 --> Router Class Initialized
INFO - 2025-12-26 11:42:07 --> Output Class Initialized
INFO - 2025-12-26 11:42:07 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:07 --> CSRF cookie sent
INFO - 2025-12-26 11:42:07 --> Input Class Initialized
INFO - 2025-12-26 11:42:07 --> Language Class Initialized
INFO - 2025-12-26 11:42:07 --> Loader Class Initialized
INFO - 2025-12-26 11:42:07 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:07 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:07 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:07 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:07 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:07 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:07 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:08 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:08 --> Controller Class Initialized
INFO - 2025-12-26 11:42:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 11:42:08 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:08 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 11:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:08 --> Upload Class Initialized
INFO - 2025-12-26 11:42:08 --> Helper loaded: text_helper
INFO - 2025-12-26 11:42:08 --> Helper loaded: custom_helper
INFO - 2025-12-26 11:42:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 11:42:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:08 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:08 --> Total execution time: 0.0801
INFO - 2025-12-26 11:42:09 --> Config Class Initialized
INFO - 2025-12-26 11:42:09 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:09 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:09 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:09 --> URI Class Initialized
INFO - 2025-12-26 11:42:09 --> Router Class Initialized
INFO - 2025-12-26 11:42:09 --> Output Class Initialized
INFO - 2025-12-26 11:42:09 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:09 --> CSRF cookie sent
INFO - 2025-12-26 11:42:09 --> Input Class Initialized
INFO - 2025-12-26 11:42:09 --> Language Class Initialized
INFO - 2025-12-26 11:42:09 --> Loader Class Initialized
INFO - 2025-12-26 11:42:09 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:09 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:09 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:09 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:09 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:09 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:09 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:09 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:09 --> Controller Class Initialized
INFO - 2025-12-26 11:42:09 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 11:42:09 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 11:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 11:42:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:09 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:09 --> Total execution time: 0.0492
INFO - 2025-12-26 11:42:10 --> Config Class Initialized
INFO - 2025-12-26 11:42:10 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:10 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:10 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:10 --> URI Class Initialized
INFO - 2025-12-26 11:42:10 --> Router Class Initialized
INFO - 2025-12-26 11:42:10 --> Output Class Initialized
INFO - 2025-12-26 11:42:10 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:10 --> CSRF cookie sent
INFO - 2025-12-26 11:42:10 --> Input Class Initialized
INFO - 2025-12-26 11:42:10 --> Language Class Initialized
INFO - 2025-12-26 11:42:10 --> Loader Class Initialized
INFO - 2025-12-26 11:42:10 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:10 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:10 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:10 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:10 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:10 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:10 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:10 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:10 --> Controller Class Initialized
INFO - 2025-12-26 11:42:10 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-26 11:42:10 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:10 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:10 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-26 11:42:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:10 --> Upload Class Initialized
INFO - 2025-12-26 11:42:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-26 11:42:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:10 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:10 --> Total execution time: 0.0522
INFO - 2025-12-26 11:42:11 --> Config Class Initialized
INFO - 2025-12-26 11:42:11 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:11 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:11 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:11 --> URI Class Initialized
INFO - 2025-12-26 11:42:11 --> Router Class Initialized
INFO - 2025-12-26 11:42:11 --> Output Class Initialized
INFO - 2025-12-26 11:42:11 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:11 --> CSRF cookie sent
INFO - 2025-12-26 11:42:11 --> Input Class Initialized
INFO - 2025-12-26 11:42:11 --> Language Class Initialized
INFO - 2025-12-26 11:42:11 --> Loader Class Initialized
INFO - 2025-12-26 11:42:11 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:11 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:11 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:11 --> Controller Class Initialized
INFO - 2025-12-26 11:42:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 11:42:11 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:11 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 11:42:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:11 --> Upload Class Initialized
INFO - 2025-12-26 11:42:11 --> Helper loaded: text_helper
INFO - 2025-12-26 11:42:11 --> Helper loaded: custom_helper
INFO - 2025-12-26 11:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 11:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:11 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:11 --> Total execution time: 0.0559
INFO - 2025-12-26 11:42:18 --> Config Class Initialized
INFO - 2025-12-26 11:42:18 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:18 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:18 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:18 --> URI Class Initialized
INFO - 2025-12-26 11:42:18 --> Router Class Initialized
INFO - 2025-12-26 11:42:18 --> Output Class Initialized
INFO - 2025-12-26 11:42:18 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:18 --> CSRF cookie sent
INFO - 2025-12-26 11:42:18 --> Input Class Initialized
INFO - 2025-12-26 11:42:18 --> Language Class Initialized
INFO - 2025-12-26 11:42:18 --> Loader Class Initialized
INFO - 2025-12-26 11:42:18 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:18 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:18 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:18 --> Controller Class Initialized
INFO - 2025-12-26 11:42:18 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 11:42:18 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:18 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:18 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 11:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:18 --> Upload Class Initialized
INFO - 2025-12-26 11:42:18 --> Helper loaded: text_helper
INFO - 2025-12-26 11:42:18 --> Helper loaded: custom_helper
INFO - 2025-12-26 11:42:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-26 11:42:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:18 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:18 --> Total execution time: 0.1275
INFO - 2025-12-26 11:42:24 --> Config Class Initialized
INFO - 2025-12-26 11:42:24 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:24 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:24 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:24 --> URI Class Initialized
INFO - 2025-12-26 11:42:24 --> Router Class Initialized
INFO - 2025-12-26 11:42:24 --> Output Class Initialized
INFO - 2025-12-26 11:42:24 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:24 --> CSRF cookie sent
INFO - 2025-12-26 11:42:24 --> Input Class Initialized
INFO - 2025-12-26 11:42:24 --> Language Class Initialized
INFO - 2025-12-26 11:42:24 --> Loader Class Initialized
INFO - 2025-12-26 11:42:24 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:24 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:24 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:24 --> Controller Class Initialized
INFO - 2025-12-26 11:42:24 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-26 11:42:24 --> Model "Bagian_model" initialized
INFO - 2025-12-26 11:42:24 --> Model "Kategori_model" initialized
INFO - 2025-12-26 11:42:24 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-26 11:42:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:24 --> Upload Class Initialized
INFO - 2025-12-26 11:42:24 --> Helper loaded: text_helper
INFO - 2025-12-26 11:42:24 --> Helper loaded: custom_helper
INFO - 2025-12-26 11:42:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-26 11:42:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:24 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:24 --> Total execution time: 0.0549
INFO - 2025-12-26 11:42:27 --> Config Class Initialized
INFO - 2025-12-26 11:42:27 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:42:27 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:42:27 --> Utf8 Class Initialized
INFO - 2025-12-26 11:42:27 --> URI Class Initialized
INFO - 2025-12-26 11:42:27 --> Router Class Initialized
INFO - 2025-12-26 11:42:27 --> Output Class Initialized
INFO - 2025-12-26 11:42:27 --> Security Class Initialized
DEBUG - 2025-12-26 11:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:42:27 --> CSRF cookie sent
INFO - 2025-12-26 11:42:27 --> Input Class Initialized
INFO - 2025-12-26 11:42:27 --> Language Class Initialized
INFO - 2025-12-26 11:42:27 --> Loader Class Initialized
INFO - 2025-12-26 11:42:27 --> Helper loaded: url_helper
INFO - 2025-12-26 11:42:27 --> Helper loaded: form_helper
INFO - 2025-12-26 11:42:27 --> Helper loaded: file_helper
INFO - 2025-12-26 11:42:27 --> Helper loaded: html_helper
INFO - 2025-12-26 11:42:27 --> Helper loaded: security_helper
INFO - 2025-12-26 11:42:27 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:42:27 --> Database Driver Class Initialized
INFO - 2025-12-26 11:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:42:27 --> Form Validation Class Initialized
INFO - 2025-12-26 11:42:27 --> Controller Class Initialized
INFO - 2025-12-26 11:42:27 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 11:42:27 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 11:42:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:42:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:42:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:42:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:42:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 11:42:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:42:27 --> Final output sent to browser
DEBUG - 2025-12-26 11:42:27 --> Total execution time: 0.0473
INFO - 2025-12-26 11:43:48 --> Config Class Initialized
INFO - 2025-12-26 11:43:48 --> Hooks Class Initialized
DEBUG - 2025-12-26 11:43:48 --> UTF-8 Support Enabled
INFO - 2025-12-26 11:43:48 --> Utf8 Class Initialized
INFO - 2025-12-26 11:43:48 --> URI Class Initialized
INFO - 2025-12-26 11:43:48 --> Router Class Initialized
INFO - 2025-12-26 11:43:48 --> Output Class Initialized
INFO - 2025-12-26 11:43:48 --> Security Class Initialized
DEBUG - 2025-12-26 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-26 11:43:48 --> CSRF cookie sent
INFO - 2025-12-26 11:43:48 --> Input Class Initialized
INFO - 2025-12-26 11:43:48 --> Language Class Initialized
INFO - 2025-12-26 11:43:48 --> Loader Class Initialized
INFO - 2025-12-26 11:43:48 --> Helper loaded: url_helper
INFO - 2025-12-26 11:43:48 --> Helper loaded: form_helper
INFO - 2025-12-26 11:43:48 --> Helper loaded: file_helper
INFO - 2025-12-26 11:43:48 --> Helper loaded: html_helper
INFO - 2025-12-26 11:43:48 --> Helper loaded: security_helper
INFO - 2025-12-26 11:43:48 --> Helper loaded: surat_helper
INFO - 2025-12-26 11:43:48 --> Database Driver Class Initialized
INFO - 2025-12-26 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-26 11:43:48 --> Form Validation Class Initialized
INFO - 2025-12-26 11:43:48 --> Controller Class Initialized
INFO - 2025-12-26 11:43:48 --> Model "Disposisi_model" initialized
INFO - 2025-12-26 11:43:48 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-26 11:43:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-26 11:43:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-26 11:43:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-26 11:43:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-26 11:43:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-26 11:43:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-26 11:43:48 --> Final output sent to browser
DEBUG - 2025-12-26 11:43:48 --> Total execution time: 0.0475
