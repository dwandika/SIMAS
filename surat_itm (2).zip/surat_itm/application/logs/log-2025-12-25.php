<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-12-25 13:42:45 --> Config Class Initialized
INFO - 2025-12-25 13:42:45 --> Hooks Class Initialized
DEBUG - 2025-12-25 13:42:45 --> UTF-8 Support Enabled
INFO - 2025-12-25 13:42:45 --> Utf8 Class Initialized
INFO - 2025-12-25 13:42:45 --> URI Class Initialized
INFO - 2025-12-25 13:42:45 --> Router Class Initialized
INFO - 2025-12-25 13:42:45 --> Output Class Initialized
INFO - 2025-12-25 13:42:45 --> Security Class Initialized
DEBUG - 2025-12-25 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 13:42:45 --> CSRF cookie sent
INFO - 2025-12-25 13:42:45 --> Input Class Initialized
INFO - 2025-12-25 13:42:45 --> Language Class Initialized
INFO - 2025-12-25 13:42:45 --> Loader Class Initialized
INFO - 2025-12-25 13:42:45 --> Helper loaded: url_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: form_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: file_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: html_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: security_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: surat_helper
INFO - 2025-12-25 13:42:45 --> Database Driver Class Initialized
INFO - 2025-12-25 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 13:42:45 --> Form Validation Class Initialized
INFO - 2025-12-25 13:42:45 --> Controller Class Initialized
INFO - 2025-12-25 13:42:45 --> Config Class Initialized
INFO - 2025-12-25 13:42:45 --> Hooks Class Initialized
DEBUG - 2025-12-25 13:42:45 --> UTF-8 Support Enabled
INFO - 2025-12-25 13:42:45 --> Utf8 Class Initialized
INFO - 2025-12-25 13:42:45 --> URI Class Initialized
INFO - 2025-12-25 13:42:45 --> Router Class Initialized
INFO - 2025-12-25 13:42:45 --> Output Class Initialized
INFO - 2025-12-25 13:42:45 --> Security Class Initialized
DEBUG - 2025-12-25 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 13:42:45 --> CSRF cookie sent
INFO - 2025-12-25 13:42:45 --> Input Class Initialized
INFO - 2025-12-25 13:42:45 --> Language Class Initialized
INFO - 2025-12-25 13:42:45 --> Loader Class Initialized
INFO - 2025-12-25 13:42:45 --> Helper loaded: url_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: form_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: file_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: html_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: security_helper
INFO - 2025-12-25 13:42:45 --> Helper loaded: surat_helper
INFO - 2025-12-25 13:42:45 --> Database Driver Class Initialized
INFO - 2025-12-25 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 13:42:45 --> Form Validation Class Initialized
INFO - 2025-12-25 13:42:45 --> Controller Class Initialized
INFO - 2025-12-25 13:42:45 --> Model "User_model" initialized
DEBUG - 2025-12-25 13:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 13:42:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-25 13:42:45 --> Final output sent to browser
DEBUG - 2025-12-25 13:42:45 --> Total execution time: 0.0813
INFO - 2025-12-25 13:42:52 --> Config Class Initialized
INFO - 2025-12-25 13:42:52 --> Hooks Class Initialized
DEBUG - 2025-12-25 13:42:52 --> UTF-8 Support Enabled
INFO - 2025-12-25 13:42:52 --> Utf8 Class Initialized
INFO - 2025-12-25 13:42:52 --> URI Class Initialized
INFO - 2025-12-25 13:42:52 --> Router Class Initialized
INFO - 2025-12-25 13:42:52 --> Output Class Initialized
INFO - 2025-12-25 13:42:52 --> Security Class Initialized
DEBUG - 2025-12-25 13:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 13:42:52 --> CSRF cookie sent
INFO - 2025-12-25 13:42:52 --> CSRF token verified
INFO - 2025-12-25 13:42:52 --> Input Class Initialized
INFO - 2025-12-25 13:42:52 --> Language Class Initialized
INFO - 2025-12-25 13:42:52 --> Loader Class Initialized
INFO - 2025-12-25 13:42:52 --> Helper loaded: url_helper
INFO - 2025-12-25 13:42:52 --> Helper loaded: form_helper
INFO - 2025-12-25 13:42:52 --> Helper loaded: file_helper
INFO - 2025-12-25 13:42:52 --> Helper loaded: html_helper
INFO - 2025-12-25 13:42:52 --> Helper loaded: security_helper
INFO - 2025-12-25 13:42:52 --> Helper loaded: surat_helper
INFO - 2025-12-25 13:42:52 --> Database Driver Class Initialized
INFO - 2025-12-25 13:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 13:42:52 --> Form Validation Class Initialized
INFO - 2025-12-25 13:42:52 --> Controller Class Initialized
INFO - 2025-12-25 13:42:52 --> Model "User_model" initialized
DEBUG - 2025-12-25 13:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 13:42:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-25 13:42:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-25 13:42:52 --> Final output sent to browser
DEBUG - 2025-12-25 13:42:52 --> Total execution time: 0.0761
INFO - 2025-12-25 13:43:00 --> Config Class Initialized
INFO - 2025-12-25 13:43:00 --> Hooks Class Initialized
DEBUG - 2025-12-25 13:43:00 --> UTF-8 Support Enabled
INFO - 2025-12-25 13:43:00 --> Utf8 Class Initialized
INFO - 2025-12-25 13:43:00 --> URI Class Initialized
INFO - 2025-12-25 13:43:00 --> Router Class Initialized
INFO - 2025-12-25 13:43:00 --> Output Class Initialized
INFO - 2025-12-25 13:43:00 --> Security Class Initialized
DEBUG - 2025-12-25 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 13:43:00 --> CSRF cookie sent
INFO - 2025-12-25 13:43:00 --> CSRF token verified
INFO - 2025-12-25 13:43:00 --> Input Class Initialized
INFO - 2025-12-25 13:43:00 --> Language Class Initialized
INFO - 2025-12-25 13:43:00 --> Loader Class Initialized
INFO - 2025-12-25 13:43:00 --> Helper loaded: url_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: form_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: file_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: html_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: security_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: surat_helper
INFO - 2025-12-25 13:43:00 --> Database Driver Class Initialized
INFO - 2025-12-25 13:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 13:43:00 --> Form Validation Class Initialized
INFO - 2025-12-25 13:43:00 --> Controller Class Initialized
INFO - 2025-12-25 13:43:00 --> Model "User_model" initialized
DEBUG - 2025-12-25 13:43:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 13:43:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-25 13:43:00 --> Config Class Initialized
INFO - 2025-12-25 13:43:00 --> Hooks Class Initialized
DEBUG - 2025-12-25 13:43:00 --> UTF-8 Support Enabled
INFO - 2025-12-25 13:43:00 --> Utf8 Class Initialized
INFO - 2025-12-25 13:43:00 --> URI Class Initialized
INFO - 2025-12-25 13:43:00 --> Router Class Initialized
INFO - 2025-12-25 13:43:00 --> Output Class Initialized
INFO - 2025-12-25 13:43:00 --> Security Class Initialized
DEBUG - 2025-12-25 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 13:43:00 --> CSRF cookie sent
INFO - 2025-12-25 13:43:00 --> Input Class Initialized
INFO - 2025-12-25 13:43:00 --> Language Class Initialized
INFO - 2025-12-25 13:43:00 --> Loader Class Initialized
INFO - 2025-12-25 13:43:00 --> Helper loaded: url_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: form_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: file_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: html_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: security_helper
INFO - 2025-12-25 13:43:00 --> Helper loaded: surat_helper
INFO - 2025-12-25 13:43:00 --> Database Driver Class Initialized
INFO - 2025-12-25 13:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 13:43:00 --> Form Validation Class Initialized
INFO - 2025-12-25 13:43:00 --> Controller Class Initialized
INFO - 2025-12-25 13:43:00 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 13:43:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 13:43:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 13:43:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 13:43:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 13:43:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 13:43:00 --> Final output sent to browser
DEBUG - 2025-12-25 13:43:00 --> Total execution time: 0.0621
INFO - 2025-12-25 14:12:45 --> Config Class Initialized
INFO - 2025-12-25 14:12:45 --> Hooks Class Initialized
DEBUG - 2025-12-25 14:12:45 --> UTF-8 Support Enabled
INFO - 2025-12-25 14:12:45 --> Utf8 Class Initialized
INFO - 2025-12-25 14:12:45 --> URI Class Initialized
INFO - 2025-12-25 14:12:45 --> Router Class Initialized
INFO - 2025-12-25 14:12:45 --> Output Class Initialized
INFO - 2025-12-25 14:12:45 --> Security Class Initialized
DEBUG - 2025-12-25 14:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 14:12:45 --> CSRF cookie sent
INFO - 2025-12-25 14:12:45 --> Input Class Initialized
INFO - 2025-12-25 14:12:45 --> Language Class Initialized
INFO - 2025-12-25 14:12:46 --> Loader Class Initialized
INFO - 2025-12-25 14:12:46 --> Helper loaded: url_helper
INFO - 2025-12-25 14:12:46 --> Helper loaded: form_helper
INFO - 2025-12-25 14:12:46 --> Helper loaded: file_helper
INFO - 2025-12-25 14:12:46 --> Helper loaded: html_helper
INFO - 2025-12-25 14:12:46 --> Helper loaded: security_helper
INFO - 2025-12-25 14:12:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 14:12:46 --> Database Driver Class Initialized
INFO - 2025-12-25 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 14:12:46 --> Form Validation Class Initialized
INFO - 2025-12-25 14:12:46 --> Controller Class Initialized
INFO - 2025-12-25 14:12:46 --> Model "Laporan_model" initialized
INFO - 2025-12-25 14:12:46 --> Model "Kategori_model" initialized
ERROR - 2025-12-25 14:12:47 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-25 14:12:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 14:14:14 --> Config Class Initialized
INFO - 2025-12-25 14:14:14 --> Hooks Class Initialized
DEBUG - 2025-12-25 14:14:14 --> UTF-8 Support Enabled
INFO - 2025-12-25 14:14:14 --> Utf8 Class Initialized
INFO - 2025-12-25 14:14:14 --> URI Class Initialized
INFO - 2025-12-25 14:14:14 --> Router Class Initialized
INFO - 2025-12-25 14:14:14 --> Output Class Initialized
INFO - 2025-12-25 14:14:14 --> Security Class Initialized
DEBUG - 2025-12-25 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 14:14:14 --> CSRF cookie sent
INFO - 2025-12-25 14:14:14 --> Input Class Initialized
INFO - 2025-12-25 14:14:14 --> Language Class Initialized
INFO - 2025-12-25 14:14:14 --> Loader Class Initialized
INFO - 2025-12-25 14:14:14 --> Helper loaded: url_helper
INFO - 2025-12-25 14:14:14 --> Helper loaded: form_helper
INFO - 2025-12-25 14:14:14 --> Helper loaded: file_helper
INFO - 2025-12-25 14:14:14 --> Helper loaded: html_helper
INFO - 2025-12-25 14:14:14 --> Helper loaded: security_helper
INFO - 2025-12-25 14:14:14 --> Helper loaded: surat_helper
INFO - 2025-12-25 14:14:14 --> Database Driver Class Initialized
INFO - 2025-12-25 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 14:14:14 --> Form Validation Class Initialized
INFO - 2025-12-25 14:14:14 --> Controller Class Initialized
INFO - 2025-12-25 14:14:14 --> Model "Laporan_model" initialized
INFO - 2025-12-25 14:14:14 --> Model "Kategori_model" initialized
ERROR - 2025-12-25 14:14:14 --> Query error: Unknown column 'u.nama' in 'field list' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-25 14:14:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 15:09:31 --> Config Class Initialized
INFO - 2025-12-25 15:09:31 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:31 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:31 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:31 --> URI Class Initialized
INFO - 2025-12-25 15:09:31 --> Router Class Initialized
INFO - 2025-12-25 15:09:31 --> Output Class Initialized
INFO - 2025-12-25 15:09:31 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:31 --> CSRF cookie sent
INFO - 2025-12-25 15:09:31 --> Input Class Initialized
INFO - 2025-12-25 15:09:31 --> Language Class Initialized
INFO - 2025-12-25 15:09:32 --> Loader Class Initialized
INFO - 2025-12-25 15:09:32 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:32 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:32 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:32 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:32 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:32 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:32 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:32 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:32 --> Controller Class Initialized
INFO - 2025-12-25 15:09:32 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 15:09:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 15:09:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:33 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:33 --> Total execution time: 1.5008
INFO - 2025-12-25 15:09:34 --> Config Class Initialized
INFO - 2025-12-25 15:09:34 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:34 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:34 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:34 --> URI Class Initialized
INFO - 2025-12-25 15:09:34 --> Router Class Initialized
INFO - 2025-12-25 15:09:34 --> Output Class Initialized
INFO - 2025-12-25 15:09:34 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:34 --> CSRF cookie sent
INFO - 2025-12-25 15:09:34 --> Input Class Initialized
INFO - 2025-12-25 15:09:34 --> Language Class Initialized
INFO - 2025-12-25 15:09:34 --> Loader Class Initialized
INFO - 2025-12-25 15:09:34 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:34 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:34 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:34 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:34 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:34 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:34 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:34 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:34 --> Controller Class Initialized
INFO - 2025-12-25 15:09:34 --> Model "Laporan_model" initialized
INFO - 2025-12-25 15:09:34 --> Model "Kategori_model" initialized
INFO - 2025-12-25 15:09:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-25 15:09:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:35 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:35 --> Total execution time: 0.2045
INFO - 2025-12-25 15:09:36 --> Config Class Initialized
INFO - 2025-12-25 15:09:36 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:36 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:36 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:36 --> URI Class Initialized
INFO - 2025-12-25 15:09:36 --> Router Class Initialized
INFO - 2025-12-25 15:09:36 --> Output Class Initialized
INFO - 2025-12-25 15:09:36 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:36 --> CSRF cookie sent
INFO - 2025-12-25 15:09:36 --> Input Class Initialized
INFO - 2025-12-25 15:09:36 --> Language Class Initialized
INFO - 2025-12-25 15:09:36 --> Loader Class Initialized
INFO - 2025-12-25 15:09:36 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:36 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:36 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:36 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:36 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:36 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:36 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:36 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:36 --> Controller Class Initialized
INFO - 2025-12-25 15:09:36 --> Model "Kategori_model" initialized
DEBUG - 2025-12-25 15:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-25 15:09:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:36 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:36 --> Total execution time: 0.1588
INFO - 2025-12-25 15:09:37 --> Config Class Initialized
INFO - 2025-12-25 15:09:37 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:37 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:37 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:37 --> URI Class Initialized
INFO - 2025-12-25 15:09:37 --> Router Class Initialized
INFO - 2025-12-25 15:09:37 --> Output Class Initialized
INFO - 2025-12-25 15:09:37 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:37 --> CSRF cookie sent
INFO - 2025-12-25 15:09:37 --> Input Class Initialized
INFO - 2025-12-25 15:09:37 --> Language Class Initialized
INFO - 2025-12-25 15:09:37 --> Loader Class Initialized
INFO - 2025-12-25 15:09:37 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:37 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:37 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:37 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:37 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:37 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:37 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:37 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:37 --> Controller Class Initialized
INFO - 2025-12-25 15:09:37 --> Model "User_model" initialized
INFO - 2025-12-25 15:09:37 --> Model "Bagian_model" initialized
DEBUG - 2025-12-25 15:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:38 --> Upload Class Initialized
INFO - 2025-12-25 15:09:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-25 15:09:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:38 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:38 --> Total execution time: 1.0610
INFO - 2025-12-25 15:09:46 --> Config Class Initialized
INFO - 2025-12-25 15:09:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:46 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:46 --> URI Class Initialized
INFO - 2025-12-25 15:09:46 --> Router Class Initialized
INFO - 2025-12-25 15:09:46 --> Output Class Initialized
INFO - 2025-12-25 15:09:46 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:46 --> CSRF cookie sent
INFO - 2025-12-25 15:09:46 --> Input Class Initialized
INFO - 2025-12-25 15:09:46 --> Language Class Initialized
INFO - 2025-12-25 15:09:46 --> Loader Class Initialized
INFO - 2025-12-25 15:09:46 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:46 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:46 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:46 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:46 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:46 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:46 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:46 --> Controller Class Initialized
INFO - 2025-12-25 15:09:46 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 15:09:46 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 15:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-25 15:09:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:46 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:46 --> Total execution time: 0.1834
INFO - 2025-12-25 15:09:48 --> Config Class Initialized
INFO - 2025-12-25 15:09:48 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:48 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:48 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:48 --> URI Class Initialized
INFO - 2025-12-25 15:09:48 --> Router Class Initialized
INFO - 2025-12-25 15:09:48 --> Output Class Initialized
INFO - 2025-12-25 15:09:48 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:48 --> CSRF cookie sent
INFO - 2025-12-25 15:09:48 --> Input Class Initialized
INFO - 2025-12-25 15:09:48 --> Language Class Initialized
INFO - 2025-12-25 15:09:48 --> Loader Class Initialized
INFO - 2025-12-25 15:09:48 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:48 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:48 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:48 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:48 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:48 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:48 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:49 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:49 --> Controller Class Initialized
INFO - 2025-12-25 15:09:49 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 15:09:49 --> Model "Bagian_model" initialized
INFO - 2025-12-25 15:09:49 --> Model "Kategori_model" initialized
INFO - 2025-12-25 15:09:49 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 15:09:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:49 --> Upload Class Initialized
INFO - 2025-12-25 15:09:49 --> Helper loaded: text_helper
INFO - 2025-12-25 15:09:49 --> Helper loaded: custom_helper
INFO - 2025-12-25 15:09:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 15:09:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:49 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:49 --> Total execution time: 0.3148
INFO - 2025-12-25 15:09:52 --> Config Class Initialized
INFO - 2025-12-25 15:09:52 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:52 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:52 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:52 --> URI Class Initialized
INFO - 2025-12-25 15:09:52 --> Router Class Initialized
INFO - 2025-12-25 15:09:52 --> Output Class Initialized
INFO - 2025-12-25 15:09:52 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:52 --> CSRF cookie sent
INFO - 2025-12-25 15:09:52 --> Input Class Initialized
INFO - 2025-12-25 15:09:52 --> Language Class Initialized
INFO - 2025-12-25 15:09:52 --> Loader Class Initialized
INFO - 2025-12-25 15:09:52 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:52 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:52 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:52 --> Controller Class Initialized
INFO - 2025-12-25 15:09:52 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 15:09:52 --> Model "Bagian_model" initialized
INFO - 2025-12-25 15:09:52 --> Model "Kategori_model" initialized
INFO - 2025-12-25 15:09:52 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 15:09:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:52 --> Upload Class Initialized
INFO - 2025-12-25 15:09:52 --> Helper loaded: text_helper
INFO - 2025-12-25 15:09:52 --> Helper loaded: custom_helper
INFO - 2025-12-25 15:09:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-25 15:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:53 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:53 --> Total execution time: 0.1445
INFO - 2025-12-25 15:09:54 --> Config Class Initialized
INFO - 2025-12-25 15:09:54 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:09:54 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:09:54 --> Utf8 Class Initialized
INFO - 2025-12-25 15:09:54 --> URI Class Initialized
INFO - 2025-12-25 15:09:54 --> Router Class Initialized
INFO - 2025-12-25 15:09:54 --> Output Class Initialized
INFO - 2025-12-25 15:09:54 --> Security Class Initialized
DEBUG - 2025-12-25 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:09:54 --> CSRF cookie sent
INFO - 2025-12-25 15:09:54 --> Input Class Initialized
INFO - 2025-12-25 15:09:54 --> Language Class Initialized
INFO - 2025-12-25 15:09:54 --> Loader Class Initialized
INFO - 2025-12-25 15:09:54 --> Helper loaded: url_helper
INFO - 2025-12-25 15:09:54 --> Helper loaded: form_helper
INFO - 2025-12-25 15:09:54 --> Helper loaded: file_helper
INFO - 2025-12-25 15:09:54 --> Helper loaded: html_helper
INFO - 2025-12-25 15:09:54 --> Helper loaded: security_helper
INFO - 2025-12-25 15:09:54 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:09:54 --> Database Driver Class Initialized
INFO - 2025-12-25 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:09:54 --> Form Validation Class Initialized
INFO - 2025-12-25 15:09:54 --> Controller Class Initialized
INFO - 2025-12-25 15:09:54 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 15:09:54 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 15:09:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:09:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:09:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:09:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:09:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/form.php
INFO - 2025-12-25 15:09:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:09:54 --> Final output sent to browser
DEBUG - 2025-12-25 15:09:54 --> Total execution time: 0.1174
INFO - 2025-12-25 15:10:08 --> Config Class Initialized
INFO - 2025-12-25 15:10:08 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:10:08 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:10:08 --> Utf8 Class Initialized
INFO - 2025-12-25 15:10:08 --> URI Class Initialized
INFO - 2025-12-25 15:10:08 --> Router Class Initialized
INFO - 2025-12-25 15:10:08 --> Output Class Initialized
INFO - 2025-12-25 15:10:08 --> Security Class Initialized
DEBUG - 2025-12-25 15:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:10:08 --> CSRF cookie sent
INFO - 2025-12-25 15:10:08 --> CSRF token verified
INFO - 2025-12-25 15:10:08 --> Input Class Initialized
INFO - 2025-12-25 15:10:08 --> Language Class Initialized
INFO - 2025-12-25 15:10:08 --> Loader Class Initialized
INFO - 2025-12-25 15:10:08 --> Helper loaded: url_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: form_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: file_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: html_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: security_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:10:08 --> Database Driver Class Initialized
INFO - 2025-12-25 15:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:10:08 --> Form Validation Class Initialized
INFO - 2025-12-25 15:10:08 --> Controller Class Initialized
INFO - 2025-12-25 15:10:08 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 15:10:08 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 15:10:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:10:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-25 15:10:08 --> Config Class Initialized
INFO - 2025-12-25 15:10:08 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:10:08 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:10:08 --> Utf8 Class Initialized
INFO - 2025-12-25 15:10:08 --> URI Class Initialized
INFO - 2025-12-25 15:10:08 --> Router Class Initialized
INFO - 2025-12-25 15:10:08 --> Output Class Initialized
INFO - 2025-12-25 15:10:08 --> Security Class Initialized
DEBUG - 2025-12-25 15:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:10:08 --> CSRF cookie sent
INFO - 2025-12-25 15:10:08 --> Input Class Initialized
INFO - 2025-12-25 15:10:08 --> Language Class Initialized
INFO - 2025-12-25 15:10:08 --> Loader Class Initialized
INFO - 2025-12-25 15:10:08 --> Helper loaded: url_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: form_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: file_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: html_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: security_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:10:08 --> Database Driver Class Initialized
INFO - 2025-12-25 15:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:10:08 --> Form Validation Class Initialized
INFO - 2025-12-25 15:10:08 --> Controller Class Initialized
INFO - 2025-12-25 15:10:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 15:10:08 --> Model "Bagian_model" initialized
INFO - 2025-12-25 15:10:08 --> Model "Kategori_model" initialized
INFO - 2025-12-25 15:10:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 15:10:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:10:08 --> Upload Class Initialized
INFO - 2025-12-25 15:10:08 --> Helper loaded: text_helper
INFO - 2025-12-25 15:10:08 --> Helper loaded: custom_helper
INFO - 2025-12-25 15:10:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:10:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:10:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:10:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-25 15:10:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:10:08 --> Final output sent to browser
DEBUG - 2025-12-25 15:10:08 --> Total execution time: 0.0536
INFO - 2025-12-25 15:10:12 --> Config Class Initialized
INFO - 2025-12-25 15:10:12 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:10:12 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:10:12 --> Utf8 Class Initialized
INFO - 2025-12-25 15:10:12 --> URI Class Initialized
INFO - 2025-12-25 15:10:12 --> Router Class Initialized
INFO - 2025-12-25 15:10:12 --> Output Class Initialized
INFO - 2025-12-25 15:10:12 --> Security Class Initialized
DEBUG - 2025-12-25 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:10:12 --> CSRF cookie sent
INFO - 2025-12-25 15:10:12 --> Input Class Initialized
INFO - 2025-12-25 15:10:12 --> Language Class Initialized
INFO - 2025-12-25 15:10:12 --> Loader Class Initialized
INFO - 2025-12-25 15:10:12 --> Helper loaded: url_helper
INFO - 2025-12-25 15:10:12 --> Helper loaded: form_helper
INFO - 2025-12-25 15:10:12 --> Helper loaded: file_helper
INFO - 2025-12-25 15:10:12 --> Helper loaded: html_helper
INFO - 2025-12-25 15:10:12 --> Helper loaded: security_helper
INFO - 2025-12-25 15:10:12 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:10:12 --> Database Driver Class Initialized
INFO - 2025-12-25 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:10:12 --> Form Validation Class Initialized
INFO - 2025-12-25 15:10:12 --> Controller Class Initialized
INFO - 2025-12-25 15:10:12 --> Model "User_model" initialized
INFO - 2025-12-25 15:10:12 --> Model "Bagian_model" initialized
DEBUG - 2025-12-25 15:10:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:10:12 --> Upload Class Initialized
INFO - 2025-12-25 15:10:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:10:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:10:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:10:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-25 15:10:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:10:13 --> Final output sent to browser
DEBUG - 2025-12-25 15:10:13 --> Total execution time: 0.0520
INFO - 2025-12-25 15:10:15 --> Config Class Initialized
INFO - 2025-12-25 15:10:15 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:10:15 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:10:15 --> Utf8 Class Initialized
INFO - 2025-12-25 15:10:15 --> URI Class Initialized
INFO - 2025-12-25 15:10:15 --> Router Class Initialized
INFO - 2025-12-25 15:10:15 --> Output Class Initialized
INFO - 2025-12-25 15:10:15 --> Security Class Initialized
DEBUG - 2025-12-25 15:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:10:15 --> CSRF cookie sent
INFO - 2025-12-25 15:10:15 --> Input Class Initialized
INFO - 2025-12-25 15:10:15 --> Language Class Initialized
INFO - 2025-12-25 15:10:15 --> Loader Class Initialized
INFO - 2025-12-25 15:10:15 --> Helper loaded: url_helper
INFO - 2025-12-25 15:10:15 --> Helper loaded: form_helper
INFO - 2025-12-25 15:10:15 --> Helper loaded: file_helper
INFO - 2025-12-25 15:10:15 --> Helper loaded: html_helper
INFO - 2025-12-25 15:10:15 --> Helper loaded: security_helper
INFO - 2025-12-25 15:10:15 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:10:15 --> Database Driver Class Initialized
INFO - 2025-12-25 15:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:10:15 --> Form Validation Class Initialized
INFO - 2025-12-25 15:10:15 --> Controller Class Initialized
INFO - 2025-12-25 15:10:15 --> Model "User_model" initialized
INFO - 2025-12-25 15:10:15 --> Model "Bagian_model" initialized
DEBUG - 2025-12-25 15:10:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:10:15 --> Upload Class Initialized
INFO - 2025-12-25 15:10:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 15:10:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 15:10:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 15:10:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-25 15:10:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 15:10:15 --> Final output sent to browser
DEBUG - 2025-12-25 15:10:15 --> Total execution time: 0.2275
INFO - 2025-12-25 15:10:58 --> Config Class Initialized
INFO - 2025-12-25 15:10:58 --> Hooks Class Initialized
DEBUG - 2025-12-25 15:10:58 --> UTF-8 Support Enabled
INFO - 2025-12-25 15:10:58 --> Utf8 Class Initialized
INFO - 2025-12-25 15:10:58 --> URI Class Initialized
INFO - 2025-12-25 15:10:58 --> Router Class Initialized
INFO - 2025-12-25 15:10:58 --> Output Class Initialized
INFO - 2025-12-25 15:10:58 --> Security Class Initialized
DEBUG - 2025-12-25 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 15:10:58 --> CSRF cookie sent
INFO - 2025-12-25 15:10:58 --> CSRF token verified
INFO - 2025-12-25 15:10:58 --> Input Class Initialized
INFO - 2025-12-25 15:10:58 --> Language Class Initialized
INFO - 2025-12-25 15:10:58 --> Loader Class Initialized
INFO - 2025-12-25 15:10:58 --> Helper loaded: url_helper
INFO - 2025-12-25 15:10:58 --> Helper loaded: form_helper
INFO - 2025-12-25 15:10:58 --> Helper loaded: file_helper
INFO - 2025-12-25 15:10:58 --> Helper loaded: html_helper
INFO - 2025-12-25 15:10:58 --> Helper loaded: security_helper
INFO - 2025-12-25 15:10:58 --> Helper loaded: surat_helper
INFO - 2025-12-25 15:10:58 --> Database Driver Class Initialized
INFO - 2025-12-25 15:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 15:10:58 --> Form Validation Class Initialized
INFO - 2025-12-25 15:10:58 --> Controller Class Initialized
INFO - 2025-12-25 15:10:58 --> Model "User_model" initialized
INFO - 2025-12-25 15:10:58 --> Model "Bagian_model" initialized
DEBUG - 2025-12-25 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 15:10:58 --> Upload Class Initialized
INFO - 2025-12-25 15:10:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-25 15:10:58 --> Query error: Unknown column 'tanda_tangan' in 'field list' - Invalid query: INSERT INTO `user` (`username`, `password`, `nama`, `role`, `jabatan`, `kode_bagian`, `foto_profil`, `tanda_tangan`, `status`) VALUES ('rektor', '$2y$10$QHAAk8errgCwcgi6DQH3aOQwdDfkN7SiQ5UW7qcUwVLO3cowe9TZ2', 'Wardi, M. Pd', 'pimpinan', 'Rektor', 'ITM', NULL, NULL, '1')
INFO - 2025-12-25 15:10:58 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:40:23 --> Config Class Initialized
INFO - 2025-12-25 22:40:23 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:40:23 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:40:23 --> Utf8 Class Initialized
INFO - 2025-12-25 22:40:23 --> URI Class Initialized
INFO - 2025-12-25 22:40:23 --> Router Class Initialized
INFO - 2025-12-25 22:40:23 --> Output Class Initialized
INFO - 2025-12-25 22:40:23 --> Security Class Initialized
DEBUG - 2025-12-25 22:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:40:23 --> CSRF cookie sent
INFO - 2025-12-25 22:40:23 --> Input Class Initialized
INFO - 2025-12-25 22:40:23 --> Language Class Initialized
INFO - 2025-12-25 22:40:23 --> Loader Class Initialized
INFO - 2025-12-25 22:40:23 --> Helper loaded: url_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: form_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: file_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: html_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: security_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:40:23 --> Database Driver Class Initialized
INFO - 2025-12-25 22:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:40:23 --> Form Validation Class Initialized
INFO - 2025-12-25 22:40:23 --> Controller Class Initialized
INFO - 2025-12-25 22:40:23 --> Config Class Initialized
INFO - 2025-12-25 22:40:23 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:40:23 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:40:23 --> Utf8 Class Initialized
INFO - 2025-12-25 22:40:23 --> URI Class Initialized
INFO - 2025-12-25 22:40:23 --> Router Class Initialized
INFO - 2025-12-25 22:40:23 --> Output Class Initialized
INFO - 2025-12-25 22:40:23 --> Security Class Initialized
DEBUG - 2025-12-25 22:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:40:23 --> CSRF cookie sent
INFO - 2025-12-25 22:40:23 --> Input Class Initialized
INFO - 2025-12-25 22:40:23 --> Language Class Initialized
INFO - 2025-12-25 22:40:23 --> Loader Class Initialized
INFO - 2025-12-25 22:40:23 --> Helper loaded: url_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: form_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: file_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: html_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: security_helper
INFO - 2025-12-25 22:40:23 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:40:23 --> Database Driver Class Initialized
INFO - 2025-12-25 22:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:40:23 --> Form Validation Class Initialized
INFO - 2025-12-25 22:40:23 --> Controller Class Initialized
INFO - 2025-12-25 22:40:23 --> Model "User_model" initialized
DEBUG - 2025-12-25 22:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:40:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-25 22:40:23 --> Final output sent to browser
DEBUG - 2025-12-25 22:40:23 --> Total execution time: 0.1906
INFO - 2025-12-25 22:40:32 --> Config Class Initialized
INFO - 2025-12-25 22:40:32 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:40:32 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:40:32 --> Utf8 Class Initialized
INFO - 2025-12-25 22:40:32 --> URI Class Initialized
INFO - 2025-12-25 22:40:32 --> Router Class Initialized
INFO - 2025-12-25 22:40:32 --> Output Class Initialized
INFO - 2025-12-25 22:40:32 --> Security Class Initialized
DEBUG - 2025-12-25 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:40:32 --> CSRF cookie sent
INFO - 2025-12-25 22:40:32 --> CSRF token verified
INFO - 2025-12-25 22:40:32 --> Input Class Initialized
INFO - 2025-12-25 22:40:32 --> Language Class Initialized
INFO - 2025-12-25 22:40:32 --> Loader Class Initialized
INFO - 2025-12-25 22:40:32 --> Helper loaded: url_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: form_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: file_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: html_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: security_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:40:32 --> Database Driver Class Initialized
INFO - 2025-12-25 22:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:40:32 --> Form Validation Class Initialized
INFO - 2025-12-25 22:40:32 --> Controller Class Initialized
INFO - 2025-12-25 22:40:32 --> Model "User_model" initialized
DEBUG - 2025-12-25 22:40:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:40:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-25 22:40:32 --> Config Class Initialized
INFO - 2025-12-25 22:40:32 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:40:32 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:40:32 --> Utf8 Class Initialized
INFO - 2025-12-25 22:40:32 --> URI Class Initialized
INFO - 2025-12-25 22:40:32 --> Router Class Initialized
INFO - 2025-12-25 22:40:32 --> Output Class Initialized
INFO - 2025-12-25 22:40:32 --> Security Class Initialized
DEBUG - 2025-12-25 22:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:40:32 --> CSRF cookie sent
INFO - 2025-12-25 22:40:32 --> Input Class Initialized
INFO - 2025-12-25 22:40:32 --> Language Class Initialized
INFO - 2025-12-25 22:40:32 --> Loader Class Initialized
INFO - 2025-12-25 22:40:32 --> Helper loaded: url_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: form_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: file_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: html_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: security_helper
INFO - 2025-12-25 22:40:32 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:40:32 --> Database Driver Class Initialized
INFO - 2025-12-25 22:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:40:32 --> Form Validation Class Initialized
INFO - 2025-12-25 22:40:32 --> Controller Class Initialized
INFO - 2025-12-25 22:40:32 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:40:32 --> Severity: error --> Exception: Call to undefined method Dashboard_model::get_total_belum_ttd() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 28
INFO - 2025-12-25 22:56:23 --> Config Class Initialized
INFO - 2025-12-25 22:56:23 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:23 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:23 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:23 --> URI Class Initialized
INFO - 2025-12-25 22:56:23 --> Router Class Initialized
INFO - 2025-12-25 22:56:23 --> Output Class Initialized
INFO - 2025-12-25 22:56:23 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:23 --> CSRF cookie sent
INFO - 2025-12-25 22:56:23 --> Input Class Initialized
INFO - 2025-12-25 22:56:23 --> Language Class Initialized
INFO - 2025-12-25 22:56:23 --> Loader Class Initialized
INFO - 2025-12-25 22:56:23 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:23 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:23 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:23 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:23 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:23 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:23 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:23 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:23 --> Controller Class Initialized
INFO - 2025-12-25 22:56:23 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:56:23 --> Severity: error --> Exception: Call to undefined method Dashboard_model::get_total_belum_ttd() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 28
INFO - 2025-12-25 22:56:24 --> Config Class Initialized
INFO - 2025-12-25 22:56:24 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:24 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:24 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:24 --> URI Class Initialized
INFO - 2025-12-25 22:56:24 --> Router Class Initialized
INFO - 2025-12-25 22:56:24 --> Output Class Initialized
INFO - 2025-12-25 22:56:24 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:24 --> CSRF cookie sent
INFO - 2025-12-25 22:56:24 --> Input Class Initialized
INFO - 2025-12-25 22:56:24 --> Language Class Initialized
INFO - 2025-12-25 22:56:24 --> Loader Class Initialized
INFO - 2025-12-25 22:56:24 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:24 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:24 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:24 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:24 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:24 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:24 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:24 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:24 --> Controller Class Initialized
INFO - 2025-12-25 22:56:24 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:56:24 --> Severity: error --> Exception: Call to undefined method Dashboard_model::get_total_belum_ttd() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 28
INFO - 2025-12-25 22:56:25 --> Config Class Initialized
INFO - 2025-12-25 22:56:25 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:25 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:25 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:25 --> URI Class Initialized
INFO - 2025-12-25 22:56:25 --> Router Class Initialized
INFO - 2025-12-25 22:56:25 --> Output Class Initialized
INFO - 2025-12-25 22:56:25 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:25 --> CSRF cookie sent
INFO - 2025-12-25 22:56:25 --> Input Class Initialized
INFO - 2025-12-25 22:56:25 --> Language Class Initialized
INFO - 2025-12-25 22:56:25 --> Loader Class Initialized
INFO - 2025-12-25 22:56:25 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:25 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:25 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:25 --> Controller Class Initialized
INFO - 2025-12-25 22:56:25 --> Model "User_model" initialized
DEBUG - 2025-12-25 22:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:56:25 --> Config Class Initialized
INFO - 2025-12-25 22:56:25 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:25 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:25 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:25 --> URI Class Initialized
INFO - 2025-12-25 22:56:25 --> Router Class Initialized
INFO - 2025-12-25 22:56:25 --> Output Class Initialized
INFO - 2025-12-25 22:56:25 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:25 --> CSRF cookie sent
INFO - 2025-12-25 22:56:25 --> Input Class Initialized
INFO - 2025-12-25 22:56:25 --> Language Class Initialized
INFO - 2025-12-25 22:56:25 --> Loader Class Initialized
INFO - 2025-12-25 22:56:25 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:25 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:25 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:25 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:25 --> Controller Class Initialized
INFO - 2025-12-25 22:56:25 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:56:25 --> Severity: error --> Exception: Call to undefined method Dashboard_model::get_total_belum_ttd() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 28
INFO - 2025-12-25 22:56:26 --> Config Class Initialized
INFO - 2025-12-25 22:56:26 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:26 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:26 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:26 --> URI Class Initialized
INFO - 2025-12-25 22:56:26 --> Router Class Initialized
INFO - 2025-12-25 22:56:26 --> Output Class Initialized
INFO - 2025-12-25 22:56:26 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:26 --> CSRF cookie sent
INFO - 2025-12-25 22:56:26 --> Input Class Initialized
INFO - 2025-12-25 22:56:26 --> Language Class Initialized
INFO - 2025-12-25 22:56:26 --> Loader Class Initialized
INFO - 2025-12-25 22:56:26 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:26 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:26 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:26 --> Controller Class Initialized
INFO - 2025-12-25 22:56:26 --> Model "User_model" initialized
INFO - 2025-12-25 22:56:26 --> Model "Bagian_model" initialized
DEBUG - 2025-12-25 22:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:56:26 --> Upload Class Initialized
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 22:56:26 --> Final output sent to browser
DEBUG - 2025-12-25 22:56:26 --> Total execution time: 0.0702
INFO - 2025-12-25 22:56:26 --> Config Class Initialized
INFO - 2025-12-25 22:56:26 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:26 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:26 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:26 --> URI Class Initialized
INFO - 2025-12-25 22:56:26 --> Router Class Initialized
INFO - 2025-12-25 22:56:26 --> Output Class Initialized
INFO - 2025-12-25 22:56:26 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:26 --> CSRF cookie sent
INFO - 2025-12-25 22:56:26 --> Input Class Initialized
INFO - 2025-12-25 22:56:26 --> Language Class Initialized
INFO - 2025-12-25 22:56:26 --> Loader Class Initialized
INFO - 2025-12-25 22:56:26 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:26 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:26 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:26 --> Controller Class Initialized
INFO - 2025-12-25 22:56:26 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 22:56:26 --> Model "Bagian_model" initialized
INFO - 2025-12-25 22:56:26 --> Model "Kategori_model" initialized
INFO - 2025-12-25 22:56:26 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 22:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:56:26 --> Upload Class Initialized
INFO - 2025-12-25 22:56:26 --> Helper loaded: text_helper
INFO - 2025-12-25 22:56:26 --> Helper loaded: custom_helper
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-25 22:56:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 22:56:26 --> Final output sent to browser
DEBUG - 2025-12-25 22:56:26 --> Total execution time: 0.0978
INFO - 2025-12-25 22:56:27 --> Config Class Initialized
INFO - 2025-12-25 22:56:27 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:27 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:27 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:27 --> URI Class Initialized
INFO - 2025-12-25 22:56:27 --> Router Class Initialized
INFO - 2025-12-25 22:56:27 --> Output Class Initialized
INFO - 2025-12-25 22:56:27 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:27 --> CSRF cookie sent
INFO - 2025-12-25 22:56:27 --> Input Class Initialized
INFO - 2025-12-25 22:56:27 --> Language Class Initialized
INFO - 2025-12-25 22:56:27 --> Loader Class Initialized
INFO - 2025-12-25 22:56:27 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:27 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:27 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:27 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:27 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:27 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:27 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:27 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:27 --> Controller Class Initialized
INFO - 2025-12-25 22:56:27 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 22:56:27 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 22:56:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:56:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 22:56:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 22:56:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 22:56:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/form.php
INFO - 2025-12-25 22:56:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 22:56:27 --> Final output sent to browser
DEBUG - 2025-12-25 22:56:27 --> Total execution time: 0.0995
INFO - 2025-12-25 22:56:29 --> Config Class Initialized
INFO - 2025-12-25 22:56:29 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:29 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:29 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:29 --> URI Class Initialized
INFO - 2025-12-25 22:56:29 --> Router Class Initialized
INFO - 2025-12-25 22:56:29 --> Output Class Initialized
INFO - 2025-12-25 22:56:29 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:29 --> CSRF cookie sent
INFO - 2025-12-25 22:56:29 --> Input Class Initialized
INFO - 2025-12-25 22:56:29 --> Language Class Initialized
INFO - 2025-12-25 22:56:29 --> Loader Class Initialized
INFO - 2025-12-25 22:56:29 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:29 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:29 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:29 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:29 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:29 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:29 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:29 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:29 --> Controller Class Initialized
INFO - 2025-12-25 22:56:29 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 22:56:29 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 22:56:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 22:56:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 22:56:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 22:56:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 22:56:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/form.php
INFO - 2025-12-25 22:56:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 22:56:29 --> Final output sent to browser
DEBUG - 2025-12-25 22:56:29 --> Total execution time: 0.0584
INFO - 2025-12-25 22:56:30 --> Config Class Initialized
INFO - 2025-12-25 22:56:30 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:56:30 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:56:30 --> Utf8 Class Initialized
INFO - 2025-12-25 22:56:30 --> URI Class Initialized
INFO - 2025-12-25 22:56:30 --> Router Class Initialized
INFO - 2025-12-25 22:56:30 --> Output Class Initialized
INFO - 2025-12-25 22:56:30 --> Security Class Initialized
DEBUG - 2025-12-25 22:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:56:30 --> CSRF cookie sent
INFO - 2025-12-25 22:56:30 --> Input Class Initialized
INFO - 2025-12-25 22:56:30 --> Language Class Initialized
INFO - 2025-12-25 22:56:30 --> Loader Class Initialized
INFO - 2025-12-25 22:56:30 --> Helper loaded: url_helper
INFO - 2025-12-25 22:56:30 --> Helper loaded: form_helper
INFO - 2025-12-25 22:56:30 --> Helper loaded: file_helper
INFO - 2025-12-25 22:56:30 --> Helper loaded: html_helper
INFO - 2025-12-25 22:56:30 --> Helper loaded: security_helper
INFO - 2025-12-25 22:56:30 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:56:30 --> Database Driver Class Initialized
INFO - 2025-12-25 22:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:56:30 --> Form Validation Class Initialized
INFO - 2025-12-25 22:56:30 --> Controller Class Initialized
INFO - 2025-12-25 22:56:30 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:56:30 --> Severity: error --> Exception: Call to undefined method Dashboard_model::get_total_belum_ttd() D:\xampp\htdocs\surat_itm\application\controllers\Dashboard.php 28
INFO - 2025-12-25 22:58:32 --> Config Class Initialized
INFO - 2025-12-25 22:58:32 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:58:32 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:58:32 --> Utf8 Class Initialized
INFO - 2025-12-25 22:58:32 --> URI Class Initialized
INFO - 2025-12-25 22:58:32 --> Router Class Initialized
INFO - 2025-12-25 22:58:32 --> Output Class Initialized
INFO - 2025-12-25 22:58:32 --> Security Class Initialized
DEBUG - 2025-12-25 22:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:58:32 --> CSRF cookie sent
INFO - 2025-12-25 22:58:32 --> Input Class Initialized
INFO - 2025-12-25 22:58:32 --> Language Class Initialized
INFO - 2025-12-25 22:58:32 --> Loader Class Initialized
INFO - 2025-12-25 22:58:32 --> Helper loaded: url_helper
INFO - 2025-12-25 22:58:32 --> Helper loaded: form_helper
INFO - 2025-12-25 22:58:32 --> Helper loaded: file_helper
INFO - 2025-12-25 22:58:32 --> Helper loaded: html_helper
INFO - 2025-12-25 22:58:32 --> Helper loaded: security_helper
INFO - 2025-12-25 22:58:32 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:58:32 --> Database Driver Class Initialized
INFO - 2025-12-25 22:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:58:32 --> Form Validation Class Initialized
INFO - 2025-12-25 22:58:32 --> Controller Class Initialized
INFO - 2025-12-25 22:58:32 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:58:32 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:58:32 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:58:34 --> Config Class Initialized
INFO - 2025-12-25 22:58:34 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:58:34 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:58:34 --> Utf8 Class Initialized
INFO - 2025-12-25 22:58:34 --> URI Class Initialized
INFO - 2025-12-25 22:58:34 --> Router Class Initialized
INFO - 2025-12-25 22:58:34 --> Output Class Initialized
INFO - 2025-12-25 22:58:34 --> Security Class Initialized
DEBUG - 2025-12-25 22:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:58:34 --> CSRF cookie sent
INFO - 2025-12-25 22:58:34 --> Input Class Initialized
INFO - 2025-12-25 22:58:34 --> Language Class Initialized
INFO - 2025-12-25 22:58:34 --> Loader Class Initialized
INFO - 2025-12-25 22:58:34 --> Helper loaded: url_helper
INFO - 2025-12-25 22:58:34 --> Helper loaded: form_helper
INFO - 2025-12-25 22:58:34 --> Helper loaded: file_helper
INFO - 2025-12-25 22:58:34 --> Helper loaded: html_helper
INFO - 2025-12-25 22:58:34 --> Helper loaded: security_helper
INFO - 2025-12-25 22:58:34 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:58:34 --> Database Driver Class Initialized
INFO - 2025-12-25 22:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:58:34 --> Form Validation Class Initialized
INFO - 2025-12-25 22:58:34 --> Controller Class Initialized
INFO - 2025-12-25 22:58:34 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:58:34 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:58:34 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:44 --> Config Class Initialized
INFO - 2025-12-25 22:59:44 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:44 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:44 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:44 --> URI Class Initialized
INFO - 2025-12-25 22:59:44 --> Router Class Initialized
INFO - 2025-12-25 22:59:44 --> Output Class Initialized
INFO - 2025-12-25 22:59:44 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:44 --> CSRF cookie sent
INFO - 2025-12-25 22:59:44 --> Input Class Initialized
INFO - 2025-12-25 22:59:44 --> Language Class Initialized
INFO - 2025-12-25 22:59:44 --> Loader Class Initialized
INFO - 2025-12-25 22:59:44 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:44 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:44 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:44 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:44 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:44 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:44 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:44 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:44 --> Controller Class Initialized
INFO - 2025-12-25 22:59:44 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:44 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:45 --> Config Class Initialized
INFO - 2025-12-25 22:59:45 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:45 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:45 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:45 --> URI Class Initialized
INFO - 2025-12-25 22:59:45 --> Router Class Initialized
INFO - 2025-12-25 22:59:45 --> Output Class Initialized
INFO - 2025-12-25 22:59:45 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:45 --> CSRF cookie sent
INFO - 2025-12-25 22:59:45 --> Input Class Initialized
INFO - 2025-12-25 22:59:45 --> Language Class Initialized
INFO - 2025-12-25 22:59:45 --> Loader Class Initialized
INFO - 2025-12-25 22:59:45 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:45 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:45 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:45 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:45 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:45 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:45 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:45 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:45 --> Controller Class Initialized
INFO - 2025-12-25 22:59:45 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:45 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:46 --> Config Class Initialized
INFO - 2025-12-25 22:59:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:46 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:46 --> URI Class Initialized
INFO - 2025-12-25 22:59:46 --> Router Class Initialized
INFO - 2025-12-25 22:59:46 --> Output Class Initialized
INFO - 2025-12-25 22:59:46 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:46 --> CSRF cookie sent
INFO - 2025-12-25 22:59:46 --> Input Class Initialized
INFO - 2025-12-25 22:59:46 --> Language Class Initialized
INFO - 2025-12-25 22:59:46 --> Loader Class Initialized
INFO - 2025-12-25 22:59:46 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:46 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:46 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:46 --> Controller Class Initialized
INFO - 2025-12-25 22:59:46 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:46 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:46 --> Config Class Initialized
INFO - 2025-12-25 22:59:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:46 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:46 --> URI Class Initialized
INFO - 2025-12-25 22:59:46 --> Router Class Initialized
INFO - 2025-12-25 22:59:46 --> Output Class Initialized
INFO - 2025-12-25 22:59:46 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:46 --> CSRF cookie sent
INFO - 2025-12-25 22:59:46 --> Input Class Initialized
INFO - 2025-12-25 22:59:46 --> Language Class Initialized
INFO - 2025-12-25 22:59:46 --> Loader Class Initialized
INFO - 2025-12-25 22:59:46 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:46 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:46 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:46 --> Controller Class Initialized
INFO - 2025-12-25 22:59:46 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:46 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:46 --> Config Class Initialized
INFO - 2025-12-25 22:59:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:46 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:46 --> URI Class Initialized
INFO - 2025-12-25 22:59:46 --> Router Class Initialized
INFO - 2025-12-25 22:59:46 --> Output Class Initialized
INFO - 2025-12-25 22:59:46 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:46 --> CSRF cookie sent
INFO - 2025-12-25 22:59:46 --> Input Class Initialized
INFO - 2025-12-25 22:59:46 --> Language Class Initialized
INFO - 2025-12-25 22:59:46 --> Loader Class Initialized
INFO - 2025-12-25 22:59:46 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:46 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:46 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:46 --> Controller Class Initialized
INFO - 2025-12-25 22:59:46 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:46 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:46 --> Config Class Initialized
INFO - 2025-12-25 22:59:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:46 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:46 --> URI Class Initialized
INFO - 2025-12-25 22:59:46 --> Router Class Initialized
INFO - 2025-12-25 22:59:46 --> Output Class Initialized
INFO - 2025-12-25 22:59:46 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:46 --> CSRF cookie sent
INFO - 2025-12-25 22:59:46 --> Input Class Initialized
INFO - 2025-12-25 22:59:46 --> Language Class Initialized
INFO - 2025-12-25 22:59:46 --> Loader Class Initialized
INFO - 2025-12-25 22:59:46 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:46 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:46 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:46 --> Controller Class Initialized
INFO - 2025-12-25 22:59:46 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:46 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 22:59:47 --> Config Class Initialized
INFO - 2025-12-25 22:59:47 --> Hooks Class Initialized
DEBUG - 2025-12-25 22:59:47 --> UTF-8 Support Enabled
INFO - 2025-12-25 22:59:47 --> Utf8 Class Initialized
INFO - 2025-12-25 22:59:47 --> URI Class Initialized
INFO - 2025-12-25 22:59:47 --> Router Class Initialized
INFO - 2025-12-25 22:59:47 --> Output Class Initialized
INFO - 2025-12-25 22:59:47 --> Security Class Initialized
DEBUG - 2025-12-25 22:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 22:59:47 --> CSRF cookie sent
INFO - 2025-12-25 22:59:47 --> Input Class Initialized
INFO - 2025-12-25 22:59:47 --> Language Class Initialized
INFO - 2025-12-25 22:59:47 --> Loader Class Initialized
INFO - 2025-12-25 22:59:47 --> Helper loaded: url_helper
INFO - 2025-12-25 22:59:47 --> Helper loaded: form_helper
INFO - 2025-12-25 22:59:47 --> Helper loaded: file_helper
INFO - 2025-12-25 22:59:47 --> Helper loaded: html_helper
INFO - 2025-12-25 22:59:47 --> Helper loaded: security_helper
INFO - 2025-12-25 22:59:47 --> Helper loaded: surat_helper
INFO - 2025-12-25 22:59:47 --> Database Driver Class Initialized
INFO - 2025-12-25 22:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 22:59:47 --> Form Validation Class Initialized
INFO - 2025-12-25 22:59:47 --> Controller Class Initialized
INFO - 2025-12-25 22:59:47 --> Model "Dashboard_model" initialized
ERROR - 2025-12-25 22:59:47 --> Query error: Unknown column 'status_ttd' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_keluar`
WHERE `status_ttd` IN('draft', 'menunggu')
INFO - 2025-12-25 22:59:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-25 23:00:33 --> Config Class Initialized
INFO - 2025-12-25 23:00:33 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:00:33 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:00:33 --> Utf8 Class Initialized
INFO - 2025-12-25 23:00:33 --> URI Class Initialized
INFO - 2025-12-25 23:00:33 --> Router Class Initialized
INFO - 2025-12-25 23:00:33 --> Output Class Initialized
INFO - 2025-12-25 23:00:33 --> Security Class Initialized
DEBUG - 2025-12-25 23:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:00:33 --> CSRF cookie sent
INFO - 2025-12-25 23:00:33 --> Input Class Initialized
INFO - 2025-12-25 23:00:33 --> Language Class Initialized
INFO - 2025-12-25 23:00:33 --> Loader Class Initialized
INFO - 2025-12-25 23:00:33 --> Helper loaded: url_helper
INFO - 2025-12-25 23:00:33 --> Helper loaded: form_helper
INFO - 2025-12-25 23:00:33 --> Helper loaded: file_helper
INFO - 2025-12-25 23:00:33 --> Helper loaded: html_helper
INFO - 2025-12-25 23:00:33 --> Helper loaded: security_helper
INFO - 2025-12-25 23:00:33 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:00:33 --> Database Driver Class Initialized
INFO - 2025-12-25 23:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:00:33 --> Form Validation Class Initialized
INFO - 2025-12-25 23:00:33 --> Controller Class Initialized
INFO - 2025-12-25 23:00:33 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:00:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:00:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:00:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:00:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:00:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:00:33 --> Final output sent to browser
DEBUG - 2025-12-25 23:00:33 --> Total execution time: 0.1757
INFO - 2025-12-25 23:00:36 --> Config Class Initialized
INFO - 2025-12-25 23:00:36 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:00:36 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:00:36 --> Utf8 Class Initialized
INFO - 2025-12-25 23:00:36 --> URI Class Initialized
INFO - 2025-12-25 23:00:36 --> Router Class Initialized
INFO - 2025-12-25 23:00:36 --> Output Class Initialized
INFO - 2025-12-25 23:00:36 --> Security Class Initialized
DEBUG - 2025-12-25 23:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:00:36 --> CSRF cookie sent
INFO - 2025-12-25 23:00:36 --> Input Class Initialized
INFO - 2025-12-25 23:00:36 --> Language Class Initialized
INFO - 2025-12-25 23:00:36 --> Loader Class Initialized
INFO - 2025-12-25 23:00:36 --> Helper loaded: url_helper
INFO - 2025-12-25 23:00:36 --> Helper loaded: form_helper
INFO - 2025-12-25 23:00:36 --> Helper loaded: file_helper
INFO - 2025-12-25 23:00:36 --> Helper loaded: html_helper
INFO - 2025-12-25 23:00:36 --> Helper loaded: security_helper
INFO - 2025-12-25 23:00:36 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:00:36 --> Database Driver Class Initialized
INFO - 2025-12-25 23:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:00:36 --> Form Validation Class Initialized
INFO - 2025-12-25 23:00:36 --> Controller Class Initialized
INFO - 2025-12-25 23:00:36 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-25 23:00:36 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:00:36 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:00:36 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-25 23:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:00:36 --> Upload Class Initialized
INFO - 2025-12-25 23:00:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:00:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:00:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-25 23:00:36 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:00:36 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:00:36 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:00:37 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-25 23:00:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-25 23:00:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:00:37 --> Final output sent to browser
DEBUG - 2025-12-25 23:00:37 --> Total execution time: 0.4215
INFO - 2025-12-25 23:02:14 --> Config Class Initialized
INFO - 2025-12-25 23:02:14 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:14 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:14 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:14 --> URI Class Initialized
INFO - 2025-12-25 23:02:14 --> Router Class Initialized
INFO - 2025-12-25 23:02:14 --> Output Class Initialized
INFO - 2025-12-25 23:02:14 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:14 --> CSRF cookie sent
INFO - 2025-12-25 23:02:14 --> Input Class Initialized
INFO - 2025-12-25 23:02:14 --> Language Class Initialized
INFO - 2025-12-25 23:02:14 --> Loader Class Initialized
INFO - 2025-12-25 23:02:14 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:14 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:14 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:14 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:14 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:14 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:14 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:14 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:14 --> Controller Class Initialized
INFO - 2025-12-25 23:02:14 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:14 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:14 --> Total execution time: 0.0585
INFO - 2025-12-25 23:02:16 --> Config Class Initialized
INFO - 2025-12-25 23:02:16 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:16 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:16 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:16 --> URI Class Initialized
INFO - 2025-12-25 23:02:16 --> Router Class Initialized
INFO - 2025-12-25 23:02:16 --> Output Class Initialized
INFO - 2025-12-25 23:02:16 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:16 --> CSRF cookie sent
INFO - 2025-12-25 23:02:16 --> Input Class Initialized
INFO - 2025-12-25 23:02:16 --> Language Class Initialized
INFO - 2025-12-25 23:02:16 --> Loader Class Initialized
INFO - 2025-12-25 23:02:16 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:16 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:16 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:16 --> Controller Class Initialized
INFO - 2025-12-25 23:02:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:16 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:16 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:16 --> Upload Class Initialized
INFO - 2025-12-25 23:02:16 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:16 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 23:02:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:16 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:16 --> Total execution time: 0.0632
INFO - 2025-12-25 23:02:18 --> Config Class Initialized
INFO - 2025-12-25 23:02:18 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:18 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:18 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:18 --> URI Class Initialized
INFO - 2025-12-25 23:02:18 --> Router Class Initialized
INFO - 2025-12-25 23:02:18 --> Output Class Initialized
INFO - 2025-12-25 23:02:18 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:18 --> CSRF cookie sent
INFO - 2025-12-25 23:02:18 --> Input Class Initialized
INFO - 2025-12-25 23:02:18 --> Language Class Initialized
INFO - 2025-12-25 23:02:18 --> Loader Class Initialized
INFO - 2025-12-25 23:02:18 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:18 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:18 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:18 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:18 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:18 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:18 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:18 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:18 --> Controller Class Initialized
INFO - 2025-12-25 23:02:19 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:19 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:19 --> Total execution time: 0.0510
INFO - 2025-12-25 23:02:20 --> Config Class Initialized
INFO - 2025-12-25 23:02:20 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:20 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:20 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:20 --> URI Class Initialized
INFO - 2025-12-25 23:02:20 --> Router Class Initialized
INFO - 2025-12-25 23:02:20 --> Output Class Initialized
INFO - 2025-12-25 23:02:20 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:20 --> CSRF cookie sent
INFO - 2025-12-25 23:02:20 --> Input Class Initialized
INFO - 2025-12-25 23:02:20 --> Language Class Initialized
INFO - 2025-12-25 23:02:20 --> Loader Class Initialized
INFO - 2025-12-25 23:02:20 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:20 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:20 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:20 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:20 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:20 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:20 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:20 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:20 --> Controller Class Initialized
INFO - 2025-12-25 23:02:20 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-25 23:02:20 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:20 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:20 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-25 23:02:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:20 --> Upload Class Initialized
INFO - 2025-12-25 23:02:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:20 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-25 23:02:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-25 23:02:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:20 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:20 --> Total execution time: 0.0706
INFO - 2025-12-25 23:02:21 --> Config Class Initialized
INFO - 2025-12-25 23:02:21 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:21 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:21 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:21 --> URI Class Initialized
INFO - 2025-12-25 23:02:21 --> Router Class Initialized
INFO - 2025-12-25 23:02:21 --> Output Class Initialized
INFO - 2025-12-25 23:02:21 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:21 --> CSRF cookie sent
INFO - 2025-12-25 23:02:21 --> Input Class Initialized
INFO - 2025-12-25 23:02:21 --> Language Class Initialized
INFO - 2025-12-25 23:02:21 --> Loader Class Initialized
INFO - 2025-12-25 23:02:21 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:21 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:21 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:21 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:21 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:21 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:21 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:22 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:22 --> Controller Class Initialized
INFO - 2025-12-25 23:02:22 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:22 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:22 --> Total execution time: 0.0571
INFO - 2025-12-25 23:02:23 --> Config Class Initialized
INFO - 2025-12-25 23:02:23 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:23 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:23 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:23 --> URI Class Initialized
INFO - 2025-12-25 23:02:23 --> Router Class Initialized
INFO - 2025-12-25 23:02:23 --> Output Class Initialized
INFO - 2025-12-25 23:02:23 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:23 --> CSRF cookie sent
INFO - 2025-12-25 23:02:23 --> Input Class Initialized
INFO - 2025-12-25 23:02:23 --> Language Class Initialized
INFO - 2025-12-25 23:02:23 --> Loader Class Initialized
INFO - 2025-12-25 23:02:23 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:23 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:23 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:23 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:23 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:23 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:23 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:23 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:23 --> Controller Class Initialized
INFO - 2025-12-25 23:02:23 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-25 23:02:23 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:23 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:23 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-25 23:02:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:23 --> Upload Class Initialized
INFO - 2025-12-25 23:02:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:23 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-25 23:02:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-25 23:02:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:23 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:23 --> Total execution time: 0.0603
INFO - 2025-12-25 23:02:26 --> Config Class Initialized
INFO - 2025-12-25 23:02:26 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:26 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:26 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:26 --> URI Class Initialized
INFO - 2025-12-25 23:02:26 --> Router Class Initialized
INFO - 2025-12-25 23:02:26 --> Output Class Initialized
INFO - 2025-12-25 23:02:26 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:26 --> CSRF cookie sent
INFO - 2025-12-25 23:02:26 --> Input Class Initialized
INFO - 2025-12-25 23:02:26 --> Language Class Initialized
INFO - 2025-12-25 23:02:26 --> Loader Class Initialized
INFO - 2025-12-25 23:02:26 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:26 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:26 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:26 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:26 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:26 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:26 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:26 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:26 --> Controller Class Initialized
INFO - 2025-12-25 23:02:26 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:26 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:26 --> Total execution time: 0.0722
INFO - 2025-12-25 23:02:29 --> Config Class Initialized
INFO - 2025-12-25 23:02:29 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:29 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:29 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:29 --> URI Class Initialized
INFO - 2025-12-25 23:02:29 --> Router Class Initialized
INFO - 2025-12-25 23:02:29 --> Output Class Initialized
INFO - 2025-12-25 23:02:29 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:29 --> CSRF cookie sent
INFO - 2025-12-25 23:02:29 --> Input Class Initialized
INFO - 2025-12-25 23:02:29 --> Language Class Initialized
INFO - 2025-12-25 23:02:29 --> Loader Class Initialized
INFO - 2025-12-25 23:02:29 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:29 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:29 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:29 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:29 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:29 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:29 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:29 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:29 --> Controller Class Initialized
INFO - 2025-12-25 23:02:29 --> Model "Disposisi_model" initialized
INFO - 2025-12-25 23:02:29 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-25 23:02:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-25 23:02:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:29 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:29 --> Total execution time: 0.0570
INFO - 2025-12-25 23:02:31 --> Config Class Initialized
INFO - 2025-12-25 23:02:31 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:31 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:31 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:31 --> URI Class Initialized
INFO - 2025-12-25 23:02:31 --> Router Class Initialized
INFO - 2025-12-25 23:02:31 --> Output Class Initialized
INFO - 2025-12-25 23:02:31 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:31 --> CSRF cookie sent
INFO - 2025-12-25 23:02:31 --> Input Class Initialized
INFO - 2025-12-25 23:02:31 --> Language Class Initialized
INFO - 2025-12-25 23:02:31 --> Loader Class Initialized
INFO - 2025-12-25 23:02:31 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:31 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:31 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:31 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:31 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:31 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:31 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:31 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:31 --> Controller Class Initialized
INFO - 2025-12-25 23:02:31 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:31 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:31 --> Total execution time: 0.0597
INFO - 2025-12-25 23:02:34 --> Config Class Initialized
INFO - 2025-12-25 23:02:34 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:34 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:34 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:34 --> URI Class Initialized
INFO - 2025-12-25 23:02:34 --> Router Class Initialized
INFO - 2025-12-25 23:02:34 --> Output Class Initialized
INFO - 2025-12-25 23:02:34 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:34 --> CSRF cookie sent
INFO - 2025-12-25 23:02:34 --> Input Class Initialized
INFO - 2025-12-25 23:02:34 --> Language Class Initialized
INFO - 2025-12-25 23:02:34 --> Loader Class Initialized
INFO - 2025-12-25 23:02:34 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:34 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:34 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:34 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:34 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:34 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:34 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:34 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:34 --> Controller Class Initialized
INFO - 2025-12-25 23:02:34 --> Model "Laporan_model" initialized
INFO - 2025-12-25 23:02:34 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-25 23:02:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:34 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:34 --> Total execution time: 0.0696
INFO - 2025-12-25 23:02:37 --> Config Class Initialized
INFO - 2025-12-25 23:02:37 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:37 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:37 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:37 --> URI Class Initialized
INFO - 2025-12-25 23:02:37 --> Router Class Initialized
INFO - 2025-12-25 23:02:37 --> Output Class Initialized
INFO - 2025-12-25 23:02:37 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:37 --> CSRF cookie sent
INFO - 2025-12-25 23:02:37 --> Input Class Initialized
INFO - 2025-12-25 23:02:37 --> Language Class Initialized
INFO - 2025-12-25 23:02:37 --> Loader Class Initialized
INFO - 2025-12-25 23:02:37 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:37 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:37 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:37 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:37 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:37 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:37 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:37 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:37 --> Controller Class Initialized
INFO - 2025-12-25 23:02:37 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:37 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:37 --> Total execution time: 0.0494
INFO - 2025-12-25 23:02:38 --> Config Class Initialized
INFO - 2025-12-25 23:02:38 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:38 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:38 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:38 --> URI Class Initialized
INFO - 2025-12-25 23:02:38 --> Router Class Initialized
INFO - 2025-12-25 23:02:38 --> Output Class Initialized
INFO - 2025-12-25 23:02:38 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:38 --> CSRF cookie sent
INFO - 2025-12-25 23:02:38 --> Input Class Initialized
INFO - 2025-12-25 23:02:38 --> Language Class Initialized
ERROR - 2025-12-25 23:02:38 --> 404 Page Not Found: Surat-keluar/tambah
INFO - 2025-12-25 23:02:43 --> Config Class Initialized
INFO - 2025-12-25 23:02:43 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:43 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:43 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:43 --> URI Class Initialized
INFO - 2025-12-25 23:02:43 --> Router Class Initialized
INFO - 2025-12-25 23:02:43 --> Output Class Initialized
INFO - 2025-12-25 23:02:43 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:43 --> CSRF cookie sent
INFO - 2025-12-25 23:02:43 --> Input Class Initialized
INFO - 2025-12-25 23:02:43 --> Language Class Initialized
INFO - 2025-12-25 23:02:43 --> Loader Class Initialized
INFO - 2025-12-25 23:02:43 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:43 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:43 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:43 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:43 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:43 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:43 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:43 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:43 --> Controller Class Initialized
INFO - 2025-12-25 23:02:43 --> Model "Dashboard_model" initialized
INFO - 2025-12-25 23:02:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-25 23:02:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:43 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:43 --> Total execution time: 0.0771
INFO - 2025-12-25 23:02:44 --> Config Class Initialized
INFO - 2025-12-25 23:02:44 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:44 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:44 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:44 --> URI Class Initialized
INFO - 2025-12-25 23:02:44 --> Router Class Initialized
INFO - 2025-12-25 23:02:44 --> Output Class Initialized
INFO - 2025-12-25 23:02:44 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:44 --> CSRF cookie sent
INFO - 2025-12-25 23:02:44 --> Input Class Initialized
INFO - 2025-12-25 23:02:44 --> Language Class Initialized
INFO - 2025-12-25 23:02:44 --> Loader Class Initialized
INFO - 2025-12-25 23:02:44 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:44 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:44 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:44 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:44 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:44 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:44 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:45 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:45 --> Controller Class Initialized
INFO - 2025-12-25 23:02:45 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-25 23:02:45 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:45 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:45 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-25 23:02:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:45 --> Upload Class Initialized
INFO - 2025-12-25 23:02:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 152
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 154
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 156
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 179
ERROR - 2025-12-25 23:02:45 --> Severity: Warning --> Undefined property: stdClass::$status_ttd D:\xampp\htdocs\surat_itm\application\views\surat_keluar\index.php 199
INFO - 2025-12-25 23:02:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-25 23:02:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:45 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:45 --> Total execution time: 0.0776
INFO - 2025-12-25 23:02:46 --> Config Class Initialized
INFO - 2025-12-25 23:02:46 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:46 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:46 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:46 --> URI Class Initialized
INFO - 2025-12-25 23:02:46 --> Router Class Initialized
INFO - 2025-12-25 23:02:46 --> Output Class Initialized
INFO - 2025-12-25 23:02:46 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:46 --> CSRF cookie sent
INFO - 2025-12-25 23:02:46 --> Input Class Initialized
INFO - 2025-12-25 23:02:46 --> Language Class Initialized
INFO - 2025-12-25 23:02:46 --> Loader Class Initialized
INFO - 2025-12-25 23:02:46 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:46 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:46 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:46 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:46 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:46 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:46 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:46 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:46 --> Controller Class Initialized
INFO - 2025-12-25 23:02:46 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-25 23:02:46 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:46 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:46 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-25 23:02:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:46 --> Upload Class Initialized
INFO - 2025-12-25 23:02:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-25 23:02:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:46 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:46 --> Total execution time: 0.3336
INFO - 2025-12-25 23:02:48 --> Config Class Initialized
INFO - 2025-12-25 23:02:48 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:48 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:48 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:48 --> URI Class Initialized
INFO - 2025-12-25 23:02:48 --> Router Class Initialized
INFO - 2025-12-25 23:02:48 --> Output Class Initialized
INFO - 2025-12-25 23:02:48 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:48 --> CSRF cookie sent
INFO - 2025-12-25 23:02:48 --> Input Class Initialized
INFO - 2025-12-25 23:02:48 --> Language Class Initialized
INFO - 2025-12-25 23:02:48 --> Loader Class Initialized
INFO - 2025-12-25 23:02:48 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:48 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:48 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:48 --> Controller Class Initialized
INFO - 2025-12-25 23:02:48 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:48 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:48 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:48 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:48 --> Upload Class Initialized
INFO - 2025-12-25 23:02:48 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:48 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 23:02:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:48 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:48 --> Total execution time: 0.0595
INFO - 2025-12-25 23:02:50 --> Config Class Initialized
INFO - 2025-12-25 23:02:50 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:50 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:50 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:50 --> URI Class Initialized
INFO - 2025-12-25 23:02:50 --> Router Class Initialized
INFO - 2025-12-25 23:02:50 --> Output Class Initialized
INFO - 2025-12-25 23:02:50 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:50 --> CSRF cookie sent
INFO - 2025-12-25 23:02:50 --> Input Class Initialized
INFO - 2025-12-25 23:02:50 --> Language Class Initialized
INFO - 2025-12-25 23:02:50 --> Loader Class Initialized
INFO - 2025-12-25 23:02:50 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:50 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:50 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:50 --> Controller Class Initialized
INFO - 2025-12-25 23:02:50 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:50 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:50 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:50 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:50 --> Upload Class Initialized
INFO - 2025-12-25 23:02:50 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:50 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-25 23:02:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:50 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:50 --> Total execution time: 0.3037
INFO - 2025-12-25 23:02:52 --> Config Class Initialized
INFO - 2025-12-25 23:02:52 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:52 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:52 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:52 --> URI Class Initialized
INFO - 2025-12-25 23:02:52 --> Router Class Initialized
INFO - 2025-12-25 23:02:52 --> Output Class Initialized
INFO - 2025-12-25 23:02:52 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:52 --> CSRF cookie sent
INFO - 2025-12-25 23:02:52 --> Input Class Initialized
INFO - 2025-12-25 23:02:52 --> Language Class Initialized
INFO - 2025-12-25 23:02:52 --> Loader Class Initialized
INFO - 2025-12-25 23:02:52 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:52 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:52 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:52 --> Controller Class Initialized
INFO - 2025-12-25 23:02:52 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:52 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:52 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:52 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:52 --> Upload Class Initialized
INFO - 2025-12-25 23:02:52 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:52 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 23:02:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:52 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:52 --> Total execution time: 0.0573
INFO - 2025-12-25 23:02:55 --> Config Class Initialized
INFO - 2025-12-25 23:02:55 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:55 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:55 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:55 --> URI Class Initialized
INFO - 2025-12-25 23:02:55 --> Router Class Initialized
INFO - 2025-12-25 23:02:55 --> Output Class Initialized
INFO - 2025-12-25 23:02:55 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:55 --> CSRF cookie sent
INFO - 2025-12-25 23:02:55 --> Input Class Initialized
INFO - 2025-12-25 23:02:55 --> Language Class Initialized
INFO - 2025-12-25 23:02:55 --> Loader Class Initialized
INFO - 2025-12-25 23:02:55 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:55 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:55 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:55 --> Controller Class Initialized
INFO - 2025-12-25 23:02:55 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:55 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:55 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:55 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:55 --> Upload Class Initialized
INFO - 2025-12-25 23:02:55 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:55 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 23:02:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:55 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:55 --> Total execution time: 0.0607
INFO - 2025-12-25 23:02:56 --> Config Class Initialized
INFO - 2025-12-25 23:02:56 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:02:56 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:02:56 --> Utf8 Class Initialized
INFO - 2025-12-25 23:02:56 --> URI Class Initialized
INFO - 2025-12-25 23:02:56 --> Router Class Initialized
INFO - 2025-12-25 23:02:56 --> Output Class Initialized
INFO - 2025-12-25 23:02:56 --> Security Class Initialized
DEBUG - 2025-12-25 23:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:02:56 --> CSRF cookie sent
INFO - 2025-12-25 23:02:56 --> Input Class Initialized
INFO - 2025-12-25 23:02:56 --> Language Class Initialized
INFO - 2025-12-25 23:02:56 --> Loader Class Initialized
INFO - 2025-12-25 23:02:56 --> Helper loaded: url_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: form_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: file_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: html_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: security_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:02:56 --> Database Driver Class Initialized
INFO - 2025-12-25 23:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:02:56 --> Form Validation Class Initialized
INFO - 2025-12-25 23:02:56 --> Controller Class Initialized
INFO - 2025-12-25 23:02:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:02:56 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:02:56 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:02:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:02:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:02:56 --> Upload Class Initialized
INFO - 2025-12-25 23:02:56 --> Helper loaded: text_helper
INFO - 2025-12-25 23:02:56 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:02:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:02:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:02:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:02:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-25 23:02:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:02:56 --> Final output sent to browser
DEBUG - 2025-12-25 23:02:56 --> Total execution time: 0.0593
INFO - 2025-12-25 23:03:06 --> Config Class Initialized
INFO - 2025-12-25 23:03:06 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:03:06 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:03:06 --> Utf8 Class Initialized
INFO - 2025-12-25 23:03:06 --> URI Class Initialized
INFO - 2025-12-25 23:03:06 --> Router Class Initialized
INFO - 2025-12-25 23:03:06 --> Output Class Initialized
INFO - 2025-12-25 23:03:06 --> Security Class Initialized
DEBUG - 2025-12-25 23:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:03:06 --> CSRF cookie sent
INFO - 2025-12-25 23:03:06 --> Input Class Initialized
INFO - 2025-12-25 23:03:06 --> Language Class Initialized
INFO - 2025-12-25 23:03:06 --> Loader Class Initialized
INFO - 2025-12-25 23:03:06 --> Helper loaded: url_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: form_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: file_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: html_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: security_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:03:06 --> Database Driver Class Initialized
INFO - 2025-12-25 23:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:03:06 --> Form Validation Class Initialized
INFO - 2025-12-25 23:03:06 --> Controller Class Initialized
INFO - 2025-12-25 23:03:06 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:03:06 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:03:06 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:03:06 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:03:06 --> Upload Class Initialized
INFO - 2025-12-25 23:03:06 --> Helper loaded: text_helper
INFO - 2025-12-25 23:03:06 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:03:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:03:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:03:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:03:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-25 23:03:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:03:06 --> Final output sent to browser
DEBUG - 2025-12-25 23:03:06 --> Total execution time: 0.0701
INFO - 2025-12-25 23:32:55 --> Config Class Initialized
INFO - 2025-12-25 23:32:55 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:32:55 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:32:55 --> Utf8 Class Initialized
INFO - 2025-12-25 23:32:55 --> URI Class Initialized
INFO - 2025-12-25 23:32:55 --> Router Class Initialized
INFO - 2025-12-25 23:32:55 --> Output Class Initialized
INFO - 2025-12-25 23:32:55 --> Security Class Initialized
DEBUG - 2025-12-25 23:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:32:55 --> CSRF cookie sent
INFO - 2025-12-25 23:32:55 --> CSRF token verified
INFO - 2025-12-25 23:32:55 --> Input Class Initialized
INFO - 2025-12-25 23:32:55 --> Language Class Initialized
INFO - 2025-12-25 23:32:55 --> Loader Class Initialized
INFO - 2025-12-25 23:32:55 --> Helper loaded: url_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: form_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: file_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: html_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: security_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:32:55 --> Database Driver Class Initialized
INFO - 2025-12-25 23:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:32:55 --> Form Validation Class Initialized
INFO - 2025-12-25 23:32:55 --> Controller Class Initialized
INFO - 2025-12-25 23:32:55 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:32:55 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:32:55 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:32:55 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:32:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:32:55 --> Upload Class Initialized
INFO - 2025-12-25 23:32:55 --> Helper loaded: text_helper
INFO - 2025-12-25 23:32:55 --> Helper loaded: custom_helper
ERROR - 2025-12-25 23:32:55 --> Severity: Warning --> require_once(D:\xampp\htdocs\surat_itm\application\libraries/PdfParser.php): Failed to open stream: No such file or directory D:\xampp\htdocs\surat_itm\application\libraries\Document_extractor.php 153
ERROR - 2025-12-25 23:32:55 --> Severity: error --> Exception: Failed opening required 'D:\xampp\htdocs\surat_itm\application\libraries/PdfParser.php' (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\surat_itm\application\libraries\Document_extractor.php 153
INFO - 2025-12-25 23:33:41 --> Config Class Initialized
INFO - 2025-12-25 23:33:41 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:33:41 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:33:41 --> Utf8 Class Initialized
INFO - 2025-12-25 23:33:41 --> URI Class Initialized
INFO - 2025-12-25 23:33:41 --> Router Class Initialized
INFO - 2025-12-25 23:33:41 --> Output Class Initialized
INFO - 2025-12-25 23:33:41 --> Security Class Initialized
DEBUG - 2025-12-25 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:33:41 --> CSRF cookie sent
INFO - 2025-12-25 23:33:45 --> Config Class Initialized
INFO - 2025-12-25 23:33:45 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:33:45 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:33:45 --> Utf8 Class Initialized
INFO - 2025-12-25 23:33:45 --> URI Class Initialized
INFO - 2025-12-25 23:33:45 --> Router Class Initialized
INFO - 2025-12-25 23:33:45 --> Output Class Initialized
INFO - 2025-12-25 23:33:45 --> Security Class Initialized
DEBUG - 2025-12-25 23:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:33:45 --> CSRF cookie sent
INFO - 2025-12-25 23:33:45 --> Input Class Initialized
INFO - 2025-12-25 23:33:45 --> Language Class Initialized
INFO - 2025-12-25 23:33:45 --> Loader Class Initialized
INFO - 2025-12-25 23:33:45 --> Helper loaded: url_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: form_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: file_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: html_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: security_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:33:45 --> Database Driver Class Initialized
INFO - 2025-12-25 23:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:33:45 --> Form Validation Class Initialized
INFO - 2025-12-25 23:33:45 --> Controller Class Initialized
INFO - 2025-12-25 23:33:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:33:45 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:33:45 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:33:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:33:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:33:45 --> Upload Class Initialized
INFO - 2025-12-25 23:33:45 --> Helper loaded: text_helper
INFO - 2025-12-25 23:33:45 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:33:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:33:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:33:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:33:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-25 23:33:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:33:45 --> Final output sent to browser
DEBUG - 2025-12-25 23:33:45 --> Total execution time: 0.0671
INFO - 2025-12-25 23:57:16 --> Config Class Initialized
INFO - 2025-12-25 23:57:16 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:57:16 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:57:16 --> Utf8 Class Initialized
INFO - 2025-12-25 23:57:16 --> URI Class Initialized
INFO - 2025-12-25 23:57:16 --> Router Class Initialized
INFO - 2025-12-25 23:57:16 --> Output Class Initialized
INFO - 2025-12-25 23:57:16 --> Security Class Initialized
DEBUG - 2025-12-25 23:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:57:16 --> CSRF cookie sent
INFO - 2025-12-25 23:57:16 --> Input Class Initialized
INFO - 2025-12-25 23:57:16 --> Language Class Initialized
INFO - 2025-12-25 23:57:16 --> Loader Class Initialized
INFO - 2025-12-25 23:57:16 --> Helper loaded: url_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: form_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: file_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: html_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: security_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:57:16 --> Database Driver Class Initialized
INFO - 2025-12-25 23:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:57:16 --> Form Validation Class Initialized
INFO - 2025-12-25 23:57:16 --> Controller Class Initialized
INFO - 2025-12-25 23:57:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-25 23:57:16 --> Model "Bagian_model" initialized
INFO - 2025-12-25 23:57:16 --> Model "Kategori_model" initialized
INFO - 2025-12-25 23:57:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-25 23:57:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-25 23:57:16 --> Upload Class Initialized
INFO - 2025-12-25 23:57:16 --> Helper loaded: text_helper
INFO - 2025-12-25 23:57:16 --> Helper loaded: custom_helper
INFO - 2025-12-25 23:57:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-25 23:57:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-25 23:57:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-25 23:57:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-25 23:57:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-25 23:57:16 --> Final output sent to browser
DEBUG - 2025-12-25 23:57:16 --> Total execution time: 0.0763
INFO - 2025-12-25 23:57:23 --> Config Class Initialized
INFO - 2025-12-25 23:57:23 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:57:23 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:57:23 --> Utf8 Class Initialized
INFO - 2025-12-25 23:57:23 --> URI Class Initialized
INFO - 2025-12-25 23:57:23 --> Router Class Initialized
INFO - 2025-12-25 23:57:23 --> Output Class Initialized
INFO - 2025-12-25 23:57:23 --> Security Class Initialized
DEBUG - 2025-12-25 23:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:57:23 --> CSRF cookie sent
INFO - 2025-12-25 23:57:23 --> Input Class Initialized
INFO - 2025-12-25 23:57:23 --> Language Class Initialized
INFO - 2025-12-25 23:57:23 --> Loader Class Initialized
INFO - 2025-12-25 23:57:23 --> Helper loaded: url_helper
INFO - 2025-12-25 23:57:23 --> Helper loaded: form_helper
INFO - 2025-12-25 23:57:23 --> Helper loaded: file_helper
INFO - 2025-12-25 23:57:23 --> Helper loaded: html_helper
INFO - 2025-12-25 23:57:23 --> Helper loaded: security_helper
INFO - 2025-12-25 23:57:23 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:57:23 --> Database Driver Class Initialized
INFO - 2025-12-25 23:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:57:23 --> Form Validation Class Initialized
INFO - 2025-12-25 23:57:23 --> Controller Class Initialized
INFO - 2025-12-25 23:57:23 --> Final output sent to browser
DEBUG - 2025-12-25 23:57:23 --> Total execution time: 0.1480
INFO - 2025-12-25 23:57:32 --> Config Class Initialized
INFO - 2025-12-25 23:57:32 --> Hooks Class Initialized
DEBUG - 2025-12-25 23:57:32 --> UTF-8 Support Enabled
INFO - 2025-12-25 23:57:32 --> Utf8 Class Initialized
INFO - 2025-12-25 23:57:32 --> URI Class Initialized
INFO - 2025-12-25 23:57:32 --> Router Class Initialized
INFO - 2025-12-25 23:57:32 --> Output Class Initialized
INFO - 2025-12-25 23:57:32 --> Security Class Initialized
DEBUG - 2025-12-25 23:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-25 23:57:32 --> Input Class Initialized
INFO - 2025-12-25 23:57:32 --> Language Class Initialized
INFO - 2025-12-25 23:57:32 --> Loader Class Initialized
INFO - 2025-12-25 23:57:32 --> Helper loaded: url_helper
INFO - 2025-12-25 23:57:32 --> Helper loaded: form_helper
INFO - 2025-12-25 23:57:32 --> Helper loaded: file_helper
INFO - 2025-12-25 23:57:32 --> Helper loaded: html_helper
INFO - 2025-12-25 23:57:32 --> Helper loaded: security_helper
INFO - 2025-12-25 23:57:32 --> Helper loaded: surat_helper
INFO - 2025-12-25 23:57:32 --> Database Driver Class Initialized
INFO - 2025-12-25 23:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-25 23:57:32 --> Form Validation Class Initialized
INFO - 2025-12-25 23:57:32 --> Controller Class Initialized
INFO - 2025-12-25 23:57:32 --> Final output sent to browser
DEBUG - 2025-12-25 23:57:32 --> Total execution time: 0.1038
