<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-19 02:27:50 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:32:16 --> 404 Page Not Found: Surat-masuk/delete
ERROR - 2025-12-19 02:32:24 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:12 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:36 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:38 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:38:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:39:29 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:39:34 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:39:57 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:40:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:40:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:45:02 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:45:03 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:45:05 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:15 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:17 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:22 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:46:44 --> 404 Page Not Found: Surat-masuk/delete
ERROR - 2025-12-19 02:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:39 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:46 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:53 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:54 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:47:56 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:48:00 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:48:08 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 02:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2025-12-19 03:01:23 --> 404 Page Not Found: Surat-masuk/detail
ERROR - 2025-12-19 03:08:11 --> 404 Page Not Found: 
ERROR - 2025-12-19 18:11:24 --> Query error: Unknown column 'isi_surat' in 'field list' - Invalid query: INSERT INTO `surat_keluar` (`bagian`, `kategori`, `id_penandatangan`, `no_surat`, `tanggal_dibuat`, `perihal`, `tujuan`, `isi_surat`, `nama_file`, `catatan`, `status`, `status_ttd`, `user_login`) VALUES (NULL, '04', '1', '04.01/ITM/XII/2025', '2025-12-19', 'Penting', 'Mahasiswa', '', 'SK_1766164284_Edaran_Pembagian_Kelompok_PLP.pdf', '', '1', 'draft', 'admin')
ERROR - 2025-12-19 18:13:55 --> Query error: Unknown column 'isi_surat' in 'field list' - Invalid query: INSERT INTO `surat_keluar` (`bagian`, `kategori`, `id_penandatangan`, `no_surat`, `tanggal_dibuat`, `perihal`, `tujuan`, `isi_surat`, `nama_file`, `catatan`, `status`, `status_ttd`, `user_login`) VALUES (NULL, '04', '1', '04.001/ITM/XII/2025', '2025-12-19', 'Penting', 'Mahasiswa', 'surat untuk pemberitahuan mahasiswa untuk mengikuti kegiatan mumas', '', '', '1', 'draft', 'admin')
ERROR - 2025-12-19 18:14:45 --> 404 Page Not Found: Disposisi/tambah
