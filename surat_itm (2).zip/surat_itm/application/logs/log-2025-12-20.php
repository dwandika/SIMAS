<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-20 03:22:21 --> 404 Page Not Found: Uploads/foto
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-20 03:22:21 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 03:22:27 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 03:22:27 --> 404 Page Not Found: Uploads/foto
ERROR - 2025-12-20 03:22:30 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 03:22:30 --> 404 Page Not Found: Uploads/foto
ERROR - 2025-12-20 03:24:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 03:28:28 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\profil\index.php 47
ERROR - 2025-12-20 03:28:34 --> Query error: Unknown column 'kepada_bagian' in 'where clause' - Invalid query: SELECT *
FROM `disposisi`
WHERE `kepada_bagian` IS NULL
ERROR - 2025-12-20 03:28:44 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:28:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 03:29:02 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:29:12 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:31:07 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:31:08 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:31:08 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:31:09 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:31:13 --> Query error: Table 'surat_itm_baru.penandatangan' doesn't exist - Invalid query: SELECT `surat_keluar`.*, `kategori`.`nama_kategori`, `penandatangan`.`nama` AS `nama_penandatangan`
FROM `surat_keluar`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_keluar`.`kategori`
LEFT JOIN `penandatangan` ON `penandatangan`.`id` = `surat_keluar`.`id_penandatangan`
ERROR - 2025-12-20 03:36:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 03:38:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 03:38:37 --> Query error: Unknown column 'kepada_bagian' in 'where clause' - Invalid query: SELECT *
FROM `disposisi`
WHERE `kepada_bagian` IS NULL
ERROR - 2025-12-20 03:43:54 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:44:07 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:46:56 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:47:05 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:48:03 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 39
ERROR - 2025-12-20 03:48:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 03:49:37 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 03:49:37 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 03:49:51 --> Query error: Unknown column 'surat_masuk.kategori' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-20 03:50:06 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:52:36 --> 404 Page Not Found: Surat-masuk/create
ERROR - 2025-12-20 03:52:42 --> 404 Page Not Found: Surat_masuk/create
ERROR - 2025-12-20 03:52:51 --> 404 Page Not Found: Surat_masuk/create
ERROR - 2025-12-20 03:55:19 --> 404 Page Not Found: Surat_masuk/create
ERROR - 2025-12-20 03:55:20 --> 404 Page Not Found: Surat_masuk/create
ERROR - 2025-12-20 03:55:24 --> 404 Page Not Found: Surat_masuk/create
ERROR - 2025-12-20 04:00:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:15:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:15:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:15:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:16:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Penandatangan_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-20 04:19:36 --> Severity: Warning --> Undefined variable $penandatangan D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 98
ERROR - 2025-12-20 04:19:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 98
ERROR - 2025-12-20 04:26:15 --> Query error: Unknown column 'kepada_bagian' in 'where clause' - Invalid query: SELECT *
FROM `disposisi`
WHERE `kepada_bagian` = 'ADM'
ERROR - 2025-12-20 04:38:56 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 04:38:56 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 04:39:07 --> Query error: Unknown column 'surat_masuk.kategori' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-20 04:39:39 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 39
ERROR - 2025-12-20 05:55:02 --> Query error: Unknown column 'surat_masuk.kategori' in 'on clause' - Invalid query: SELECT `surat_masuk`.*, `kategori`.`nama_kategori`, `bagian`.`nama_bagian`
FROM `surat_masuk`
LEFT JOIN `kategori` ON `kategori`.`kode_kategori` = `surat_masuk`.`kategori`
LEFT JOIN `bagian` ON `bagian`.`kode_bagian` = `surat_masuk`.`bagian`
ORDER BY `surat_masuk`.`tanggal_diterima` DESC
ERROR - 2025-12-20 05:55:17 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 39
ERROR - 2025-12-20 05:55:22 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 05:55:22 --> Severity: Warning --> Undefined property: stdClass::$tipe D:\xampp\htdocs\surat_itm\application\views\users\index.php 57
ERROR - 2025-12-20 06:00:12 --> Severity: error --> Exception: Call to undefined method User_model::get_by_username() D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 20
ERROR - 2025-12-20 06:28:37 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:28:40 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:28:41 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:28:41 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:28:48 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:30:54 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:31:03 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:32:09 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:32:15 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:48 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:49 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:49 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:50 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:50 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:34:50 --> 404 Page Not Found: 
ERROR - 2025-12-20 06:35:56 --> Severity: error --> Exception: Call to undefined method User_model::get_by_username() D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 20
ERROR - 2025-12-20 06:40:45 --> Severity: error --> Exception: syntax error, unexpected token "public" D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 22
ERROR - 2025-12-20 06:40:46 --> Severity: error --> Exception: syntax error, unexpected token "public" D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 22
ERROR - 2025-12-20 06:40:46 --> Severity: error --> Exception: syntax error, unexpected token "public" D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 22
ERROR - 2025-12-20 06:40:47 --> Severity: error --> Exception: syntax error, unexpected token "public" D:\xampp\htdocs\surat_itm\application\controllers\Profil.php 22
ERROR - 2025-12-20 06:44:37 --> Severity: error --> Exception: Call to undefined method User_model::get_by_username() D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 32
ERROR - 2025-12-20 06:45:32 --> Severity: error --> Exception: Call to undefined method User_model::get_by_username() D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 32
ERROR - 2025-12-20 06:45:40 --> Severity: error --> Exception: Call to undefined method User_model::get_by_username() D:\xampp\htdocs\surat_itm\application\controllers\Auth.php 32
ERROR - 2025-12-20 06:48:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 06:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 06:50:56 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 06:50:56 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 06:50:57 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 06:50:57 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-20 07:00:11 --> Query error: Unknown column 'user_login' in 'field list' - Invalid query: INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`, `user_login`, `status`) VALUES ('MHS', 'Mahasiswa', 'admin', '1')
ERROR - 2025-12-20 07:17:17 --> 404 Page Not Found: Assets/img
