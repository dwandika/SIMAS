<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-24 01:43:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-24 02:39:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-24 02:43:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-24 02:55:12 --> Could not find the language line "form_validation_valid_date"
ERROR - 2025-12-24 02:55:12 --> Could not find the language line "form_validation_valid_date"
ERROR - 2025-12-24 02:55:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
ERROR - 2025-12-24 03:05:51 --> 404 Page Not Found: Surat-masuk/export
ERROR - 2025-12-24 03:26:41 --> Severity: Warning --> Undefined array key "WARNING" D:\xampp\htdocs\surat_itm\system\core\Log.php 181
ERROR - 2025-12-24 03:26:41 --> PDF Parser library tidak ditemukan
INFO - 2025-12-24 03:31:17 --> Config Class Initialized
INFO - 2025-12-24 03:31:17 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:31:17 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:31:17 --> Utf8 Class Initialized
INFO - 2025-12-24 03:31:17 --> URI Class Initialized
INFO - 2025-12-24 03:31:17 --> Router Class Initialized
INFO - 2025-12-24 03:31:17 --> Output Class Initialized
INFO - 2025-12-24 03:31:17 --> Security Class Initialized
DEBUG - 2025-12-24 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:31:17 --> Input Class Initialized
INFO - 2025-12-24 03:31:17 --> Language Class Initialized
INFO - 2025-12-24 03:31:17 --> Loader Class Initialized
INFO - 2025-12-24 03:31:17 --> Helper loaded: url_helper
INFO - 2025-12-24 03:31:17 --> Helper loaded: form_helper
INFO - 2025-12-24 03:31:17 --> Helper loaded: file_helper
INFO - 2025-12-24 03:31:17 --> Helper loaded: html_helper
INFO - 2025-12-24 03:31:17 --> Helper loaded: security_helper
INFO - 2025-12-24 03:31:17 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:31:17 --> Database Driver Class Initialized
INFO - 2025-12-24 03:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:31:17 --> Form Validation Class Initialized
INFO - 2025-12-24 03:31:17 --> Controller Class Initialized
INFO - 2025-12-24 03:31:17 --> Document Extractor Library Loaded
INFO - 2025-12-24 03:31:17 --> Extracting text from: test_1766543477_694b5075a06b3.pdf (pdf)
ERROR - 2025-12-24 03:31:17 --> Severity: error --> Exception: Call to undefined method Document_extractor::_is_pdf_searchable() D:\xampp\htdocs\surat_itm\application\libraries\Document_extractor.php 102
INFO - 2025-12-24 03:31:37 --> Config Class Initialized
INFO - 2025-12-24 03:31:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:31:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:31:37 --> Utf8 Class Initialized
INFO - 2025-12-24 03:31:37 --> URI Class Initialized
INFO - 2025-12-24 03:31:37 --> Router Class Initialized
INFO - 2025-12-24 03:31:37 --> Output Class Initialized
INFO - 2025-12-24 03:31:37 --> Security Class Initialized
DEBUG - 2025-12-24 03:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:31:37 --> Input Class Initialized
INFO - 2025-12-24 03:31:37 --> Language Class Initialized
INFO - 2025-12-24 03:31:37 --> Loader Class Initialized
INFO - 2025-12-24 03:31:37 --> Helper loaded: url_helper
INFO - 2025-12-24 03:31:37 --> Helper loaded: form_helper
INFO - 2025-12-24 03:31:37 --> Helper loaded: file_helper
INFO - 2025-12-24 03:31:37 --> Helper loaded: html_helper
INFO - 2025-12-24 03:31:37 --> Helper loaded: security_helper
INFO - 2025-12-24 03:31:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:31:37 --> Database Driver Class Initialized
INFO - 2025-12-24 03:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:31:37 --> Form Validation Class Initialized
INFO - 2025-12-24 03:31:37 --> Controller Class Initialized
INFO - 2025-12-24 03:31:37 --> Document Extractor Library Loaded
INFO - 2025-12-24 03:31:37 --> Extracting text from: test_1766543497_694b508953d07.png (png)
INFO - 2025-12-24 03:31:38 --> OCR extracted: 1740 characters
ERROR - 2025-12-24 03:31:38 --> Severity: error --> Exception: Call to undefined method Document_extractor::extract_surat_data() D:\xampp\htdocs\surat_itm\application\controllers\test_ocr.php 170
INFO - 2025-12-24 03:33:02 --> Config Class Initialized
INFO - 2025-12-24 03:33:02 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:33:02 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:33:02 --> Utf8 Class Initialized
INFO - 2025-12-24 03:33:02 --> URI Class Initialized
INFO - 2025-12-24 03:33:02 --> Router Class Initialized
INFO - 2025-12-24 03:33:02 --> Output Class Initialized
INFO - 2025-12-24 03:33:02 --> Security Class Initialized
DEBUG - 2025-12-24 03:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:33:02 --> Input Class Initialized
INFO - 2025-12-24 03:33:02 --> Language Class Initialized
INFO - 2025-12-24 03:33:02 --> Loader Class Initialized
INFO - 2025-12-24 03:33:02 --> Helper loaded: url_helper
INFO - 2025-12-24 03:33:02 --> Helper loaded: form_helper
INFO - 2025-12-24 03:33:02 --> Helper loaded: file_helper
INFO - 2025-12-24 03:33:02 --> Helper loaded: html_helper
INFO - 2025-12-24 03:33:02 --> Helper loaded: security_helper
INFO - 2025-12-24 03:33:02 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:33:02 --> Database Driver Class Initialized
INFO - 2025-12-24 03:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:33:02 --> Form Validation Class Initialized
INFO - 2025-12-24 03:33:02 --> Controller Class Initialized
INFO - 2025-12-24 03:33:02 --> Document Extractor Library Loaded
INFO - 2025-12-24 03:33:02 --> Extracting text from: test_1766543582_694b50dee4222.docx (docx)
ERROR - 2025-12-24 03:33:02 --> ZipArchive extension not available
INFO - 2025-12-24 03:33:02 --> Final output sent to browser
DEBUG - 2025-12-24 03:33:02 --> Total execution time: 0.1035
INFO - 2025-12-24 03:33:18 --> Config Class Initialized
INFO - 2025-12-24 03:33:18 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:33:18 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:33:18 --> Utf8 Class Initialized
INFO - 2025-12-24 03:33:18 --> URI Class Initialized
INFO - 2025-12-24 03:33:18 --> Router Class Initialized
INFO - 2025-12-24 03:33:18 --> Output Class Initialized
INFO - 2025-12-24 03:33:18 --> Security Class Initialized
DEBUG - 2025-12-24 03:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:33:18 --> Input Class Initialized
INFO - 2025-12-24 03:33:19 --> Language Class Initialized
INFO - 2025-12-24 03:33:19 --> Loader Class Initialized
INFO - 2025-12-24 03:33:19 --> Helper loaded: url_helper
INFO - 2025-12-24 03:33:19 --> Helper loaded: form_helper
INFO - 2025-12-24 03:33:19 --> Helper loaded: file_helper
INFO - 2025-12-24 03:33:19 --> Helper loaded: html_helper
INFO - 2025-12-24 03:33:19 --> Helper loaded: security_helper
INFO - 2025-12-24 03:33:19 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:33:19 --> Database Driver Class Initialized
INFO - 2025-12-24 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:33:19 --> Form Validation Class Initialized
INFO - 2025-12-24 03:33:19 --> Controller Class Initialized
INFO - 2025-12-24 03:33:19 --> Document Extractor Library Loaded
INFO - 2025-12-24 03:33:19 --> Extracting text from: test_1766543599_694b50ef0ce4c.pdf (pdf)
ERROR - 2025-12-24 03:33:19 --> Severity: error --> Exception: Call to undefined method Document_extractor::_is_pdf_searchable() D:\xampp\htdocs\surat_itm\application\libraries\Document_extractor.php 102
INFO - 2025-12-24 03:33:54 --> Config Class Initialized
INFO - 2025-12-24 03:33:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:33:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:33:54 --> Utf8 Class Initialized
INFO - 2025-12-24 03:33:54 --> URI Class Initialized
INFO - 2025-12-24 03:33:54 --> Router Class Initialized
INFO - 2025-12-24 03:33:54 --> Output Class Initialized
INFO - 2025-12-24 03:33:54 --> Security Class Initialized
DEBUG - 2025-12-24 03:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:33:54 --> Input Class Initialized
INFO - 2025-12-24 03:33:54 --> Language Class Initialized
INFO - 2025-12-24 03:33:54 --> Loader Class Initialized
INFO - 2025-12-24 03:33:54 --> Helper loaded: url_helper
INFO - 2025-12-24 03:33:54 --> Helper loaded: form_helper
INFO - 2025-12-24 03:33:54 --> Helper loaded: file_helper
INFO - 2025-12-24 03:33:54 --> Helper loaded: html_helper
INFO - 2025-12-24 03:33:54 --> Helper loaded: security_helper
INFO - 2025-12-24 03:33:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:33:54 --> Database Driver Class Initialized
INFO - 2025-12-24 03:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:33:54 --> Form Validation Class Initialized
INFO - 2025-12-24 03:33:54 --> Controller Class Initialized
INFO - 2025-12-24 03:33:54 --> Final output sent to browser
DEBUG - 2025-12-24 03:33:54 --> Total execution time: 0.1145
INFO - 2025-12-24 03:34:15 --> Config Class Initialized
INFO - 2025-12-24 03:34:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:34:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:34:15 --> Utf8 Class Initialized
INFO - 2025-12-24 03:34:15 --> URI Class Initialized
INFO - 2025-12-24 03:34:15 --> Router Class Initialized
INFO - 2025-12-24 03:34:15 --> Output Class Initialized
INFO - 2025-12-24 03:34:15 --> Security Class Initialized
DEBUG - 2025-12-24 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:34:15 --> Input Class Initialized
INFO - 2025-12-24 03:34:15 --> Language Class Initialized
INFO - 2025-12-24 03:34:15 --> Loader Class Initialized
INFO - 2025-12-24 03:34:15 --> Helper loaded: url_helper
INFO - 2025-12-24 03:34:15 --> Helper loaded: form_helper
INFO - 2025-12-24 03:34:15 --> Helper loaded: file_helper
INFO - 2025-12-24 03:34:15 --> Helper loaded: html_helper
INFO - 2025-12-24 03:34:15 --> Helper loaded: security_helper
INFO - 2025-12-24 03:34:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:34:15 --> Database Driver Class Initialized
INFO - 2025-12-24 03:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:34:15 --> Form Validation Class Initialized
INFO - 2025-12-24 03:34:15 --> Controller Class Initialized
INFO - 2025-12-24 03:34:16 --> Final output sent to browser
DEBUG - 2025-12-24 03:34:16 --> Total execution time: 0.7073
INFO - 2025-12-24 03:34:50 --> Config Class Initialized
INFO - 2025-12-24 03:34:50 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:34:50 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:34:50 --> Utf8 Class Initialized
INFO - 2025-12-24 03:34:50 --> URI Class Initialized
INFO - 2025-12-24 03:34:50 --> Router Class Initialized
INFO - 2025-12-24 03:34:50 --> Output Class Initialized
INFO - 2025-12-24 03:34:50 --> Security Class Initialized
DEBUG - 2025-12-24 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:34:50 --> Input Class Initialized
INFO - 2025-12-24 03:34:50 --> Language Class Initialized
INFO - 2025-12-24 03:34:50 --> Loader Class Initialized
INFO - 2025-12-24 03:34:50 --> Helper loaded: url_helper
INFO - 2025-12-24 03:34:50 --> Helper loaded: form_helper
INFO - 2025-12-24 03:34:50 --> Helper loaded: file_helper
INFO - 2025-12-24 03:34:50 --> Helper loaded: html_helper
INFO - 2025-12-24 03:34:50 --> Helper loaded: security_helper
INFO - 2025-12-24 03:34:50 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:34:50 --> Database Driver Class Initialized
INFO - 2025-12-24 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:34:50 --> Form Validation Class Initialized
INFO - 2025-12-24 03:34:50 --> Controller Class Initialized
INFO - 2025-12-24 03:34:50 --> Final output sent to browser
DEBUG - 2025-12-24 03:34:50 --> Total execution time: 0.3956
INFO - 2025-12-24 03:35:21 --> Config Class Initialized
INFO - 2025-12-24 03:35:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:35:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:35:21 --> Utf8 Class Initialized
INFO - 2025-12-24 03:35:21 --> URI Class Initialized
INFO - 2025-12-24 03:35:21 --> Router Class Initialized
INFO - 2025-12-24 03:35:21 --> Output Class Initialized
INFO - 2025-12-24 03:35:21 --> Security Class Initialized
DEBUG - 2025-12-24 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:35:21 --> Input Class Initialized
INFO - 2025-12-24 03:35:21 --> Language Class Initialized
INFO - 2025-12-24 03:35:21 --> Loader Class Initialized
INFO - 2025-12-24 03:35:21 --> Helper loaded: url_helper
INFO - 2025-12-24 03:35:21 --> Helper loaded: form_helper
INFO - 2025-12-24 03:35:21 --> Helper loaded: file_helper
INFO - 2025-12-24 03:35:21 --> Helper loaded: html_helper
INFO - 2025-12-24 03:35:21 --> Helper loaded: security_helper
INFO - 2025-12-24 03:35:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:35:21 --> Database Driver Class Initialized
INFO - 2025-12-24 03:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:35:21 --> Form Validation Class Initialized
INFO - 2025-12-24 03:35:21 --> Controller Class Initialized
INFO - 2025-12-24 03:35:21 --> Final output sent to browser
DEBUG - 2025-12-24 03:35:21 --> Total execution time: 0.0680
INFO - 2025-12-24 03:36:35 --> Config Class Initialized
INFO - 2025-12-24 03:36:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:36:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:36:35 --> Utf8 Class Initialized
INFO - 2025-12-24 03:36:35 --> URI Class Initialized
INFO - 2025-12-24 03:36:35 --> Router Class Initialized
INFO - 2025-12-24 03:36:35 --> Output Class Initialized
INFO - 2025-12-24 03:36:35 --> Security Class Initialized
DEBUG - 2025-12-24 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:36:35 --> Input Class Initialized
INFO - 2025-12-24 03:36:35 --> Language Class Initialized
INFO - 2025-12-24 03:36:35 --> Loader Class Initialized
INFO - 2025-12-24 03:36:35 --> Helper loaded: url_helper
INFO - 2025-12-24 03:36:35 --> Helper loaded: form_helper
INFO - 2025-12-24 03:36:35 --> Helper loaded: file_helper
INFO - 2025-12-24 03:36:35 --> Helper loaded: html_helper
INFO - 2025-12-24 03:36:35 --> Helper loaded: security_helper
INFO - 2025-12-24 03:36:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:36:35 --> Database Driver Class Initialized
INFO - 2025-12-24 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:36:35 --> Form Validation Class Initialized
INFO - 2025-12-24 03:36:35 --> Controller Class Initialized
INFO - 2025-12-24 03:36:36 --> Final output sent to browser
DEBUG - 2025-12-24 03:36:36 --> Total execution time: 1.5722
INFO - 2025-12-24 03:39:53 --> Config Class Initialized
INFO - 2025-12-24 03:39:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:39:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:39:53 --> Utf8 Class Initialized
INFO - 2025-12-24 03:39:53 --> URI Class Initialized
INFO - 2025-12-24 03:39:53 --> Router Class Initialized
INFO - 2025-12-24 03:39:53 --> Output Class Initialized
INFO - 2025-12-24 03:39:53 --> Security Class Initialized
DEBUG - 2025-12-24 03:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:39:53 --> Input Class Initialized
INFO - 2025-12-24 03:39:53 --> Language Class Initialized
INFO - 2025-12-24 03:39:53 --> Loader Class Initialized
INFO - 2025-12-24 03:39:53 --> Helper loaded: url_helper
INFO - 2025-12-24 03:39:53 --> Helper loaded: form_helper
INFO - 2025-12-24 03:39:53 --> Helper loaded: file_helper
INFO - 2025-12-24 03:39:53 --> Helper loaded: html_helper
INFO - 2025-12-24 03:39:53 --> Helper loaded: security_helper
INFO - 2025-12-24 03:39:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:39:53 --> Database Driver Class Initialized
INFO - 2025-12-24 03:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:39:53 --> Form Validation Class Initialized
INFO - 2025-12-24 03:39:53 --> Controller Class Initialized
INFO - 2025-12-24 03:39:55 --> Final output sent to browser
DEBUG - 2025-12-24 03:39:55 --> Total execution time: 1.9371
INFO - 2025-12-24 03:52:24 --> Config Class Initialized
INFO - 2025-12-24 03:52:24 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:52:24 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:52:24 --> Utf8 Class Initialized
INFO - 2025-12-24 03:52:24 --> URI Class Initialized
INFO - 2025-12-24 03:52:24 --> Router Class Initialized
INFO - 2025-12-24 03:52:24 --> Output Class Initialized
INFO - 2025-12-24 03:52:24 --> Security Class Initialized
DEBUG - 2025-12-24 03:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:52:24 --> CSRF cookie sent
INFO - 2025-12-24 03:52:24 --> Input Class Initialized
INFO - 2025-12-24 03:52:24 --> Language Class Initialized
INFO - 2025-12-24 03:52:24 --> Loader Class Initialized
INFO - 2025-12-24 03:52:24 --> Helper loaded: url_helper
INFO - 2025-12-24 03:52:24 --> Helper loaded: form_helper
INFO - 2025-12-24 03:52:24 --> Helper loaded: file_helper
INFO - 2025-12-24 03:52:24 --> Helper loaded: html_helper
INFO - 2025-12-24 03:52:24 --> Helper loaded: security_helper
INFO - 2025-12-24 03:52:24 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:52:24 --> Database Driver Class Initialized
INFO - 2025-12-24 03:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:52:24 --> Form Validation Class Initialized
INFO - 2025-12-24 03:52:24 --> Controller Class Initialized
INFO - 2025-12-24 03:52:24 --> Final output sent to browser
DEBUG - 2025-12-24 03:52:24 --> Total execution time: 0.0871
INFO - 2025-12-24 03:52:35 --> Config Class Initialized
INFO - 2025-12-24 03:52:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:52:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:52:35 --> Utf8 Class Initialized
INFO - 2025-12-24 03:52:35 --> URI Class Initialized
INFO - 2025-12-24 03:52:35 --> Router Class Initialized
INFO - 2025-12-24 03:52:35 --> Output Class Initialized
INFO - 2025-12-24 03:52:35 --> Security Class Initialized
DEBUG - 2025-12-24 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:52:35 --> Input Class Initialized
INFO - 2025-12-24 03:52:35 --> Language Class Initialized
INFO - 2025-12-24 03:52:35 --> Loader Class Initialized
INFO - 2025-12-24 03:52:35 --> Helper loaded: url_helper
INFO - 2025-12-24 03:52:35 --> Helper loaded: form_helper
INFO - 2025-12-24 03:52:35 --> Helper loaded: file_helper
INFO - 2025-12-24 03:52:35 --> Helper loaded: html_helper
INFO - 2025-12-24 03:52:35 --> Helper loaded: security_helper
INFO - 2025-12-24 03:52:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:52:35 --> Database Driver Class Initialized
INFO - 2025-12-24 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:52:35 --> Form Validation Class Initialized
INFO - 2025-12-24 03:52:35 --> Controller Class Initialized
INFO - 2025-12-24 03:52:35 --> Final output sent to browser
DEBUG - 2025-12-24 03:52:35 --> Total execution time: 0.0664
INFO - 2025-12-24 03:52:42 --> Config Class Initialized
INFO - 2025-12-24 03:52:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:52:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:52:42 --> Utf8 Class Initialized
INFO - 2025-12-24 03:52:42 --> URI Class Initialized
INFO - 2025-12-24 03:52:42 --> Router Class Initialized
INFO - 2025-12-24 03:52:42 --> Output Class Initialized
INFO - 2025-12-24 03:52:42 --> Security Class Initialized
DEBUG - 2025-12-24 03:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:52:42 --> CSRF cookie sent
INFO - 2025-12-24 03:52:42 --> Input Class Initialized
INFO - 2025-12-24 03:52:42 --> Language Class Initialized
INFO - 2025-12-24 03:52:42 --> Loader Class Initialized
INFO - 2025-12-24 03:52:42 --> Helper loaded: url_helper
INFO - 2025-12-24 03:52:42 --> Helper loaded: form_helper
INFO - 2025-12-24 03:52:42 --> Helper loaded: file_helper
INFO - 2025-12-24 03:52:42 --> Helper loaded: html_helper
INFO - 2025-12-24 03:52:42 --> Helper loaded: security_helper
INFO - 2025-12-24 03:52:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:52:42 --> Database Driver Class Initialized
INFO - 2025-12-24 03:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:52:42 --> Form Validation Class Initialized
INFO - 2025-12-24 03:52:42 --> Controller Class Initialized
INFO - 2025-12-24 03:52:42 --> Final output sent to browser
DEBUG - 2025-12-24 03:52:42 --> Total execution time: 0.0542
INFO - 2025-12-24 03:52:52 --> Config Class Initialized
INFO - 2025-12-24 03:52:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:52:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:52:52 --> Utf8 Class Initialized
INFO - 2025-12-24 03:52:52 --> URI Class Initialized
INFO - 2025-12-24 03:52:52 --> Router Class Initialized
INFO - 2025-12-24 03:52:52 --> Output Class Initialized
INFO - 2025-12-24 03:52:52 --> Security Class Initialized
DEBUG - 2025-12-24 03:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:52:52 --> Input Class Initialized
INFO - 2025-12-24 03:52:52 --> Language Class Initialized
INFO - 2025-12-24 03:52:52 --> Loader Class Initialized
INFO - 2025-12-24 03:52:52 --> Helper loaded: url_helper
INFO - 2025-12-24 03:52:52 --> Helper loaded: form_helper
INFO - 2025-12-24 03:52:52 --> Helper loaded: file_helper
INFO - 2025-12-24 03:52:52 --> Helper loaded: html_helper
INFO - 2025-12-24 03:52:52 --> Helper loaded: security_helper
INFO - 2025-12-24 03:52:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:52:52 --> Database Driver Class Initialized
INFO - 2025-12-24 03:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:52:52 --> Form Validation Class Initialized
INFO - 2025-12-24 03:52:52 --> Controller Class Initialized
INFO - 2025-12-24 03:52:52 --> Final output sent to browser
DEBUG - 2025-12-24 03:52:52 --> Total execution time: 0.0514
INFO - 2025-12-24 03:53:25 --> Config Class Initialized
INFO - 2025-12-24 03:53:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:53:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:53:25 --> Utf8 Class Initialized
INFO - 2025-12-24 03:53:25 --> URI Class Initialized
DEBUG - 2025-12-24 03:53:25 --> No URI present. Default controller set.
INFO - 2025-12-24 03:53:25 --> Router Class Initialized
INFO - 2025-12-24 03:53:25 --> Output Class Initialized
INFO - 2025-12-24 03:53:25 --> Security Class Initialized
DEBUG - 2025-12-24 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:53:25 --> CSRF cookie sent
INFO - 2025-12-24 03:53:25 --> Input Class Initialized
INFO - 2025-12-24 03:53:25 --> Language Class Initialized
INFO - 2025-12-24 03:53:25 --> Loader Class Initialized
INFO - 2025-12-24 03:53:25 --> Helper loaded: url_helper
INFO - 2025-12-24 03:53:25 --> Helper loaded: form_helper
INFO - 2025-12-24 03:53:25 --> Helper loaded: file_helper
INFO - 2025-12-24 03:53:25 --> Helper loaded: html_helper
INFO - 2025-12-24 03:53:25 --> Helper loaded: security_helper
INFO - 2025-12-24 03:53:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:53:25 --> Database Driver Class Initialized
INFO - 2025-12-24 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:53:25 --> Form Validation Class Initialized
INFO - 2025-12-24 03:53:25 --> Controller Class Initialized
INFO - 2025-12-24 03:53:25 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 03:53:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:53:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:53:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:53:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 03:53:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:53:25 --> Final output sent to browser
DEBUG - 2025-12-24 03:53:25 --> Total execution time: 0.0614
INFO - 2025-12-24 03:53:27 --> Config Class Initialized
INFO - 2025-12-24 03:53:27 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:53:27 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:53:27 --> Utf8 Class Initialized
INFO - 2025-12-24 03:53:27 --> URI Class Initialized
INFO - 2025-12-24 03:53:27 --> Router Class Initialized
INFO - 2025-12-24 03:53:27 --> Output Class Initialized
INFO - 2025-12-24 03:53:27 --> Security Class Initialized
DEBUG - 2025-12-24 03:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:53:27 --> CSRF cookie sent
INFO - 2025-12-24 03:53:27 --> Input Class Initialized
INFO - 2025-12-24 03:53:27 --> Language Class Initialized
INFO - 2025-12-24 03:53:27 --> Loader Class Initialized
INFO - 2025-12-24 03:53:27 --> Helper loaded: url_helper
INFO - 2025-12-24 03:53:27 --> Helper loaded: form_helper
INFO - 2025-12-24 03:53:27 --> Helper loaded: file_helper
INFO - 2025-12-24 03:53:27 --> Helper loaded: html_helper
INFO - 2025-12-24 03:53:27 --> Helper loaded: security_helper
INFO - 2025-12-24 03:53:27 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:53:27 --> Database Driver Class Initialized
INFO - 2025-12-24 03:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:53:27 --> Form Validation Class Initialized
INFO - 2025-12-24 03:53:27 --> Controller Class Initialized
INFO - 2025-12-24 03:53:27 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 03:53:27 --> Model "Bagian_model" initialized
INFO - 2025-12-24 03:53:27 --> Model "Kategori_model" initialized
INFO - 2025-12-24 03:53:27 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 03:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:53:27 --> Upload Class Initialized
INFO - 2025-12-24 03:53:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:53:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:53:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:53:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 03:53:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:53:27 --> Final output sent to browser
DEBUG - 2025-12-24 03:53:27 --> Total execution time: 0.0547
INFO - 2025-12-24 03:53:29 --> Config Class Initialized
INFO - 2025-12-24 03:53:29 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:53:29 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:53:29 --> Utf8 Class Initialized
INFO - 2025-12-24 03:53:29 --> URI Class Initialized
INFO - 2025-12-24 03:53:29 --> Router Class Initialized
INFO - 2025-12-24 03:53:29 --> Output Class Initialized
INFO - 2025-12-24 03:53:29 --> Security Class Initialized
DEBUG - 2025-12-24 03:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:53:29 --> CSRF cookie sent
INFO - 2025-12-24 03:53:29 --> Input Class Initialized
INFO - 2025-12-24 03:53:29 --> Language Class Initialized
INFO - 2025-12-24 03:53:29 --> Loader Class Initialized
INFO - 2025-12-24 03:53:29 --> Helper loaded: url_helper
INFO - 2025-12-24 03:53:29 --> Helper loaded: form_helper
INFO - 2025-12-24 03:53:29 --> Helper loaded: file_helper
INFO - 2025-12-24 03:53:29 --> Helper loaded: html_helper
INFO - 2025-12-24 03:53:29 --> Helper loaded: security_helper
INFO - 2025-12-24 03:53:29 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:53:29 --> Database Driver Class Initialized
INFO - 2025-12-24 03:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:53:29 --> Form Validation Class Initialized
INFO - 2025-12-24 03:53:29 --> Controller Class Initialized
INFO - 2025-12-24 03:53:29 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 03:53:29 --> Model "Bagian_model" initialized
INFO - 2025-12-24 03:53:29 --> Model "Kategori_model" initialized
INFO - 2025-12-24 03:53:29 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 03:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:53:29 --> Upload Class Initialized
INFO - 2025-12-24 03:53:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:53:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:53:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:53:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 03:53:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:53:29 --> Final output sent to browser
DEBUG - 2025-12-24 03:53:29 --> Total execution time: 0.0525
INFO - 2025-12-24 03:56:02 --> Config Class Initialized
INFO - 2025-12-24 03:56:02 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:56:02 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:56:02 --> Utf8 Class Initialized
INFO - 2025-12-24 03:56:02 --> URI Class Initialized
INFO - 2025-12-24 03:56:02 --> Router Class Initialized
INFO - 2025-12-24 03:56:02 --> Output Class Initialized
INFO - 2025-12-24 03:56:02 --> Security Class Initialized
DEBUG - 2025-12-24 03:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:56:02 --> CSRF cookie sent
INFO - 2025-12-24 03:56:02 --> Input Class Initialized
INFO - 2025-12-24 03:56:02 --> Language Class Initialized
INFO - 2025-12-24 03:56:02 --> Loader Class Initialized
INFO - 2025-12-24 03:56:02 --> Helper loaded: url_helper
INFO - 2025-12-24 03:56:02 --> Helper loaded: form_helper
INFO - 2025-12-24 03:56:02 --> Helper loaded: file_helper
INFO - 2025-12-24 03:56:02 --> Helper loaded: html_helper
INFO - 2025-12-24 03:56:02 --> Helper loaded: security_helper
INFO - 2025-12-24 03:56:02 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:56:02 --> Database Driver Class Initialized
INFO - 2025-12-24 03:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:56:02 --> Form Validation Class Initialized
INFO - 2025-12-24 03:56:02 --> Controller Class Initialized
INFO - 2025-12-24 03:56:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 03:56:02 --> Model "Bagian_model" initialized
INFO - 2025-12-24 03:56:02 --> Model "Kategori_model" initialized
INFO - 2025-12-24 03:56:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 03:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:56:02 --> Upload Class Initialized
INFO - 2025-12-24 03:56:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:56:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:56:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:56:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 03:56:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:56:02 --> Final output sent to browser
DEBUG - 2025-12-24 03:56:02 --> Total execution time: 0.0746
INFO - 2025-12-24 03:56:25 --> Config Class Initialized
INFO - 2025-12-24 03:56:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:56:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:56:25 --> Utf8 Class Initialized
INFO - 2025-12-24 03:56:25 --> URI Class Initialized
INFO - 2025-12-24 03:56:25 --> Router Class Initialized
INFO - 2025-12-24 03:56:25 --> Output Class Initialized
INFO - 2025-12-24 03:56:25 --> Security Class Initialized
DEBUG - 2025-12-24 03:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:56:25 --> CSRF cookie sent
INFO - 2025-12-24 03:56:25 --> Input Class Initialized
INFO - 2025-12-24 03:56:25 --> Language Class Initialized
INFO - 2025-12-24 03:56:25 --> Loader Class Initialized
INFO - 2025-12-24 03:56:25 --> Helper loaded: url_helper
INFO - 2025-12-24 03:56:25 --> Helper loaded: form_helper
INFO - 2025-12-24 03:56:25 --> Helper loaded: file_helper
INFO - 2025-12-24 03:56:25 --> Helper loaded: html_helper
INFO - 2025-12-24 03:56:25 --> Helper loaded: security_helper
INFO - 2025-12-24 03:56:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:56:25 --> Database Driver Class Initialized
INFO - 2025-12-24 03:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:56:25 --> Form Validation Class Initialized
INFO - 2025-12-24 03:56:25 --> Controller Class Initialized
INFO - 2025-12-24 03:56:25 --> Model "User_model" initialized
INFO - 2025-12-24 03:56:25 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 03:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:56:25 --> Upload Class Initialized
INFO - 2025-12-24 03:56:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:56:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:56:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:56:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-24 03:56:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:56:25 --> Final output sent to browser
DEBUG - 2025-12-24 03:56:25 --> Total execution time: 0.0693
INFO - 2025-12-24 03:59:11 --> Config Class Initialized
INFO - 2025-12-24 03:59:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:59:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:59:11 --> Utf8 Class Initialized
INFO - 2025-12-24 03:59:11 --> URI Class Initialized
INFO - 2025-12-24 03:59:11 --> Router Class Initialized
INFO - 2025-12-24 03:59:11 --> Output Class Initialized
INFO - 2025-12-24 03:59:11 --> Security Class Initialized
DEBUG - 2025-12-24 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:59:11 --> CSRF cookie sent
INFO - 2025-12-24 03:59:11 --> Input Class Initialized
INFO - 2025-12-24 03:59:11 --> Language Class Initialized
INFO - 2025-12-24 03:59:11 --> Loader Class Initialized
INFO - 2025-12-24 03:59:11 --> Helper loaded: url_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: form_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: file_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: html_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: security_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:59:11 --> Database Driver Class Initialized
INFO - 2025-12-24 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:59:11 --> Form Validation Class Initialized
INFO - 2025-12-24 03:59:11 --> Controller Class Initialized
INFO - 2025-12-24 03:59:11 --> Model "User_model" initialized
INFO - 2025-12-24 03:59:11 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 03:59:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:59:11 --> Upload Class Initialized
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:59:11 --> Final output sent to browser
DEBUG - 2025-12-24 03:59:11 --> Total execution time: 0.0783
INFO - 2025-12-24 03:59:11 --> Config Class Initialized
INFO - 2025-12-24 03:59:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:59:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:59:11 --> Utf8 Class Initialized
INFO - 2025-12-24 03:59:11 --> URI Class Initialized
INFO - 2025-12-24 03:59:11 --> Router Class Initialized
INFO - 2025-12-24 03:59:11 --> Output Class Initialized
INFO - 2025-12-24 03:59:11 --> Security Class Initialized
DEBUG - 2025-12-24 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:59:11 --> CSRF cookie sent
INFO - 2025-12-24 03:59:11 --> Input Class Initialized
INFO - 2025-12-24 03:59:11 --> Language Class Initialized
INFO - 2025-12-24 03:59:11 --> Loader Class Initialized
INFO - 2025-12-24 03:59:11 --> Helper loaded: url_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: form_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: file_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: html_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: security_helper
INFO - 2025-12-24 03:59:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:59:11 --> Database Driver Class Initialized
INFO - 2025-12-24 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:59:11 --> Form Validation Class Initialized
INFO - 2025-12-24 03:59:11 --> Controller Class Initialized
INFO - 2025-12-24 03:59:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 03:59:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 03:59:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 03:59:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 03:59:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:59:11 --> Upload Class Initialized
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 03:59:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:59:11 --> Final output sent to browser
DEBUG - 2025-12-24 03:59:11 --> Total execution time: 0.1213
INFO - 2025-12-24 03:59:12 --> Config Class Initialized
INFO - 2025-12-24 03:59:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 03:59:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 03:59:12 --> Utf8 Class Initialized
INFO - 2025-12-24 03:59:12 --> URI Class Initialized
INFO - 2025-12-24 03:59:12 --> Router Class Initialized
INFO - 2025-12-24 03:59:12 --> Output Class Initialized
INFO - 2025-12-24 03:59:12 --> Security Class Initialized
DEBUG - 2025-12-24 03:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 03:59:12 --> CSRF cookie sent
INFO - 2025-12-24 03:59:12 --> Input Class Initialized
INFO - 2025-12-24 03:59:12 --> Language Class Initialized
INFO - 2025-12-24 03:59:12 --> Loader Class Initialized
INFO - 2025-12-24 03:59:12 --> Helper loaded: url_helper
INFO - 2025-12-24 03:59:12 --> Helper loaded: form_helper
INFO - 2025-12-24 03:59:12 --> Helper loaded: file_helper
INFO - 2025-12-24 03:59:12 --> Helper loaded: html_helper
INFO - 2025-12-24 03:59:12 --> Helper loaded: security_helper
INFO - 2025-12-24 03:59:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 03:59:12 --> Database Driver Class Initialized
INFO - 2025-12-24 03:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 03:59:12 --> Form Validation Class Initialized
INFO - 2025-12-24 03:59:12 --> Controller Class Initialized
INFO - 2025-12-24 03:59:12 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 03:59:12 --> Model "Bagian_model" initialized
INFO - 2025-12-24 03:59:12 --> Model "Kategori_model" initialized
INFO - 2025-12-24 03:59:12 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 03:59:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 03:59:12 --> Upload Class Initialized
INFO - 2025-12-24 03:59:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 03:59:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 03:59:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 03:59:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 03:59:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 03:59:12 --> Final output sent to browser
DEBUG - 2025-12-24 03:59:12 --> Total execution time: 0.4521
INFO - 2025-12-24 04:01:46 --> Config Class Initialized
INFO - 2025-12-24 04:01:46 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:01:46 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:01:46 --> Utf8 Class Initialized
INFO - 2025-12-24 04:01:46 --> URI Class Initialized
INFO - 2025-12-24 04:01:46 --> Router Class Initialized
INFO - 2025-12-24 04:01:46 --> Output Class Initialized
INFO - 2025-12-24 04:01:46 --> Security Class Initialized
DEBUG - 2025-12-24 04:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:01:46 --> CSRF cookie sent
INFO - 2025-12-24 04:01:46 --> Input Class Initialized
INFO - 2025-12-24 04:01:46 --> Language Class Initialized
INFO - 2025-12-24 04:01:46 --> Loader Class Initialized
INFO - 2025-12-24 04:01:46 --> Helper loaded: url_helper
INFO - 2025-12-24 04:01:46 --> Helper loaded: form_helper
INFO - 2025-12-24 04:01:46 --> Helper loaded: file_helper
INFO - 2025-12-24 04:01:46 --> Helper loaded: html_helper
INFO - 2025-12-24 04:01:46 --> Helper loaded: security_helper
INFO - 2025-12-24 04:01:46 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:01:46 --> Database Driver Class Initialized
INFO - 2025-12-24 04:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:01:46 --> Form Validation Class Initialized
INFO - 2025-12-24 04:01:46 --> Controller Class Initialized
INFO - 2025-12-24 04:01:46 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 04:01:46 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:01:46 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 04:01:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 04:20:14 --> Config Class Initialized
INFO - 2025-12-24 04:20:14 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:20:14 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:20:14 --> Utf8 Class Initialized
INFO - 2025-12-24 04:20:14 --> URI Class Initialized
INFO - 2025-12-24 04:20:14 --> Router Class Initialized
INFO - 2025-12-24 04:20:14 --> Output Class Initialized
INFO - 2025-12-24 04:20:14 --> Security Class Initialized
DEBUG - 2025-12-24 04:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:20:14 --> CSRF cookie sent
INFO - 2025-12-24 04:20:14 --> Input Class Initialized
INFO - 2025-12-24 04:20:14 --> Language Class Initialized
INFO - 2025-12-24 04:20:14 --> Loader Class Initialized
INFO - 2025-12-24 04:20:14 --> Helper loaded: url_helper
INFO - 2025-12-24 04:20:14 --> Helper loaded: form_helper
INFO - 2025-12-24 04:20:14 --> Helper loaded: file_helper
INFO - 2025-12-24 04:20:14 --> Helper loaded: html_helper
INFO - 2025-12-24 04:20:14 --> Helper loaded: security_helper
INFO - 2025-12-24 04:20:14 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:20:14 --> Database Driver Class Initialized
INFO - 2025-12-24 04:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:20:14 --> Form Validation Class Initialized
INFO - 2025-12-24 04:20:14 --> Controller Class Initialized
INFO - 2025-12-24 04:20:14 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 04:20:14 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:20:14 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 04:20:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 04:21:22 --> Config Class Initialized
INFO - 2025-12-24 04:21:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:21:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:21:22 --> Utf8 Class Initialized
INFO - 2025-12-24 04:21:22 --> URI Class Initialized
INFO - 2025-12-24 04:21:22 --> Router Class Initialized
INFO - 2025-12-24 04:21:22 --> Output Class Initialized
INFO - 2025-12-24 04:21:22 --> Security Class Initialized
DEBUG - 2025-12-24 04:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:21:22 --> CSRF cookie sent
INFO - 2025-12-24 04:21:22 --> Input Class Initialized
INFO - 2025-12-24 04:21:22 --> Language Class Initialized
INFO - 2025-12-24 04:21:22 --> Loader Class Initialized
INFO - 2025-12-24 04:21:22 --> Helper loaded: url_helper
INFO - 2025-12-24 04:21:22 --> Helper loaded: form_helper
INFO - 2025-12-24 04:21:22 --> Helper loaded: file_helper
INFO - 2025-12-24 04:21:22 --> Helper loaded: html_helper
INFO - 2025-12-24 04:21:22 --> Helper loaded: security_helper
INFO - 2025-12-24 04:21:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:21:22 --> Database Driver Class Initialized
INFO - 2025-12-24 04:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:21:22 --> Form Validation Class Initialized
INFO - 2025-12-24 04:21:22 --> Controller Class Initialized
INFO - 2025-12-24 04:21:22 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:21:22 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:21:22 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:21:22 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:21:22 --> Upload Class Initialized
INFO - 2025-12-24 04:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:21:22 --> Final output sent to browser
DEBUG - 2025-12-24 04:21:22 --> Total execution time: 0.1481
INFO - 2025-12-24 04:21:25 --> Config Class Initialized
INFO - 2025-12-24 04:21:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:21:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:21:25 --> Utf8 Class Initialized
INFO - 2025-12-24 04:21:25 --> URI Class Initialized
INFO - 2025-12-24 04:21:25 --> Router Class Initialized
INFO - 2025-12-24 04:21:25 --> Output Class Initialized
INFO - 2025-12-24 04:21:25 --> Security Class Initialized
DEBUG - 2025-12-24 04:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:21:25 --> CSRF cookie sent
INFO - 2025-12-24 04:21:25 --> Input Class Initialized
INFO - 2025-12-24 04:21:25 --> Language Class Initialized
INFO - 2025-12-24 04:21:25 --> Loader Class Initialized
INFO - 2025-12-24 04:21:25 --> Helper loaded: url_helper
INFO - 2025-12-24 04:21:25 --> Helper loaded: form_helper
INFO - 2025-12-24 04:21:25 --> Helper loaded: file_helper
INFO - 2025-12-24 04:21:25 --> Helper loaded: html_helper
INFO - 2025-12-24 04:21:25 --> Helper loaded: security_helper
INFO - 2025-12-24 04:21:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:21:25 --> Database Driver Class Initialized
INFO - 2025-12-24 04:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:21:25 --> Form Validation Class Initialized
INFO - 2025-12-24 04:21:25 --> Controller Class Initialized
INFO - 2025-12-24 04:21:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:21:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:21:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:21:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:21:25 --> Upload Class Initialized
INFO - 2025-12-24 04:21:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:21:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:21:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:21:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:21:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:21:25 --> Final output sent to browser
DEBUG - 2025-12-24 04:21:25 --> Total execution time: 0.0575
INFO - 2025-12-24 04:24:19 --> Config Class Initialized
INFO - 2025-12-24 04:24:19 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:24:19 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:24:19 --> Utf8 Class Initialized
INFO - 2025-12-24 04:24:19 --> URI Class Initialized
INFO - 2025-12-24 04:24:19 --> Router Class Initialized
INFO - 2025-12-24 04:24:19 --> Output Class Initialized
INFO - 2025-12-24 04:24:19 --> Security Class Initialized
DEBUG - 2025-12-24 04:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:24:19 --> CSRF cookie sent
INFO - 2025-12-24 04:24:19 --> Input Class Initialized
INFO - 2025-12-24 04:24:19 --> Language Class Initialized
INFO - 2025-12-24 04:24:19 --> Loader Class Initialized
INFO - 2025-12-24 04:24:19 --> Helper loaded: url_helper
INFO - 2025-12-24 04:24:19 --> Helper loaded: form_helper
INFO - 2025-12-24 04:24:19 --> Helper loaded: file_helper
INFO - 2025-12-24 04:24:19 --> Helper loaded: html_helper
INFO - 2025-12-24 04:24:19 --> Helper loaded: security_helper
INFO - 2025-12-24 04:24:19 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:24:19 --> Database Driver Class Initialized
INFO - 2025-12-24 04:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:24:19 --> Form Validation Class Initialized
INFO - 2025-12-24 04:24:19 --> Controller Class Initialized
INFO - 2025-12-24 04:24:19 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:24:19 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:24:19 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:24:19 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:24:19 --> Upload Class Initialized
INFO - 2025-12-24 04:24:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:24:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:24:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:24:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:24:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:24:19 --> Final output sent to browser
DEBUG - 2025-12-24 04:24:19 --> Total execution time: 0.1239
INFO - 2025-12-24 04:26:07 --> Config Class Initialized
INFO - 2025-12-24 04:26:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:26:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:26:07 --> Utf8 Class Initialized
INFO - 2025-12-24 04:26:07 --> URI Class Initialized
INFO - 2025-12-24 04:26:07 --> Router Class Initialized
INFO - 2025-12-24 04:26:07 --> Output Class Initialized
INFO - 2025-12-24 04:26:07 --> Security Class Initialized
DEBUG - 2025-12-24 04:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:26:07 --> CSRF cookie sent
INFO - 2025-12-24 04:26:07 --> Input Class Initialized
INFO - 2025-12-24 04:26:07 --> Language Class Initialized
INFO - 2025-12-24 04:26:07 --> Loader Class Initialized
INFO - 2025-12-24 04:26:07 --> Helper loaded: url_helper
INFO - 2025-12-24 04:26:07 --> Helper loaded: form_helper
INFO - 2025-12-24 04:26:07 --> Helper loaded: file_helper
INFO - 2025-12-24 04:26:07 --> Helper loaded: html_helper
INFO - 2025-12-24 04:26:07 --> Helper loaded: security_helper
INFO - 2025-12-24 04:26:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:26:07 --> Database Driver Class Initialized
INFO - 2025-12-24 04:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:26:07 --> Form Validation Class Initialized
INFO - 2025-12-24 04:26:07 --> Controller Class Initialized
INFO - 2025-12-24 04:26:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:26:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:26:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:26:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:26:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:26:07 --> Upload Class Initialized
INFO - 2025-12-24 04:26:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:26:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:26:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:26:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:26:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:26:07 --> Final output sent to browser
DEBUG - 2025-12-24 04:26:07 --> Total execution time: 0.2326
INFO - 2025-12-24 04:31:11 --> Config Class Initialized
INFO - 2025-12-24 04:31:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:31:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:31:11 --> Utf8 Class Initialized
INFO - 2025-12-24 04:31:11 --> URI Class Initialized
INFO - 2025-12-24 04:31:11 --> Router Class Initialized
INFO - 2025-12-24 04:31:11 --> Output Class Initialized
INFO - 2025-12-24 04:31:11 --> Security Class Initialized
DEBUG - 2025-12-24 04:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:31:11 --> CSRF cookie sent
INFO - 2025-12-24 04:31:11 --> Input Class Initialized
INFO - 2025-12-24 04:31:11 --> Language Class Initialized
INFO - 2025-12-24 04:31:11 --> Loader Class Initialized
INFO - 2025-12-24 04:31:11 --> Helper loaded: url_helper
INFO - 2025-12-24 04:31:11 --> Helper loaded: form_helper
INFO - 2025-12-24 04:31:11 --> Helper loaded: file_helper
INFO - 2025-12-24 04:31:11 --> Helper loaded: html_helper
INFO - 2025-12-24 04:31:11 --> Helper loaded: security_helper
INFO - 2025-12-24 04:31:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:31:11 --> Database Driver Class Initialized
INFO - 2025-12-24 04:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:31:11 --> Form Validation Class Initialized
INFO - 2025-12-24 04:31:11 --> Controller Class Initialized
INFO - 2025-12-24 04:31:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:31:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:31:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:31:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:31:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:31:11 --> Upload Class Initialized
INFO - 2025-12-24 04:31:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:31:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:31:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:31:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:31:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:31:11 --> Final output sent to browser
DEBUG - 2025-12-24 04:31:11 --> Total execution time: 0.3404
INFO - 2025-12-24 04:31:21 --> Config Class Initialized
INFO - 2025-12-24 04:31:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:31:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:31:21 --> Utf8 Class Initialized
INFO - 2025-12-24 04:31:21 --> URI Class Initialized
INFO - 2025-12-24 04:31:21 --> Router Class Initialized
INFO - 2025-12-24 04:31:21 --> Output Class Initialized
INFO - 2025-12-24 04:31:21 --> Security Class Initialized
DEBUG - 2025-12-24 04:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:31:21 --> CSRF cookie sent
INFO - 2025-12-24 04:31:21 --> CSRF token verified
INFO - 2025-12-24 04:31:21 --> Input Class Initialized
INFO - 2025-12-24 04:31:21 --> Language Class Initialized
INFO - 2025-12-24 04:31:21 --> Loader Class Initialized
INFO - 2025-12-24 04:31:21 --> Helper loaded: url_helper
INFO - 2025-12-24 04:31:21 --> Helper loaded: form_helper
INFO - 2025-12-24 04:31:21 --> Helper loaded: file_helper
INFO - 2025-12-24 04:31:21 --> Helper loaded: html_helper
INFO - 2025-12-24 04:31:21 --> Helper loaded: security_helper
INFO - 2025-12-24 04:31:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:31:21 --> Database Driver Class Initialized
INFO - 2025-12-24 04:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:31:21 --> Form Validation Class Initialized
INFO - 2025-12-24 04:31:21 --> Controller Class Initialized
INFO - 2025-12-24 04:31:21 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:31:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:31:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:31:21 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:31:21 --> Upload Class Initialized
INFO - 2025-12-24 04:31:22 --> Config Class Initialized
INFO - 2025-12-24 04:31:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:31:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:31:22 --> Utf8 Class Initialized
INFO - 2025-12-24 04:31:22 --> URI Class Initialized
INFO - 2025-12-24 04:31:22 --> Router Class Initialized
INFO - 2025-12-24 04:31:22 --> Output Class Initialized
INFO - 2025-12-24 04:31:22 --> Security Class Initialized
DEBUG - 2025-12-24 04:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:31:22 --> CSRF cookie sent
INFO - 2025-12-24 04:31:22 --> Input Class Initialized
INFO - 2025-12-24 04:31:22 --> Language Class Initialized
INFO - 2025-12-24 04:31:22 --> Loader Class Initialized
INFO - 2025-12-24 04:31:22 --> Helper loaded: url_helper
INFO - 2025-12-24 04:31:22 --> Helper loaded: form_helper
INFO - 2025-12-24 04:31:22 --> Helper loaded: file_helper
INFO - 2025-12-24 04:31:22 --> Helper loaded: html_helper
INFO - 2025-12-24 04:31:22 --> Helper loaded: security_helper
INFO - 2025-12-24 04:31:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:31:22 --> Database Driver Class Initialized
INFO - 2025-12-24 04:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:31:22 --> Form Validation Class Initialized
INFO - 2025-12-24 04:31:22 --> Controller Class Initialized
INFO - 2025-12-24 04:31:22 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:31:22 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:31:22 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:31:22 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:31:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:31:22 --> Upload Class Initialized
INFO - 2025-12-24 04:31:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:31:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:31:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:31:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:31:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:31:22 --> Final output sent to browser
DEBUG - 2025-12-24 04:31:22 --> Total execution time: 0.0779
INFO - 2025-12-24 04:32:20 --> Config Class Initialized
INFO - 2025-12-24 04:32:20 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:32:20 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:32:20 --> Utf8 Class Initialized
INFO - 2025-12-24 04:32:20 --> URI Class Initialized
INFO - 2025-12-24 04:32:20 --> Router Class Initialized
INFO - 2025-12-24 04:32:20 --> Output Class Initialized
INFO - 2025-12-24 04:32:20 --> Security Class Initialized
DEBUG - 2025-12-24 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:32:20 --> CSRF cookie sent
INFO - 2025-12-24 04:32:20 --> CSRF token verified
INFO - 2025-12-24 04:32:20 --> Input Class Initialized
INFO - 2025-12-24 04:32:20 --> Language Class Initialized
INFO - 2025-12-24 04:32:20 --> Loader Class Initialized
INFO - 2025-12-24 04:32:20 --> Helper loaded: url_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: form_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: file_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: html_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: security_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:32:20 --> Database Driver Class Initialized
INFO - 2025-12-24 04:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:32:20 --> Form Validation Class Initialized
INFO - 2025-12-24 04:32:20 --> Controller Class Initialized
INFO - 2025-12-24 04:32:20 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:32:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:32:20 --> Upload Class Initialized
INFO - 2025-12-24 04:32:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 04:32:20 --> Config Class Initialized
INFO - 2025-12-24 04:32:20 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:32:20 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:32:20 --> Utf8 Class Initialized
INFO - 2025-12-24 04:32:20 --> URI Class Initialized
INFO - 2025-12-24 04:32:20 --> Router Class Initialized
INFO - 2025-12-24 04:32:20 --> Output Class Initialized
INFO - 2025-12-24 04:32:20 --> Security Class Initialized
DEBUG - 2025-12-24 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:32:20 --> CSRF cookie sent
INFO - 2025-12-24 04:32:20 --> Input Class Initialized
INFO - 2025-12-24 04:32:20 --> Language Class Initialized
INFO - 2025-12-24 04:32:20 --> Loader Class Initialized
INFO - 2025-12-24 04:32:20 --> Helper loaded: url_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: form_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: file_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: html_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: security_helper
INFO - 2025-12-24 04:32:20 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:32:20 --> Database Driver Class Initialized
INFO - 2025-12-24 04:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:32:20 --> Form Validation Class Initialized
INFO - 2025-12-24 04:32:20 --> Controller Class Initialized
INFO - 2025-12-24 04:32:20 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:32:20 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:32:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:32:20 --> Upload Class Initialized
INFO - 2025-12-24 04:32:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:32:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:32:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:32:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:32:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:32:20 --> Final output sent to browser
DEBUG - 2025-12-24 04:32:20 --> Total execution time: 0.1692
INFO - 2025-12-24 04:32:25 --> Config Class Initialized
INFO - 2025-12-24 04:32:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:32:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:32:25 --> Utf8 Class Initialized
INFO - 2025-12-24 04:32:25 --> URI Class Initialized
INFO - 2025-12-24 04:32:25 --> Router Class Initialized
INFO - 2025-12-24 04:32:25 --> Output Class Initialized
INFO - 2025-12-24 04:32:25 --> Security Class Initialized
DEBUG - 2025-12-24 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:32:25 --> CSRF cookie sent
INFO - 2025-12-24 04:32:25 --> Input Class Initialized
INFO - 2025-12-24 04:32:25 --> Language Class Initialized
INFO - 2025-12-24 04:32:25 --> Loader Class Initialized
INFO - 2025-12-24 04:32:25 --> Helper loaded: url_helper
INFO - 2025-12-24 04:32:25 --> Helper loaded: form_helper
INFO - 2025-12-24 04:32:25 --> Helper loaded: file_helper
INFO - 2025-12-24 04:32:25 --> Helper loaded: html_helper
INFO - 2025-12-24 04:32:25 --> Helper loaded: security_helper
INFO - 2025-12-24 04:32:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:32:25 --> Database Driver Class Initialized
INFO - 2025-12-24 04:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:32:25 --> Form Validation Class Initialized
INFO - 2025-12-24 04:32:25 --> Controller Class Initialized
INFO - 2025-12-24 04:32:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:32:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:32:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:32:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:32:25 --> Upload Class Initialized
INFO - 2025-12-24 04:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:32:25 --> Final output sent to browser
DEBUG - 2025-12-24 04:32:25 --> Total execution time: 0.0539
INFO - 2025-12-24 04:32:27 --> Config Class Initialized
INFO - 2025-12-24 04:32:27 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:32:27 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:32:27 --> Utf8 Class Initialized
INFO - 2025-12-24 04:32:27 --> URI Class Initialized
INFO - 2025-12-24 04:32:27 --> Router Class Initialized
INFO - 2025-12-24 04:32:27 --> Output Class Initialized
INFO - 2025-12-24 04:32:27 --> Security Class Initialized
DEBUG - 2025-12-24 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:32:27 --> CSRF cookie sent
INFO - 2025-12-24 04:32:27 --> Input Class Initialized
INFO - 2025-12-24 04:32:27 --> Language Class Initialized
INFO - 2025-12-24 04:32:27 --> Loader Class Initialized
INFO - 2025-12-24 04:32:27 --> Helper loaded: url_helper
INFO - 2025-12-24 04:32:27 --> Helper loaded: form_helper
INFO - 2025-12-24 04:32:27 --> Helper loaded: file_helper
INFO - 2025-12-24 04:32:27 --> Helper loaded: html_helper
INFO - 2025-12-24 04:32:27 --> Helper loaded: security_helper
INFO - 2025-12-24 04:32:27 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:32:27 --> Database Driver Class Initialized
INFO - 2025-12-24 04:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:32:27 --> Form Validation Class Initialized
INFO - 2025-12-24 04:32:27 --> Controller Class Initialized
INFO - 2025-12-24 04:32:27 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:32:27 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:32:27 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:32:27 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:32:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:32:27 --> Upload Class Initialized
INFO - 2025-12-24 04:32:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:32:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:32:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:32:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:32:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:32:27 --> Final output sent to browser
DEBUG - 2025-12-24 04:32:27 --> Total execution time: 0.0537
INFO - 2025-12-24 04:32:33 --> Config Class Initialized
INFO - 2025-12-24 04:32:33 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:32:33 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:32:33 --> Utf8 Class Initialized
INFO - 2025-12-24 04:32:33 --> URI Class Initialized
INFO - 2025-12-24 04:32:33 --> Router Class Initialized
INFO - 2025-12-24 04:32:33 --> Output Class Initialized
INFO - 2025-12-24 04:32:33 --> Security Class Initialized
DEBUG - 2025-12-24 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:32:33 --> CSRF cookie sent
INFO - 2025-12-24 04:32:33 --> Input Class Initialized
INFO - 2025-12-24 04:32:33 --> Language Class Initialized
INFO - 2025-12-24 04:32:33 --> Loader Class Initialized
INFO - 2025-12-24 04:32:33 --> Helper loaded: url_helper
INFO - 2025-12-24 04:32:33 --> Helper loaded: form_helper
INFO - 2025-12-24 04:32:33 --> Helper loaded: file_helper
INFO - 2025-12-24 04:32:33 --> Helper loaded: html_helper
INFO - 2025-12-24 04:32:33 --> Helper loaded: security_helper
INFO - 2025-12-24 04:32:33 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:32:33 --> Database Driver Class Initialized
INFO - 2025-12-24 04:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:32:33 --> Form Validation Class Initialized
INFO - 2025-12-24 04:32:33 --> Controller Class Initialized
INFO - 2025-12-24 04:32:33 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:32:33 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:32:33 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:32:33 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:32:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:32:33 --> Upload Class Initialized
INFO - 2025-12-24 04:32:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:32:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:32:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:32:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:32:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:32:33 --> Final output sent to browser
DEBUG - 2025-12-24 04:32:33 --> Total execution time: 0.0536
INFO - 2025-12-24 04:33:02 --> Config Class Initialized
INFO - 2025-12-24 04:33:02 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:33:02 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:33:02 --> Utf8 Class Initialized
INFO - 2025-12-24 04:33:02 --> URI Class Initialized
INFO - 2025-12-24 04:33:02 --> Router Class Initialized
INFO - 2025-12-24 04:33:02 --> Output Class Initialized
INFO - 2025-12-24 04:33:02 --> Security Class Initialized
DEBUG - 2025-12-24 04:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:33:02 --> CSRF cookie sent
INFO - 2025-12-24 04:33:02 --> Input Class Initialized
INFO - 2025-12-24 04:33:02 --> Language Class Initialized
INFO - 2025-12-24 04:33:02 --> Loader Class Initialized
INFO - 2025-12-24 04:33:02 --> Helper loaded: url_helper
INFO - 2025-12-24 04:33:02 --> Helper loaded: form_helper
INFO - 2025-12-24 04:33:02 --> Helper loaded: file_helper
INFO - 2025-12-24 04:33:02 --> Helper loaded: html_helper
INFO - 2025-12-24 04:33:02 --> Helper loaded: security_helper
INFO - 2025-12-24 04:33:02 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:33:02 --> Database Driver Class Initialized
INFO - 2025-12-24 04:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:33:02 --> Form Validation Class Initialized
INFO - 2025-12-24 04:33:02 --> Controller Class Initialized
INFO - 2025-12-24 04:33:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:33:02 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:33:02 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:33:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:33:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:33:02 --> Upload Class Initialized
INFO - 2025-12-24 04:33:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:33:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:33:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:33:02 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:33:21 --> Config Class Initialized
INFO - 2025-12-24 04:33:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:33:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:33:21 --> Utf8 Class Initialized
INFO - 2025-12-24 04:33:21 --> URI Class Initialized
INFO - 2025-12-24 04:33:21 --> Router Class Initialized
INFO - 2025-12-24 04:33:21 --> Output Class Initialized
INFO - 2025-12-24 04:33:21 --> Security Class Initialized
DEBUG - 2025-12-24 04:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:33:21 --> CSRF cookie sent
INFO - 2025-12-24 04:33:21 --> Input Class Initialized
INFO - 2025-12-24 04:33:21 --> Language Class Initialized
INFO - 2025-12-24 04:33:21 --> Loader Class Initialized
INFO - 2025-12-24 04:33:21 --> Helper loaded: url_helper
INFO - 2025-12-24 04:33:21 --> Helper loaded: form_helper
INFO - 2025-12-24 04:33:21 --> Helper loaded: file_helper
INFO - 2025-12-24 04:33:21 --> Helper loaded: html_helper
INFO - 2025-12-24 04:33:21 --> Helper loaded: security_helper
INFO - 2025-12-24 04:33:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:33:21 --> Database Driver Class Initialized
INFO - 2025-12-24 04:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:33:21 --> Form Validation Class Initialized
INFO - 2025-12-24 04:33:21 --> Controller Class Initialized
INFO - 2025-12-24 04:33:21 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:33:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:33:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:33:21 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:33:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:33:21 --> Upload Class Initialized
INFO - 2025-12-24 04:33:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:33:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:33:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:33:22 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:33:23 --> Config Class Initialized
INFO - 2025-12-24 04:33:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:33:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:33:23 --> Utf8 Class Initialized
INFO - 2025-12-24 04:33:23 --> URI Class Initialized
INFO - 2025-12-24 04:33:23 --> Router Class Initialized
INFO - 2025-12-24 04:33:23 --> Output Class Initialized
INFO - 2025-12-24 04:33:23 --> Security Class Initialized
DEBUG - 2025-12-24 04:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:33:23 --> CSRF cookie sent
INFO - 2025-12-24 04:33:23 --> Input Class Initialized
INFO - 2025-12-24 04:33:23 --> Language Class Initialized
INFO - 2025-12-24 04:33:23 --> Loader Class Initialized
INFO - 2025-12-24 04:33:23 --> Helper loaded: url_helper
INFO - 2025-12-24 04:33:23 --> Helper loaded: form_helper
INFO - 2025-12-24 04:33:23 --> Helper loaded: file_helper
INFO - 2025-12-24 04:33:23 --> Helper loaded: html_helper
INFO - 2025-12-24 04:33:23 --> Helper loaded: security_helper
INFO - 2025-12-24 04:33:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:33:23 --> Database Driver Class Initialized
INFO - 2025-12-24 04:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:33:23 --> Form Validation Class Initialized
INFO - 2025-12-24 04:33:23 --> Controller Class Initialized
INFO - 2025-12-24 04:33:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:33:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:33:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:33:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:33:23 --> Upload Class Initialized
INFO - 2025-12-24 04:33:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:33:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:33:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:33:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:33:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:33:23 --> Final output sent to browser
DEBUG - 2025-12-24 04:33:23 --> Total execution time: 0.0794
INFO - 2025-12-24 04:33:30 --> Config Class Initialized
INFO - 2025-12-24 04:33:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:33:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:33:30 --> Utf8 Class Initialized
INFO - 2025-12-24 04:33:30 --> URI Class Initialized
INFO - 2025-12-24 04:33:30 --> Router Class Initialized
INFO - 2025-12-24 04:33:30 --> Output Class Initialized
INFO - 2025-12-24 04:33:30 --> Security Class Initialized
DEBUG - 2025-12-24 04:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:33:30 --> CSRF cookie sent
INFO - 2025-12-24 04:33:30 --> Input Class Initialized
INFO - 2025-12-24 04:33:30 --> Language Class Initialized
INFO - 2025-12-24 04:33:30 --> Loader Class Initialized
INFO - 2025-12-24 04:33:30 --> Helper loaded: url_helper
INFO - 2025-12-24 04:33:30 --> Helper loaded: form_helper
INFO - 2025-12-24 04:33:30 --> Helper loaded: file_helper
INFO - 2025-12-24 04:33:30 --> Helper loaded: html_helper
INFO - 2025-12-24 04:33:30 --> Helper loaded: security_helper
INFO - 2025-12-24 04:33:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:33:30 --> Database Driver Class Initialized
INFO - 2025-12-24 04:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:33:30 --> Form Validation Class Initialized
INFO - 2025-12-24 04:33:30 --> Controller Class Initialized
INFO - 2025-12-24 04:33:30 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:33:30 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:33:30 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:33:30 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:33:30 --> Upload Class Initialized
INFO - 2025-12-24 04:33:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:33:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:33:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:33:30 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:43 --> Config Class Initialized
INFO - 2025-12-24 04:38:43 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:43 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:43 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:43 --> URI Class Initialized
INFO - 2025-12-24 04:38:43 --> Router Class Initialized
INFO - 2025-12-24 04:38:43 --> Output Class Initialized
INFO - 2025-12-24 04:38:43 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:43 --> CSRF cookie sent
INFO - 2025-12-24 04:38:43 --> Input Class Initialized
INFO - 2025-12-24 04:38:43 --> Language Class Initialized
INFO - 2025-12-24 04:38:43 --> Loader Class Initialized
INFO - 2025-12-24 04:38:43 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:43 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:43 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:43 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:43 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:43 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:43 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:43 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:43 --> Controller Class Initialized
INFO - 2025-12-24 04:38:43 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:43 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:43 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:43 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:43 --> Upload Class Initialized
INFO - 2025-12-24 04:38:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:43 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:45 --> Config Class Initialized
INFO - 2025-12-24 04:38:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:45 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:45 --> URI Class Initialized
INFO - 2025-12-24 04:38:45 --> Router Class Initialized
INFO - 2025-12-24 04:38:45 --> Output Class Initialized
INFO - 2025-12-24 04:38:45 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:45 --> CSRF cookie sent
INFO - 2025-12-24 04:38:45 --> Input Class Initialized
INFO - 2025-12-24 04:38:45 --> Language Class Initialized
INFO - 2025-12-24 04:38:45 --> Loader Class Initialized
INFO - 2025-12-24 04:38:45 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:45 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:45 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:45 --> Controller Class Initialized
INFO - 2025-12-24 04:38:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:45 --> Upload Class Initialized
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:45 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:45 --> Config Class Initialized
INFO - 2025-12-24 04:38:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:45 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:45 --> URI Class Initialized
INFO - 2025-12-24 04:38:45 --> Router Class Initialized
INFO - 2025-12-24 04:38:45 --> Output Class Initialized
INFO - 2025-12-24 04:38:45 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:45 --> CSRF cookie sent
INFO - 2025-12-24 04:38:45 --> Input Class Initialized
INFO - 2025-12-24 04:38:45 --> Language Class Initialized
INFO - 2025-12-24 04:38:45 --> Loader Class Initialized
INFO - 2025-12-24 04:38:45 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:45 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:45 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:45 --> Controller Class Initialized
INFO - 2025-12-24 04:38:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:45 --> Upload Class Initialized
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:45 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:45 --> Config Class Initialized
INFO - 2025-12-24 04:38:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:45 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:45 --> URI Class Initialized
INFO - 2025-12-24 04:38:45 --> Router Class Initialized
INFO - 2025-12-24 04:38:45 --> Output Class Initialized
INFO - 2025-12-24 04:38:45 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:45 --> CSRF cookie sent
INFO - 2025-12-24 04:38:45 --> Input Class Initialized
INFO - 2025-12-24 04:38:45 --> Language Class Initialized
INFO - 2025-12-24 04:38:45 --> Loader Class Initialized
INFO - 2025-12-24 04:38:45 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:45 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:45 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:45 --> Controller Class Initialized
INFO - 2025-12-24 04:38:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:45 --> Upload Class Initialized
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:45 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:45 --> Config Class Initialized
INFO - 2025-12-24 04:38:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:45 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:45 --> URI Class Initialized
INFO - 2025-12-24 04:38:45 --> Router Class Initialized
INFO - 2025-12-24 04:38:45 --> Output Class Initialized
INFO - 2025-12-24 04:38:45 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:45 --> CSRF cookie sent
INFO - 2025-12-24 04:38:45 --> Input Class Initialized
INFO - 2025-12-24 04:38:45 --> Language Class Initialized
INFO - 2025-12-24 04:38:45 --> Loader Class Initialized
INFO - 2025-12-24 04:38:45 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:45 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:45 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:45 --> Controller Class Initialized
INFO - 2025-12-24 04:38:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:45 --> Upload Class Initialized
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:45 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:46 --> Config Class Initialized
INFO - 2025-12-24 04:38:46 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:46 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:46 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:46 --> URI Class Initialized
INFO - 2025-12-24 04:38:46 --> Router Class Initialized
INFO - 2025-12-24 04:38:46 --> Output Class Initialized
INFO - 2025-12-24 04:38:46 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:46 --> CSRF cookie sent
INFO - 2025-12-24 04:38:46 --> Input Class Initialized
INFO - 2025-12-24 04:38:46 --> Language Class Initialized
INFO - 2025-12-24 04:38:46 --> Loader Class Initialized
INFO - 2025-12-24 04:38:46 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:46 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:46 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:46 --> Controller Class Initialized
INFO - 2025-12-24 04:38:46 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:46 --> Upload Class Initialized
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:46 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:46 --> Config Class Initialized
INFO - 2025-12-24 04:38:46 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:46 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:46 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:46 --> URI Class Initialized
INFO - 2025-12-24 04:38:46 --> Router Class Initialized
INFO - 2025-12-24 04:38:46 --> Output Class Initialized
INFO - 2025-12-24 04:38:46 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:46 --> CSRF cookie sent
INFO - 2025-12-24 04:38:46 --> Input Class Initialized
INFO - 2025-12-24 04:38:46 --> Language Class Initialized
INFO - 2025-12-24 04:38:46 --> Loader Class Initialized
INFO - 2025-12-24 04:38:46 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:46 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:46 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:46 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:46 --> Controller Class Initialized
INFO - 2025-12-24 04:38:46 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:46 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:46 --> Upload Class Initialized
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:46 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:47 --> Config Class Initialized
INFO - 2025-12-24 04:38:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:47 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:47 --> URI Class Initialized
INFO - 2025-12-24 04:38:47 --> Router Class Initialized
INFO - 2025-12-24 04:38:47 --> Output Class Initialized
INFO - 2025-12-24 04:38:47 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:47 --> CSRF cookie sent
INFO - 2025-12-24 04:38:47 --> Input Class Initialized
INFO - 2025-12-24 04:38:47 --> Language Class Initialized
INFO - 2025-12-24 04:38:47 --> Loader Class Initialized
INFO - 2025-12-24 04:38:47 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:47 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:47 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:47 --> Controller Class Initialized
INFO - 2025-12-24 04:38:47 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:47 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:47 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:47 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:47 --> Upload Class Initialized
INFO - 2025-12-24 04:38:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:47 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:47 --> Config Class Initialized
INFO - 2025-12-24 04:38:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:47 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:47 --> URI Class Initialized
INFO - 2025-12-24 04:38:47 --> Router Class Initialized
INFO - 2025-12-24 04:38:47 --> Output Class Initialized
INFO - 2025-12-24 04:38:47 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:47 --> CSRF cookie sent
INFO - 2025-12-24 04:38:47 --> Input Class Initialized
INFO - 2025-12-24 04:38:47 --> Language Class Initialized
INFO - 2025-12-24 04:38:47 --> Loader Class Initialized
INFO - 2025-12-24 04:38:47 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:48 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:48 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:48 --> Controller Class Initialized
INFO - 2025-12-24 04:38:48 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:48 --> Upload Class Initialized
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:48 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:48 --> Config Class Initialized
INFO - 2025-12-24 04:38:48 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:48 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:48 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:48 --> URI Class Initialized
INFO - 2025-12-24 04:38:48 --> Router Class Initialized
INFO - 2025-12-24 04:38:48 --> Output Class Initialized
INFO - 2025-12-24 04:38:48 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:48 --> CSRF cookie sent
INFO - 2025-12-24 04:38:48 --> Input Class Initialized
INFO - 2025-12-24 04:38:48 --> Language Class Initialized
INFO - 2025-12-24 04:38:48 --> Loader Class Initialized
INFO - 2025-12-24 04:38:48 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:48 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:48 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:48 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:48 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:48 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:48 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:48 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:48 --> Controller Class Initialized
INFO - 2025-12-24 04:38:48 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:48 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:48 --> Upload Class Initialized
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:48 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:38:52 --> Config Class Initialized
INFO - 2025-12-24 04:38:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:52 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:52 --> URI Class Initialized
DEBUG - 2025-12-24 04:38:52 --> No URI present. Default controller set.
INFO - 2025-12-24 04:38:52 --> Router Class Initialized
INFO - 2025-12-24 04:38:52 --> Output Class Initialized
INFO - 2025-12-24 04:38:52 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:52 --> CSRF cookie sent
INFO - 2025-12-24 04:38:52 --> Input Class Initialized
INFO - 2025-12-24 04:38:52 --> Language Class Initialized
INFO - 2025-12-24 04:38:52 --> Loader Class Initialized
INFO - 2025-12-24 04:38:52 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:52 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:52 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:52 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:52 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:52 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:52 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:52 --> Controller Class Initialized
INFO - 2025-12-24 04:38:52 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:38:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:38:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:38:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:38:52 --> Final output sent to browser
DEBUG - 2025-12-24 04:38:52 --> Total execution time: 0.0540
INFO - 2025-12-24 04:38:55 --> Config Class Initialized
INFO - 2025-12-24 04:38:55 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:38:55 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:38:55 --> Utf8 Class Initialized
INFO - 2025-12-24 04:38:55 --> URI Class Initialized
INFO - 2025-12-24 04:38:55 --> Router Class Initialized
INFO - 2025-12-24 04:38:55 --> Output Class Initialized
INFO - 2025-12-24 04:38:55 --> Security Class Initialized
DEBUG - 2025-12-24 04:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:38:55 --> CSRF cookie sent
INFO - 2025-12-24 04:38:55 --> Input Class Initialized
INFO - 2025-12-24 04:38:55 --> Language Class Initialized
INFO - 2025-12-24 04:38:55 --> Loader Class Initialized
INFO - 2025-12-24 04:38:55 --> Helper loaded: url_helper
INFO - 2025-12-24 04:38:55 --> Helper loaded: form_helper
INFO - 2025-12-24 04:38:55 --> Helper loaded: file_helper
INFO - 2025-12-24 04:38:55 --> Helper loaded: html_helper
INFO - 2025-12-24 04:38:55 --> Helper loaded: security_helper
INFO - 2025-12-24 04:38:55 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:38:55 --> Database Driver Class Initialized
INFO - 2025-12-24 04:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:38:55 --> Form Validation Class Initialized
INFO - 2025-12-24 04:38:55 --> Controller Class Initialized
INFO - 2025-12-24 04:38:55 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:38:55 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:38:55 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:38:55 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:38:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:38:55 --> Upload Class Initialized
INFO - 2025-12-24 04:38:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:38:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:38:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:38:55 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:06 --> Config Class Initialized
INFO - 2025-12-24 04:40:06 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:06 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:06 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:06 --> URI Class Initialized
INFO - 2025-12-24 04:40:06 --> Router Class Initialized
INFO - 2025-12-24 04:40:06 --> Output Class Initialized
INFO - 2025-12-24 04:40:06 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:06 --> CSRF cookie sent
INFO - 2025-12-24 04:40:06 --> Input Class Initialized
INFO - 2025-12-24 04:40:06 --> Language Class Initialized
INFO - 2025-12-24 04:40:06 --> Loader Class Initialized
INFO - 2025-12-24 04:40:06 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:06 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:06 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:06 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:06 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:06 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:06 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:06 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:06 --> Controller Class Initialized
INFO - 2025-12-24 04:40:06 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:06 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:06 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:06 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:06 --> Upload Class Initialized
INFO - 2025-12-24 04:40:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:06 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:06 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:07 --> Config Class Initialized
INFO - 2025-12-24 04:40:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:07 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:07 --> URI Class Initialized
INFO - 2025-12-24 04:40:07 --> Router Class Initialized
INFO - 2025-12-24 04:40:07 --> Output Class Initialized
INFO - 2025-12-24 04:40:07 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:07 --> CSRF cookie sent
INFO - 2025-12-24 04:40:07 --> Input Class Initialized
INFO - 2025-12-24 04:40:07 --> Language Class Initialized
INFO - 2025-12-24 04:40:07 --> Loader Class Initialized
INFO - 2025-12-24 04:40:07 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:07 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:07 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:07 --> Controller Class Initialized
INFO - 2025-12-24 04:40:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:07 --> Upload Class Initialized
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:07 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:07 --> Config Class Initialized
INFO - 2025-12-24 04:40:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:07 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:07 --> URI Class Initialized
INFO - 2025-12-24 04:40:07 --> Router Class Initialized
INFO - 2025-12-24 04:40:07 --> Output Class Initialized
INFO - 2025-12-24 04:40:07 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:07 --> CSRF cookie sent
INFO - 2025-12-24 04:40:07 --> Input Class Initialized
INFO - 2025-12-24 04:40:07 --> Language Class Initialized
INFO - 2025-12-24 04:40:07 --> Loader Class Initialized
INFO - 2025-12-24 04:40:07 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:07 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:07 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:07 --> Controller Class Initialized
INFO - 2025-12-24 04:40:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:07 --> Upload Class Initialized
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:07 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:07 --> Config Class Initialized
INFO - 2025-12-24 04:40:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:07 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:07 --> URI Class Initialized
INFO - 2025-12-24 04:40:07 --> Router Class Initialized
INFO - 2025-12-24 04:40:07 --> Output Class Initialized
INFO - 2025-12-24 04:40:07 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:07 --> CSRF cookie sent
INFO - 2025-12-24 04:40:07 --> Input Class Initialized
INFO - 2025-12-24 04:40:07 --> Language Class Initialized
INFO - 2025-12-24 04:40:07 --> Loader Class Initialized
INFO - 2025-12-24 04:40:07 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:07 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:07 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:07 --> Controller Class Initialized
INFO - 2025-12-24 04:40:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:07 --> Upload Class Initialized
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:07 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:08 --> Config Class Initialized
INFO - 2025-12-24 04:40:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:08 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:08 --> URI Class Initialized
INFO - 2025-12-24 04:40:08 --> Router Class Initialized
INFO - 2025-12-24 04:40:08 --> Output Class Initialized
INFO - 2025-12-24 04:40:08 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:08 --> CSRF cookie sent
INFO - 2025-12-24 04:40:08 --> Input Class Initialized
INFO - 2025-12-24 04:40:08 --> Language Class Initialized
INFO - 2025-12-24 04:40:08 --> Loader Class Initialized
INFO - 2025-12-24 04:40:08 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:08 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:08 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:08 --> Controller Class Initialized
INFO - 2025-12-24 04:40:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:08 --> Upload Class Initialized
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:08 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:08 --> Config Class Initialized
INFO - 2025-12-24 04:40:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:08 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:08 --> URI Class Initialized
INFO - 2025-12-24 04:40:08 --> Router Class Initialized
INFO - 2025-12-24 04:40:08 --> Output Class Initialized
INFO - 2025-12-24 04:40:08 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:08 --> CSRF cookie sent
INFO - 2025-12-24 04:40:08 --> Input Class Initialized
INFO - 2025-12-24 04:40:08 --> Language Class Initialized
INFO - 2025-12-24 04:40:08 --> Loader Class Initialized
INFO - 2025-12-24 04:40:08 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:08 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:08 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:08 --> Controller Class Initialized
INFO - 2025-12-24 04:40:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:08 --> Upload Class Initialized
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:08 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:08 --> Config Class Initialized
INFO - 2025-12-24 04:40:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:08 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:08 --> URI Class Initialized
INFO - 2025-12-24 04:40:08 --> Router Class Initialized
INFO - 2025-12-24 04:40:08 --> Output Class Initialized
INFO - 2025-12-24 04:40:08 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:08 --> CSRF cookie sent
INFO - 2025-12-24 04:40:08 --> Input Class Initialized
INFO - 2025-12-24 04:40:08 --> Language Class Initialized
INFO - 2025-12-24 04:40:08 --> Loader Class Initialized
INFO - 2025-12-24 04:40:08 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:08 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:08 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:08 --> Controller Class Initialized
INFO - 2025-12-24 04:40:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:08 --> Upload Class Initialized
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:08 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:10 --> Config Class Initialized
INFO - 2025-12-24 04:40:10 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:10 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:10 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:10 --> URI Class Initialized
DEBUG - 2025-12-24 04:40:10 --> No URI present. Default controller set.
INFO - 2025-12-24 04:40:10 --> Router Class Initialized
INFO - 2025-12-24 04:40:10 --> Output Class Initialized
INFO - 2025-12-24 04:40:10 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:10 --> CSRF cookie sent
INFO - 2025-12-24 04:40:10 --> Input Class Initialized
INFO - 2025-12-24 04:40:10 --> Language Class Initialized
INFO - 2025-12-24 04:40:10 --> Loader Class Initialized
INFO - 2025-12-24 04:40:10 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:10 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:10 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:10 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:10 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:10 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:10 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:10 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:10 --> Controller Class Initialized
INFO - 2025-12-24 04:40:10 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:40:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:40:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:40:10 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:40:10 --> Final output sent to browser
DEBUG - 2025-12-24 04:40:10 --> Total execution time: 0.0531
INFO - 2025-12-24 04:40:12 --> Config Class Initialized
INFO - 2025-12-24 04:40:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:12 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:12 --> URI Class Initialized
DEBUG - 2025-12-24 04:40:12 --> No URI present. Default controller set.
INFO - 2025-12-24 04:40:12 --> Router Class Initialized
INFO - 2025-12-24 04:40:12 --> Output Class Initialized
INFO - 2025-12-24 04:40:12 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:12 --> CSRF cookie sent
INFO - 2025-12-24 04:40:12 --> Input Class Initialized
INFO - 2025-12-24 04:40:12 --> Language Class Initialized
INFO - 2025-12-24 04:40:12 --> Loader Class Initialized
INFO - 2025-12-24 04:40:12 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:12 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:12 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:12 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:12 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:12 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:13 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:13 --> Controller Class Initialized
INFO - 2025-12-24 04:40:13 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:40:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:40:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:40:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:40:13 --> Final output sent to browser
DEBUG - 2025-12-24 04:40:13 --> Total execution time: 0.0570
INFO - 2025-12-24 04:40:16 --> Config Class Initialized
INFO - 2025-12-24 04:40:16 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:16 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:16 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:16 --> URI Class Initialized
INFO - 2025-12-24 04:40:16 --> Router Class Initialized
INFO - 2025-12-24 04:40:16 --> Output Class Initialized
INFO - 2025-12-24 04:40:16 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:16 --> CSRF cookie sent
INFO - 2025-12-24 04:40:16 --> Input Class Initialized
INFO - 2025-12-24 04:40:16 --> Language Class Initialized
INFO - 2025-12-24 04:40:16 --> Loader Class Initialized
INFO - 2025-12-24 04:40:16 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:16 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:16 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:16 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:16 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:16 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:16 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:16 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:16 --> Controller Class Initialized
INFO - 2025-12-24 04:40:16 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 04:40:16 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 04:40:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:40:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-24 04:40:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:40:16 --> Final output sent to browser
DEBUG - 2025-12-24 04:40:16 --> Total execution time: 0.1611
INFO - 2025-12-24 04:40:20 --> Config Class Initialized
INFO - 2025-12-24 04:40:20 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:20 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:20 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:20 --> URI Class Initialized
INFO - 2025-12-24 04:40:20 --> Router Class Initialized
INFO - 2025-12-24 04:40:20 --> Output Class Initialized
INFO - 2025-12-24 04:40:20 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:20 --> CSRF cookie sent
INFO - 2025-12-24 04:40:20 --> Input Class Initialized
INFO - 2025-12-24 04:40:20 --> Language Class Initialized
INFO - 2025-12-24 04:40:20 --> Loader Class Initialized
INFO - 2025-12-24 04:40:20 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:20 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:20 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:20 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:20 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:20 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:20 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:20 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:20 --> Controller Class Initialized
INFO - 2025-12-24 04:40:20 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:20 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:20 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:20 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:20 --> Upload Class Initialized
INFO - 2025-12-24 04:40:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:20 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:40:20 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:40:29 --> Config Class Initialized
INFO - 2025-12-24 04:40:29 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:40:29 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:40:29 --> Utf8 Class Initialized
INFO - 2025-12-24 04:40:29 --> URI Class Initialized
INFO - 2025-12-24 04:40:29 --> Router Class Initialized
INFO - 2025-12-24 04:40:29 --> Output Class Initialized
INFO - 2025-12-24 04:40:29 --> Security Class Initialized
DEBUG - 2025-12-24 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:40:29 --> CSRF cookie sent
INFO - 2025-12-24 04:40:29 --> Input Class Initialized
INFO - 2025-12-24 04:40:29 --> Language Class Initialized
INFO - 2025-12-24 04:40:29 --> Loader Class Initialized
INFO - 2025-12-24 04:40:29 --> Helper loaded: url_helper
INFO - 2025-12-24 04:40:29 --> Helper loaded: form_helper
INFO - 2025-12-24 04:40:29 --> Helper loaded: file_helper
INFO - 2025-12-24 04:40:29 --> Helper loaded: html_helper
INFO - 2025-12-24 04:40:29 --> Helper loaded: security_helper
INFO - 2025-12-24 04:40:29 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:40:29 --> Database Driver Class Initialized
INFO - 2025-12-24 04:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:40:29 --> Form Validation Class Initialized
INFO - 2025-12-24 04:40:29 --> Controller Class Initialized
INFO - 2025-12-24 04:40:29 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:40:29 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:40:29 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:40:29 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:40:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:40:29 --> Upload Class Initialized
INFO - 2025-12-24 04:40:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:40:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:40:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:40:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:40:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:40:29 --> Final output sent to browser
DEBUG - 2025-12-24 04:40:29 --> Total execution time: 0.0580
INFO - 2025-12-24 04:41:18 --> Config Class Initialized
INFO - 2025-12-24 04:41:18 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:41:18 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:41:18 --> Utf8 Class Initialized
INFO - 2025-12-24 04:41:18 --> URI Class Initialized
INFO - 2025-12-24 04:41:18 --> Router Class Initialized
INFO - 2025-12-24 04:41:18 --> Output Class Initialized
INFO - 2025-12-24 04:41:18 --> Security Class Initialized
DEBUG - 2025-12-24 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:41:18 --> CSRF cookie sent
INFO - 2025-12-24 04:41:18 --> Input Class Initialized
INFO - 2025-12-24 04:41:18 --> Language Class Initialized
INFO - 2025-12-24 04:41:18 --> Loader Class Initialized
INFO - 2025-12-24 04:41:18 --> Helper loaded: url_helper
INFO - 2025-12-24 04:41:18 --> Helper loaded: form_helper
INFO - 2025-12-24 04:41:18 --> Helper loaded: file_helper
INFO - 2025-12-24 04:41:18 --> Helper loaded: html_helper
INFO - 2025-12-24 04:41:18 --> Helper loaded: security_helper
INFO - 2025-12-24 04:41:18 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:41:18 --> Database Driver Class Initialized
INFO - 2025-12-24 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:41:18 --> Form Validation Class Initialized
INFO - 2025-12-24 04:41:18 --> Controller Class Initialized
INFO - 2025-12-24 04:41:18 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:41:18 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:41:18 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:41:18 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:41:18 --> Upload Class Initialized
INFO - 2025-12-24 04:41:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:41:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:41:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:41:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:41:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:41:18 --> Final output sent to browser
DEBUG - 2025-12-24 04:41:18 --> Total execution time: 0.0527
INFO - 2025-12-24 04:41:19 --> Config Class Initialized
INFO - 2025-12-24 04:41:19 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:41:19 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:41:19 --> Utf8 Class Initialized
INFO - 2025-12-24 04:41:19 --> URI Class Initialized
INFO - 2025-12-24 04:41:19 --> Router Class Initialized
INFO - 2025-12-24 04:41:19 --> Output Class Initialized
INFO - 2025-12-24 04:41:19 --> Security Class Initialized
DEBUG - 2025-12-24 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:41:19 --> CSRF cookie sent
INFO - 2025-12-24 04:41:19 --> Input Class Initialized
INFO - 2025-12-24 04:41:19 --> Language Class Initialized
INFO - 2025-12-24 04:41:19 --> Loader Class Initialized
INFO - 2025-12-24 04:41:19 --> Helper loaded: url_helper
INFO - 2025-12-24 04:41:19 --> Helper loaded: form_helper
INFO - 2025-12-24 04:41:19 --> Helper loaded: file_helper
INFO - 2025-12-24 04:41:19 --> Helper loaded: html_helper
INFO - 2025-12-24 04:41:19 --> Helper loaded: security_helper
INFO - 2025-12-24 04:41:19 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:41:19 --> Database Driver Class Initialized
INFO - 2025-12-24 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:41:19 --> Form Validation Class Initialized
INFO - 2025-12-24 04:41:19 --> Controller Class Initialized
INFO - 2025-12-24 04:41:19 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:41:19 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:41:19 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:41:19 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:41:19 --> Upload Class Initialized
INFO - 2025-12-24 04:41:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:41:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:41:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:41:19 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 169
INFO - 2025-12-24 04:42:11 --> Config Class Initialized
INFO - 2025-12-24 04:42:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:42:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:42:11 --> Utf8 Class Initialized
INFO - 2025-12-24 04:42:11 --> URI Class Initialized
INFO - 2025-12-24 04:42:11 --> Router Class Initialized
INFO - 2025-12-24 04:42:11 --> Output Class Initialized
INFO - 2025-12-24 04:42:11 --> Security Class Initialized
DEBUG - 2025-12-24 04:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:42:11 --> CSRF cookie sent
INFO - 2025-12-24 04:42:11 --> Input Class Initialized
INFO - 2025-12-24 04:42:11 --> Language Class Initialized
INFO - 2025-12-24 04:42:11 --> Loader Class Initialized
INFO - 2025-12-24 04:42:11 --> Helper loaded: url_helper
INFO - 2025-12-24 04:42:11 --> Helper loaded: form_helper
INFO - 2025-12-24 04:42:11 --> Helper loaded: file_helper
INFO - 2025-12-24 04:42:11 --> Helper loaded: html_helper
INFO - 2025-12-24 04:42:11 --> Helper loaded: security_helper
INFO - 2025-12-24 04:42:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:42:11 --> Database Driver Class Initialized
INFO - 2025-12-24 04:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:42:11 --> Form Validation Class Initialized
INFO - 2025-12-24 04:42:11 --> Controller Class Initialized
INFO - 2025-12-24 04:42:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:42:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:42:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:42:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:42:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:42:11 --> Upload Class Initialized
INFO - 2025-12-24 04:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:42:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:42:12 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 189
INFO - 2025-12-24 04:43:55 --> Config Class Initialized
INFO - 2025-12-24 04:43:55 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:55 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:55 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:55 --> URI Class Initialized
INFO - 2025-12-24 04:43:55 --> Router Class Initialized
INFO - 2025-12-24 04:43:55 --> Output Class Initialized
INFO - 2025-12-24 04:43:55 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:55 --> CSRF cookie sent
INFO - 2025-12-24 04:43:55 --> Input Class Initialized
INFO - 2025-12-24 04:43:55 --> Language Class Initialized
INFO - 2025-12-24 04:43:55 --> Loader Class Initialized
INFO - 2025-12-24 04:43:55 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:55 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:55 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:55 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:55 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:55 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:55 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:55 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:55 --> Controller Class Initialized
INFO - 2025-12-24 04:43:55 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:55 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:55 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:55 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:55 --> Upload Class Initialized
INFO - 2025-12-24 04:43:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:55 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:43:56 --> Config Class Initialized
INFO - 2025-12-24 04:43:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:56 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:56 --> URI Class Initialized
INFO - 2025-12-24 04:43:56 --> Router Class Initialized
INFO - 2025-12-24 04:43:56 --> Output Class Initialized
INFO - 2025-12-24 04:43:56 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:56 --> CSRF cookie sent
INFO - 2025-12-24 04:43:56 --> Input Class Initialized
INFO - 2025-12-24 04:43:56 --> Language Class Initialized
INFO - 2025-12-24 04:43:56 --> Loader Class Initialized
INFO - 2025-12-24 04:43:56 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:56 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:56 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:56 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:56 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:56 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:56 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:56 --> Controller Class Initialized
INFO - 2025-12-24 04:43:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:56 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:56 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:56 --> Upload Class Initialized
INFO - 2025-12-24 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:56 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:43:57 --> Config Class Initialized
INFO - 2025-12-24 04:43:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:57 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:57 --> URI Class Initialized
INFO - 2025-12-24 04:43:57 --> Router Class Initialized
INFO - 2025-12-24 04:43:57 --> Output Class Initialized
INFO - 2025-12-24 04:43:57 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:57 --> CSRF cookie sent
INFO - 2025-12-24 04:43:57 --> Input Class Initialized
INFO - 2025-12-24 04:43:57 --> Language Class Initialized
INFO - 2025-12-24 04:43:57 --> Loader Class Initialized
INFO - 2025-12-24 04:43:57 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:57 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:57 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:57 --> Controller Class Initialized
INFO - 2025-12-24 04:43:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:57 --> Upload Class Initialized
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:57 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:43:57 --> Config Class Initialized
INFO - 2025-12-24 04:43:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:57 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:57 --> URI Class Initialized
INFO - 2025-12-24 04:43:57 --> Router Class Initialized
INFO - 2025-12-24 04:43:57 --> Output Class Initialized
INFO - 2025-12-24 04:43:57 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:57 --> CSRF cookie sent
INFO - 2025-12-24 04:43:57 --> Input Class Initialized
INFO - 2025-12-24 04:43:57 --> Language Class Initialized
INFO - 2025-12-24 04:43:57 --> Loader Class Initialized
INFO - 2025-12-24 04:43:57 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:57 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:57 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:57 --> Controller Class Initialized
INFO - 2025-12-24 04:43:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:57 --> Upload Class Initialized
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:57 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:43:57 --> Config Class Initialized
INFO - 2025-12-24 04:43:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:57 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:57 --> URI Class Initialized
INFO - 2025-12-24 04:43:57 --> Router Class Initialized
INFO - 2025-12-24 04:43:57 --> Output Class Initialized
INFO - 2025-12-24 04:43:57 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:57 --> CSRF cookie sent
INFO - 2025-12-24 04:43:57 --> Input Class Initialized
INFO - 2025-12-24 04:43:57 --> Language Class Initialized
INFO - 2025-12-24 04:43:57 --> Loader Class Initialized
INFO - 2025-12-24 04:43:57 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:57 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:57 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:57 --> Controller Class Initialized
INFO - 2025-12-24 04:43:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:57 --> Upload Class Initialized
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:57 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:43:58 --> Config Class Initialized
INFO - 2025-12-24 04:43:58 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:43:58 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:43:58 --> Utf8 Class Initialized
INFO - 2025-12-24 04:43:58 --> URI Class Initialized
INFO - 2025-12-24 04:43:58 --> Router Class Initialized
INFO - 2025-12-24 04:43:58 --> Output Class Initialized
INFO - 2025-12-24 04:43:58 --> Security Class Initialized
DEBUG - 2025-12-24 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:43:58 --> CSRF cookie sent
INFO - 2025-12-24 04:43:58 --> Input Class Initialized
INFO - 2025-12-24 04:43:58 --> Language Class Initialized
INFO - 2025-12-24 04:43:58 --> Loader Class Initialized
INFO - 2025-12-24 04:43:58 --> Helper loaded: url_helper
INFO - 2025-12-24 04:43:58 --> Helper loaded: form_helper
INFO - 2025-12-24 04:43:58 --> Helper loaded: file_helper
INFO - 2025-12-24 04:43:58 --> Helper loaded: html_helper
INFO - 2025-12-24 04:43:58 --> Helper loaded: security_helper
INFO - 2025-12-24 04:43:58 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:43:58 --> Database Driver Class Initialized
INFO - 2025-12-24 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:43:58 --> Form Validation Class Initialized
INFO - 2025-12-24 04:43:58 --> Controller Class Initialized
INFO - 2025-12-24 04:43:58 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:43:58 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:43:58 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:43:58 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:43:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:43:58 --> Upload Class Initialized
INFO - 2025-12-24 04:43:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:43:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:43:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 04:43:58 --> Severity: error --> Exception: Call to undefined function character_limiter() D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 183
INFO - 2025-12-24 04:44:05 --> Config Class Initialized
INFO - 2025-12-24 04:44:05 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:05 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:05 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:05 --> URI Class Initialized
INFO - 2025-12-24 04:44:05 --> Router Class Initialized
INFO - 2025-12-24 04:44:05 --> Output Class Initialized
INFO - 2025-12-24 04:44:05 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:05 --> CSRF cookie sent
INFO - 2025-12-24 04:44:05 --> Input Class Initialized
INFO - 2025-12-24 04:44:05 --> Language Class Initialized
INFO - 2025-12-24 04:44:05 --> Loader Class Initialized
INFO - 2025-12-24 04:44:05 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:05 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:05 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:05 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:05 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:05 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:05 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:05 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:05 --> Controller Class Initialized
INFO - 2025-12-24 04:44:05 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:44:05 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:05 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:44:05 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:44:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:05 --> Upload Class Initialized
INFO - 2025-12-24 04:44:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:44:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:05 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:05 --> Total execution time: 0.0530
INFO - 2025-12-24 04:44:21 --> Config Class Initialized
INFO - 2025-12-24 04:44:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:21 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:21 --> URI Class Initialized
INFO - 2025-12-24 04:44:21 --> Router Class Initialized
INFO - 2025-12-24 04:44:21 --> Output Class Initialized
INFO - 2025-12-24 04:44:21 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:21 --> CSRF cookie sent
INFO - 2025-12-24 04:44:21 --> Input Class Initialized
INFO - 2025-12-24 04:44:21 --> Language Class Initialized
INFO - 2025-12-24 04:44:21 --> Loader Class Initialized
INFO - 2025-12-24 04:44:21 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:21 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:21 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:21 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:21 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:21 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:21 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:21 --> Controller Class Initialized
INFO - 2025-12-24 04:44:21 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:44:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:44:21 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:21 --> Upload Class Initialized
INFO - 2025-12-24 04:44:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:44:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:21 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:21 --> Total execution time: 0.0610
INFO - 2025-12-24 04:44:23 --> Config Class Initialized
INFO - 2025-12-24 04:44:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:23 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:23 --> URI Class Initialized
INFO - 2025-12-24 04:44:23 --> Router Class Initialized
INFO - 2025-12-24 04:44:23 --> Output Class Initialized
INFO - 2025-12-24 04:44:23 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:23 --> CSRF cookie sent
INFO - 2025-12-24 04:44:23 --> Input Class Initialized
INFO - 2025-12-24 04:44:23 --> Language Class Initialized
INFO - 2025-12-24 04:44:23 --> Loader Class Initialized
INFO - 2025-12-24 04:44:23 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:23 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:23 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:23 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:23 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:23 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:23 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:23 --> Controller Class Initialized
INFO - 2025-12-24 04:44:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:44:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:44:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:44:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:23 --> Upload Class Initialized
INFO - 2025-12-24 04:44:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:44:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:23 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:23 --> Total execution time: 0.1996
INFO - 2025-12-24 04:44:32 --> Config Class Initialized
INFO - 2025-12-24 04:44:32 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:32 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:32 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:32 --> URI Class Initialized
INFO - 2025-12-24 04:44:32 --> Router Class Initialized
INFO - 2025-12-24 04:44:32 --> Output Class Initialized
INFO - 2025-12-24 04:44:32 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:32 --> CSRF cookie sent
INFO - 2025-12-24 04:44:32 --> Input Class Initialized
INFO - 2025-12-24 04:44:32 --> Language Class Initialized
INFO - 2025-12-24 04:44:32 --> Loader Class Initialized
INFO - 2025-12-24 04:44:32 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:32 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:32 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:32 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:32 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:32 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:32 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:32 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:32 --> Controller Class Initialized
INFO - 2025-12-24 04:44:32 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:44:32 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:32 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:44:32 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:32 --> Upload Class Initialized
INFO - 2025-12-24 04:44:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 04:44:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:32 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:32 --> Total execution time: 0.1164
INFO - 2025-12-24 04:44:36 --> Config Class Initialized
INFO - 2025-12-24 04:44:36 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:36 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:36 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:36 --> URI Class Initialized
INFO - 2025-12-24 04:44:36 --> Router Class Initialized
INFO - 2025-12-24 04:44:36 --> Output Class Initialized
INFO - 2025-12-24 04:44:36 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:36 --> CSRF cookie sent
INFO - 2025-12-24 04:44:36 --> Input Class Initialized
INFO - 2025-12-24 04:44:36 --> Language Class Initialized
INFO - 2025-12-24 04:44:36 --> Loader Class Initialized
INFO - 2025-12-24 04:44:36 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:36 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:36 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:36 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:36 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:36 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:36 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:36 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:36 --> Controller Class Initialized
INFO - 2025-12-24 04:44:36 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:44:36 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:36 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:44:36 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:36 --> Upload Class Initialized
INFO - 2025-12-24 04:44:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:44:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:36 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:36 --> Total execution time: 0.0554
INFO - 2025-12-24 04:44:39 --> Config Class Initialized
INFO - 2025-12-24 04:44:39 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:39 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:39 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:39 --> URI Class Initialized
INFO - 2025-12-24 04:44:39 --> Router Class Initialized
INFO - 2025-12-24 04:44:39 --> Output Class Initialized
INFO - 2025-12-24 04:44:39 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:39 --> CSRF cookie sent
INFO - 2025-12-24 04:44:39 --> Input Class Initialized
INFO - 2025-12-24 04:44:39 --> Language Class Initialized
INFO - 2025-12-24 04:44:39 --> Loader Class Initialized
INFO - 2025-12-24 04:44:39 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:39 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:39 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:39 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:39 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:39 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:39 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:39 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:39 --> Controller Class Initialized
INFO - 2025-12-24 04:44:39 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 04:44:39 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 04:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:44:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/form.php
INFO - 2025-12-24 04:44:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:39 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:39 --> Total execution time: 0.1090
INFO - 2025-12-24 04:44:54 --> Config Class Initialized
INFO - 2025-12-24 04:44:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:54 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:54 --> URI Class Initialized
INFO - 2025-12-24 04:44:54 --> Router Class Initialized
INFO - 2025-12-24 04:44:54 --> Output Class Initialized
INFO - 2025-12-24 04:44:54 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:54 --> CSRF cookie sent
INFO - 2025-12-24 04:44:54 --> Input Class Initialized
INFO - 2025-12-24 04:44:54 --> Language Class Initialized
INFO - 2025-12-24 04:44:54 --> Loader Class Initialized
INFO - 2025-12-24 04:44:54 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:54 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:54 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:54 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:54 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:54 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:55 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:55 --> Controller Class Initialized
INFO - 2025-12-24 04:44:55 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:44:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:44:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:44:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:44:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:44:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:44:55 --> Final output sent to browser
DEBUG - 2025-12-24 04:44:55 --> Total execution time: 0.0583
INFO - 2025-12-24 04:44:58 --> Config Class Initialized
INFO - 2025-12-24 04:44:58 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:44:58 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:44:58 --> Utf8 Class Initialized
INFO - 2025-12-24 04:44:58 --> URI Class Initialized
INFO - 2025-12-24 04:44:58 --> Router Class Initialized
INFO - 2025-12-24 04:44:58 --> Output Class Initialized
INFO - 2025-12-24 04:44:58 --> Security Class Initialized
DEBUG - 2025-12-24 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:44:58 --> CSRF cookie sent
INFO - 2025-12-24 04:44:58 --> Input Class Initialized
INFO - 2025-12-24 04:44:58 --> Language Class Initialized
INFO - 2025-12-24 04:44:58 --> Loader Class Initialized
INFO - 2025-12-24 04:44:58 --> Helper loaded: url_helper
INFO - 2025-12-24 04:44:58 --> Helper loaded: form_helper
INFO - 2025-12-24 04:44:58 --> Helper loaded: file_helper
INFO - 2025-12-24 04:44:58 --> Helper loaded: html_helper
INFO - 2025-12-24 04:44:58 --> Helper loaded: security_helper
INFO - 2025-12-24 04:44:58 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:44:58 --> Database Driver Class Initialized
INFO - 2025-12-24 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:44:58 --> Form Validation Class Initialized
INFO - 2025-12-24 04:44:58 --> Controller Class Initialized
INFO - 2025-12-24 04:44:58 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 04:44:58 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:44:58 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 04:44:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 04:45:05 --> Config Class Initialized
INFO - 2025-12-24 04:45:05 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:45:05 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:45:05 --> Utf8 Class Initialized
INFO - 2025-12-24 04:45:05 --> URI Class Initialized
INFO - 2025-12-24 04:45:05 --> Router Class Initialized
INFO - 2025-12-24 04:45:05 --> Output Class Initialized
INFO - 2025-12-24 04:45:05 --> Security Class Initialized
DEBUG - 2025-12-24 04:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:45:05 --> CSRF cookie sent
INFO - 2025-12-24 04:45:05 --> Input Class Initialized
INFO - 2025-12-24 04:45:05 --> Language Class Initialized
INFO - 2025-12-24 04:45:05 --> Loader Class Initialized
INFO - 2025-12-24 04:45:05 --> Helper loaded: url_helper
INFO - 2025-12-24 04:45:05 --> Helper loaded: form_helper
INFO - 2025-12-24 04:45:05 --> Helper loaded: file_helper
INFO - 2025-12-24 04:45:05 --> Helper loaded: html_helper
INFO - 2025-12-24 04:45:05 --> Helper loaded: security_helper
INFO - 2025-12-24 04:45:05 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:45:05 --> Database Driver Class Initialized
INFO - 2025-12-24 04:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:45:05 --> Form Validation Class Initialized
INFO - 2025-12-24 04:45:05 --> Controller Class Initialized
INFO - 2025-12-24 04:45:05 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:45:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:45:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:45:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:45:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:45:05 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:45:05 --> Final output sent to browser
DEBUG - 2025-12-24 04:45:05 --> Total execution time: 0.0495
INFO - 2025-12-24 04:45:11 --> Config Class Initialized
INFO - 2025-12-24 04:45:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:45:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:45:11 --> Utf8 Class Initialized
INFO - 2025-12-24 04:45:11 --> URI Class Initialized
INFO - 2025-12-24 04:45:11 --> Router Class Initialized
INFO - 2025-12-24 04:45:11 --> Output Class Initialized
INFO - 2025-12-24 04:45:11 --> Security Class Initialized
DEBUG - 2025-12-24 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:45:11 --> CSRF cookie sent
INFO - 2025-12-24 04:45:11 --> Input Class Initialized
INFO - 2025-12-24 04:45:11 --> Language Class Initialized
INFO - 2025-12-24 04:45:11 --> Loader Class Initialized
INFO - 2025-12-24 04:45:11 --> Helper loaded: url_helper
INFO - 2025-12-24 04:45:11 --> Helper loaded: form_helper
INFO - 2025-12-24 04:45:11 --> Helper loaded: file_helper
INFO - 2025-12-24 04:45:11 --> Helper loaded: html_helper
INFO - 2025-12-24 04:45:11 --> Helper loaded: security_helper
INFO - 2025-12-24 04:45:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:45:11 --> Database Driver Class Initialized
INFO - 2025-12-24 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:45:11 --> Form Validation Class Initialized
INFO - 2025-12-24 04:45:11 --> Controller Class Initialized
INFO - 2025-12-24 04:45:11 --> Model "Laporan_model" initialized
INFO - 2025-12-24 04:45:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:45:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:45:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:45:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:45:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 04:45:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:45:11 --> Final output sent to browser
DEBUG - 2025-12-24 04:45:11 --> Total execution time: 0.0534
INFO - 2025-12-24 04:45:15 --> Config Class Initialized
INFO - 2025-12-24 04:45:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:45:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:45:15 --> Utf8 Class Initialized
INFO - 2025-12-24 04:45:15 --> URI Class Initialized
INFO - 2025-12-24 04:45:15 --> Router Class Initialized
INFO - 2025-12-24 04:45:15 --> Output Class Initialized
INFO - 2025-12-24 04:45:15 --> Security Class Initialized
DEBUG - 2025-12-24 04:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:45:15 --> CSRF cookie sent
INFO - 2025-12-24 04:45:15 --> Input Class Initialized
INFO - 2025-12-24 04:45:15 --> Language Class Initialized
INFO - 2025-12-24 04:45:15 --> Loader Class Initialized
INFO - 2025-12-24 04:45:15 --> Helper loaded: url_helper
INFO - 2025-12-24 04:45:15 --> Helper loaded: form_helper
INFO - 2025-12-24 04:45:15 --> Helper loaded: file_helper
INFO - 2025-12-24 04:45:15 --> Helper loaded: html_helper
INFO - 2025-12-24 04:45:15 --> Helper loaded: security_helper
INFO - 2025-12-24 04:45:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:45:15 --> Database Driver Class Initialized
INFO - 2025-12-24 04:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:45:15 --> Form Validation Class Initialized
INFO - 2025-12-24 04:45:15 --> Controller Class Initialized
INFO - 2025-12-24 04:45:15 --> Model "Laporan_model" initialized
INFO - 2025-12-24 04:45:15 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:45:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_masuk.php
INFO - 2025-12-24 04:45:16 --> Final output sent to browser
DEBUG - 2025-12-24 04:45:16 --> Total execution time: 0.1126
INFO - 2025-12-24 04:48:30 --> Config Class Initialized
INFO - 2025-12-24 04:48:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:30 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:30 --> URI Class Initialized
INFO - 2025-12-24 04:48:30 --> Router Class Initialized
INFO - 2025-12-24 04:48:30 --> Output Class Initialized
INFO - 2025-12-24 04:48:30 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:30 --> CSRF cookie sent
INFO - 2025-12-24 04:48:30 --> Input Class Initialized
INFO - 2025-12-24 04:48:30 --> Language Class Initialized
INFO - 2025-12-24 04:48:30 --> Loader Class Initialized
INFO - 2025-12-24 04:48:30 --> Helper loaded: url_helper
INFO - 2025-12-24 04:48:30 --> Helper loaded: form_helper
INFO - 2025-12-24 04:48:30 --> Helper loaded: file_helper
INFO - 2025-12-24 04:48:30 --> Helper loaded: html_helper
INFO - 2025-12-24 04:48:30 --> Helper loaded: security_helper
INFO - 2025-12-24 04:48:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:48:30 --> Database Driver Class Initialized
INFO - 2025-12-24 04:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:48:30 --> Form Validation Class Initialized
INFO - 2025-12-24 04:48:30 --> Controller Class Initialized
INFO - 2025-12-24 04:48:30 --> Model "Laporan_model" initialized
INFO - 2025-12-24 04:48:30 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:48:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:48:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:48:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:48:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 04:48:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:48:30 --> Final output sent to browser
DEBUG - 2025-12-24 04:48:30 --> Total execution time: 0.0926
INFO - 2025-12-24 04:48:34 --> Config Class Initialized
INFO - 2025-12-24 04:48:34 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:34 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:34 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:34 --> URI Class Initialized
INFO - 2025-12-24 04:48:34 --> Router Class Initialized
INFO - 2025-12-24 04:48:34 --> Output Class Initialized
INFO - 2025-12-24 04:48:34 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:34 --> CSRF cookie sent
INFO - 2025-12-24 04:48:34 --> Input Class Initialized
INFO - 2025-12-24 04:48:34 --> Language Class Initialized
INFO - 2025-12-24 04:48:34 --> Loader Class Initialized
INFO - 2025-12-24 04:48:34 --> Helper loaded: url_helper
INFO - 2025-12-24 04:48:34 --> Helper loaded: form_helper
INFO - 2025-12-24 04:48:34 --> Helper loaded: file_helper
INFO - 2025-12-24 04:48:34 --> Helper loaded: html_helper
INFO - 2025-12-24 04:48:34 --> Helper loaded: security_helper
INFO - 2025-12-24 04:48:34 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:48:34 --> Database Driver Class Initialized
INFO - 2025-12-24 04:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:48:34 --> Form Validation Class Initialized
INFO - 2025-12-24 04:48:34 --> Controller Class Initialized
INFO - 2025-12-24 04:48:34 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:48:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:48:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:48:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:48:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:48:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:48:34 --> Final output sent to browser
DEBUG - 2025-12-24 04:48:34 --> Total execution time: 0.0548
INFO - 2025-12-24 04:48:37 --> Config Class Initialized
INFO - 2025-12-24 04:48:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:37 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:37 --> URI Class Initialized
INFO - 2025-12-24 04:48:37 --> Router Class Initialized
INFO - 2025-12-24 04:48:37 --> Output Class Initialized
INFO - 2025-12-24 04:48:37 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:37 --> CSRF cookie sent
INFO - 2025-12-24 04:48:37 --> Input Class Initialized
INFO - 2025-12-24 04:48:37 --> Language Class Initialized
INFO - 2025-12-24 04:48:37 --> Loader Class Initialized
INFO - 2025-12-24 04:48:37 --> Helper loaded: url_helper
INFO - 2025-12-24 04:48:37 --> Helper loaded: form_helper
INFO - 2025-12-24 04:48:37 --> Helper loaded: file_helper
INFO - 2025-12-24 04:48:37 --> Helper loaded: html_helper
INFO - 2025-12-24 04:48:37 --> Helper loaded: security_helper
INFO - 2025-12-24 04:48:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:48:37 --> Database Driver Class Initialized
INFO - 2025-12-24 04:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:48:37 --> Form Validation Class Initialized
INFO - 2025-12-24 04:48:37 --> Controller Class Initialized
INFO - 2025-12-24 04:48:37 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:48:37 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:48:37 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:48:37 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:48:37 --> Upload Class Initialized
INFO - 2025-12-24 04:48:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:48:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:48:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:48:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 04:48:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:48:37 --> Final output sent to browser
DEBUG - 2025-12-24 04:48:37 --> Total execution time: 0.0583
INFO - 2025-12-24 04:48:42 --> Config Class Initialized
INFO - 2025-12-24 04:48:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:42 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:42 --> URI Class Initialized
INFO - 2025-12-24 04:48:42 --> Router Class Initialized
INFO - 2025-12-24 04:48:42 --> Output Class Initialized
INFO - 2025-12-24 04:48:42 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:42 --> CSRF cookie sent
INFO - 2025-12-24 04:48:42 --> Input Class Initialized
INFO - 2025-12-24 04:48:42 --> Language Class Initialized
INFO - 2025-12-24 04:48:42 --> Loader Class Initialized
INFO - 2025-12-24 04:48:42 --> Helper loaded: url_helper
INFO - 2025-12-24 04:48:42 --> Helper loaded: form_helper
INFO - 2025-12-24 04:48:42 --> Helper loaded: file_helper
INFO - 2025-12-24 04:48:42 --> Helper loaded: html_helper
INFO - 2025-12-24 04:48:42 --> Helper loaded: security_helper
INFO - 2025-12-24 04:48:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:48:42 --> Database Driver Class Initialized
INFO - 2025-12-24 04:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:48:42 --> Form Validation Class Initialized
INFO - 2025-12-24 04:48:42 --> Controller Class Initialized
INFO - 2025-12-24 04:48:42 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:48:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:48:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:48:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:48:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:48:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:48:42 --> Final output sent to browser
DEBUG - 2025-12-24 04:48:42 --> Total execution time: 0.0514
INFO - 2025-12-24 04:48:57 --> Config Class Initialized
INFO - 2025-12-24 04:48:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:57 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:57 --> URI Class Initialized
INFO - 2025-12-24 04:48:57 --> Router Class Initialized
INFO - 2025-12-24 04:48:57 --> Output Class Initialized
INFO - 2025-12-24 04:48:57 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:57 --> CSRF cookie sent
INFO - 2025-12-24 04:48:57 --> Input Class Initialized
INFO - 2025-12-24 04:48:57 --> Language Class Initialized
ERROR - 2025-12-24 04:48:57 --> 404 Page Not Found: Surat-keluar/tambah
INFO - 2025-12-24 04:48:59 --> Config Class Initialized
INFO - 2025-12-24 04:48:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:48:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:48:59 --> Utf8 Class Initialized
INFO - 2025-12-24 04:48:59 --> URI Class Initialized
INFO - 2025-12-24 04:48:59 --> Router Class Initialized
INFO - 2025-12-24 04:48:59 --> Output Class Initialized
INFO - 2025-12-24 04:48:59 --> Security Class Initialized
DEBUG - 2025-12-24 04:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:48:59 --> CSRF cookie sent
INFO - 2025-12-24 04:48:59 --> Input Class Initialized
INFO - 2025-12-24 04:48:59 --> Language Class Initialized
INFO - 2025-12-24 04:48:59 --> Loader Class Initialized
INFO - 2025-12-24 04:48:59 --> Helper loaded: url_helper
INFO - 2025-12-24 04:48:59 --> Helper loaded: form_helper
INFO - 2025-12-24 04:48:59 --> Helper loaded: file_helper
INFO - 2025-12-24 04:48:59 --> Helper loaded: html_helper
INFO - 2025-12-24 04:48:59 --> Helper loaded: security_helper
INFO - 2025-12-24 04:48:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:48:59 --> Database Driver Class Initialized
INFO - 2025-12-24 04:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:48:59 --> Form Validation Class Initialized
INFO - 2025-12-24 04:48:59 --> Controller Class Initialized
INFO - 2025-12-24 04:48:59 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 04:48:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:48:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:48:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:48:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 04:48:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:48:59 --> Final output sent to browser
DEBUG - 2025-12-24 04:48:59 --> Total execution time: 0.0528
INFO - 2025-12-24 04:49:01 --> Config Class Initialized
INFO - 2025-12-24 04:49:01 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:49:01 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:49:01 --> Utf8 Class Initialized
INFO - 2025-12-24 04:49:01 --> URI Class Initialized
INFO - 2025-12-24 04:49:01 --> Router Class Initialized
INFO - 2025-12-24 04:49:01 --> Output Class Initialized
INFO - 2025-12-24 04:49:01 --> Security Class Initialized
DEBUG - 2025-12-24 04:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:49:01 --> CSRF cookie sent
INFO - 2025-12-24 04:49:01 --> Input Class Initialized
INFO - 2025-12-24 04:49:01 --> Language Class Initialized
INFO - 2025-12-24 04:49:01 --> Loader Class Initialized
INFO - 2025-12-24 04:49:01 --> Helper loaded: url_helper
INFO - 2025-12-24 04:49:01 --> Helper loaded: form_helper
INFO - 2025-12-24 04:49:01 --> Helper loaded: file_helper
INFO - 2025-12-24 04:49:01 --> Helper loaded: html_helper
INFO - 2025-12-24 04:49:01 --> Helper loaded: security_helper
INFO - 2025-12-24 04:49:01 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:49:01 --> Database Driver Class Initialized
INFO - 2025-12-24 04:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:49:01 --> Form Validation Class Initialized
INFO - 2025-12-24 04:49:01 --> Controller Class Initialized
INFO - 2025-12-24 04:49:01 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:49:01 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:49:01 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:49:01 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:49:01 --> Upload Class Initialized
INFO - 2025-12-24 04:49:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:49:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:49:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:49:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:49:01 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:49:01 --> Final output sent to browser
DEBUG - 2025-12-24 04:49:01 --> Total execution time: 0.0736
INFO - 2025-12-24 04:49:12 --> Config Class Initialized
INFO - 2025-12-24 04:49:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:49:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:49:12 --> Utf8 Class Initialized
INFO - 2025-12-24 04:49:12 --> URI Class Initialized
INFO - 2025-12-24 04:49:12 --> Router Class Initialized
INFO - 2025-12-24 04:49:12 --> Output Class Initialized
INFO - 2025-12-24 04:49:12 --> Security Class Initialized
DEBUG - 2025-12-24 04:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:49:12 --> CSRF cookie sent
INFO - 2025-12-24 04:49:12 --> CSRF token verified
INFO - 2025-12-24 04:49:12 --> Input Class Initialized
INFO - 2025-12-24 04:49:12 --> Language Class Initialized
INFO - 2025-12-24 04:49:12 --> Loader Class Initialized
INFO - 2025-12-24 04:49:12 --> Helper loaded: url_helper
INFO - 2025-12-24 04:49:12 --> Helper loaded: form_helper
INFO - 2025-12-24 04:49:12 --> Helper loaded: file_helper
INFO - 2025-12-24 04:49:12 --> Helper loaded: html_helper
INFO - 2025-12-24 04:49:12 --> Helper loaded: security_helper
INFO - 2025-12-24 04:49:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:49:12 --> Database Driver Class Initialized
INFO - 2025-12-24 04:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:49:12 --> Form Validation Class Initialized
INFO - 2025-12-24 04:49:12 --> Controller Class Initialized
INFO - 2025-12-24 04:49:12 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:49:12 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:49:12 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:49:12 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:49:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:49:12 --> Upload Class Initialized
INFO - 2025-12-24 04:49:13 --> Config Class Initialized
INFO - 2025-12-24 04:49:13 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:49:13 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:49:13 --> Utf8 Class Initialized
INFO - 2025-12-24 04:49:13 --> URI Class Initialized
INFO - 2025-12-24 04:49:13 --> Router Class Initialized
INFO - 2025-12-24 04:49:13 --> Output Class Initialized
INFO - 2025-12-24 04:49:13 --> Security Class Initialized
DEBUG - 2025-12-24 04:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:49:13 --> CSRF cookie sent
INFO - 2025-12-24 04:49:13 --> Input Class Initialized
INFO - 2025-12-24 04:49:13 --> Language Class Initialized
INFO - 2025-12-24 04:49:13 --> Loader Class Initialized
INFO - 2025-12-24 04:49:13 --> Helper loaded: url_helper
INFO - 2025-12-24 04:49:13 --> Helper loaded: form_helper
INFO - 2025-12-24 04:49:13 --> Helper loaded: file_helper
INFO - 2025-12-24 04:49:13 --> Helper loaded: html_helper
INFO - 2025-12-24 04:49:13 --> Helper loaded: security_helper
INFO - 2025-12-24 04:49:13 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:49:13 --> Database Driver Class Initialized
INFO - 2025-12-24 04:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:49:13 --> Form Validation Class Initialized
INFO - 2025-12-24 04:49:13 --> Controller Class Initialized
INFO - 2025-12-24 04:49:13 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:49:13 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:49:13 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:49:13 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:49:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:49:13 --> Upload Class Initialized
INFO - 2025-12-24 04:49:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 04:49:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 04:49:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 04:49:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 04:49:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 04:49:13 --> Final output sent to browser
DEBUG - 2025-12-24 04:49:13 --> Total execution time: 0.0709
INFO - 2025-12-24 04:49:56 --> Config Class Initialized
INFO - 2025-12-24 04:49:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 04:49:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 04:49:56 --> Utf8 Class Initialized
INFO - 2025-12-24 04:49:56 --> URI Class Initialized
INFO - 2025-12-24 04:49:56 --> Router Class Initialized
INFO - 2025-12-24 04:49:56 --> Output Class Initialized
INFO - 2025-12-24 04:49:56 --> Security Class Initialized
DEBUG - 2025-12-24 04:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 04:49:56 --> CSRF cookie sent
INFO - 2025-12-24 04:49:56 --> CSRF token verified
INFO - 2025-12-24 04:49:56 --> Input Class Initialized
INFO - 2025-12-24 04:49:56 --> Language Class Initialized
INFO - 2025-12-24 04:49:56 --> Loader Class Initialized
INFO - 2025-12-24 04:49:56 --> Helper loaded: url_helper
INFO - 2025-12-24 04:49:56 --> Helper loaded: form_helper
INFO - 2025-12-24 04:49:56 --> Helper loaded: file_helper
INFO - 2025-12-24 04:49:56 --> Helper loaded: html_helper
INFO - 2025-12-24 04:49:56 --> Helper loaded: security_helper
INFO - 2025-12-24 04:49:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 04:49:56 --> Database Driver Class Initialized
INFO - 2025-12-24 04:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 04:49:56 --> Form Validation Class Initialized
INFO - 2025-12-24 04:49:56 --> Controller Class Initialized
INFO - 2025-12-24 04:49:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 04:49:56 --> Model "Bagian_model" initialized
INFO - 2025-12-24 04:49:56 --> Model "Kategori_model" initialized
INFO - 2025-12-24 04:49:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 04:49:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 04:49:56 --> Upload Class Initialized
INFO - 2025-12-24 04:49:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-24 04:49:56 --> Query error: Unknown column 'no_surat_auto' in 'field list' - Invalid query: SELECT `no_surat_auto`
FROM `surat_masuk`
WHERE `kode_bagian` = 'ITM'
AND YEAR(created_at) = '2025'
ORDER BY `id` DESC
 LIMIT 1
INFO - 2025-12-24 04:49:56 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 05:00:16 --> Config Class Initialized
INFO - 2025-12-24 05:00:16 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:00:16 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:00:16 --> Utf8 Class Initialized
INFO - 2025-12-24 05:00:16 --> URI Class Initialized
INFO - 2025-12-24 05:00:16 --> Router Class Initialized
INFO - 2025-12-24 05:00:16 --> Output Class Initialized
INFO - 2025-12-24 05:00:16 --> Security Class Initialized
DEBUG - 2025-12-24 05:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:00:16 --> CSRF cookie sent
INFO - 2025-12-24 05:00:16 --> Input Class Initialized
INFO - 2025-12-24 05:00:16 --> Language Class Initialized
INFO - 2025-12-24 05:00:16 --> Loader Class Initialized
INFO - 2025-12-24 05:00:16 --> Helper loaded: url_helper
INFO - 2025-12-24 05:00:16 --> Helper loaded: form_helper
INFO - 2025-12-24 05:00:16 --> Helper loaded: file_helper
INFO - 2025-12-24 05:00:16 --> Helper loaded: html_helper
INFO - 2025-12-24 05:00:16 --> Helper loaded: security_helper
INFO - 2025-12-24 05:00:16 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:00:16 --> Database Driver Class Initialized
INFO - 2025-12-24 05:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:00:16 --> Form Validation Class Initialized
INFO - 2025-12-24 05:00:16 --> Controller Class Initialized
INFO - 2025-12-24 05:00:16 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:00:16 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:00:16 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:00:16 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:00:16 --> Upload Class Initialized
INFO - 2025-12-24 05:00:16 --> Helper loaded: text_helper
INFO - 2025-12-24 05:00:18 --> Config Class Initialized
INFO - 2025-12-24 05:00:18 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:00:18 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:00:18 --> Utf8 Class Initialized
INFO - 2025-12-24 05:00:18 --> URI Class Initialized
INFO - 2025-12-24 05:00:18 --> Router Class Initialized
INFO - 2025-12-24 05:00:18 --> Output Class Initialized
INFO - 2025-12-24 05:00:18 --> Security Class Initialized
DEBUG - 2025-12-24 05:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:00:18 --> CSRF cookie sent
INFO - 2025-12-24 05:00:18 --> Input Class Initialized
INFO - 2025-12-24 05:00:18 --> Language Class Initialized
INFO - 2025-12-24 05:00:18 --> Loader Class Initialized
INFO - 2025-12-24 05:00:18 --> Helper loaded: url_helper
INFO - 2025-12-24 05:00:18 --> Helper loaded: form_helper
INFO - 2025-12-24 05:00:18 --> Helper loaded: file_helper
INFO - 2025-12-24 05:00:18 --> Helper loaded: html_helper
INFO - 2025-12-24 05:00:18 --> Helper loaded: security_helper
INFO - 2025-12-24 05:00:18 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:00:18 --> Database Driver Class Initialized
INFO - 2025-12-24 05:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:00:18 --> Form Validation Class Initialized
INFO - 2025-12-24 05:00:18 --> Controller Class Initialized
INFO - 2025-12-24 05:00:18 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:00:18 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:00:18 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:00:18 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:00:18 --> Upload Class Initialized
INFO - 2025-12-24 05:00:18 --> Helper loaded: text_helper
INFO - 2025-12-24 05:00:20 --> Config Class Initialized
INFO - 2025-12-24 05:00:20 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:00:20 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:00:20 --> Utf8 Class Initialized
INFO - 2025-12-24 05:00:20 --> URI Class Initialized
INFO - 2025-12-24 05:00:20 --> Router Class Initialized
INFO - 2025-12-24 05:00:20 --> Output Class Initialized
INFO - 2025-12-24 05:00:20 --> Security Class Initialized
DEBUG - 2025-12-24 05:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:00:20 --> CSRF cookie sent
INFO - 2025-12-24 05:00:20 --> Input Class Initialized
INFO - 2025-12-24 05:00:20 --> Language Class Initialized
INFO - 2025-12-24 05:00:20 --> Loader Class Initialized
INFO - 2025-12-24 05:00:20 --> Helper loaded: url_helper
INFO - 2025-12-24 05:00:20 --> Helper loaded: form_helper
INFO - 2025-12-24 05:00:20 --> Helper loaded: file_helper
INFO - 2025-12-24 05:00:20 --> Helper loaded: html_helper
INFO - 2025-12-24 05:00:20 --> Helper loaded: security_helper
INFO - 2025-12-24 05:00:20 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:00:20 --> Database Driver Class Initialized
INFO - 2025-12-24 05:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:00:20 --> Form Validation Class Initialized
INFO - 2025-12-24 05:00:20 --> Controller Class Initialized
INFO - 2025-12-24 05:00:20 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:00:20 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:00:20 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:00:20 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:00:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:00:20 --> Upload Class Initialized
INFO - 2025-12-24 05:00:20 --> Helper loaded: text_helper
INFO - 2025-12-24 05:00:23 --> Config Class Initialized
INFO - 2025-12-24 05:00:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:00:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:00:23 --> Utf8 Class Initialized
INFO - 2025-12-24 05:00:23 --> URI Class Initialized
INFO - 2025-12-24 05:00:23 --> Router Class Initialized
INFO - 2025-12-24 05:00:23 --> Output Class Initialized
INFO - 2025-12-24 05:00:23 --> Security Class Initialized
DEBUG - 2025-12-24 05:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:00:23 --> CSRF cookie sent
INFO - 2025-12-24 05:00:23 --> Input Class Initialized
INFO - 2025-12-24 05:00:23 --> Language Class Initialized
INFO - 2025-12-24 05:00:23 --> Loader Class Initialized
INFO - 2025-12-24 05:00:23 --> Helper loaded: url_helper
INFO - 2025-12-24 05:00:23 --> Helper loaded: form_helper
INFO - 2025-12-24 05:00:23 --> Helper loaded: file_helper
INFO - 2025-12-24 05:00:23 --> Helper loaded: html_helper
INFO - 2025-12-24 05:00:23 --> Helper loaded: security_helper
INFO - 2025-12-24 05:00:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:00:23 --> Database Driver Class Initialized
INFO - 2025-12-24 05:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:00:23 --> Form Validation Class Initialized
INFO - 2025-12-24 05:00:23 --> Controller Class Initialized
INFO - 2025-12-24 05:00:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:00:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:00:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:00:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:00:23 --> Upload Class Initialized
INFO - 2025-12-24 05:00:24 --> Helper loaded: text_helper
INFO - 2025-12-24 05:01:33 --> Config Class Initialized
INFO - 2025-12-24 05:01:33 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:01:33 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:01:33 --> Utf8 Class Initialized
INFO - 2025-12-24 05:01:33 --> URI Class Initialized
INFO - 2025-12-24 05:01:33 --> Router Class Initialized
INFO - 2025-12-24 05:01:33 --> Output Class Initialized
INFO - 2025-12-24 05:01:33 --> Security Class Initialized
DEBUG - 2025-12-24 05:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:01:33 --> CSRF cookie sent
INFO - 2025-12-24 05:01:33 --> Input Class Initialized
INFO - 2025-12-24 05:01:33 --> Language Class Initialized
INFO - 2025-12-24 05:01:33 --> Loader Class Initialized
INFO - 2025-12-24 05:01:33 --> Helper loaded: url_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: form_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: file_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: html_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: security_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:01:33 --> Database Driver Class Initialized
INFO - 2025-12-24 05:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:01:33 --> Form Validation Class Initialized
INFO - 2025-12-24 05:01:33 --> Controller Class Initialized
INFO - 2025-12-24 05:01:33 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:01:33 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:01:33 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:01:33 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:01:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:01:33 --> Upload Class Initialized
INFO - 2025-12-24 05:01:33 --> Helper loaded: text_helper
INFO - 2025-12-24 05:01:33 --> Helper loaded: custom_helper
ERROR - 2025-12-24 05:01:33 --> Query error: Table 'surat_itm.surat_itm_bagian' doesn't exist - Invalid query: SELECT `sm`.*, `b`.`nama_bagian`, `k`.`nama_kategori`, `u`.`nama` as `created_by_name`
FROM `surat_masuk` `sm`
LEFT JOIN `surat_itm_bagian` `b` ON `sm`.`kode_bagian` = `b`.`kode_bagian`
LEFT JOIN `surat_itm_kategori` `k` ON `sm`.`kode_kategori` = `k`.`kode_kategori`
LEFT JOIN `surat_itm_user` `u` ON `sm`.`created_by` = `u`.`id`
ORDER BY `sm`.`created_at` DESC
INFO - 2025-12-24 05:01:33 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 05:01:35 --> Config Class Initialized
INFO - 2025-12-24 05:01:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:01:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:01:35 --> Utf8 Class Initialized
INFO - 2025-12-24 05:01:35 --> URI Class Initialized
INFO - 2025-12-24 05:01:35 --> Router Class Initialized
INFO - 2025-12-24 05:01:35 --> Output Class Initialized
INFO - 2025-12-24 05:01:35 --> Security Class Initialized
DEBUG - 2025-12-24 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:01:35 --> CSRF cookie sent
INFO - 2025-12-24 05:01:35 --> Input Class Initialized
INFO - 2025-12-24 05:01:35 --> Language Class Initialized
INFO - 2025-12-24 05:01:35 --> Loader Class Initialized
INFO - 2025-12-24 05:01:35 --> Helper loaded: url_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: form_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: file_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: html_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: security_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:01:35 --> Database Driver Class Initialized
INFO - 2025-12-24 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:01:35 --> Form Validation Class Initialized
INFO - 2025-12-24 05:01:35 --> Controller Class Initialized
INFO - 2025-12-24 05:01:35 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:01:35 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:01:35 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:01:35 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:01:35 --> Upload Class Initialized
INFO - 2025-12-24 05:01:35 --> Helper loaded: text_helper
INFO - 2025-12-24 05:01:35 --> Helper loaded: custom_helper
ERROR - 2025-12-24 05:01:35 --> Query error: Table 'surat_itm.surat_itm_bagian' doesn't exist - Invalid query: SELECT `sm`.*, `b`.`nama_bagian`, `k`.`nama_kategori`, `u`.`nama` as `created_by_name`
FROM `surat_masuk` `sm`
LEFT JOIN `surat_itm_bagian` `b` ON `sm`.`kode_bagian` = `b`.`kode_bagian`
LEFT JOIN `surat_itm_kategori` `k` ON `sm`.`kode_kategori` = `k`.`kode_kategori`
LEFT JOIN `surat_itm_user` `u` ON `sm`.`created_by` = `u`.`id`
ORDER BY `sm`.`created_at` DESC
INFO - 2025-12-24 05:01:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 05:03:57 --> Config Class Initialized
INFO - 2025-12-24 05:03:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:03:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:03:57 --> Utf8 Class Initialized
INFO - 2025-12-24 05:03:57 --> URI Class Initialized
INFO - 2025-12-24 05:03:57 --> Router Class Initialized
INFO - 2025-12-24 05:03:57 --> Output Class Initialized
INFO - 2025-12-24 05:03:57 --> Security Class Initialized
DEBUG - 2025-12-24 05:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:03:57 --> CSRF cookie sent
INFO - 2025-12-24 05:03:57 --> Input Class Initialized
INFO - 2025-12-24 05:03:57 --> Language Class Initialized
INFO - 2025-12-24 05:03:57 --> Loader Class Initialized
INFO - 2025-12-24 05:03:57 --> Helper loaded: url_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: form_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: file_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: html_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: security_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:03:57 --> Database Driver Class Initialized
INFO - 2025-12-24 05:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:03:57 --> Form Validation Class Initialized
INFO - 2025-12-24 05:03:57 --> Controller Class Initialized
INFO - 2025-12-24 05:03:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:03:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:03:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:03:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:03:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:03:57 --> Upload Class Initialized
INFO - 2025-12-24 05:03:57 --> Helper loaded: text_helper
INFO - 2025-12-24 05:03:57 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:03:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:03:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:03:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:03:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:03:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:03:57 --> Final output sent to browser
DEBUG - 2025-12-24 05:03:57 --> Total execution time: 0.0883
INFO - 2025-12-24 05:03:59 --> Config Class Initialized
INFO - 2025-12-24 05:03:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:03:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:03:59 --> Utf8 Class Initialized
INFO - 2025-12-24 05:03:59 --> URI Class Initialized
INFO - 2025-12-24 05:03:59 --> Router Class Initialized
INFO - 2025-12-24 05:03:59 --> Output Class Initialized
INFO - 2025-12-24 05:03:59 --> Security Class Initialized
DEBUG - 2025-12-24 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:03:59 --> CSRF cookie sent
INFO - 2025-12-24 05:03:59 --> Input Class Initialized
INFO - 2025-12-24 05:03:59 --> Language Class Initialized
INFO - 2025-12-24 05:03:59 --> Loader Class Initialized
INFO - 2025-12-24 05:03:59 --> Helper loaded: url_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: form_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: file_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: html_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: security_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:03:59 --> Database Driver Class Initialized
INFO - 2025-12-24 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:03:59 --> Form Validation Class Initialized
INFO - 2025-12-24 05:03:59 --> Controller Class Initialized
INFO - 2025-12-24 05:03:59 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:03:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:03:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:03:59 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:03:59 --> Upload Class Initialized
INFO - 2025-12-24 05:03:59 --> Helper loaded: text_helper
INFO - 2025-12-24 05:03:59 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:03:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:03:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:03:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:03:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:03:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:03:59 --> Final output sent to browser
DEBUG - 2025-12-24 05:03:59 --> Total execution time: 0.0544
INFO - 2025-12-24 05:04:12 --> Config Class Initialized
INFO - 2025-12-24 05:04:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:04:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:04:12 --> Utf8 Class Initialized
INFO - 2025-12-24 05:04:12 --> URI Class Initialized
INFO - 2025-12-24 05:04:12 --> Router Class Initialized
INFO - 2025-12-24 05:04:12 --> Output Class Initialized
INFO - 2025-12-24 05:04:12 --> Security Class Initialized
DEBUG - 2025-12-24 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:04:12 --> CSRF cookie sent
INFO - 2025-12-24 05:04:12 --> CSRF token verified
INFO - 2025-12-24 05:04:12 --> Input Class Initialized
INFO - 2025-12-24 05:04:12 --> Language Class Initialized
INFO - 2025-12-24 05:04:12 --> Loader Class Initialized
INFO - 2025-12-24 05:04:12 --> Helper loaded: url_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: form_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: file_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: html_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: security_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:04:12 --> Database Driver Class Initialized
INFO - 2025-12-24 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:04:12 --> Form Validation Class Initialized
INFO - 2025-12-24 05:04:12 --> Controller Class Initialized
INFO - 2025-12-24 05:04:12 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:04:12 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:04:12 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:04:12 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:04:12 --> Upload Class Initialized
INFO - 2025-12-24 05:04:12 --> Helper loaded: text_helper
INFO - 2025-12-24 05:04:12 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:04:13 --> Config Class Initialized
INFO - 2025-12-24 05:04:13 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:04:13 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:04:13 --> Utf8 Class Initialized
INFO - 2025-12-24 05:04:13 --> URI Class Initialized
INFO - 2025-12-24 05:04:13 --> Router Class Initialized
INFO - 2025-12-24 05:04:13 --> Output Class Initialized
INFO - 2025-12-24 05:04:13 --> Security Class Initialized
DEBUG - 2025-12-24 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:04:13 --> CSRF cookie sent
INFO - 2025-12-24 05:04:13 --> Input Class Initialized
INFO - 2025-12-24 05:04:13 --> Language Class Initialized
INFO - 2025-12-24 05:04:13 --> Loader Class Initialized
INFO - 2025-12-24 05:04:13 --> Helper loaded: url_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: form_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: file_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: html_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: security_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:04:13 --> Database Driver Class Initialized
INFO - 2025-12-24 05:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:04:13 --> Form Validation Class Initialized
INFO - 2025-12-24 05:04:13 --> Controller Class Initialized
INFO - 2025-12-24 05:04:13 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:04:13 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:04:13 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:04:13 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:04:13 --> Upload Class Initialized
INFO - 2025-12-24 05:04:13 --> Helper loaded: text_helper
INFO - 2025-12-24 05:04:13 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:04:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:04:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:04:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:04:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:04:13 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:04:13 --> Final output sent to browser
DEBUG - 2025-12-24 05:04:13 --> Total execution time: 0.0698
INFO - 2025-12-24 05:04:26 --> Config Class Initialized
INFO - 2025-12-24 05:04:26 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:04:26 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:04:26 --> Utf8 Class Initialized
INFO - 2025-12-24 05:04:26 --> URI Class Initialized
INFO - 2025-12-24 05:04:26 --> Router Class Initialized
INFO - 2025-12-24 05:04:26 --> Output Class Initialized
INFO - 2025-12-24 05:04:26 --> Security Class Initialized
DEBUG - 2025-12-24 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:04:26 --> CSRF cookie sent
INFO - 2025-12-24 05:04:26 --> CSRF token verified
INFO - 2025-12-24 05:04:26 --> Input Class Initialized
INFO - 2025-12-24 05:04:26 --> Language Class Initialized
INFO - 2025-12-24 05:04:26 --> Loader Class Initialized
INFO - 2025-12-24 05:04:26 --> Helper loaded: url_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: form_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: file_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: html_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: security_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:04:26 --> Database Driver Class Initialized
INFO - 2025-12-24 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:04:26 --> Form Validation Class Initialized
INFO - 2025-12-24 05:04:26 --> Controller Class Initialized
INFO - 2025-12-24 05:04:26 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:04:26 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:04:26 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:04:26 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:04:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:04:26 --> Upload Class Initialized
INFO - 2025-12-24 05:04:26 --> Helper loaded: text_helper
INFO - 2025-12-24 05:04:26 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:04:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-24 05:04:26 --> Query error: Table 'surat_itm.log_aktivitas' doesn't exist - Invalid query: INSERT INTO `log_aktivitas` (`user_id`, `aktivitas`, `keterangan`, `ip_address`, `created_at`) VALUES ('1', 'Input Surat Masuk', 'Nomor: 00.001/04/XII/2025 dari Yth. Seluruh Mahasiswa', '::1', '2025-12-24 05:04:26')
INFO - 2025-12-24 05:04:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 05:06:54 --> Config Class Initialized
INFO - 2025-12-24 05:06:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:06:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:06:54 --> Utf8 Class Initialized
INFO - 2025-12-24 05:06:54 --> URI Class Initialized
INFO - 2025-12-24 05:06:54 --> Router Class Initialized
INFO - 2025-12-24 05:06:54 --> Output Class Initialized
INFO - 2025-12-24 05:06:54 --> Security Class Initialized
DEBUG - 2025-12-24 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:06:54 --> CSRF cookie sent
INFO - 2025-12-24 05:06:54 --> Input Class Initialized
INFO - 2025-12-24 05:06:54 --> Language Class Initialized
INFO - 2025-12-24 05:06:54 --> Loader Class Initialized
INFO - 2025-12-24 05:06:54 --> Helper loaded: url_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: form_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: file_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: html_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: security_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:06:54 --> Database Driver Class Initialized
INFO - 2025-12-24 05:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:06:54 --> Form Validation Class Initialized
INFO - 2025-12-24 05:06:54 --> Controller Class Initialized
INFO - 2025-12-24 05:06:54 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:06:54 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:06:54 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:06:54 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:06:54 --> Upload Class Initialized
INFO - 2025-12-24 05:06:54 --> Helper loaded: text_helper
INFO - 2025-12-24 05:06:54 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:06:54 --> Final output sent to browser
DEBUG - 2025-12-24 05:06:54 --> Total execution time: 0.0920
INFO - 2025-12-24 05:06:56 --> Config Class Initialized
INFO - 2025-12-24 05:06:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:06:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:06:56 --> Utf8 Class Initialized
INFO - 2025-12-24 05:06:56 --> URI Class Initialized
INFO - 2025-12-24 05:06:56 --> Router Class Initialized
INFO - 2025-12-24 05:06:56 --> Output Class Initialized
INFO - 2025-12-24 05:06:56 --> Security Class Initialized
DEBUG - 2025-12-24 05:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:06:56 --> CSRF cookie sent
INFO - 2025-12-24 05:06:56 --> Input Class Initialized
INFO - 2025-12-24 05:06:56 --> Language Class Initialized
INFO - 2025-12-24 05:06:56 --> Loader Class Initialized
INFO - 2025-12-24 05:06:56 --> Helper loaded: url_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: form_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: file_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: html_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: security_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:06:56 --> Database Driver Class Initialized
INFO - 2025-12-24 05:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:06:56 --> Form Validation Class Initialized
INFO - 2025-12-24 05:06:56 --> Controller Class Initialized
INFO - 2025-12-24 05:06:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:06:56 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:06:56 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:06:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:06:56 --> Upload Class Initialized
INFO - 2025-12-24 05:06:56 --> Helper loaded: text_helper
INFO - 2025-12-24 05:06:56 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:06:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:06:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:06:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:06:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:06:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:06:56 --> Final output sent to browser
DEBUG - 2025-12-24 05:06:56 --> Total execution time: 0.0574
INFO - 2025-12-24 05:07:09 --> Config Class Initialized
INFO - 2025-12-24 05:07:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:07:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:07:09 --> Utf8 Class Initialized
INFO - 2025-12-24 05:07:09 --> URI Class Initialized
INFO - 2025-12-24 05:07:09 --> Router Class Initialized
INFO - 2025-12-24 05:07:09 --> Output Class Initialized
INFO - 2025-12-24 05:07:09 --> Security Class Initialized
DEBUG - 2025-12-24 05:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:07:09 --> CSRF cookie sent
INFO - 2025-12-24 05:07:09 --> CSRF token verified
INFO - 2025-12-24 05:07:09 --> Input Class Initialized
INFO - 2025-12-24 05:07:09 --> Language Class Initialized
INFO - 2025-12-24 05:07:09 --> Loader Class Initialized
INFO - 2025-12-24 05:07:09 --> Helper loaded: url_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: form_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: file_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: html_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: security_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:07:09 --> Database Driver Class Initialized
INFO - 2025-12-24 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:07:09 --> Form Validation Class Initialized
INFO - 2025-12-24 05:07:09 --> Controller Class Initialized
INFO - 2025-12-24 05:07:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:07:09 --> Upload Class Initialized
INFO - 2025-12-24 05:07:09 --> Helper loaded: text_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:07:09 --> Config Class Initialized
INFO - 2025-12-24 05:07:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:07:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:07:09 --> Utf8 Class Initialized
INFO - 2025-12-24 05:07:09 --> URI Class Initialized
INFO - 2025-12-24 05:07:09 --> Router Class Initialized
INFO - 2025-12-24 05:07:09 --> Output Class Initialized
INFO - 2025-12-24 05:07:09 --> Security Class Initialized
DEBUG - 2025-12-24 05:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:07:09 --> CSRF cookie sent
INFO - 2025-12-24 05:07:09 --> Input Class Initialized
INFO - 2025-12-24 05:07:09 --> Language Class Initialized
INFO - 2025-12-24 05:07:09 --> Loader Class Initialized
INFO - 2025-12-24 05:07:09 --> Helper loaded: url_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: form_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: file_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: html_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: security_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:07:09 --> Database Driver Class Initialized
INFO - 2025-12-24 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:07:09 --> Form Validation Class Initialized
INFO - 2025-12-24 05:07:09 --> Controller Class Initialized
INFO - 2025-12-24 05:07:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:07:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:07:09 --> Upload Class Initialized
INFO - 2025-12-24 05:07:09 --> Helper loaded: text_helper
INFO - 2025-12-24 05:07:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:07:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:07:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:07:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:07:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:07:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:07:09 --> Final output sent to browser
DEBUG - 2025-12-24 05:07:09 --> Total execution time: 0.0670
INFO - 2025-12-24 05:07:23 --> Config Class Initialized
INFO - 2025-12-24 05:07:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:07:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:07:23 --> Utf8 Class Initialized
INFO - 2025-12-24 05:07:23 --> URI Class Initialized
INFO - 2025-12-24 05:07:23 --> Router Class Initialized
INFO - 2025-12-24 05:07:23 --> Output Class Initialized
INFO - 2025-12-24 05:07:23 --> Security Class Initialized
DEBUG - 2025-12-24 05:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:07:23 --> CSRF cookie sent
INFO - 2025-12-24 05:07:23 --> CSRF token verified
INFO - 2025-12-24 05:07:23 --> Input Class Initialized
INFO - 2025-12-24 05:07:23 --> Language Class Initialized
INFO - 2025-12-24 05:07:23 --> Loader Class Initialized
INFO - 2025-12-24 05:07:23 --> Helper loaded: url_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: form_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: file_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: html_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: security_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:07:23 --> Database Driver Class Initialized
INFO - 2025-12-24 05:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:07:23 --> Form Validation Class Initialized
INFO - 2025-12-24 05:07:23 --> Controller Class Initialized
INFO - 2025-12-24 05:07:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:07:23 --> Upload Class Initialized
INFO - 2025-12-24 05:07:23 --> Helper loaded: text_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:07:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 05:07:23 --> Config Class Initialized
INFO - 2025-12-24 05:07:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:07:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:07:23 --> Utf8 Class Initialized
INFO - 2025-12-24 05:07:23 --> URI Class Initialized
INFO - 2025-12-24 05:07:23 --> Router Class Initialized
INFO - 2025-12-24 05:07:23 --> Output Class Initialized
INFO - 2025-12-24 05:07:23 --> Security Class Initialized
DEBUG - 2025-12-24 05:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:07:23 --> CSRF cookie sent
INFO - 2025-12-24 05:07:23 --> Input Class Initialized
INFO - 2025-12-24 05:07:23 --> Language Class Initialized
INFO - 2025-12-24 05:07:23 --> Loader Class Initialized
INFO - 2025-12-24 05:07:23 --> Helper loaded: url_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: form_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: file_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: html_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: security_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:07:23 --> Database Driver Class Initialized
INFO - 2025-12-24 05:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:07:23 --> Form Validation Class Initialized
INFO - 2025-12-24 05:07:23 --> Controller Class Initialized
INFO - 2025-12-24 05:07:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:07:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:07:23 --> Upload Class Initialized
INFO - 2025-12-24 05:07:23 --> Helper loaded: text_helper
INFO - 2025-12-24 05:07:23 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:07:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:07:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:07:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 05:07:23 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 137
ERROR - 2025-12-24 05:07:23 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\surat_masuk\index.php 137
INFO - 2025-12-24 05:07:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:07:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:07:23 --> Final output sent to browser
DEBUG - 2025-12-24 05:07:23 --> Total execution time: 0.0584
INFO - 2025-12-24 05:09:37 --> Config Class Initialized
INFO - 2025-12-24 05:09:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:09:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:09:37 --> Utf8 Class Initialized
INFO - 2025-12-24 05:09:37 --> URI Class Initialized
INFO - 2025-12-24 05:09:37 --> Router Class Initialized
INFO - 2025-12-24 05:09:37 --> Output Class Initialized
INFO - 2025-12-24 05:09:37 --> Security Class Initialized
DEBUG - 2025-12-24 05:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:09:37 --> CSRF cookie sent
INFO - 2025-12-24 05:09:37 --> Input Class Initialized
INFO - 2025-12-24 05:09:37 --> Language Class Initialized
INFO - 2025-12-24 05:09:37 --> Loader Class Initialized
INFO - 2025-12-24 05:09:37 --> Helper loaded: url_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: form_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: file_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: html_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: security_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:09:37 --> Database Driver Class Initialized
INFO - 2025-12-24 05:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:09:37 --> Form Validation Class Initialized
INFO - 2025-12-24 05:09:37 --> Controller Class Initialized
INFO - 2025-12-24 05:09:37 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:09:37 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:09:37 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:09:37 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:09:37 --> Upload Class Initialized
INFO - 2025-12-24 05:09:37 --> Helper loaded: text_helper
INFO - 2025-12-24 05:09:37 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:09:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:09:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:09:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:09:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:09:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:09:37 --> Final output sent to browser
DEBUG - 2025-12-24 05:09:37 --> Total execution time: 0.2121
INFO - 2025-12-24 05:09:48 --> Config Class Initialized
INFO - 2025-12-24 05:09:48 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:09:48 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:09:48 --> Utf8 Class Initialized
INFO - 2025-12-24 05:09:48 --> URI Class Initialized
INFO - 2025-12-24 05:09:48 --> Router Class Initialized
INFO - 2025-12-24 05:09:48 --> Output Class Initialized
INFO - 2025-12-24 05:09:48 --> Security Class Initialized
DEBUG - 2025-12-24 05:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:09:48 --> CSRF cookie sent
INFO - 2025-12-24 05:09:48 --> Input Class Initialized
INFO - 2025-12-24 05:09:48 --> Language Class Initialized
INFO - 2025-12-24 05:09:48 --> Loader Class Initialized
INFO - 2025-12-24 05:09:48 --> Helper loaded: url_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: form_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: file_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: html_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: security_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:09:48 --> Database Driver Class Initialized
INFO - 2025-12-24 05:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:09:48 --> Form Validation Class Initialized
INFO - 2025-12-24 05:09:48 --> Controller Class Initialized
INFO - 2025-12-24 05:09:48 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:09:48 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:09:48 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:09:48 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:09:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:09:48 --> Upload Class Initialized
INFO - 2025-12-24 05:09:48 --> Helper loaded: text_helper
INFO - 2025-12-24 05:09:48 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:09:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:09:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:09:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:09:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:09:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:09:48 --> Final output sent to browser
DEBUG - 2025-12-24 05:09:48 --> Total execution time: 0.0558
INFO - 2025-12-24 05:09:53 --> Config Class Initialized
INFO - 2025-12-24 05:09:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:09:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:09:53 --> Utf8 Class Initialized
INFO - 2025-12-24 05:09:53 --> URI Class Initialized
INFO - 2025-12-24 05:09:53 --> Router Class Initialized
INFO - 2025-12-24 05:09:53 --> Output Class Initialized
INFO - 2025-12-24 05:09:53 --> Security Class Initialized
DEBUG - 2025-12-24 05:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:09:53 --> CSRF cookie sent
INFO - 2025-12-24 05:09:53 --> Input Class Initialized
INFO - 2025-12-24 05:09:53 --> Language Class Initialized
INFO - 2025-12-24 05:09:53 --> Loader Class Initialized
INFO - 2025-12-24 05:09:53 --> Helper loaded: url_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: form_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: file_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: html_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: security_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:09:53 --> Database Driver Class Initialized
INFO - 2025-12-24 05:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:09:53 --> Form Validation Class Initialized
INFO - 2025-12-24 05:09:53 --> Controller Class Initialized
INFO - 2025-12-24 05:09:53 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:09:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:09:53 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:09:53 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:09:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:09:53 --> Upload Class Initialized
INFO - 2025-12-24 05:09:53 --> Helper loaded: text_helper
INFO - 2025-12-24 05:09:53 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:09:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:09:53 --> Final output sent to browser
DEBUG - 2025-12-24 05:09:53 --> Total execution time: 0.0562
INFO - 2025-12-24 05:09:59 --> Config Class Initialized
INFO - 2025-12-24 05:09:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:09:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:09:59 --> Utf8 Class Initialized
INFO - 2025-12-24 05:09:59 --> URI Class Initialized
INFO - 2025-12-24 05:09:59 --> Router Class Initialized
INFO - 2025-12-24 05:09:59 --> Output Class Initialized
INFO - 2025-12-24 05:09:59 --> Security Class Initialized
DEBUG - 2025-12-24 05:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:09:59 --> CSRF cookie sent
INFO - 2025-12-24 05:09:59 --> Input Class Initialized
INFO - 2025-12-24 05:09:59 --> Language Class Initialized
INFO - 2025-12-24 05:09:59 --> Loader Class Initialized
INFO - 2025-12-24 05:09:59 --> Helper loaded: url_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: form_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: file_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: html_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: security_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:09:59 --> Database Driver Class Initialized
INFO - 2025-12-24 05:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:09:59 --> Form Validation Class Initialized
INFO - 2025-12-24 05:09:59 --> Controller Class Initialized
INFO - 2025-12-24 05:09:59 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:09:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:09:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:09:59 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:09:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:09:59 --> Upload Class Initialized
INFO - 2025-12-24 05:09:59 --> Helper loaded: text_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:09:59 --> Helper loaded: download_helper
INFO - 2025-12-24 05:15:15 --> Config Class Initialized
INFO - 2025-12-24 05:15:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:15:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:15:15 --> Utf8 Class Initialized
INFO - 2025-12-24 05:15:15 --> URI Class Initialized
INFO - 2025-12-24 05:15:15 --> Router Class Initialized
INFO - 2025-12-24 05:15:15 --> Output Class Initialized
INFO - 2025-12-24 05:15:15 --> Security Class Initialized
DEBUG - 2025-12-24 05:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:15:15 --> CSRF cookie sent
INFO - 2025-12-24 05:15:15 --> Input Class Initialized
INFO - 2025-12-24 05:15:15 --> Language Class Initialized
INFO - 2025-12-24 05:15:15 --> Loader Class Initialized
INFO - 2025-12-24 05:15:15 --> Helper loaded: url_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: form_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: file_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: html_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: security_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:15:15 --> Database Driver Class Initialized
INFO - 2025-12-24 05:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:15:15 --> Form Validation Class Initialized
INFO - 2025-12-24 05:15:15 --> Controller Class Initialized
INFO - 2025-12-24 05:15:15 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:15:15 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:15:15 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:15:15 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:15:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:15:15 --> Upload Class Initialized
INFO - 2025-12-24 05:15:15 --> Helper loaded: text_helper
INFO - 2025-12-24 05:15:15 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:15:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:15:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:15:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:15:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:15:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:15:15 --> Final output sent to browser
DEBUG - 2025-12-24 05:15:15 --> Total execution time: 0.2934
INFO - 2025-12-24 05:15:25 --> Config Class Initialized
INFO - 2025-12-24 05:15:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:15:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:15:25 --> Utf8 Class Initialized
INFO - 2025-12-24 05:15:25 --> URI Class Initialized
INFO - 2025-12-24 05:15:25 --> Router Class Initialized
INFO - 2025-12-24 05:15:25 --> Output Class Initialized
INFO - 2025-12-24 05:15:25 --> Security Class Initialized
DEBUG - 2025-12-24 05:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:15:25 --> CSRF cookie sent
INFO - 2025-12-24 05:15:25 --> CSRF token verified
INFO - 2025-12-24 05:15:25 --> Input Class Initialized
INFO - 2025-12-24 05:15:25 --> Language Class Initialized
INFO - 2025-12-24 05:15:25 --> Loader Class Initialized
INFO - 2025-12-24 05:15:25 --> Helper loaded: url_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: form_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: file_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: html_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: security_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:15:25 --> Database Driver Class Initialized
INFO - 2025-12-24 05:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:15:25 --> Form Validation Class Initialized
INFO - 2025-12-24 05:15:25 --> Controller Class Initialized
INFO - 2025-12-24 05:15:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:15:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:15:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:15:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:15:25 --> Upload Class Initialized
INFO - 2025-12-24 05:15:25 --> Helper loaded: text_helper
INFO - 2025-12-24 05:15:25 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:15:26 --> Config Class Initialized
INFO - 2025-12-24 05:15:26 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:15:26 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:15:26 --> Utf8 Class Initialized
INFO - 2025-12-24 05:15:26 --> URI Class Initialized
INFO - 2025-12-24 05:15:26 --> Router Class Initialized
INFO - 2025-12-24 05:15:26 --> Output Class Initialized
INFO - 2025-12-24 05:15:26 --> Security Class Initialized
DEBUG - 2025-12-24 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:15:26 --> CSRF cookie sent
INFO - 2025-12-24 05:15:26 --> Input Class Initialized
INFO - 2025-12-24 05:15:26 --> Language Class Initialized
INFO - 2025-12-24 05:15:26 --> Loader Class Initialized
INFO - 2025-12-24 05:15:26 --> Helper loaded: url_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: form_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: file_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: html_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: security_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:15:26 --> Database Driver Class Initialized
INFO - 2025-12-24 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:15:26 --> Form Validation Class Initialized
INFO - 2025-12-24 05:15:26 --> Controller Class Initialized
INFO - 2025-12-24 05:15:26 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:15:26 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:15:26 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:15:26 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:15:26 --> Upload Class Initialized
INFO - 2025-12-24 05:15:26 --> Helper loaded: text_helper
INFO - 2025-12-24 05:15:26 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:15:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:15:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:15:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:15:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:15:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:15:26 --> Final output sent to browser
DEBUG - 2025-12-24 05:15:26 --> Total execution time: 0.0748
INFO - 2025-12-24 05:16:04 --> Config Class Initialized
INFO - 2025-12-24 05:16:04 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:16:04 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:16:04 --> Utf8 Class Initialized
INFO - 2025-12-24 05:16:04 --> URI Class Initialized
INFO - 2025-12-24 05:16:04 --> Router Class Initialized
INFO - 2025-12-24 05:16:04 --> Output Class Initialized
INFO - 2025-12-24 05:16:04 --> Security Class Initialized
DEBUG - 2025-12-24 05:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:16:04 --> CSRF cookie sent
INFO - 2025-12-24 05:16:04 --> Input Class Initialized
INFO - 2025-12-24 05:16:04 --> Language Class Initialized
INFO - 2025-12-24 05:16:04 --> Loader Class Initialized
INFO - 2025-12-24 05:16:04 --> Helper loaded: url_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: form_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: file_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: html_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: security_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:16:04 --> Database Driver Class Initialized
INFO - 2025-12-24 05:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:16:04 --> Form Validation Class Initialized
INFO - 2025-12-24 05:16:04 --> Controller Class Initialized
INFO - 2025-12-24 05:16:04 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:16:04 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:16:04 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:16:04 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:16:04 --> Upload Class Initialized
INFO - 2025-12-24 05:16:04 --> Helper loaded: text_helper
INFO - 2025-12-24 05:16:04 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:16:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:16:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:16:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:16:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:16:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:16:04 --> Final output sent to browser
DEBUG - 2025-12-24 05:16:04 --> Total execution time: 0.2762
INFO - 2025-12-24 05:16:14 --> Config Class Initialized
INFO - 2025-12-24 05:16:14 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:16:14 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:16:14 --> Utf8 Class Initialized
INFO - 2025-12-24 05:16:14 --> URI Class Initialized
INFO - 2025-12-24 05:16:14 --> Router Class Initialized
INFO - 2025-12-24 05:16:14 --> Output Class Initialized
INFO - 2025-12-24 05:16:14 --> Security Class Initialized
DEBUG - 2025-12-24 05:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:16:14 --> CSRF cookie sent
INFO - 2025-12-24 05:16:14 --> CSRF token verified
INFO - 2025-12-24 05:16:14 --> Input Class Initialized
INFO - 2025-12-24 05:16:14 --> Language Class Initialized
INFO - 2025-12-24 05:16:14 --> Loader Class Initialized
INFO - 2025-12-24 05:16:14 --> Helper loaded: url_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: form_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: file_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: html_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: security_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:16:14 --> Database Driver Class Initialized
INFO - 2025-12-24 05:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:16:14 --> Form Validation Class Initialized
INFO - 2025-12-24 05:16:14 --> Controller Class Initialized
INFO - 2025-12-24 05:16:14 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:16:14 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:16:14 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:16:14 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:16:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:16:14 --> Upload Class Initialized
INFO - 2025-12-24 05:16:14 --> Helper loaded: text_helper
INFO - 2025-12-24 05:16:14 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:16:15 --> Config Class Initialized
INFO - 2025-12-24 05:16:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:16:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:16:15 --> Utf8 Class Initialized
INFO - 2025-12-24 05:16:15 --> URI Class Initialized
INFO - 2025-12-24 05:16:15 --> Router Class Initialized
INFO - 2025-12-24 05:16:15 --> Output Class Initialized
INFO - 2025-12-24 05:16:15 --> Security Class Initialized
DEBUG - 2025-12-24 05:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:16:15 --> CSRF cookie sent
INFO - 2025-12-24 05:16:15 --> Input Class Initialized
INFO - 2025-12-24 05:16:15 --> Language Class Initialized
INFO - 2025-12-24 05:16:15 --> Loader Class Initialized
INFO - 2025-12-24 05:16:15 --> Helper loaded: url_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: form_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: file_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: html_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: security_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:16:15 --> Database Driver Class Initialized
INFO - 2025-12-24 05:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:16:15 --> Form Validation Class Initialized
INFO - 2025-12-24 05:16:15 --> Controller Class Initialized
INFO - 2025-12-24 05:16:15 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:16:15 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:16:15 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:16:15 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:16:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:16:15 --> Upload Class Initialized
INFO - 2025-12-24 05:16:15 --> Helper loaded: text_helper
INFO - 2025-12-24 05:16:15 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:16:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:16:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:16:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:16:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:16:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:16:15 --> Final output sent to browser
DEBUG - 2025-12-24 05:16:15 --> Total execution time: 0.0903
INFO - 2025-12-24 05:16:30 --> Config Class Initialized
INFO - 2025-12-24 05:16:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:16:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:16:30 --> Utf8 Class Initialized
INFO - 2025-12-24 05:16:30 --> URI Class Initialized
INFO - 2025-12-24 05:16:30 --> Router Class Initialized
INFO - 2025-12-24 05:16:30 --> Output Class Initialized
INFO - 2025-12-24 05:16:30 --> Security Class Initialized
DEBUG - 2025-12-24 05:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:16:30 --> CSRF cookie sent
INFO - 2025-12-24 05:16:30 --> CSRF token verified
INFO - 2025-12-24 05:16:30 --> Input Class Initialized
INFO - 2025-12-24 05:16:30 --> Language Class Initialized
INFO - 2025-12-24 05:16:30 --> Loader Class Initialized
INFO - 2025-12-24 05:16:30 --> Helper loaded: url_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: form_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: file_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: html_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: security_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:16:30 --> Database Driver Class Initialized
INFO - 2025-12-24 05:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:16:30 --> Form Validation Class Initialized
INFO - 2025-12-24 05:16:30 --> Controller Class Initialized
INFO - 2025-12-24 05:16:30 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:16:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:16:30 --> Upload Class Initialized
INFO - 2025-12-24 05:16:30 --> Helper loaded: text_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:16:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 05:16:30 --> Config Class Initialized
INFO - 2025-12-24 05:16:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:16:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:16:30 --> Utf8 Class Initialized
INFO - 2025-12-24 05:16:30 --> URI Class Initialized
INFO - 2025-12-24 05:16:30 --> Router Class Initialized
INFO - 2025-12-24 05:16:30 --> Output Class Initialized
INFO - 2025-12-24 05:16:30 --> Security Class Initialized
DEBUG - 2025-12-24 05:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:16:30 --> CSRF cookie sent
INFO - 2025-12-24 05:16:30 --> Input Class Initialized
INFO - 2025-12-24 05:16:30 --> Language Class Initialized
INFO - 2025-12-24 05:16:30 --> Loader Class Initialized
INFO - 2025-12-24 05:16:30 --> Helper loaded: url_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: form_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: file_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: html_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: security_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:16:30 --> Database Driver Class Initialized
INFO - 2025-12-24 05:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:16:30 --> Form Validation Class Initialized
INFO - 2025-12-24 05:16:30 --> Controller Class Initialized
INFO - 2025-12-24 05:16:30 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:16:30 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:16:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:16:30 --> Upload Class Initialized
INFO - 2025-12-24 05:16:30 --> Helper loaded: text_helper
INFO - 2025-12-24 05:16:30 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:16:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:16:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:16:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:16:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:16:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:16:30 --> Final output sent to browser
DEBUG - 2025-12-24 05:16:30 --> Total execution time: 0.0562
INFO - 2025-12-24 05:19:45 --> Config Class Initialized
INFO - 2025-12-24 05:19:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:45 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:45 --> URI Class Initialized
INFO - 2025-12-24 05:19:45 --> Router Class Initialized
INFO - 2025-12-24 05:19:45 --> Output Class Initialized
INFO - 2025-12-24 05:19:45 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:45 --> CSRF cookie sent
INFO - 2025-12-24 05:19:45 --> Input Class Initialized
INFO - 2025-12-24 05:19:45 --> Language Class Initialized
INFO - 2025-12-24 05:19:45 --> Loader Class Initialized
INFO - 2025-12-24 05:19:45 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:45 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:45 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:45 --> Controller Class Initialized
INFO - 2025-12-24 05:19:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:45 --> Upload Class Initialized
INFO - 2025-12-24 05:19:45 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:45 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:19:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:19:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:19:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:19:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:19:45 --> Final output sent to browser
DEBUG - 2025-12-24 05:19:45 --> Total execution time: 0.0906
INFO - 2025-12-24 05:19:49 --> Config Class Initialized
INFO - 2025-12-24 05:19:49 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:49 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:49 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:49 --> URI Class Initialized
INFO - 2025-12-24 05:19:49 --> Router Class Initialized
INFO - 2025-12-24 05:19:49 --> Output Class Initialized
INFO - 2025-12-24 05:19:49 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:49 --> CSRF cookie sent
INFO - 2025-12-24 05:19:49 --> Input Class Initialized
INFO - 2025-12-24 05:19:49 --> Language Class Initialized
INFO - 2025-12-24 05:19:49 --> Loader Class Initialized
INFO - 2025-12-24 05:19:49 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:49 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:49 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:49 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:49 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:49 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:49 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:50 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:50 --> Controller Class Initialized
INFO - 2025-12-24 05:19:50 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:50 --> Upload Class Initialized
INFO - 2025-12-24 05:19:50 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:50 --> Config Class Initialized
INFO - 2025-12-24 05:19:50 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:50 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:50 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:50 --> URI Class Initialized
INFO - 2025-12-24 05:19:50 --> Router Class Initialized
INFO - 2025-12-24 05:19:50 --> Output Class Initialized
INFO - 2025-12-24 05:19:50 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:50 --> CSRF cookie sent
INFO - 2025-12-24 05:19:50 --> Input Class Initialized
INFO - 2025-12-24 05:19:50 --> Language Class Initialized
INFO - 2025-12-24 05:19:50 --> Loader Class Initialized
INFO - 2025-12-24 05:19:50 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:50 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:50 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:50 --> Controller Class Initialized
INFO - 2025-12-24 05:19:50 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:50 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:50 --> Upload Class Initialized
INFO - 2025-12-24 05:19:50 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:50 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:19:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:19:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:19:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:19:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:19:50 --> Final output sent to browser
DEBUG - 2025-12-24 05:19:50 --> Total execution time: 0.1481
INFO - 2025-12-24 05:19:53 --> Config Class Initialized
INFO - 2025-12-24 05:19:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:53 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:53 --> URI Class Initialized
INFO - 2025-12-24 05:19:53 --> Router Class Initialized
INFO - 2025-12-24 05:19:53 --> Output Class Initialized
INFO - 2025-12-24 05:19:53 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:53 --> CSRF cookie sent
INFO - 2025-12-24 05:19:53 --> Input Class Initialized
INFO - 2025-12-24 05:19:53 --> Language Class Initialized
INFO - 2025-12-24 05:19:53 --> Loader Class Initialized
INFO - 2025-12-24 05:19:53 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:53 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:53 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:53 --> Controller Class Initialized
INFO - 2025-12-24 05:19:53 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:53 --> Upload Class Initialized
INFO - 2025-12-24 05:19:53 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:53 --> Config Class Initialized
INFO - 2025-12-24 05:19:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:53 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:53 --> URI Class Initialized
INFO - 2025-12-24 05:19:53 --> Router Class Initialized
INFO - 2025-12-24 05:19:53 --> Output Class Initialized
INFO - 2025-12-24 05:19:53 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:53 --> CSRF cookie sent
INFO - 2025-12-24 05:19:53 --> Input Class Initialized
INFO - 2025-12-24 05:19:53 --> Language Class Initialized
INFO - 2025-12-24 05:19:53 --> Loader Class Initialized
INFO - 2025-12-24 05:19:53 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:53 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:53 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:53 --> Controller Class Initialized
INFO - 2025-12-24 05:19:53 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:53 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:53 --> Upload Class Initialized
INFO - 2025-12-24 05:19:53 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:53 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:19:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:19:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:19:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:19:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:19:53 --> Final output sent to browser
DEBUG - 2025-12-24 05:19:53 --> Total execution time: 0.0891
INFO - 2025-12-24 05:19:56 --> Config Class Initialized
INFO - 2025-12-24 05:19:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:56 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:56 --> URI Class Initialized
INFO - 2025-12-24 05:19:56 --> Router Class Initialized
INFO - 2025-12-24 05:19:56 --> Output Class Initialized
INFO - 2025-12-24 05:19:56 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:56 --> CSRF cookie sent
INFO - 2025-12-24 05:19:56 --> Input Class Initialized
INFO - 2025-12-24 05:19:56 --> Language Class Initialized
INFO - 2025-12-24 05:19:56 --> Loader Class Initialized
INFO - 2025-12-24 05:19:56 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:56 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:56 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:56 --> Controller Class Initialized
INFO - 2025-12-24 05:19:56 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:56 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:56 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:56 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:56 --> Upload Class Initialized
INFO - 2025-12-24 05:19:56 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:56 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:57 --> Config Class Initialized
INFO - 2025-12-24 05:19:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:57 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:57 --> URI Class Initialized
INFO - 2025-12-24 05:19:57 --> Router Class Initialized
INFO - 2025-12-24 05:19:57 --> Output Class Initialized
INFO - 2025-12-24 05:19:57 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:57 --> CSRF cookie sent
INFO - 2025-12-24 05:19:57 --> Input Class Initialized
INFO - 2025-12-24 05:19:57 --> Language Class Initialized
INFO - 2025-12-24 05:19:57 --> Loader Class Initialized
INFO - 2025-12-24 05:19:57 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:57 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:57 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:57 --> Controller Class Initialized
INFO - 2025-12-24 05:19:57 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:57 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:57 --> Upload Class Initialized
INFO - 2025-12-24 05:19:57 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:57 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:19:57 --> Final output sent to browser
DEBUG - 2025-12-24 05:19:57 --> Total execution time: 0.0623
INFO - 2025-12-24 05:19:59 --> Config Class Initialized
INFO - 2025-12-24 05:19:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:19:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:19:59 --> Utf8 Class Initialized
INFO - 2025-12-24 05:19:59 --> URI Class Initialized
INFO - 2025-12-24 05:19:59 --> Router Class Initialized
INFO - 2025-12-24 05:19:59 --> Output Class Initialized
INFO - 2025-12-24 05:19:59 --> Security Class Initialized
DEBUG - 2025-12-24 05:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:19:59 --> CSRF cookie sent
INFO - 2025-12-24 05:19:59 --> Input Class Initialized
INFO - 2025-12-24 05:19:59 --> Language Class Initialized
INFO - 2025-12-24 05:19:59 --> Loader Class Initialized
INFO - 2025-12-24 05:19:59 --> Helper loaded: url_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: form_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: file_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: html_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: security_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:19:59 --> Database Driver Class Initialized
INFO - 2025-12-24 05:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:19:59 --> Form Validation Class Initialized
INFO - 2025-12-24 05:19:59 --> Controller Class Initialized
INFO - 2025-12-24 05:19:59 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:19:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:19:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:19:59 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:19:59 --> Upload Class Initialized
INFO - 2025-12-24 05:19:59 --> Helper loaded: text_helper
INFO - 2025-12-24 05:19:59 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:19:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:19:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:19:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:19:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:19:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:19:59 --> Final output sent to browser
DEBUG - 2025-12-24 05:19:59 --> Total execution time: 0.3058
INFO - 2025-12-24 05:20:07 --> Config Class Initialized
INFO - 2025-12-24 05:20:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:20:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:20:07 --> Utf8 Class Initialized
INFO - 2025-12-24 05:20:07 --> URI Class Initialized
INFO - 2025-12-24 05:20:07 --> Router Class Initialized
INFO - 2025-12-24 05:20:07 --> Output Class Initialized
INFO - 2025-12-24 05:20:07 --> Security Class Initialized
DEBUG - 2025-12-24 05:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:20:07 --> CSRF cookie sent
INFO - 2025-12-24 05:20:07 --> CSRF token verified
INFO - 2025-12-24 05:20:07 --> Input Class Initialized
INFO - 2025-12-24 05:20:07 --> Language Class Initialized
INFO - 2025-12-24 05:20:07 --> Loader Class Initialized
INFO - 2025-12-24 05:20:07 --> Helper loaded: url_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: form_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: file_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: html_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: security_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:20:07 --> Database Driver Class Initialized
INFO - 2025-12-24 05:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:20:07 --> Form Validation Class Initialized
INFO - 2025-12-24 05:20:07 --> Controller Class Initialized
INFO - 2025-12-24 05:20:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:20:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:20:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:20:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:20:07 --> Upload Class Initialized
INFO - 2025-12-24 05:20:07 --> Helper loaded: text_helper
INFO - 2025-12-24 05:20:07 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:20:09 --> Config Class Initialized
INFO - 2025-12-24 05:20:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:20:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:20:09 --> Utf8 Class Initialized
INFO - 2025-12-24 05:20:09 --> URI Class Initialized
INFO - 2025-12-24 05:20:09 --> Router Class Initialized
INFO - 2025-12-24 05:20:09 --> Output Class Initialized
INFO - 2025-12-24 05:20:09 --> Security Class Initialized
DEBUG - 2025-12-24 05:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:20:09 --> CSRF cookie sent
INFO - 2025-12-24 05:20:09 --> Input Class Initialized
INFO - 2025-12-24 05:20:09 --> Language Class Initialized
INFO - 2025-12-24 05:20:09 --> Loader Class Initialized
INFO - 2025-12-24 05:20:09 --> Helper loaded: url_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: form_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: file_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: html_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: security_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:20:09 --> Database Driver Class Initialized
INFO - 2025-12-24 05:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:20:09 --> Form Validation Class Initialized
INFO - 2025-12-24 05:20:09 --> Controller Class Initialized
INFO - 2025-12-24 05:20:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:20:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:20:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:20:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:20:09 --> Upload Class Initialized
INFO - 2025-12-24 05:20:09 --> Helper loaded: text_helper
INFO - 2025-12-24 05:20:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:20:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:20:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:20:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:20:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:20:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:20:09 --> Final output sent to browser
DEBUG - 2025-12-24 05:20:09 --> Total execution time: 0.1879
INFO - 2025-12-24 05:20:17 --> Config Class Initialized
INFO - 2025-12-24 05:20:17 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:20:17 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:20:17 --> Utf8 Class Initialized
INFO - 2025-12-24 05:20:17 --> URI Class Initialized
INFO - 2025-12-24 05:20:17 --> Router Class Initialized
INFO - 2025-12-24 05:20:17 --> Output Class Initialized
INFO - 2025-12-24 05:20:17 --> Security Class Initialized
DEBUG - 2025-12-24 05:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:20:17 --> CSRF cookie sent
INFO - 2025-12-24 05:20:17 --> CSRF token verified
INFO - 2025-12-24 05:20:17 --> Input Class Initialized
INFO - 2025-12-24 05:20:17 --> Language Class Initialized
INFO - 2025-12-24 05:20:17 --> Loader Class Initialized
INFO - 2025-12-24 05:20:17 --> Helper loaded: url_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: form_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: file_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: html_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: security_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:20:17 --> Database Driver Class Initialized
INFO - 2025-12-24 05:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:20:17 --> Form Validation Class Initialized
INFO - 2025-12-24 05:20:17 --> Controller Class Initialized
INFO - 2025-12-24 05:20:17 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:20:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:20:17 --> Upload Class Initialized
INFO - 2025-12-24 05:20:17 --> Helper loaded: text_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:20:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-24 05:20:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated D:\xampp\htdocs\surat_itm\application\controllers\Surat_masuk.php 123
INFO - 2025-12-24 05:20:17 --> Config Class Initialized
INFO - 2025-12-24 05:20:17 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:20:17 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:20:17 --> Utf8 Class Initialized
INFO - 2025-12-24 05:20:17 --> URI Class Initialized
INFO - 2025-12-24 05:20:17 --> Router Class Initialized
INFO - 2025-12-24 05:20:17 --> Output Class Initialized
INFO - 2025-12-24 05:20:17 --> Security Class Initialized
DEBUG - 2025-12-24 05:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:20:17 --> CSRF cookie sent
INFO - 2025-12-24 05:20:17 --> Input Class Initialized
INFO - 2025-12-24 05:20:17 --> Language Class Initialized
INFO - 2025-12-24 05:20:17 --> Loader Class Initialized
INFO - 2025-12-24 05:20:17 --> Helper loaded: url_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: form_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: file_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: html_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: security_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:20:17 --> Database Driver Class Initialized
INFO - 2025-12-24 05:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:20:17 --> Form Validation Class Initialized
INFO - 2025-12-24 05:20:17 --> Controller Class Initialized
INFO - 2025-12-24 05:20:17 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:20:17 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:20:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:20:17 --> Upload Class Initialized
INFO - 2025-12-24 05:20:17 --> Helper loaded: text_helper
INFO - 2025-12-24 05:20:17 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:20:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:20:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:20:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:20:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:20:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:20:17 --> Final output sent to browser
DEBUG - 2025-12-24 05:20:17 --> Total execution time: 0.0565
INFO - 2025-12-24 05:21:52 --> Config Class Initialized
INFO - 2025-12-24 05:21:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:21:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:21:52 --> Utf8 Class Initialized
INFO - 2025-12-24 05:21:52 --> URI Class Initialized
INFO - 2025-12-24 05:21:52 --> Router Class Initialized
INFO - 2025-12-24 05:21:52 --> Output Class Initialized
INFO - 2025-12-24 05:21:52 --> Security Class Initialized
DEBUG - 2025-12-24 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:21:52 --> CSRF cookie sent
INFO - 2025-12-24 05:21:52 --> Input Class Initialized
INFO - 2025-12-24 05:21:52 --> Language Class Initialized
INFO - 2025-12-24 05:21:52 --> Loader Class Initialized
INFO - 2025-12-24 05:21:52 --> Helper loaded: url_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: form_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: file_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: html_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: security_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:21:52 --> Database Driver Class Initialized
INFO - 2025-12-24 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:21:52 --> Form Validation Class Initialized
INFO - 2025-12-24 05:21:52 --> Controller Class Initialized
INFO - 2025-12-24 05:21:52 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:21:52 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:21:52 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:21:52 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:21:52 --> Upload Class Initialized
INFO - 2025-12-24 05:21:52 --> Helper loaded: text_helper
INFO - 2025-12-24 05:21:52 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:21:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:21:52 --> Final output sent to browser
DEBUG - 2025-12-24 05:21:52 --> Total execution time: 0.2761
INFO - 2025-12-24 05:22:01 --> Config Class Initialized
INFO - 2025-12-24 05:22:01 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:01 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:01 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:01 --> URI Class Initialized
INFO - 2025-12-24 05:22:01 --> Router Class Initialized
INFO - 2025-12-24 05:22:01 --> Output Class Initialized
INFO - 2025-12-24 05:22:01 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:01 --> CSRF cookie sent
INFO - 2025-12-24 05:22:01 --> CSRF token verified
INFO - 2025-12-24 05:22:01 --> Input Class Initialized
INFO - 2025-12-24 05:22:01 --> Language Class Initialized
INFO - 2025-12-24 05:22:01 --> Loader Class Initialized
INFO - 2025-12-24 05:22:01 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:01 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:01 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:01 --> Controller Class Initialized
INFO - 2025-12-24 05:22:01 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:01 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:01 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:01 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:01 --> Upload Class Initialized
INFO - 2025-12-24 05:22:01 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:01 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:02 --> Config Class Initialized
INFO - 2025-12-24 05:22:02 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:02 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:02 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:02 --> URI Class Initialized
INFO - 2025-12-24 05:22:02 --> Router Class Initialized
INFO - 2025-12-24 05:22:02 --> Output Class Initialized
INFO - 2025-12-24 05:22:02 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:02 --> CSRF cookie sent
INFO - 2025-12-24 05:22:02 --> Input Class Initialized
INFO - 2025-12-24 05:22:02 --> Language Class Initialized
INFO - 2025-12-24 05:22:02 --> Loader Class Initialized
INFO - 2025-12-24 05:22:02 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:02 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:02 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:02 --> Controller Class Initialized
INFO - 2025-12-24 05:22:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:02 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:02 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:02 --> Upload Class Initialized
INFO - 2025-12-24 05:22:02 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:02 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 05:22:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:22:02 --> Final output sent to browser
DEBUG - 2025-12-24 05:22:02 --> Total execution time: 0.0746
INFO - 2025-12-24 05:22:11 --> Config Class Initialized
INFO - 2025-12-24 05:22:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:11 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:11 --> URI Class Initialized
INFO - 2025-12-24 05:22:11 --> Router Class Initialized
INFO - 2025-12-24 05:22:11 --> Output Class Initialized
INFO - 2025-12-24 05:22:11 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:11 --> CSRF cookie sent
INFO - 2025-12-24 05:22:11 --> CSRF token verified
INFO - 2025-12-24 05:22:11 --> Input Class Initialized
INFO - 2025-12-24 05:22:11 --> Language Class Initialized
INFO - 2025-12-24 05:22:11 --> Loader Class Initialized
INFO - 2025-12-24 05:22:11 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:11 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:11 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:11 --> Controller Class Initialized
INFO - 2025-12-24 05:22:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:11 --> Upload Class Initialized
INFO - 2025-12-24 05:22:11 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 05:22:11 --> Config Class Initialized
INFO - 2025-12-24 05:22:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:11 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:11 --> URI Class Initialized
INFO - 2025-12-24 05:22:11 --> Router Class Initialized
INFO - 2025-12-24 05:22:11 --> Output Class Initialized
INFO - 2025-12-24 05:22:11 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:11 --> CSRF cookie sent
INFO - 2025-12-24 05:22:11 --> Input Class Initialized
INFO - 2025-12-24 05:22:11 --> Language Class Initialized
INFO - 2025-12-24 05:22:11 --> Loader Class Initialized
INFO - 2025-12-24 05:22:11 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:11 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:11 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:11 --> Controller Class Initialized
INFO - 2025-12-24 05:22:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:11 --> Upload Class Initialized
INFO - 2025-12-24 05:22:11 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:11 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:22:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:22:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:22:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:22:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:22:11 --> Final output sent to browser
DEBUG - 2025-12-24 05:22:11 --> Total execution time: 0.0565
INFO - 2025-12-24 05:22:18 --> Config Class Initialized
INFO - 2025-12-24 05:22:18 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:18 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:18 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:18 --> URI Class Initialized
INFO - 2025-12-24 05:22:18 --> Router Class Initialized
INFO - 2025-12-24 05:22:18 --> Output Class Initialized
INFO - 2025-12-24 05:22:18 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:18 --> CSRF cookie sent
INFO - 2025-12-24 05:22:18 --> Input Class Initialized
INFO - 2025-12-24 05:22:18 --> Language Class Initialized
INFO - 2025-12-24 05:22:18 --> Loader Class Initialized
INFO - 2025-12-24 05:22:18 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:18 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:18 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:18 --> Controller Class Initialized
INFO - 2025-12-24 05:22:18 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:18 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:18 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:18 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:18 --> Upload Class Initialized
INFO - 2025-12-24 05:22:18 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:18 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:22:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:22:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:22:27 --> Config Class Initialized
INFO - 2025-12-24 05:22:27 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:27 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:27 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:27 --> URI Class Initialized
INFO - 2025-12-24 05:22:27 --> Router Class Initialized
INFO - 2025-12-24 05:22:27 --> Output Class Initialized
INFO - 2025-12-24 05:22:27 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:27 --> CSRF cookie sent
INFO - 2025-12-24 05:22:27 --> Input Class Initialized
INFO - 2025-12-24 05:22:27 --> Language Class Initialized
INFO - 2025-12-24 05:22:27 --> Loader Class Initialized
INFO - 2025-12-24 05:22:27 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:27 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:27 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:27 --> Controller Class Initialized
INFO - 2025-12-24 05:22:27 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:27 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:27 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:27 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:27 --> Upload Class Initialized
INFO - 2025-12-24 05:22:27 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:27 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:22:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:22:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:22:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:22:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:22:27 --> Final output sent to browser
DEBUG - 2025-12-24 05:22:27 --> Total execution time: 0.0619
INFO - 2025-12-24 05:22:32 --> Config Class Initialized
INFO - 2025-12-24 05:22:32 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:22:32 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:22:32 --> Utf8 Class Initialized
INFO - 2025-12-24 05:22:32 --> URI Class Initialized
INFO - 2025-12-24 05:22:32 --> Router Class Initialized
INFO - 2025-12-24 05:22:32 --> Output Class Initialized
INFO - 2025-12-24 05:22:32 --> Security Class Initialized
DEBUG - 2025-12-24 05:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:22:32 --> CSRF cookie sent
INFO - 2025-12-24 05:22:32 --> Input Class Initialized
INFO - 2025-12-24 05:22:32 --> Language Class Initialized
INFO - 2025-12-24 05:22:32 --> Loader Class Initialized
INFO - 2025-12-24 05:22:32 --> Helper loaded: url_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: form_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: file_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: html_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: security_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:22:32 --> Database Driver Class Initialized
INFO - 2025-12-24 05:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:22:32 --> Form Validation Class Initialized
INFO - 2025-12-24 05:22:32 --> Controller Class Initialized
INFO - 2025-12-24 05:22:32 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:22:32 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:22:32 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:22:32 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:22:32 --> Upload Class Initialized
INFO - 2025-12-24 05:22:32 --> Helper loaded: text_helper
INFO - 2025-12-24 05:22:32 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:22:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:22:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:22:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 05:22:32 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
ERROR - 2025-12-24 05:22:32 --> Severity: Warning --> Undefined property: stdClass::$no_surat_asli D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 41
INFO - 2025-12-24 05:22:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 05:22:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:22:32 --> Final output sent to browser
DEBUG - 2025-12-24 05:22:32 --> Total execution time: 0.0819
INFO - 2025-12-24 05:23:35 --> Config Class Initialized
INFO - 2025-12-24 05:23:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:23:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:23:35 --> Utf8 Class Initialized
INFO - 2025-12-24 05:23:35 --> URI Class Initialized
INFO - 2025-12-24 05:23:35 --> Router Class Initialized
INFO - 2025-12-24 05:23:35 --> Output Class Initialized
INFO - 2025-12-24 05:23:35 --> Security Class Initialized
DEBUG - 2025-12-24 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:23:35 --> CSRF cookie sent
INFO - 2025-12-24 05:23:35 --> Input Class Initialized
INFO - 2025-12-24 05:23:35 --> Language Class Initialized
INFO - 2025-12-24 05:23:35 --> Loader Class Initialized
INFO - 2025-12-24 05:23:35 --> Helper loaded: url_helper
INFO - 2025-12-24 05:23:35 --> Helper loaded: form_helper
INFO - 2025-12-24 05:23:35 --> Helper loaded: file_helper
INFO - 2025-12-24 05:23:35 --> Helper loaded: html_helper
INFO - 2025-12-24 05:23:35 --> Helper loaded: security_helper
INFO - 2025-12-24 05:23:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:23:35 --> Database Driver Class Initialized
INFO - 2025-12-24 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:23:35 --> Form Validation Class Initialized
INFO - 2025-12-24 05:23:35 --> Controller Class Initialized
INFO - 2025-12-24 05:23:35 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 05:23:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:23:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:23:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:23:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 05:23:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:23:35 --> Final output sent to browser
DEBUG - 2025-12-24 05:23:35 --> Total execution time: 0.0697
INFO - 2025-12-24 05:23:40 --> Config Class Initialized
INFO - 2025-12-24 05:23:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:23:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:23:40 --> Utf8 Class Initialized
INFO - 2025-12-24 05:23:40 --> URI Class Initialized
INFO - 2025-12-24 05:23:40 --> Router Class Initialized
INFO - 2025-12-24 05:23:40 --> Output Class Initialized
INFO - 2025-12-24 05:23:40 --> Security Class Initialized
DEBUG - 2025-12-24 05:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:23:40 --> CSRF cookie sent
INFO - 2025-12-24 05:23:40 --> Input Class Initialized
INFO - 2025-12-24 05:23:40 --> Language Class Initialized
INFO - 2025-12-24 05:23:40 --> Loader Class Initialized
INFO - 2025-12-24 05:23:40 --> Helper loaded: url_helper
INFO - 2025-12-24 05:23:40 --> Helper loaded: form_helper
INFO - 2025-12-24 05:23:40 --> Helper loaded: file_helper
INFO - 2025-12-24 05:23:40 --> Helper loaded: html_helper
INFO - 2025-12-24 05:23:40 --> Helper loaded: security_helper
INFO - 2025-12-24 05:23:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:23:40 --> Database Driver Class Initialized
INFO - 2025-12-24 05:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:23:40 --> Form Validation Class Initialized
INFO - 2025-12-24 05:23:40 --> Controller Class Initialized
INFO - 2025-12-24 05:23:40 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 05:23:40 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:23:40 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 05:23:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 05:23:42 --> Config Class Initialized
INFO - 2025-12-24 05:23:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:23:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:23:42 --> Utf8 Class Initialized
INFO - 2025-12-24 05:23:42 --> URI Class Initialized
INFO - 2025-12-24 05:23:42 --> Router Class Initialized
INFO - 2025-12-24 05:23:42 --> Output Class Initialized
INFO - 2025-12-24 05:23:43 --> Security Class Initialized
DEBUG - 2025-12-24 05:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:23:43 --> CSRF cookie sent
INFO - 2025-12-24 05:23:43 --> Input Class Initialized
INFO - 2025-12-24 05:23:43 --> Language Class Initialized
INFO - 2025-12-24 05:23:43 --> Loader Class Initialized
INFO - 2025-12-24 05:23:43 --> Helper loaded: url_helper
INFO - 2025-12-24 05:23:43 --> Helper loaded: form_helper
INFO - 2025-12-24 05:23:43 --> Helper loaded: file_helper
INFO - 2025-12-24 05:23:43 --> Helper loaded: html_helper
INFO - 2025-12-24 05:23:43 --> Helper loaded: security_helper
INFO - 2025-12-24 05:23:43 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:23:43 --> Database Driver Class Initialized
INFO - 2025-12-24 05:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:23:43 --> Form Validation Class Initialized
INFO - 2025-12-24 05:23:43 --> Controller Class Initialized
INFO - 2025-12-24 05:23:43 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 05:23:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:23:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:23:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:23:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 05:23:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:23:43 --> Final output sent to browser
DEBUG - 2025-12-24 05:23:43 --> Total execution time: 0.0526
INFO - 2025-12-24 05:23:50 --> Config Class Initialized
INFO - 2025-12-24 05:23:50 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:23:50 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:23:50 --> Utf8 Class Initialized
INFO - 2025-12-24 05:23:50 --> URI Class Initialized
INFO - 2025-12-24 05:23:50 --> Router Class Initialized
INFO - 2025-12-24 05:23:50 --> Output Class Initialized
INFO - 2025-12-24 05:23:50 --> Security Class Initialized
DEBUG - 2025-12-24 05:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:23:50 --> CSRF cookie sent
INFO - 2025-12-24 05:23:50 --> Input Class Initialized
INFO - 2025-12-24 05:23:50 --> Language Class Initialized
INFO - 2025-12-24 05:23:50 --> Loader Class Initialized
INFO - 2025-12-24 05:23:50 --> Helper loaded: url_helper
INFO - 2025-12-24 05:23:50 --> Helper loaded: form_helper
INFO - 2025-12-24 05:23:50 --> Helper loaded: file_helper
INFO - 2025-12-24 05:23:50 --> Helper loaded: html_helper
INFO - 2025-12-24 05:23:50 --> Helper loaded: security_helper
INFO - 2025-12-24 05:23:50 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:23:50 --> Database Driver Class Initialized
INFO - 2025-12-24 05:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:23:50 --> Form Validation Class Initialized
INFO - 2025-12-24 05:23:50 --> Controller Class Initialized
INFO - 2025-12-24 05:23:50 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 05:23:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:23:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:23:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:23:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 05:23:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:23:50 --> Final output sent to browser
DEBUG - 2025-12-24 05:23:50 --> Total execution time: 0.0494
INFO - 2025-12-24 05:23:53 --> Config Class Initialized
INFO - 2025-12-24 05:23:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:23:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:23:53 --> Utf8 Class Initialized
INFO - 2025-12-24 05:23:53 --> URI Class Initialized
INFO - 2025-12-24 05:23:53 --> Router Class Initialized
INFO - 2025-12-24 05:23:53 --> Output Class Initialized
INFO - 2025-12-24 05:23:53 --> Security Class Initialized
DEBUG - 2025-12-24 05:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:23:53 --> CSRF cookie sent
INFO - 2025-12-24 05:23:53 --> Input Class Initialized
INFO - 2025-12-24 05:23:53 --> Language Class Initialized
INFO - 2025-12-24 05:23:53 --> Loader Class Initialized
INFO - 2025-12-24 05:23:53 --> Helper loaded: url_helper
INFO - 2025-12-24 05:23:53 --> Helper loaded: form_helper
INFO - 2025-12-24 05:23:53 --> Helper loaded: file_helper
INFO - 2025-12-24 05:23:53 --> Helper loaded: html_helper
INFO - 2025-12-24 05:23:53 --> Helper loaded: security_helper
INFO - 2025-12-24 05:23:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:23:53 --> Database Driver Class Initialized
INFO - 2025-12-24 05:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:23:53 --> Form Validation Class Initialized
INFO - 2025-12-24 05:23:53 --> Controller Class Initialized
INFO - 2025-12-24 05:23:53 --> Model "User_model" initialized
INFO - 2025-12-24 05:23:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:23:53 --> Upload Class Initialized
INFO - 2025-12-24 05:23:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:23:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:23:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 05:23:53 --> Severity: Warning --> Undefined property: stdClass::$tanda_tangan D:\xampp\htdocs\surat_itm\application\views\profil\index.php 133
INFO - 2025-12-24 05:23:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\profil/index.php
INFO - 2025-12-24 05:23:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:23:53 --> Final output sent to browser
DEBUG - 2025-12-24 05:23:53 --> Total execution time: 0.1405
INFO - 2025-12-24 05:24:08 --> Config Class Initialized
INFO - 2025-12-24 05:24:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 05:24:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 05:24:08 --> Utf8 Class Initialized
INFO - 2025-12-24 05:24:08 --> URI Class Initialized
INFO - 2025-12-24 05:24:08 --> Router Class Initialized
INFO - 2025-12-24 05:24:08 --> Output Class Initialized
INFO - 2025-12-24 05:24:08 --> Security Class Initialized
DEBUG - 2025-12-24 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 05:24:08 --> CSRF cookie sent
INFO - 2025-12-24 05:24:08 --> Input Class Initialized
INFO - 2025-12-24 05:24:08 --> Language Class Initialized
INFO - 2025-12-24 05:24:08 --> Loader Class Initialized
INFO - 2025-12-24 05:24:08 --> Helper loaded: url_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: form_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: file_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: html_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: security_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 05:24:08 --> Database Driver Class Initialized
INFO - 2025-12-24 05:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 05:24:08 --> Form Validation Class Initialized
INFO - 2025-12-24 05:24:08 --> Controller Class Initialized
INFO - 2025-12-24 05:24:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 05:24:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 05:24:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 05:24:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 05:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 05:24:08 --> Upload Class Initialized
INFO - 2025-12-24 05:24:08 --> Helper loaded: text_helper
INFO - 2025-12-24 05:24:08 --> Helper loaded: custom_helper
INFO - 2025-12-24 05:24:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 05:24:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 05:24:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 05:24:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 05:24:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 05:24:08 --> Final output sent to browser
DEBUG - 2025-12-24 05:24:08 --> Total execution time: 0.0564
INFO - 2025-12-24 07:51:21 --> Config Class Initialized
INFO - 2025-12-24 07:51:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:21 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:21 --> URI Class Initialized
INFO - 2025-12-24 07:51:21 --> Router Class Initialized
INFO - 2025-12-24 07:51:21 --> Output Class Initialized
INFO - 2025-12-24 07:51:21 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:21 --> CSRF cookie sent
INFO - 2025-12-24 07:51:21 --> Input Class Initialized
INFO - 2025-12-24 07:51:21 --> Language Class Initialized
INFO - 2025-12-24 07:51:22 --> Loader Class Initialized
INFO - 2025-12-24 07:51:22 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:22 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:22 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:22 --> Controller Class Initialized
INFO - 2025-12-24 07:51:22 --> Config Class Initialized
INFO - 2025-12-24 07:51:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:22 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:22 --> URI Class Initialized
INFO - 2025-12-24 07:51:22 --> Router Class Initialized
INFO - 2025-12-24 07:51:22 --> Output Class Initialized
INFO - 2025-12-24 07:51:22 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:22 --> CSRF cookie sent
INFO - 2025-12-24 07:51:22 --> Input Class Initialized
INFO - 2025-12-24 07:51:22 --> Language Class Initialized
INFO - 2025-12-24 07:51:22 --> Loader Class Initialized
INFO - 2025-12-24 07:51:22 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:22 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:22 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:22 --> Controller Class Initialized
INFO - 2025-12-24 07:51:22 --> Model "User_model" initialized
DEBUG - 2025-12-24 07:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:51:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-24 07:51:23 --> Final output sent to browser
DEBUG - 2025-12-24 07:51:23 --> Total execution time: 0.3928
INFO - 2025-12-24 07:51:30 --> Config Class Initialized
INFO - 2025-12-24 07:51:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:30 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:30 --> URI Class Initialized
INFO - 2025-12-24 07:51:30 --> Router Class Initialized
INFO - 2025-12-24 07:51:30 --> Output Class Initialized
INFO - 2025-12-24 07:51:30 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:30 --> CSRF cookie sent
INFO - 2025-12-24 07:51:30 --> CSRF token verified
INFO - 2025-12-24 07:51:30 --> Input Class Initialized
INFO - 2025-12-24 07:51:30 --> Language Class Initialized
INFO - 2025-12-24 07:51:30 --> Loader Class Initialized
INFO - 2025-12-24 07:51:30 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:30 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:30 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:30 --> Controller Class Initialized
INFO - 2025-12-24 07:51:30 --> Model "User_model" initialized
DEBUG - 2025-12-24 07:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:51:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 07:51:30 --> Config Class Initialized
INFO - 2025-12-24 07:51:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:30 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:30 --> URI Class Initialized
INFO - 2025-12-24 07:51:30 --> Router Class Initialized
INFO - 2025-12-24 07:51:30 --> Output Class Initialized
INFO - 2025-12-24 07:51:30 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:30 --> CSRF cookie sent
INFO - 2025-12-24 07:51:30 --> Input Class Initialized
INFO - 2025-12-24 07:51:30 --> Language Class Initialized
INFO - 2025-12-24 07:51:30 --> Loader Class Initialized
INFO - 2025-12-24 07:51:30 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:30 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:30 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:30 --> Controller Class Initialized
INFO - 2025-12-24 07:51:30 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 07:51:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:51:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:51:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:51:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 07:51:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:51:30 --> Final output sent to browser
DEBUG - 2025-12-24 07:51:30 --> Total execution time: 0.2640
INFO - 2025-12-24 07:51:34 --> Config Class Initialized
INFO - 2025-12-24 07:51:34 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:34 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:34 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:34 --> URI Class Initialized
INFO - 2025-12-24 07:51:34 --> Router Class Initialized
INFO - 2025-12-24 07:51:34 --> Output Class Initialized
INFO - 2025-12-24 07:51:34 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:34 --> CSRF cookie sent
INFO - 2025-12-24 07:51:34 --> Input Class Initialized
INFO - 2025-12-24 07:51:34 --> Language Class Initialized
INFO - 2025-12-24 07:51:34 --> Loader Class Initialized
INFO - 2025-12-24 07:51:34 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:34 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:34 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:34 --> Controller Class Initialized
INFO - 2025-12-24 07:51:34 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:51:34 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:51:34 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:51:34 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:51:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:51:34 --> Upload Class Initialized
INFO - 2025-12-24 07:51:34 --> Helper loaded: text_helper
INFO - 2025-12-24 07:51:34 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:51:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:51:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:51:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:51:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 07:51:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:51:34 --> Final output sent to browser
DEBUG - 2025-12-24 07:51:34 --> Total execution time: 0.3653
INFO - 2025-12-24 07:51:37 --> Config Class Initialized
INFO - 2025-12-24 07:51:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:51:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:51:37 --> Utf8 Class Initialized
INFO - 2025-12-24 07:51:37 --> URI Class Initialized
INFO - 2025-12-24 07:51:37 --> Router Class Initialized
INFO - 2025-12-24 07:51:37 --> Output Class Initialized
INFO - 2025-12-24 07:51:37 --> Security Class Initialized
DEBUG - 2025-12-24 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:51:37 --> CSRF cookie sent
INFO - 2025-12-24 07:51:37 --> Input Class Initialized
INFO - 2025-12-24 07:51:37 --> Language Class Initialized
INFO - 2025-12-24 07:51:37 --> Loader Class Initialized
INFO - 2025-12-24 07:51:37 --> Helper loaded: url_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: form_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: file_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: html_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: security_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:51:37 --> Database Driver Class Initialized
INFO - 2025-12-24 07:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:51:37 --> Form Validation Class Initialized
INFO - 2025-12-24 07:51:37 --> Controller Class Initialized
INFO - 2025-12-24 07:51:37 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:51:37 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:51:37 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:51:37 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:51:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:51:37 --> Upload Class Initialized
INFO - 2025-12-24 07:51:37 --> Helper loaded: text_helper
INFO - 2025-12-24 07:51:37 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:51:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:51:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:51:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 07:51:37 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
ERROR - 2025-12-24 07:51:37 --> Severity: Warning --> Undefined property: stdClass::$no_surat_asli D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 41
INFO - 2025-12-24 07:51:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 07:51:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:51:37 --> Final output sent to browser
DEBUG - 2025-12-24 07:51:37 --> Total execution time: 0.0700
INFO - 2025-12-24 07:53:59 --> Config Class Initialized
INFO - 2025-12-24 07:53:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:53:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:53:59 --> Utf8 Class Initialized
INFO - 2025-12-24 07:53:59 --> URI Class Initialized
INFO - 2025-12-24 07:53:59 --> Router Class Initialized
INFO - 2025-12-24 07:53:59 --> Output Class Initialized
INFO - 2025-12-24 07:53:59 --> Security Class Initialized
DEBUG - 2025-12-24 07:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:53:59 --> CSRF cookie sent
INFO - 2025-12-24 07:53:59 --> Input Class Initialized
INFO - 2025-12-24 07:53:59 --> Language Class Initialized
INFO - 2025-12-24 07:53:59 --> Loader Class Initialized
INFO - 2025-12-24 07:53:59 --> Helper loaded: url_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: form_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: file_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: html_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: security_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:53:59 --> Database Driver Class Initialized
INFO - 2025-12-24 07:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:53:59 --> Form Validation Class Initialized
INFO - 2025-12-24 07:53:59 --> Controller Class Initialized
INFO - 2025-12-24 07:53:59 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:53:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:53:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:53:59 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:53:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:53:59 --> Upload Class Initialized
INFO - 2025-12-24 07:53:59 --> Helper loaded: text_helper
INFO - 2025-12-24 07:53:59 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:53:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:53:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:53:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 07:53:59 --> Severity: Warning --> Undefined variable $s D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
ERROR - 2025-12-24 07:53:59 --> Severity: Warning --> Attempt to read property "no_surat" on null D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
INFO - 2025-12-24 07:53:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 07:53:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:53:59 --> Final output sent to browser
DEBUG - 2025-12-24 07:53:59 --> Total execution time: 0.0603
INFO - 2025-12-24 07:54:00 --> Config Class Initialized
INFO - 2025-12-24 07:54:00 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:00 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:00 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:00 --> URI Class Initialized
INFO - 2025-12-24 07:54:00 --> Router Class Initialized
INFO - 2025-12-24 07:54:00 --> Output Class Initialized
INFO - 2025-12-24 07:54:00 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:00 --> CSRF cookie sent
INFO - 2025-12-24 07:54:00 --> Input Class Initialized
INFO - 2025-12-24 07:54:00 --> Language Class Initialized
INFO - 2025-12-24 07:54:00 --> Loader Class Initialized
INFO - 2025-12-24 07:54:00 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:00 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:00 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:00 --> Controller Class Initialized
INFO - 2025-12-24 07:54:00 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:54:00 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:54:00 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:54:00 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:54:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:00 --> Upload Class Initialized
INFO - 2025-12-24 07:54:00 --> Helper loaded: text_helper
INFO - 2025-12-24 07:54:00 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:54:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 07:54:00 --> Severity: Warning --> Undefined variable $s D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
ERROR - 2025-12-24 07:54:00 --> Severity: Warning --> Attempt to read property "no_surat" on null D:\xampp\htdocs\surat_itm\application\views\surat_masuk\detail.php 37
INFO - 2025-12-24 07:54:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 07:54:00 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:00 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:00 --> Total execution time: 0.0687
INFO - 2025-12-24 07:54:24 --> Config Class Initialized
INFO - 2025-12-24 07:54:24 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:24 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:24 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:24 --> URI Class Initialized
INFO - 2025-12-24 07:54:24 --> Router Class Initialized
INFO - 2025-12-24 07:54:24 --> Output Class Initialized
INFO - 2025-12-24 07:54:24 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:24 --> CSRF cookie sent
INFO - 2025-12-24 07:54:24 --> Input Class Initialized
INFO - 2025-12-24 07:54:24 --> Language Class Initialized
INFO - 2025-12-24 07:54:24 --> Loader Class Initialized
INFO - 2025-12-24 07:54:24 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:24 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:24 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:24 --> Controller Class Initialized
INFO - 2025-12-24 07:54:24 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:54:24 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:54:24 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:54:24 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:54:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:24 --> Upload Class Initialized
INFO - 2025-12-24 07:54:24 --> Helper loaded: text_helper
INFO - 2025-12-24 07:54:24 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:54:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 07:54:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:24 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:24 --> Total execution time: 0.1263
INFO - 2025-12-24 07:54:31 --> Config Class Initialized
INFO - 2025-12-24 07:54:31 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:31 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:31 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:31 --> URI Class Initialized
INFO - 2025-12-24 07:54:31 --> Router Class Initialized
INFO - 2025-12-24 07:54:31 --> Output Class Initialized
INFO - 2025-12-24 07:54:31 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:31 --> CSRF cookie sent
INFO - 2025-12-24 07:54:31 --> Input Class Initialized
INFO - 2025-12-24 07:54:31 --> Language Class Initialized
INFO - 2025-12-24 07:54:31 --> Loader Class Initialized
INFO - 2025-12-24 07:54:31 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:31 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:31 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:31 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:31 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:31 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:31 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:31 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:31 --> Controller Class Initialized
INFO - 2025-12-24 07:54:31 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 07:54:31 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 07:54:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/form.php
INFO - 2025-12-24 07:54:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:31 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:31 --> Total execution time: 0.1181
INFO - 2025-12-24 07:54:34 --> Config Class Initialized
INFO - 2025-12-24 07:54:34 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:34 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:34 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:34 --> URI Class Initialized
INFO - 2025-12-24 07:54:34 --> Router Class Initialized
INFO - 2025-12-24 07:54:34 --> Output Class Initialized
INFO - 2025-12-24 07:54:34 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:34 --> CSRF cookie sent
INFO - 2025-12-24 07:54:34 --> Input Class Initialized
INFO - 2025-12-24 07:54:34 --> Language Class Initialized
INFO - 2025-12-24 07:54:34 --> Loader Class Initialized
INFO - 2025-12-24 07:54:34 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:34 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:34 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:34 --> Controller Class Initialized
INFO - 2025-12-24 07:54:34 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 07:54:34 --> Model "Bagian_model" initialized
INFO - 2025-12-24 07:54:34 --> Model "Kategori_model" initialized
INFO - 2025-12-24 07:54:34 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 07:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:34 --> Upload Class Initialized
INFO - 2025-12-24 07:54:34 --> Helper loaded: text_helper
INFO - 2025-12-24 07:54:34 --> Helper loaded: custom_helper
INFO - 2025-12-24 07:54:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 07:54:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:34 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:34 --> Total execution time: 0.0555
INFO - 2025-12-24 07:54:36 --> Config Class Initialized
INFO - 2025-12-24 07:54:36 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:36 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:36 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:36 --> URI Class Initialized
INFO - 2025-12-24 07:54:36 --> Router Class Initialized
INFO - 2025-12-24 07:54:36 --> Output Class Initialized
INFO - 2025-12-24 07:54:36 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:36 --> CSRF cookie sent
INFO - 2025-12-24 07:54:36 --> Input Class Initialized
INFO - 2025-12-24 07:54:36 --> Language Class Initialized
INFO - 2025-12-24 07:54:36 --> Loader Class Initialized
INFO - 2025-12-24 07:54:36 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:36 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:36 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:36 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:36 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:36 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:36 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:36 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:36 --> Controller Class Initialized
INFO - 2025-12-24 07:54:36 --> Model "User_model" initialized
INFO - 2025-12-24 07:54:36 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 07:54:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:36 --> Upload Class Initialized
INFO - 2025-12-24 07:54:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-24 07:54:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:36 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:36 --> Total execution time: 0.1611
INFO - 2025-12-24 07:54:38 --> Config Class Initialized
INFO - 2025-12-24 07:54:38 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:38 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:38 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:38 --> URI Class Initialized
INFO - 2025-12-24 07:54:38 --> Router Class Initialized
INFO - 2025-12-24 07:54:38 --> Output Class Initialized
INFO - 2025-12-24 07:54:38 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:38 --> CSRF cookie sent
INFO - 2025-12-24 07:54:38 --> Input Class Initialized
INFO - 2025-12-24 07:54:38 --> Language Class Initialized
INFO - 2025-12-24 07:54:38 --> Loader Class Initialized
INFO - 2025-12-24 07:54:38 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:38 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:38 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:38 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:38 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:38 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:38 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:38 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:38 --> Controller Class Initialized
INFO - 2025-12-24 07:54:38 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 07:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-24 07:54:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:38 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:38 --> Total execution time: 0.0931
INFO - 2025-12-24 07:54:40 --> Config Class Initialized
INFO - 2025-12-24 07:54:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:40 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:40 --> URI Class Initialized
INFO - 2025-12-24 07:54:40 --> Router Class Initialized
INFO - 2025-12-24 07:54:40 --> Output Class Initialized
INFO - 2025-12-24 07:54:40 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:40 --> CSRF cookie sent
INFO - 2025-12-24 07:54:40 --> Input Class Initialized
INFO - 2025-12-24 07:54:40 --> Language Class Initialized
INFO - 2025-12-24 07:54:40 --> Loader Class Initialized
INFO - 2025-12-24 07:54:40 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:40 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:40 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:40 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:40 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:40 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:40 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:40 --> Controller Class Initialized
INFO - 2025-12-24 07:54:40 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 07:54:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 07:54:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:40 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:40 --> Total execution time: 0.1355
INFO - 2025-12-24 07:54:41 --> Config Class Initialized
INFO - 2025-12-24 07:54:41 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:41 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:41 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:41 --> URI Class Initialized
INFO - 2025-12-24 07:54:41 --> Router Class Initialized
INFO - 2025-12-24 07:54:41 --> Output Class Initialized
INFO - 2025-12-24 07:54:41 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:41 --> CSRF cookie sent
INFO - 2025-12-24 07:54:41 --> Input Class Initialized
INFO - 2025-12-24 07:54:41 --> Language Class Initialized
INFO - 2025-12-24 07:54:41 --> Loader Class Initialized
INFO - 2025-12-24 07:54:41 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:41 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:41 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:41 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:41 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:41 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:41 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:41 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:41 --> Controller Class Initialized
INFO - 2025-12-24 07:54:41 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 07:54:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-24 07:54:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:41 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:41 --> Total execution time: 0.0486
INFO - 2025-12-24 07:54:42 --> Config Class Initialized
INFO - 2025-12-24 07:54:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:42 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:42 --> URI Class Initialized
INFO - 2025-12-24 07:54:42 --> Router Class Initialized
INFO - 2025-12-24 07:54:42 --> Output Class Initialized
INFO - 2025-12-24 07:54:42 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:42 --> CSRF cookie sent
INFO - 2025-12-24 07:54:42 --> Input Class Initialized
INFO - 2025-12-24 07:54:42 --> Language Class Initialized
INFO - 2025-12-24 07:54:42 --> Loader Class Initialized
INFO - 2025-12-24 07:54:42 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:42 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:42 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:42 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:42 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:42 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:42 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:42 --> Controller Class Initialized
INFO - 2025-12-24 07:54:42 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 07:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 07:54:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 07:54:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 07:54:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 07:54:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 07:54:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 07:54:42 --> Final output sent to browser
DEBUG - 2025-12-24 07:54:42 --> Total execution time: 0.0508
INFO - 2025-12-24 07:54:47 --> Config Class Initialized
INFO - 2025-12-24 07:54:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 07:54:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 07:54:47 --> Utf8 Class Initialized
INFO - 2025-12-24 07:54:47 --> URI Class Initialized
INFO - 2025-12-24 07:54:47 --> Router Class Initialized
INFO - 2025-12-24 07:54:47 --> Output Class Initialized
INFO - 2025-12-24 07:54:47 --> Security Class Initialized
DEBUG - 2025-12-24 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 07:54:47 --> CSRF cookie sent
INFO - 2025-12-24 07:54:47 --> Input Class Initialized
INFO - 2025-12-24 07:54:47 --> Language Class Initialized
INFO - 2025-12-24 07:54:47 --> Loader Class Initialized
INFO - 2025-12-24 07:54:47 --> Helper loaded: url_helper
INFO - 2025-12-24 07:54:47 --> Helper loaded: form_helper
INFO - 2025-12-24 07:54:47 --> Helper loaded: file_helper
INFO - 2025-12-24 07:54:47 --> Helper loaded: html_helper
INFO - 2025-12-24 07:54:47 --> Helper loaded: security_helper
INFO - 2025-12-24 07:54:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 07:54:47 --> Database Driver Class Initialized
INFO - 2025-12-24 07:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 07:54:47 --> Form Validation Class Initialized
INFO - 2025-12-24 07:54:47 --> Controller Class Initialized
INFO - 2025-12-24 07:54:47 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 07:54:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-12-24 07:54:47 --> Query error: Unknown column 'kategori' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `surat_masuk`
WHERE `kategori` = '16'
INFO - 2025-12-24 07:54:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 08:05:09 --> Config Class Initialized
INFO - 2025-12-24 08:05:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:05:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:05:09 --> Utf8 Class Initialized
INFO - 2025-12-24 08:05:09 --> URI Class Initialized
INFO - 2025-12-24 08:05:09 --> Router Class Initialized
INFO - 2025-12-24 08:05:09 --> Output Class Initialized
INFO - 2025-12-24 08:05:09 --> Security Class Initialized
DEBUG - 2025-12-24 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:05:09 --> CSRF cookie sent
INFO - 2025-12-24 08:05:09 --> Input Class Initialized
INFO - 2025-12-24 08:05:09 --> Language Class Initialized
INFO - 2025-12-24 08:05:09 --> Loader Class Initialized
INFO - 2025-12-24 08:05:09 --> Helper loaded: url_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: form_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: file_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: html_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: security_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:05:09 --> Database Driver Class Initialized
INFO - 2025-12-24 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:05:09 --> Form Validation Class Initialized
INFO - 2025-12-24 08:05:09 --> Controller Class Initialized
INFO - 2025-12-24 08:05:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:05:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:05:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:05:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:05:09 --> Upload Class Initialized
INFO - 2025-12-24 08:05:09 --> Helper loaded: text_helper
INFO - 2025-12-24 08:05:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:05:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:05:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:05:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:05:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 08:05:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:05:09 --> Final output sent to browser
DEBUG - 2025-12-24 08:05:09 --> Total execution time: 0.3058
INFO - 2025-12-24 08:05:11 --> Config Class Initialized
INFO - 2025-12-24 08:05:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:05:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:05:11 --> Utf8 Class Initialized
INFO - 2025-12-24 08:05:11 --> URI Class Initialized
INFO - 2025-12-24 08:05:11 --> Router Class Initialized
INFO - 2025-12-24 08:05:11 --> Output Class Initialized
INFO - 2025-12-24 08:05:11 --> Security Class Initialized
DEBUG - 2025-12-24 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:05:11 --> CSRF cookie sent
INFO - 2025-12-24 08:05:11 --> Input Class Initialized
INFO - 2025-12-24 08:05:11 --> Language Class Initialized
INFO - 2025-12-24 08:05:11 --> Loader Class Initialized
INFO - 2025-12-24 08:05:11 --> Helper loaded: url_helper
INFO - 2025-12-24 08:05:11 --> Helper loaded: form_helper
INFO - 2025-12-24 08:05:11 --> Helper loaded: file_helper
INFO - 2025-12-24 08:05:11 --> Helper loaded: html_helper
INFO - 2025-12-24 08:05:11 --> Helper loaded: security_helper
INFO - 2025-12-24 08:05:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:05:11 --> Database Driver Class Initialized
INFO - 2025-12-24 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:05:11 --> Form Validation Class Initialized
INFO - 2025-12-24 08:05:11 --> Controller Class Initialized
INFO - 2025-12-24 08:05:11 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 08:05:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:05:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:05:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:05:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 08:05:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:05:11 --> Final output sent to browser
DEBUG - 2025-12-24 08:05:11 --> Total execution time: 0.0525
INFO - 2025-12-24 08:05:13 --> Config Class Initialized
INFO - 2025-12-24 08:05:13 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:05:13 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:05:13 --> Utf8 Class Initialized
INFO - 2025-12-24 08:05:13 --> URI Class Initialized
INFO - 2025-12-24 08:05:13 --> Router Class Initialized
INFO - 2025-12-24 08:05:13 --> Output Class Initialized
INFO - 2025-12-24 08:05:13 --> Security Class Initialized
DEBUG - 2025-12-24 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:05:13 --> CSRF cookie sent
INFO - 2025-12-24 08:05:13 --> Input Class Initialized
INFO - 2025-12-24 08:05:13 --> Language Class Initialized
INFO - 2025-12-24 08:05:13 --> Loader Class Initialized
INFO - 2025-12-24 08:05:13 --> Helper loaded: url_helper
INFO - 2025-12-24 08:05:13 --> Helper loaded: form_helper
INFO - 2025-12-24 08:05:13 --> Helper loaded: file_helper
INFO - 2025-12-24 08:05:13 --> Helper loaded: html_helper
INFO - 2025-12-24 08:05:13 --> Helper loaded: security_helper
INFO - 2025-12-24 08:05:13 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:05:13 --> Database Driver Class Initialized
INFO - 2025-12-24 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:05:13 --> Form Validation Class Initialized
INFO - 2025-12-24 08:05:13 --> Controller Class Initialized
INFO - 2025-12-24 08:05:13 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:05:13 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:05:13 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 08:05:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 08:11:27 --> Config Class Initialized
INFO - 2025-12-24 08:11:27 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:11:27 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:11:27 --> Utf8 Class Initialized
INFO - 2025-12-24 08:11:27 --> URI Class Initialized
INFO - 2025-12-24 08:11:27 --> Router Class Initialized
INFO - 2025-12-24 08:11:27 --> Output Class Initialized
INFO - 2025-12-24 08:11:27 --> Security Class Initialized
DEBUG - 2025-12-24 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:11:27 --> CSRF cookie sent
INFO - 2025-12-24 08:11:27 --> Input Class Initialized
INFO - 2025-12-24 08:11:27 --> Language Class Initialized
INFO - 2025-12-24 08:11:27 --> Loader Class Initialized
INFO - 2025-12-24 08:11:27 --> Helper loaded: url_helper
INFO - 2025-12-24 08:11:27 --> Helper loaded: form_helper
INFO - 2025-12-24 08:11:27 --> Helper loaded: file_helper
INFO - 2025-12-24 08:11:27 --> Helper loaded: html_helper
INFO - 2025-12-24 08:11:27 --> Helper loaded: security_helper
INFO - 2025-12-24 08:11:27 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:11:27 --> Database Driver Class Initialized
INFO - 2025-12-24 08:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:11:27 --> Form Validation Class Initialized
INFO - 2025-12-24 08:11:27 --> Controller Class Initialized
INFO - 2025-12-24 08:11:27 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 08:11:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:11:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:11:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:11:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 08:11:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:11:27 --> Final output sent to browser
DEBUG - 2025-12-24 08:11:27 --> Total execution time: 0.0807
INFO - 2025-12-24 08:11:29 --> Config Class Initialized
INFO - 2025-12-24 08:11:29 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:11:29 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:11:29 --> Utf8 Class Initialized
INFO - 2025-12-24 08:11:29 --> URI Class Initialized
INFO - 2025-12-24 08:11:29 --> Router Class Initialized
INFO - 2025-12-24 08:11:29 --> Output Class Initialized
INFO - 2025-12-24 08:11:29 --> Security Class Initialized
DEBUG - 2025-12-24 08:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:11:29 --> CSRF cookie sent
INFO - 2025-12-24 08:11:29 --> Input Class Initialized
INFO - 2025-12-24 08:11:29 --> Language Class Initialized
INFO - 2025-12-24 08:11:29 --> Loader Class Initialized
INFO - 2025-12-24 08:11:29 --> Helper loaded: url_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: form_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: file_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: html_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: security_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:11:29 --> Database Driver Class Initialized
INFO - 2025-12-24 08:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:11:29 --> Form Validation Class Initialized
INFO - 2025-12-24 08:11:29 --> Controller Class Initialized
INFO - 2025-12-24 08:11:29 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:11:29 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:11:29 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:11:29 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:11:29 --> Upload Class Initialized
INFO - 2025-12-24 08:11:29 --> Helper loaded: text_helper
INFO - 2025-12-24 08:11:29 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:11:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:11:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:11:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:11:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:11:29 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:11:29 --> Final output sent to browser
DEBUG - 2025-12-24 08:11:29 --> Total execution time: 0.0679
INFO - 2025-12-24 08:11:31 --> Config Class Initialized
INFO - 2025-12-24 08:11:31 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:11:31 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:11:31 --> Utf8 Class Initialized
INFO - 2025-12-24 08:11:31 --> URI Class Initialized
INFO - 2025-12-24 08:11:31 --> Router Class Initialized
INFO - 2025-12-24 08:11:31 --> Output Class Initialized
INFO - 2025-12-24 08:11:31 --> Security Class Initialized
DEBUG - 2025-12-24 08:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:11:31 --> CSRF cookie sent
INFO - 2025-12-24 08:11:31 --> Input Class Initialized
INFO - 2025-12-24 08:11:31 --> Language Class Initialized
INFO - 2025-12-24 08:11:31 --> Loader Class Initialized
INFO - 2025-12-24 08:11:31 --> Helper loaded: url_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: form_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: file_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: html_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: security_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:11:31 --> Database Driver Class Initialized
INFO - 2025-12-24 08:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:11:31 --> Form Validation Class Initialized
INFO - 2025-12-24 08:11:31 --> Controller Class Initialized
INFO - 2025-12-24 08:11:31 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:11:31 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:11:31 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:11:31 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:11:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:11:31 --> Upload Class Initialized
INFO - 2025-12-24 08:11:31 --> Helper loaded: text_helper
INFO - 2025-12-24 08:11:31 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:11:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:11:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:11:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:11:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 08:11:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:11:31 --> Final output sent to browser
DEBUG - 2025-12-24 08:11:31 --> Total execution time: 0.0558
INFO - 2025-12-24 08:11:54 --> Config Class Initialized
INFO - 2025-12-24 08:11:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:11:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:11:54 --> Utf8 Class Initialized
INFO - 2025-12-24 08:11:54 --> URI Class Initialized
INFO - 2025-12-24 08:11:54 --> Router Class Initialized
INFO - 2025-12-24 08:11:54 --> Output Class Initialized
INFO - 2025-12-24 08:11:54 --> Security Class Initialized
DEBUG - 2025-12-24 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:11:54 --> CSRF cookie sent
INFO - 2025-12-24 08:11:54 --> CSRF token verified
INFO - 2025-12-24 08:11:54 --> Input Class Initialized
INFO - 2025-12-24 08:11:54 --> Language Class Initialized
INFO - 2025-12-24 08:11:54 --> Loader Class Initialized
INFO - 2025-12-24 08:11:54 --> Helper loaded: url_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: form_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: file_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: html_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: security_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:11:54 --> Database Driver Class Initialized
INFO - 2025-12-24 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:11:54 --> Form Validation Class Initialized
INFO - 2025-12-24 08:11:54 --> Controller Class Initialized
INFO - 2025-12-24 08:11:54 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:11:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:11:54 --> Upload Class Initialized
INFO - 2025-12-24 08:11:54 --> Helper loaded: text_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:11:54 --> Config Class Initialized
INFO - 2025-12-24 08:11:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:11:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:11:54 --> Utf8 Class Initialized
INFO - 2025-12-24 08:11:54 --> URI Class Initialized
INFO - 2025-12-24 08:11:54 --> Router Class Initialized
INFO - 2025-12-24 08:11:54 --> Output Class Initialized
INFO - 2025-12-24 08:11:54 --> Security Class Initialized
DEBUG - 2025-12-24 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:11:54 --> CSRF cookie sent
INFO - 2025-12-24 08:11:54 --> Input Class Initialized
INFO - 2025-12-24 08:11:54 --> Language Class Initialized
INFO - 2025-12-24 08:11:54 --> Loader Class Initialized
INFO - 2025-12-24 08:11:54 --> Helper loaded: url_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: form_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: file_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: html_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: security_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:11:54 --> Database Driver Class Initialized
INFO - 2025-12-24 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:11:54 --> Form Validation Class Initialized
INFO - 2025-12-24 08:11:54 --> Controller Class Initialized
INFO - 2025-12-24 08:11:54 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:11:54 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:11:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:11:54 --> Upload Class Initialized
INFO - 2025-12-24 08:11:54 --> Helper loaded: text_helper
INFO - 2025-12-24 08:11:54 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:11:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:11:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:11:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:11:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 08:11:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:11:54 --> Final output sent to browser
DEBUG - 2025-12-24 08:11:54 --> Total execution time: 0.0604
INFO - 2025-12-24 08:12:09 --> Config Class Initialized
INFO - 2025-12-24 08:12:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:09 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:09 --> URI Class Initialized
INFO - 2025-12-24 08:12:09 --> Router Class Initialized
INFO - 2025-12-24 08:12:09 --> Output Class Initialized
INFO - 2025-12-24 08:12:09 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:09 --> CSRF cookie sent
INFO - 2025-12-24 08:12:09 --> Input Class Initialized
INFO - 2025-12-24 08:12:09 --> Language Class Initialized
INFO - 2025-12-24 08:12:09 --> Loader Class Initialized
INFO - 2025-12-24 08:12:09 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:09 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:09 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:09 --> Controller Class Initialized
INFO - 2025-12-24 08:12:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:09 --> Upload Class Initialized
INFO - 2025-12-24 08:12:09 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:12:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:09 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:09 --> Total execution time: 0.0594
INFO - 2025-12-24 08:12:11 --> Config Class Initialized
INFO - 2025-12-24 08:12:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:11 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:11 --> URI Class Initialized
INFO - 2025-12-24 08:12:11 --> Router Class Initialized
INFO - 2025-12-24 08:12:11 --> Output Class Initialized
INFO - 2025-12-24 08:12:11 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:11 --> CSRF cookie sent
INFO - 2025-12-24 08:12:11 --> Input Class Initialized
INFO - 2025-12-24 08:12:11 --> Language Class Initialized
INFO - 2025-12-24 08:12:11 --> Loader Class Initialized
INFO - 2025-12-24 08:12:11 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:11 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:11 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:11 --> Controller Class Initialized
INFO - 2025-12-24 08:12:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:11 --> Upload Class Initialized
INFO - 2025-12-24 08:12:11 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:11 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 08:12:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:11 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:11 --> Total execution time: 0.0635
INFO - 2025-12-24 08:12:23 --> Config Class Initialized
INFO - 2025-12-24 08:12:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:23 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:23 --> URI Class Initialized
INFO - 2025-12-24 08:12:23 --> Router Class Initialized
INFO - 2025-12-24 08:12:23 --> Output Class Initialized
INFO - 2025-12-24 08:12:23 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:23 --> CSRF cookie sent
INFO - 2025-12-24 08:12:23 --> CSRF token verified
INFO - 2025-12-24 08:12:23 --> Input Class Initialized
INFO - 2025-12-24 08:12:23 --> Language Class Initialized
INFO - 2025-12-24 08:12:23 --> Loader Class Initialized
INFO - 2025-12-24 08:12:23 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:23 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:23 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:23 --> Controller Class Initialized
INFO - 2025-12-24 08:12:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:23 --> Upload Class Initialized
INFO - 2025-12-24 08:12:23 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:23 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:25 --> Config Class Initialized
INFO - 2025-12-24 08:12:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:25 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:25 --> URI Class Initialized
INFO - 2025-12-24 08:12:25 --> Router Class Initialized
INFO - 2025-12-24 08:12:25 --> Output Class Initialized
INFO - 2025-12-24 08:12:25 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:25 --> CSRF cookie sent
INFO - 2025-12-24 08:12:25 --> Input Class Initialized
INFO - 2025-12-24 08:12:25 --> Language Class Initialized
INFO - 2025-12-24 08:12:25 --> Loader Class Initialized
INFO - 2025-12-24 08:12:25 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:25 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:25 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:25 --> Controller Class Initialized
INFO - 2025-12-24 08:12:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:25 --> Upload Class Initialized
INFO - 2025-12-24 08:12:25 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:25 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 08:12:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:25 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:25 --> Total execution time: 0.0785
INFO - 2025-12-24 08:12:35 --> Config Class Initialized
INFO - 2025-12-24 08:12:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:35 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:35 --> URI Class Initialized
INFO - 2025-12-24 08:12:35 --> Router Class Initialized
INFO - 2025-12-24 08:12:35 --> Output Class Initialized
INFO - 2025-12-24 08:12:35 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:35 --> CSRF cookie sent
INFO - 2025-12-24 08:12:35 --> CSRF token verified
INFO - 2025-12-24 08:12:35 --> Input Class Initialized
INFO - 2025-12-24 08:12:35 --> Language Class Initialized
INFO - 2025-12-24 08:12:35 --> Loader Class Initialized
INFO - 2025-12-24 08:12:35 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:35 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:35 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:35 --> Controller Class Initialized
INFO - 2025-12-24 08:12:35 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:35 --> Upload Class Initialized
INFO - 2025-12-24 08:12:35 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 08:12:35 --> Config Class Initialized
INFO - 2025-12-24 08:12:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:35 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:35 --> URI Class Initialized
INFO - 2025-12-24 08:12:35 --> Router Class Initialized
INFO - 2025-12-24 08:12:35 --> Output Class Initialized
INFO - 2025-12-24 08:12:35 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:35 --> CSRF cookie sent
INFO - 2025-12-24 08:12:35 --> Input Class Initialized
INFO - 2025-12-24 08:12:35 --> Language Class Initialized
INFO - 2025-12-24 08:12:35 --> Loader Class Initialized
INFO - 2025-12-24 08:12:35 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:35 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:35 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:35 --> Controller Class Initialized
INFO - 2025-12-24 08:12:35 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:35 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:35 --> Upload Class Initialized
INFO - 2025-12-24 08:12:35 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:35 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:12:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:35 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:35 --> Total execution time: 0.0755
INFO - 2025-12-24 08:12:37 --> Config Class Initialized
INFO - 2025-12-24 08:12:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:37 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:37 --> URI Class Initialized
INFO - 2025-12-24 08:12:37 --> Router Class Initialized
INFO - 2025-12-24 08:12:37 --> Output Class Initialized
INFO - 2025-12-24 08:12:37 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:37 --> CSRF cookie sent
INFO - 2025-12-24 08:12:37 --> Input Class Initialized
INFO - 2025-12-24 08:12:37 --> Language Class Initialized
INFO - 2025-12-24 08:12:37 --> Loader Class Initialized
INFO - 2025-12-24 08:12:37 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:37 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:37 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:37 --> Controller Class Initialized
INFO - 2025-12-24 08:12:37 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:37 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:37 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:37 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:37 --> Upload Class Initialized
INFO - 2025-12-24 08:12:37 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:37 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 08:12:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:37 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:37 --> Total execution time: 0.0614
INFO - 2025-12-24 08:12:40 --> Config Class Initialized
INFO - 2025-12-24 08:12:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:40 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:40 --> URI Class Initialized
INFO - 2025-12-24 08:12:40 --> Router Class Initialized
INFO - 2025-12-24 08:12:40 --> Output Class Initialized
INFO - 2025-12-24 08:12:40 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:40 --> CSRF cookie sent
INFO - 2025-12-24 08:12:40 --> Input Class Initialized
INFO - 2025-12-24 08:12:40 --> Language Class Initialized
INFO - 2025-12-24 08:12:40 --> Loader Class Initialized
INFO - 2025-12-24 08:12:40 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:40 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:40 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:40 --> Controller Class Initialized
INFO - 2025-12-24 08:12:40 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:40 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:40 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:40 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:40 --> Upload Class Initialized
INFO - 2025-12-24 08:12:40 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:40 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:12:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:40 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:40 --> Total execution time: 0.0560
INFO - 2025-12-24 08:12:43 --> Config Class Initialized
INFO - 2025-12-24 08:12:43 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:43 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:43 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:43 --> URI Class Initialized
INFO - 2025-12-24 08:12:43 --> Router Class Initialized
INFO - 2025-12-24 08:12:43 --> Output Class Initialized
INFO - 2025-12-24 08:12:43 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:43 --> CSRF cookie sent
INFO - 2025-12-24 08:12:43 --> Input Class Initialized
INFO - 2025-12-24 08:12:43 --> Language Class Initialized
INFO - 2025-12-24 08:12:43 --> Loader Class Initialized
INFO - 2025-12-24 08:12:43 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:43 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:43 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:43 --> Controller Class Initialized
INFO - 2025-12-24 08:12:43 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:43 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:43 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:43 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:43 --> Upload Class Initialized
INFO - 2025-12-24 08:12:43 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:43 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:45 --> Config Class Initialized
INFO - 2025-12-24 08:12:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:45 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:45 --> URI Class Initialized
INFO - 2025-12-24 08:12:45 --> Router Class Initialized
INFO - 2025-12-24 08:12:45 --> Output Class Initialized
INFO - 2025-12-24 08:12:45 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:45 --> CSRF cookie sent
INFO - 2025-12-24 08:12:45 --> Input Class Initialized
INFO - 2025-12-24 08:12:45 --> Language Class Initialized
INFO - 2025-12-24 08:12:45 --> Loader Class Initialized
INFO - 2025-12-24 08:12:45 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:45 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:45 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:45 --> Controller Class Initialized
INFO - 2025-12-24 08:12:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:45 --> Upload Class Initialized
INFO - 2025-12-24 08:12:45 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:45 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:12:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:12:45 --> Final output sent to browser
DEBUG - 2025-12-24 08:12:45 --> Total execution time: 0.0574
INFO - 2025-12-24 08:12:47 --> Config Class Initialized
INFO - 2025-12-24 08:12:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:47 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:47 --> URI Class Initialized
INFO - 2025-12-24 08:12:47 --> Router Class Initialized
INFO - 2025-12-24 08:12:47 --> Output Class Initialized
INFO - 2025-12-24 08:12:47 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:47 --> CSRF cookie sent
INFO - 2025-12-24 08:12:47 --> Input Class Initialized
INFO - 2025-12-24 08:12:47 --> Language Class Initialized
INFO - 2025-12-24 08:12:47 --> Loader Class Initialized
INFO - 2025-12-24 08:12:47 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:47 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:47 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:47 --> Controller Class Initialized
INFO - 2025-12-24 08:12:47 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:12:47 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:47 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:12:47 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:12:47 --> Upload Class Initialized
INFO - 2025-12-24 08:12:47 --> Helper loaded: text_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:12:47 --> Helper loaded: download_helper
INFO - 2025-12-24 08:12:57 --> Config Class Initialized
INFO - 2025-12-24 08:12:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:12:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:12:57 --> Utf8 Class Initialized
INFO - 2025-12-24 08:12:57 --> URI Class Initialized
INFO - 2025-12-24 08:12:57 --> Router Class Initialized
INFO - 2025-12-24 08:12:57 --> Output Class Initialized
INFO - 2025-12-24 08:12:57 --> Security Class Initialized
DEBUG - 2025-12-24 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:12:57 --> CSRF cookie sent
INFO - 2025-12-24 08:12:57 --> Input Class Initialized
INFO - 2025-12-24 08:12:57 --> Language Class Initialized
INFO - 2025-12-24 08:12:57 --> Loader Class Initialized
INFO - 2025-12-24 08:12:57 --> Helper loaded: url_helper
INFO - 2025-12-24 08:12:57 --> Helper loaded: form_helper
INFO - 2025-12-24 08:12:57 --> Helper loaded: file_helper
INFO - 2025-12-24 08:12:57 --> Helper loaded: html_helper
INFO - 2025-12-24 08:12:57 --> Helper loaded: security_helper
INFO - 2025-12-24 08:12:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:12:57 --> Database Driver Class Initialized
INFO - 2025-12-24 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:12:57 --> Form Validation Class Initialized
INFO - 2025-12-24 08:12:57 --> Controller Class Initialized
INFO - 2025-12-24 08:12:57 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:12:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:12:57 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 08:12:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 08:13:02 --> Config Class Initialized
INFO - 2025-12-24 08:13:02 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:13:02 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:13:02 --> Utf8 Class Initialized
INFO - 2025-12-24 08:13:02 --> URI Class Initialized
INFO - 2025-12-24 08:13:02 --> Router Class Initialized
INFO - 2025-12-24 08:13:02 --> Output Class Initialized
INFO - 2025-12-24 08:13:02 --> Security Class Initialized
DEBUG - 2025-12-24 08:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:13:02 --> CSRF cookie sent
INFO - 2025-12-24 08:13:02 --> Input Class Initialized
INFO - 2025-12-24 08:13:02 --> Language Class Initialized
INFO - 2025-12-24 08:13:02 --> Loader Class Initialized
INFO - 2025-12-24 08:13:02 --> Helper loaded: url_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: form_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: file_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: html_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: security_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:13:02 --> Database Driver Class Initialized
INFO - 2025-12-24 08:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:13:02 --> Form Validation Class Initialized
INFO - 2025-12-24 08:13:02 --> Controller Class Initialized
INFO - 2025-12-24 08:13:02 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:13:02 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:13:02 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:13:02 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:13:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:13:02 --> Upload Class Initialized
INFO - 2025-12-24 08:13:02 --> Helper loaded: text_helper
INFO - 2025-12-24 08:13:02 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:13:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:13:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:13:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:13:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:13:02 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:13:02 --> Final output sent to browser
DEBUG - 2025-12-24 08:13:02 --> Total execution time: 0.0558
INFO - 2025-12-24 08:13:08 --> Config Class Initialized
INFO - 2025-12-24 08:13:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:13:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:13:08 --> Utf8 Class Initialized
INFO - 2025-12-24 08:13:08 --> URI Class Initialized
INFO - 2025-12-24 08:13:08 --> Router Class Initialized
INFO - 2025-12-24 08:13:08 --> Output Class Initialized
INFO - 2025-12-24 08:13:08 --> Security Class Initialized
DEBUG - 2025-12-24 08:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:13:08 --> CSRF cookie sent
INFO - 2025-12-24 08:13:08 --> Input Class Initialized
INFO - 2025-12-24 08:13:08 --> Language Class Initialized
INFO - 2025-12-24 08:13:08 --> Loader Class Initialized
INFO - 2025-12-24 08:13:08 --> Helper loaded: url_helper
INFO - 2025-12-24 08:13:08 --> Helper loaded: form_helper
INFO - 2025-12-24 08:13:08 --> Helper loaded: file_helper
INFO - 2025-12-24 08:13:08 --> Helper loaded: html_helper
INFO - 2025-12-24 08:13:08 --> Helper loaded: security_helper
INFO - 2025-12-24 08:13:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:13:08 --> Database Driver Class Initialized
INFO - 2025-12-24 08:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:13:08 --> Form Validation Class Initialized
INFO - 2025-12-24 08:13:08 --> Controller Class Initialized
INFO - 2025-12-24 08:13:08 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 08:13:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:13:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:13:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:13:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 08:13:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:13:08 --> Final output sent to browser
DEBUG - 2025-12-24 08:13:08 --> Total execution time: 0.0511
INFO - 2025-12-24 08:17:21 --> Config Class Initialized
INFO - 2025-12-24 08:17:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:17:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:17:21 --> Utf8 Class Initialized
INFO - 2025-12-24 08:17:21 --> URI Class Initialized
INFO - 2025-12-24 08:17:21 --> Router Class Initialized
INFO - 2025-12-24 08:17:21 --> Output Class Initialized
INFO - 2025-12-24 08:17:21 --> Security Class Initialized
DEBUG - 2025-12-24 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:17:21 --> CSRF cookie sent
INFO - 2025-12-24 08:17:21 --> Input Class Initialized
INFO - 2025-12-24 08:17:21 --> Language Class Initialized
INFO - 2025-12-24 08:17:21 --> Loader Class Initialized
INFO - 2025-12-24 08:17:21 --> Helper loaded: url_helper
INFO - 2025-12-24 08:17:21 --> Helper loaded: form_helper
INFO - 2025-12-24 08:17:21 --> Helper loaded: file_helper
INFO - 2025-12-24 08:17:21 --> Helper loaded: html_helper
INFO - 2025-12-24 08:17:21 --> Helper loaded: security_helper
INFO - 2025-12-24 08:17:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:17:21 --> Database Driver Class Initialized
INFO - 2025-12-24 08:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:17:21 --> Form Validation Class Initialized
INFO - 2025-12-24 08:17:21 --> Controller Class Initialized
INFO - 2025-12-24 08:17:21 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:17:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:17:21 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 08:17:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Nomor_surat_model D:\xampp\htdocs\surat_itm\system\core\Loader.php 350
INFO - 2025-12-24 08:21:21 --> Config Class Initialized
INFO - 2025-12-24 08:21:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:21:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:21:21 --> Utf8 Class Initialized
INFO - 2025-12-24 08:21:21 --> URI Class Initialized
INFO - 2025-12-24 08:21:21 --> Router Class Initialized
INFO - 2025-12-24 08:21:21 --> Output Class Initialized
INFO - 2025-12-24 08:21:21 --> Security Class Initialized
DEBUG - 2025-12-24 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:21:21 --> CSRF cookie sent
INFO - 2025-12-24 08:21:21 --> Input Class Initialized
INFO - 2025-12-24 08:21:21 --> Language Class Initialized
INFO - 2025-12-24 08:21:21 --> Loader Class Initialized
INFO - 2025-12-24 08:21:21 --> Helper loaded: url_helper
INFO - 2025-12-24 08:21:21 --> Helper loaded: form_helper
INFO - 2025-12-24 08:21:21 --> Helper loaded: file_helper
INFO - 2025-12-24 08:21:21 --> Helper loaded: html_helper
INFO - 2025-12-24 08:21:21 --> Helper loaded: security_helper
INFO - 2025-12-24 08:21:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:21:21 --> Database Driver Class Initialized
INFO - 2025-12-24 08:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:21:21 --> Form Validation Class Initialized
INFO - 2025-12-24 08:21:21 --> Controller Class Initialized
INFO - 2025-12-24 08:21:21 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:21:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:21:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:21:21 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:21:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:21:21 --> Upload Class Initialized
INFO - 2025-12-24 08:21:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:21:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:21:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 08:21:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:21:22 --> Final output sent to browser
DEBUG - 2025-12-24 08:21:22 --> Total execution time: 0.2532
INFO - 2025-12-24 08:21:24 --> Config Class Initialized
INFO - 2025-12-24 08:21:24 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:21:24 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:21:24 --> Utf8 Class Initialized
INFO - 2025-12-24 08:21:24 --> URI Class Initialized
INFO - 2025-12-24 08:21:24 --> Router Class Initialized
INFO - 2025-12-24 08:21:24 --> Output Class Initialized
INFO - 2025-12-24 08:21:24 --> Security Class Initialized
DEBUG - 2025-12-24 08:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:21:24 --> CSRF cookie sent
INFO - 2025-12-24 08:21:24 --> Input Class Initialized
INFO - 2025-12-24 08:21:24 --> Language Class Initialized
INFO - 2025-12-24 08:21:24 --> Loader Class Initialized
INFO - 2025-12-24 08:21:24 --> Helper loaded: url_helper
INFO - 2025-12-24 08:21:24 --> Helper loaded: form_helper
INFO - 2025-12-24 08:21:24 --> Helper loaded: file_helper
INFO - 2025-12-24 08:21:24 --> Helper loaded: html_helper
INFO - 2025-12-24 08:21:24 --> Helper loaded: security_helper
INFO - 2025-12-24 08:21:24 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:21:24 --> Database Driver Class Initialized
INFO - 2025-12-24 08:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:21:24 --> Form Validation Class Initialized
INFO - 2025-12-24 08:21:24 --> Controller Class Initialized
INFO - 2025-12-24 08:21:24 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:21:24 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:21:24 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:21:24 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:21:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:21:24 --> Upload Class Initialized
INFO - 2025-12-24 08:21:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:21:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:21:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 08:21:24 --> Severity: Warning --> Undefined variable $pejabat D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 219
ERROR - 2025-12-24 08:21:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 219
INFO - 2025-12-24 08:21:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:21:24 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:21:24 --> Final output sent to browser
DEBUG - 2025-12-24 08:21:24 --> Total execution time: 0.0545
INFO - 2025-12-24 08:21:37 --> Config Class Initialized
INFO - 2025-12-24 08:21:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:21:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:21:37 --> Utf8 Class Initialized
INFO - 2025-12-24 08:21:37 --> URI Class Initialized
INFO - 2025-12-24 08:21:37 --> Router Class Initialized
INFO - 2025-12-24 08:21:37 --> Output Class Initialized
INFO - 2025-12-24 08:21:37 --> Security Class Initialized
DEBUG - 2025-12-24 08:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:21:37 --> CSRF cookie sent
INFO - 2025-12-24 08:21:39 --> Config Class Initialized
INFO - 2025-12-24 08:21:39 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:21:39 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:21:39 --> Utf8 Class Initialized
INFO - 2025-12-24 08:21:39 --> URI Class Initialized
INFO - 2025-12-24 08:21:39 --> Router Class Initialized
INFO - 2025-12-24 08:21:39 --> Output Class Initialized
INFO - 2025-12-24 08:21:39 --> Security Class Initialized
DEBUG - 2025-12-24 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:21:39 --> CSRF cookie sent
INFO - 2025-12-24 08:23:30 --> Config Class Initialized
INFO - 2025-12-24 08:23:30 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:23:30 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:23:30 --> Utf8 Class Initialized
INFO - 2025-12-24 08:23:30 --> URI Class Initialized
INFO - 2025-12-24 08:23:30 --> Router Class Initialized
INFO - 2025-12-24 08:23:30 --> Output Class Initialized
INFO - 2025-12-24 08:23:30 --> Security Class Initialized
DEBUG - 2025-12-24 08:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:23:30 --> CSRF cookie sent
INFO - 2025-12-24 08:23:30 --> Input Class Initialized
INFO - 2025-12-24 08:23:30 --> Language Class Initialized
INFO - 2025-12-24 08:23:30 --> Loader Class Initialized
INFO - 2025-12-24 08:23:30 --> Helper loaded: url_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: form_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: file_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: html_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: security_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:23:30 --> Database Driver Class Initialized
INFO - 2025-12-24 08:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:23:30 --> Form Validation Class Initialized
INFO - 2025-12-24 08:23:30 --> Controller Class Initialized
INFO - 2025-12-24 08:23:30 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:23:30 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:23:30 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:23:30 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:23:30 --> Upload Class Initialized
INFO - 2025-12-24 08:23:30 --> Helper loaded: text_helper
INFO - 2025-12-24 08:23:30 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:23:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:23:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:23:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:23:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:23:30 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:23:30 --> Final output sent to browser
DEBUG - 2025-12-24 08:23:30 --> Total execution time: 0.0586
INFO - 2025-12-24 08:23:38 --> Config Class Initialized
INFO - 2025-12-24 08:23:38 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:23:38 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:23:38 --> Utf8 Class Initialized
INFO - 2025-12-24 08:23:38 --> URI Class Initialized
INFO - 2025-12-24 08:23:38 --> Router Class Initialized
INFO - 2025-12-24 08:23:38 --> Output Class Initialized
INFO - 2025-12-24 08:23:38 --> Security Class Initialized
DEBUG - 2025-12-24 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:23:38 --> CSRF cookie sent
INFO - 2025-12-24 08:23:38 --> Input Class Initialized
INFO - 2025-12-24 08:23:38 --> Language Class Initialized
INFO - 2025-12-24 08:23:38 --> Loader Class Initialized
INFO - 2025-12-24 08:23:38 --> Helper loaded: url_helper
INFO - 2025-12-24 08:23:38 --> Helper loaded: form_helper
INFO - 2025-12-24 08:23:38 --> Helper loaded: file_helper
INFO - 2025-12-24 08:23:38 --> Helper loaded: html_helper
INFO - 2025-12-24 08:23:38 --> Helper loaded: security_helper
INFO - 2025-12-24 08:23:38 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:23:38 --> Database Driver Class Initialized
INFO - 2025-12-24 08:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:23:38 --> Form Validation Class Initialized
INFO - 2025-12-24 08:23:38 --> Controller Class Initialized
INFO - 2025-12-24 08:23:38 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:23:38 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:23:38 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:23:38 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:23:38 --> Upload Class Initialized
INFO - 2025-12-24 08:23:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:23:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:23:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:23:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 08:23:38 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:23:38 --> Final output sent to browser
DEBUG - 2025-12-24 08:23:38 --> Total execution time: 0.0554
INFO - 2025-12-24 08:23:40 --> Config Class Initialized
INFO - 2025-12-24 08:23:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:23:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:23:40 --> Utf8 Class Initialized
INFO - 2025-12-24 08:23:40 --> URI Class Initialized
INFO - 2025-12-24 08:23:40 --> Router Class Initialized
INFO - 2025-12-24 08:23:40 --> Output Class Initialized
INFO - 2025-12-24 08:23:40 --> Security Class Initialized
DEBUG - 2025-12-24 08:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:23:40 --> CSRF cookie sent
INFO - 2025-12-24 08:23:40 --> Input Class Initialized
INFO - 2025-12-24 08:23:40 --> Language Class Initialized
INFO - 2025-12-24 08:23:40 --> Loader Class Initialized
INFO - 2025-12-24 08:23:40 --> Helper loaded: url_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: form_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: file_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: html_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: security_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:23:40 --> Database Driver Class Initialized
INFO - 2025-12-24 08:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:23:40 --> Form Validation Class Initialized
INFO - 2025-12-24 08:23:40 --> Controller Class Initialized
INFO - 2025-12-24 08:23:40 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:23:40 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:23:40 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:23:40 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:23:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:23:40 --> Upload Class Initialized
INFO - 2025-12-24 08:23:40 --> Helper loaded: text_helper
INFO - 2025-12-24 08:23:40 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:23:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:23:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:23:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:23:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:23:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:23:40 --> Final output sent to browser
DEBUG - 2025-12-24 08:23:40 --> Total execution time: 0.0542
INFO - 2025-12-24 08:31:36 --> Config Class Initialized
INFO - 2025-12-24 08:31:36 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:31:36 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:31:36 --> Utf8 Class Initialized
INFO - 2025-12-24 08:31:36 --> URI Class Initialized
INFO - 2025-12-24 08:31:36 --> Router Class Initialized
INFO - 2025-12-24 08:31:36 --> Output Class Initialized
INFO - 2025-12-24 08:31:36 --> Security Class Initialized
DEBUG - 2025-12-24 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:31:36 --> CSRF cookie sent
INFO - 2025-12-24 08:31:36 --> Input Class Initialized
INFO - 2025-12-24 08:31:36 --> Language Class Initialized
INFO - 2025-12-24 08:31:36 --> Loader Class Initialized
INFO - 2025-12-24 08:31:36 --> Helper loaded: url_helper
INFO - 2025-12-24 08:31:36 --> Helper loaded: form_helper
INFO - 2025-12-24 08:31:36 --> Helper loaded: file_helper
INFO - 2025-12-24 08:31:36 --> Helper loaded: html_helper
INFO - 2025-12-24 08:31:36 --> Helper loaded: security_helper
INFO - 2025-12-24 08:31:36 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:31:36 --> Database Driver Class Initialized
INFO - 2025-12-24 08:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:31:36 --> Form Validation Class Initialized
INFO - 2025-12-24 08:31:36 --> Controller Class Initialized
INFO - 2025-12-24 08:31:36 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:31:36 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:31:36 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:31:36 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:31:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:31:36 --> Upload Class Initialized
INFO - 2025-12-24 08:31:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:31:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:31:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:31:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 08:31:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:31:36 --> Final output sent to browser
DEBUG - 2025-12-24 08:31:36 --> Total execution time: 0.3239
INFO - 2025-12-24 08:43:50 --> Config Class Initialized
INFO - 2025-12-24 08:43:50 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:43:50 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:43:50 --> Utf8 Class Initialized
INFO - 2025-12-24 08:43:50 --> URI Class Initialized
INFO - 2025-12-24 08:43:50 --> Router Class Initialized
INFO - 2025-12-24 08:43:50 --> Output Class Initialized
INFO - 2025-12-24 08:43:50 --> Security Class Initialized
DEBUG - 2025-12-24 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:43:50 --> CSRF cookie sent
INFO - 2025-12-24 08:43:50 --> Input Class Initialized
INFO - 2025-12-24 08:43:50 --> Language Class Initialized
INFO - 2025-12-24 08:43:50 --> Loader Class Initialized
INFO - 2025-12-24 08:43:50 --> Helper loaded: url_helper
INFO - 2025-12-24 08:43:50 --> Helper loaded: form_helper
INFO - 2025-12-24 08:43:50 --> Helper loaded: file_helper
INFO - 2025-12-24 08:43:50 --> Helper loaded: html_helper
INFO - 2025-12-24 08:43:50 --> Helper loaded: security_helper
INFO - 2025-12-24 08:43:50 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:43:50 --> Database Driver Class Initialized
INFO - 2025-12-24 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:43:50 --> Form Validation Class Initialized
INFO - 2025-12-24 08:43:50 --> Controller Class Initialized
INFO - 2025-12-24 08:43:50 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:43:50 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:43:50 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:43:50 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:43:50 --> Upload Class Initialized
INFO - 2025-12-24 08:43:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:43:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:43:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 99
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 102
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 103
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 105
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 107
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $uploaded_file D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 117
ERROR - 2025-12-24 08:43:50 --> Severity: Warning --> Undefined variable $extracted D:\xampp\htdocs\surat_itm\application\views\surat_keluar\form.php 283
INFO - 2025-12-24 08:43:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:43:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:43:50 --> Final output sent to browser
DEBUG - 2025-12-24 08:43:50 --> Total execution time: 0.3246
INFO - 2025-12-24 08:44:59 --> Config Class Initialized
INFO - 2025-12-24 08:44:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:44:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:44:59 --> Utf8 Class Initialized
INFO - 2025-12-24 08:44:59 --> URI Class Initialized
INFO - 2025-12-24 08:44:59 --> Router Class Initialized
INFO - 2025-12-24 08:44:59 --> Output Class Initialized
INFO - 2025-12-24 08:44:59 --> Security Class Initialized
DEBUG - 2025-12-24 08:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:44:59 --> CSRF cookie sent
INFO - 2025-12-24 08:44:59 --> Input Class Initialized
INFO - 2025-12-24 08:44:59 --> Language Class Initialized
INFO - 2025-12-24 08:44:59 --> Loader Class Initialized
INFO - 2025-12-24 08:44:59 --> Helper loaded: url_helper
INFO - 2025-12-24 08:44:59 --> Helper loaded: form_helper
INFO - 2025-12-24 08:44:59 --> Helper loaded: file_helper
INFO - 2025-12-24 08:44:59 --> Helper loaded: html_helper
INFO - 2025-12-24 08:44:59 --> Helper loaded: security_helper
INFO - 2025-12-24 08:44:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:44:59 --> Database Driver Class Initialized
INFO - 2025-12-24 08:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:44:59 --> Form Validation Class Initialized
INFO - 2025-12-24 08:44:59 --> Controller Class Initialized
INFO - 2025-12-24 08:44:59 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:44:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:44:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:44:59 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:44:59 --> Upload Class Initialized
INFO - 2025-12-24 08:44:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:44:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:44:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:44:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:44:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:44:59 --> Final output sent to browser
DEBUG - 2025-12-24 08:44:59 --> Total execution time: 0.0989
INFO - 2025-12-24 08:45:10 --> Config Class Initialized
INFO - 2025-12-24 08:45:10 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:45:10 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:45:10 --> Utf8 Class Initialized
INFO - 2025-12-24 08:45:10 --> URI Class Initialized
INFO - 2025-12-24 08:45:10 --> Router Class Initialized
INFO - 2025-12-24 08:45:10 --> Output Class Initialized
INFO - 2025-12-24 08:45:10 --> Security Class Initialized
DEBUG - 2025-12-24 08:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:45:10 --> CSRF cookie sent
INFO - 2025-12-24 08:45:10 --> CSRF token verified
INFO - 2025-12-24 08:45:10 --> Input Class Initialized
INFO - 2025-12-24 08:45:10 --> Language Class Initialized
ERROR - 2025-12-24 08:45:10 --> 404 Page Not Found: Surat-keluar/upload_extract
INFO - 2025-12-24 08:45:18 --> Config Class Initialized
INFO - 2025-12-24 08:45:18 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:45:18 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:45:18 --> Utf8 Class Initialized
INFO - 2025-12-24 08:45:18 --> URI Class Initialized
INFO - 2025-12-24 08:45:18 --> Router Class Initialized
INFO - 2025-12-24 08:45:18 --> Output Class Initialized
INFO - 2025-12-24 08:45:18 --> Security Class Initialized
DEBUG - 2025-12-24 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:45:18 --> CSRF cookie sent
INFO - 2025-12-24 08:45:18 --> Input Class Initialized
INFO - 2025-12-24 08:45:18 --> Language Class Initialized
INFO - 2025-12-24 08:45:18 --> Loader Class Initialized
INFO - 2025-12-24 08:45:18 --> Helper loaded: url_helper
INFO - 2025-12-24 08:45:18 --> Helper loaded: form_helper
INFO - 2025-12-24 08:45:18 --> Helper loaded: file_helper
INFO - 2025-12-24 08:45:18 --> Helper loaded: html_helper
INFO - 2025-12-24 08:45:18 --> Helper loaded: security_helper
INFO - 2025-12-24 08:45:18 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:45:18 --> Database Driver Class Initialized
INFO - 2025-12-24 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:45:18 --> Form Validation Class Initialized
INFO - 2025-12-24 08:45:18 --> Controller Class Initialized
INFO - 2025-12-24 08:45:18 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:45:18 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:45:18 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:45:18 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:45:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:45:18 --> Upload Class Initialized
INFO - 2025-12-24 08:45:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:45:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:45:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:45:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:45:18 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:45:18 --> Final output sent to browser
DEBUG - 2025-12-24 08:45:18 --> Total execution time: 0.0543
INFO - 2025-12-24 08:46:15 --> Config Class Initialized
INFO - 2025-12-24 08:46:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:46:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:46:15 --> Utf8 Class Initialized
INFO - 2025-12-24 08:46:15 --> URI Class Initialized
INFO - 2025-12-24 08:46:15 --> Router Class Initialized
INFO - 2025-12-24 08:46:15 --> Output Class Initialized
INFO - 2025-12-24 08:46:15 --> Security Class Initialized
DEBUG - 2025-12-24 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:46:15 --> CSRF cookie sent
INFO - 2025-12-24 08:46:15 --> Input Class Initialized
INFO - 2025-12-24 08:46:15 --> Language Class Initialized
ERROR - 2025-12-24 08:46:15 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:46:24 --> Config Class Initialized
INFO - 2025-12-24 08:46:24 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:46:24 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:46:24 --> Utf8 Class Initialized
INFO - 2025-12-24 08:46:24 --> URI Class Initialized
INFO - 2025-12-24 08:46:24 --> Router Class Initialized
INFO - 2025-12-24 08:46:24 --> Output Class Initialized
INFO - 2025-12-24 08:46:24 --> Security Class Initialized
DEBUG - 2025-12-24 08:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:46:24 --> CSRF cookie sent
INFO - 2025-12-24 08:46:24 --> Input Class Initialized
INFO - 2025-12-24 08:46:24 --> Language Class Initialized
ERROR - 2025-12-24 08:46:24 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:47:42 --> Config Class Initialized
INFO - 2025-12-24 08:47:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:42 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:42 --> URI Class Initialized
INFO - 2025-12-24 08:47:42 --> Router Class Initialized
INFO - 2025-12-24 08:47:42 --> Output Class Initialized
INFO - 2025-12-24 08:47:42 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:42 --> CSRF cookie sent
INFO - 2025-12-24 08:47:42 --> Input Class Initialized
INFO - 2025-12-24 08:47:42 --> Language Class Initialized
ERROR - 2025-12-24 08:47:42 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:47:43 --> Config Class Initialized
INFO - 2025-12-24 08:47:43 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:43 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:43 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:43 --> URI Class Initialized
INFO - 2025-12-24 08:47:43 --> Router Class Initialized
INFO - 2025-12-24 08:47:43 --> Output Class Initialized
INFO - 2025-12-24 08:47:43 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:43 --> CSRF cookie sent
INFO - 2025-12-24 08:47:43 --> Input Class Initialized
INFO - 2025-12-24 08:47:43 --> Language Class Initialized
ERROR - 2025-12-24 08:47:43 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:47:44 --> Config Class Initialized
INFO - 2025-12-24 08:47:44 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:44 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:44 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:44 --> URI Class Initialized
INFO - 2025-12-24 08:47:44 --> Router Class Initialized
INFO - 2025-12-24 08:47:44 --> Output Class Initialized
INFO - 2025-12-24 08:47:44 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:44 --> CSRF cookie sent
INFO - 2025-12-24 08:47:44 --> Input Class Initialized
INFO - 2025-12-24 08:47:44 --> Language Class Initialized
ERROR - 2025-12-24 08:47:44 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:47:45 --> Config Class Initialized
INFO - 2025-12-24 08:47:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:45 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:45 --> URI Class Initialized
INFO - 2025-12-24 08:47:45 --> Router Class Initialized
INFO - 2025-12-24 08:47:45 --> Output Class Initialized
INFO - 2025-12-24 08:47:45 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:45 --> CSRF cookie sent
INFO - 2025-12-24 08:47:45 --> Input Class Initialized
INFO - 2025-12-24 08:47:45 --> Language Class Initialized
INFO - 2025-12-24 08:47:45 --> Loader Class Initialized
INFO - 2025-12-24 08:47:45 --> Helper loaded: url_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: form_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: file_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: html_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: security_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:47:45 --> Database Driver Class Initialized
INFO - 2025-12-24 08:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:47:45 --> Form Validation Class Initialized
INFO - 2025-12-24 08:47:45 --> Controller Class Initialized
INFO - 2025-12-24 08:47:45 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:47:45 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:47:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:47:45 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:47:45 --> Upload Class Initialized
INFO - 2025-12-24 08:47:45 --> Helper loaded: text_helper
INFO - 2025-12-24 08:47:45 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:47:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:47:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:47:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:47:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:47:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:47:45 --> Final output sent to browser
DEBUG - 2025-12-24 08:47:45 --> Total execution time: 0.0808
INFO - 2025-12-24 08:47:47 --> Config Class Initialized
INFO - 2025-12-24 08:47:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:47 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:47 --> URI Class Initialized
INFO - 2025-12-24 08:47:47 --> Router Class Initialized
INFO - 2025-12-24 08:47:47 --> Output Class Initialized
INFO - 2025-12-24 08:47:47 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:47 --> CSRF cookie sent
INFO - 2025-12-24 08:47:47 --> Input Class Initialized
INFO - 2025-12-24 08:47:47 --> Language Class Initialized
INFO - 2025-12-24 08:47:47 --> Loader Class Initialized
INFO - 2025-12-24 08:47:47 --> Helper loaded: url_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: form_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: file_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: html_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: security_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:47:47 --> Database Driver Class Initialized
INFO - 2025-12-24 08:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:47:47 --> Form Validation Class Initialized
INFO - 2025-12-24 08:47:47 --> Controller Class Initialized
INFO - 2025-12-24 08:47:47 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:47:47 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:47:47 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:47:47 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:47:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:47:47 --> Upload Class Initialized
INFO - 2025-12-24 08:47:47 --> Helper loaded: text_helper
INFO - 2025-12-24 08:47:47 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:47:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:47:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:47:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:47:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:47:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:47:47 --> Final output sent to browser
DEBUG - 2025-12-24 08:47:47 --> Total execution time: 0.0577
INFO - 2025-12-24 08:47:48 --> Config Class Initialized
INFO - 2025-12-24 08:47:48 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:48 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:48 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:48 --> URI Class Initialized
INFO - 2025-12-24 08:47:48 --> Router Class Initialized
INFO - 2025-12-24 08:47:48 --> Output Class Initialized
INFO - 2025-12-24 08:47:48 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:48 --> CSRF cookie sent
INFO - 2025-12-24 08:47:48 --> Input Class Initialized
INFO - 2025-12-24 08:47:48 --> Language Class Initialized
INFO - 2025-12-24 08:47:48 --> Loader Class Initialized
INFO - 2025-12-24 08:47:48 --> Helper loaded: url_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: form_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: file_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: html_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: security_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:47:48 --> Database Driver Class Initialized
INFO - 2025-12-24 08:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:47:48 --> Form Validation Class Initialized
INFO - 2025-12-24 08:47:48 --> Controller Class Initialized
INFO - 2025-12-24 08:47:48 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:47:48 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:47:48 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:47:48 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:47:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:47:48 --> Upload Class Initialized
INFO - 2025-12-24 08:47:48 --> Helper loaded: text_helper
INFO - 2025-12-24 08:47:48 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:47:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:47:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:47:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:47:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:47:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:47:48 --> Final output sent to browser
DEBUG - 2025-12-24 08:47:48 --> Total execution time: 0.0570
INFO - 2025-12-24 08:47:49 --> Config Class Initialized
INFO - 2025-12-24 08:47:49 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:47:49 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:47:49 --> Utf8 Class Initialized
INFO - 2025-12-24 08:47:49 --> URI Class Initialized
INFO - 2025-12-24 08:47:49 --> Router Class Initialized
INFO - 2025-12-24 08:47:49 --> Output Class Initialized
INFO - 2025-12-24 08:47:49 --> Security Class Initialized
DEBUG - 2025-12-24 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:47:49 --> CSRF cookie sent
INFO - 2025-12-24 08:47:49 --> Input Class Initialized
INFO - 2025-12-24 08:47:49 --> Language Class Initialized
ERROR - 2025-12-24 08:47:49 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:53:07 --> Config Class Initialized
INFO - 2025-12-24 08:53:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:07 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:07 --> URI Class Initialized
INFO - 2025-12-24 08:53:07 --> Router Class Initialized
INFO - 2025-12-24 08:53:07 --> Output Class Initialized
INFO - 2025-12-24 08:53:07 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:07 --> CSRF cookie sent
INFO - 2025-12-24 08:53:07 --> Input Class Initialized
INFO - 2025-12-24 08:53:07 --> Language Class Initialized
ERROR - 2025-12-24 08:53:07 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:53:10 --> Config Class Initialized
INFO - 2025-12-24 08:53:10 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:10 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:10 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:10 --> URI Class Initialized
INFO - 2025-12-24 08:53:10 --> Router Class Initialized
INFO - 2025-12-24 08:53:10 --> Output Class Initialized
INFO - 2025-12-24 08:53:10 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:10 --> CSRF cookie sent
INFO - 2025-12-24 08:53:10 --> Input Class Initialized
INFO - 2025-12-24 08:53:10 --> Language Class Initialized
ERROR - 2025-12-24 08:53:10 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:53:11 --> Config Class Initialized
INFO - 2025-12-24 08:53:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:11 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:11 --> URI Class Initialized
INFO - 2025-12-24 08:53:11 --> Router Class Initialized
INFO - 2025-12-24 08:53:11 --> Output Class Initialized
INFO - 2025-12-24 08:53:11 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:11 --> CSRF cookie sent
INFO - 2025-12-24 08:53:11 --> Input Class Initialized
INFO - 2025-12-24 08:53:11 --> Language Class Initialized
INFO - 2025-12-24 08:53:11 --> Loader Class Initialized
INFO - 2025-12-24 08:53:11 --> Helper loaded: url_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: form_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: file_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: html_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: security_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:53:11 --> Database Driver Class Initialized
INFO - 2025-12-24 08:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:53:11 --> Form Validation Class Initialized
INFO - 2025-12-24 08:53:11 --> Controller Class Initialized
INFO - 2025-12-24 08:53:11 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:53:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:53:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:53:11 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:53:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:53:11 --> Upload Class Initialized
INFO - 2025-12-24 08:53:11 --> Helper loaded: text_helper
INFO - 2025-12-24 08:53:11 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:53:11 --> Final output sent to browser
DEBUG - 2025-12-24 08:53:11 --> Total execution time: 0.0683
INFO - 2025-12-24 08:53:12 --> Config Class Initialized
INFO - 2025-12-24 08:53:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:12 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:12 --> URI Class Initialized
INFO - 2025-12-24 08:53:12 --> Router Class Initialized
INFO - 2025-12-24 08:53:12 --> Output Class Initialized
INFO - 2025-12-24 08:53:12 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:12 --> CSRF cookie sent
INFO - 2025-12-24 08:53:12 --> Input Class Initialized
INFO - 2025-12-24 08:53:12 --> Language Class Initialized
INFO - 2025-12-24 08:53:12 --> Loader Class Initialized
INFO - 2025-12-24 08:53:12 --> Helper loaded: url_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: form_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: file_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: html_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: security_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:53:12 --> Database Driver Class Initialized
INFO - 2025-12-24 08:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:53:12 --> Form Validation Class Initialized
INFO - 2025-12-24 08:53:12 --> Controller Class Initialized
INFO - 2025-12-24 08:53:12 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:53:12 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:53:12 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:53:12 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:53:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:53:12 --> Upload Class Initialized
INFO - 2025-12-24 08:53:12 --> Helper loaded: text_helper
INFO - 2025-12-24 08:53:12 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:53:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:53:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:53:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:53:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:53:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:53:12 --> Final output sent to browser
DEBUG - 2025-12-24 08:53:12 --> Total execution time: 0.0630
INFO - 2025-12-24 08:53:13 --> Config Class Initialized
INFO - 2025-12-24 08:53:13 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:13 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:13 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:13 --> URI Class Initialized
INFO - 2025-12-24 08:53:13 --> Router Class Initialized
INFO - 2025-12-24 08:53:13 --> Output Class Initialized
INFO - 2025-12-24 08:53:13 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:14 --> CSRF cookie sent
INFO - 2025-12-24 08:53:14 --> Input Class Initialized
INFO - 2025-12-24 08:53:14 --> Language Class Initialized
INFO - 2025-12-24 08:53:14 --> Loader Class Initialized
INFO - 2025-12-24 08:53:14 --> Helper loaded: url_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: form_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: file_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: html_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: security_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:53:14 --> Database Driver Class Initialized
INFO - 2025-12-24 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:53:14 --> Form Validation Class Initialized
INFO - 2025-12-24 08:53:14 --> Controller Class Initialized
INFO - 2025-12-24 08:53:14 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 08:53:14 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:53:14 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:53:14 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 08:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:53:14 --> Upload Class Initialized
INFO - 2025-12-24 08:53:14 --> Helper loaded: text_helper
INFO - 2025-12-24 08:53:14 --> Helper loaded: custom_helper
INFO - 2025-12-24 08:53:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:53:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:53:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:53:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 08:53:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:53:14 --> Final output sent to browser
DEBUG - 2025-12-24 08:53:14 --> Total execution time: 0.0626
INFO - 2025-12-24 08:53:15 --> Config Class Initialized
INFO - 2025-12-24 08:53:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:53:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:53:15 --> Utf8 Class Initialized
INFO - 2025-12-24 08:53:15 --> URI Class Initialized
INFO - 2025-12-24 08:53:15 --> Router Class Initialized
INFO - 2025-12-24 08:53:15 --> Output Class Initialized
INFO - 2025-12-24 08:53:15 --> Security Class Initialized
DEBUG - 2025-12-24 08:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:53:15 --> CSRF cookie sent
INFO - 2025-12-24 08:53:15 --> Input Class Initialized
INFO - 2025-12-24 08:53:15 --> Language Class Initialized
ERROR - 2025-12-24 08:53:15 --> Severity: Compile Error --> Cannot redeclare Surat_keluar::upload_extract() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 265
INFO - 2025-12-24 08:54:51 --> Config Class Initialized
INFO - 2025-12-24 08:54:51 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:54:51 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:54:51 --> Utf8 Class Initialized
INFO - 2025-12-24 08:54:51 --> URI Class Initialized
INFO - 2025-12-24 08:54:51 --> Router Class Initialized
INFO - 2025-12-24 08:54:51 --> Output Class Initialized
INFO - 2025-12-24 08:54:51 --> Security Class Initialized
DEBUG - 2025-12-24 08:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:54:51 --> CSRF cookie sent
INFO - 2025-12-24 08:54:51 --> Input Class Initialized
INFO - 2025-12-24 08:54:51 --> Language Class Initialized
INFO - 2025-12-24 08:54:51 --> Loader Class Initialized
INFO - 2025-12-24 08:54:51 --> Helper loaded: url_helper
INFO - 2025-12-24 08:54:51 --> Helper loaded: form_helper
INFO - 2025-12-24 08:54:51 --> Helper loaded: file_helper
INFO - 2025-12-24 08:54:51 --> Helper loaded: html_helper
INFO - 2025-12-24 08:54:51 --> Helper loaded: security_helper
INFO - 2025-12-24 08:54:51 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:54:51 --> Database Driver Class Initialized
INFO - 2025-12-24 08:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:54:51 --> Form Validation Class Initialized
INFO - 2025-12-24 08:54:51 --> Controller Class Initialized
INFO - 2025-12-24 08:54:51 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:54:51 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:54:51 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:54:51 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:54:51 --> Upload Class Initialized
INFO - 2025-12-24 08:54:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:54:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:54:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:54:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 08:54:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:54:51 --> Final output sent to browser
DEBUG - 2025-12-24 08:54:51 --> Total execution time: 0.0928
INFO - 2025-12-24 08:54:54 --> Config Class Initialized
INFO - 2025-12-24 08:54:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:54:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:54:54 --> Utf8 Class Initialized
INFO - 2025-12-24 08:54:54 --> URI Class Initialized
INFO - 2025-12-24 08:54:54 --> Router Class Initialized
INFO - 2025-12-24 08:54:54 --> Output Class Initialized
INFO - 2025-12-24 08:54:54 --> Security Class Initialized
DEBUG - 2025-12-24 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:54:54 --> CSRF cookie sent
INFO - 2025-12-24 08:54:54 --> Input Class Initialized
INFO - 2025-12-24 08:54:54 --> Language Class Initialized
INFO - 2025-12-24 08:54:54 --> Loader Class Initialized
INFO - 2025-12-24 08:54:54 --> Helper loaded: url_helper
INFO - 2025-12-24 08:54:54 --> Helper loaded: form_helper
INFO - 2025-12-24 08:54:54 --> Helper loaded: file_helper
INFO - 2025-12-24 08:54:54 --> Helper loaded: html_helper
INFO - 2025-12-24 08:54:54 --> Helper loaded: security_helper
INFO - 2025-12-24 08:54:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:54:54 --> Database Driver Class Initialized
INFO - 2025-12-24 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:54:54 --> Form Validation Class Initialized
INFO - 2025-12-24 08:54:54 --> Controller Class Initialized
INFO - 2025-12-24 08:54:54 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:54:54 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:54:54 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:54:54 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:54:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:54:54 --> Upload Class Initialized
INFO - 2025-12-24 08:54:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:54:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:54:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:54:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:54:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:54:54 --> Final output sent to browser
DEBUG - 2025-12-24 08:54:54 --> Total execution time: 0.0755
INFO - 2025-12-24 08:55:03 --> Config Class Initialized
INFO - 2025-12-24 08:55:03 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:55:03 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:55:03 --> Utf8 Class Initialized
INFO - 2025-12-24 08:55:03 --> URI Class Initialized
INFO - 2025-12-24 08:55:03 --> Router Class Initialized
INFO - 2025-12-24 08:55:03 --> Output Class Initialized
INFO - 2025-12-24 08:55:03 --> Security Class Initialized
DEBUG - 2025-12-24 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:55:03 --> CSRF cookie sent
INFO - 2025-12-24 08:55:03 --> CSRF token verified
INFO - 2025-12-24 08:55:03 --> Input Class Initialized
INFO - 2025-12-24 08:55:03 --> Language Class Initialized
INFO - 2025-12-24 08:55:03 --> Loader Class Initialized
INFO - 2025-12-24 08:55:03 --> Helper loaded: url_helper
INFO - 2025-12-24 08:55:03 --> Helper loaded: form_helper
INFO - 2025-12-24 08:55:03 --> Helper loaded: file_helper
INFO - 2025-12-24 08:55:03 --> Helper loaded: html_helper
INFO - 2025-12-24 08:55:03 --> Helper loaded: security_helper
INFO - 2025-12-24 08:55:03 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:55:03 --> Database Driver Class Initialized
INFO - 2025-12-24 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:55:03 --> Form Validation Class Initialized
INFO - 2025-12-24 08:55:03 --> Controller Class Initialized
INFO - 2025-12-24 08:55:03 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:55:03 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:55:03 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:55:03 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:55:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:55:03 --> Upload Class Initialized
ERROR - 2025-12-24 08:55:04 --> Severity: error --> Exception: Call to undefined method Document_extractor::extract_surat_keluar_data() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 97
INFO - 2025-12-24 08:55:40 --> Config Class Initialized
INFO - 2025-12-24 08:55:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:55:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:55:40 --> Utf8 Class Initialized
INFO - 2025-12-24 08:55:40 --> URI Class Initialized
INFO - 2025-12-24 08:55:40 --> Router Class Initialized
INFO - 2025-12-24 08:55:40 --> Output Class Initialized
INFO - 2025-12-24 08:55:40 --> Security Class Initialized
DEBUG - 2025-12-24 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:55:40 --> CSRF cookie sent
INFO - 2025-12-24 08:55:40 --> Input Class Initialized
INFO - 2025-12-24 08:55:40 --> Language Class Initialized
INFO - 2025-12-24 08:55:40 --> Loader Class Initialized
INFO - 2025-12-24 08:55:40 --> Helper loaded: url_helper
INFO - 2025-12-24 08:55:40 --> Helper loaded: form_helper
INFO - 2025-12-24 08:55:40 --> Helper loaded: file_helper
INFO - 2025-12-24 08:55:40 --> Helper loaded: html_helper
INFO - 2025-12-24 08:55:40 --> Helper loaded: security_helper
INFO - 2025-12-24 08:55:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:55:40 --> Database Driver Class Initialized
INFO - 2025-12-24 08:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:55:40 --> Form Validation Class Initialized
INFO - 2025-12-24 08:55:40 --> Controller Class Initialized
INFO - 2025-12-24 08:55:40 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:55:40 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:55:40 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:55:40 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:55:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:55:40 --> Upload Class Initialized
INFO - 2025-12-24 08:55:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:55:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:55:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:55:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:55:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:55:40 --> Final output sent to browser
DEBUG - 2025-12-24 08:55:40 --> Total execution time: 0.0943
INFO - 2025-12-24 08:55:49 --> Config Class Initialized
INFO - 2025-12-24 08:55:49 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:55:49 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:55:49 --> Utf8 Class Initialized
INFO - 2025-12-24 08:55:49 --> URI Class Initialized
INFO - 2025-12-24 08:55:49 --> Router Class Initialized
INFO - 2025-12-24 08:55:49 --> Output Class Initialized
INFO - 2025-12-24 08:55:49 --> Security Class Initialized
DEBUG - 2025-12-24 08:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:55:49 --> CSRF cookie sent
INFO - 2025-12-24 08:55:49 --> CSRF token verified
INFO - 2025-12-24 08:55:49 --> Input Class Initialized
INFO - 2025-12-24 08:55:49 --> Language Class Initialized
INFO - 2025-12-24 08:55:49 --> Loader Class Initialized
INFO - 2025-12-24 08:55:49 --> Helper loaded: url_helper
INFO - 2025-12-24 08:55:49 --> Helper loaded: form_helper
INFO - 2025-12-24 08:55:49 --> Helper loaded: file_helper
INFO - 2025-12-24 08:55:49 --> Helper loaded: html_helper
INFO - 2025-12-24 08:55:49 --> Helper loaded: security_helper
INFO - 2025-12-24 08:55:49 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:55:49 --> Database Driver Class Initialized
INFO - 2025-12-24 08:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:55:49 --> Form Validation Class Initialized
INFO - 2025-12-24 08:55:49 --> Controller Class Initialized
INFO - 2025-12-24 08:55:49 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:55:49 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:55:49 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:55:49 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:55:49 --> Upload Class Initialized
ERROR - 2025-12-24 08:55:50 --> Severity: error --> Exception: Call to undefined method Document_extractor::extract_surat_keluar_data() D:\xampp\htdocs\surat_itm\application\controllers\Surat_keluar.php 97
INFO - 2025-12-24 08:59:33 --> Config Class Initialized
INFO - 2025-12-24 08:59:33 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:59:33 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:59:33 --> Utf8 Class Initialized
INFO - 2025-12-24 08:59:33 --> URI Class Initialized
INFO - 2025-12-24 08:59:33 --> Router Class Initialized
INFO - 2025-12-24 08:59:33 --> Output Class Initialized
INFO - 2025-12-24 08:59:33 --> Security Class Initialized
DEBUG - 2025-12-24 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:59:33 --> CSRF cookie sent
INFO - 2025-12-24 08:59:33 --> Input Class Initialized
INFO - 2025-12-24 08:59:33 --> Language Class Initialized
INFO - 2025-12-24 08:59:33 --> Loader Class Initialized
INFO - 2025-12-24 08:59:33 --> Helper loaded: url_helper
INFO - 2025-12-24 08:59:33 --> Helper loaded: form_helper
INFO - 2025-12-24 08:59:33 --> Helper loaded: file_helper
INFO - 2025-12-24 08:59:33 --> Helper loaded: html_helper
INFO - 2025-12-24 08:59:33 --> Helper loaded: security_helper
INFO - 2025-12-24 08:59:33 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:59:33 --> Database Driver Class Initialized
INFO - 2025-12-24 08:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:59:33 --> Form Validation Class Initialized
INFO - 2025-12-24 08:59:33 --> Controller Class Initialized
INFO - 2025-12-24 08:59:33 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:59:33 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:59:33 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:59:33 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:59:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:59:33 --> Upload Class Initialized
INFO - 2025-12-24 08:59:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:59:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:59:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:59:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:59:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:59:33 --> Final output sent to browser
DEBUG - 2025-12-24 08:59:33 --> Total execution time: 0.0591
INFO - 2025-12-24 08:59:51 --> Config Class Initialized
INFO - 2025-12-24 08:59:51 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:59:51 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:59:51 --> Utf8 Class Initialized
INFO - 2025-12-24 08:59:51 --> URI Class Initialized
INFO - 2025-12-24 08:59:51 --> Router Class Initialized
INFO - 2025-12-24 08:59:51 --> Output Class Initialized
INFO - 2025-12-24 08:59:51 --> Security Class Initialized
DEBUG - 2025-12-24 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:59:51 --> CSRF cookie sent
INFO - 2025-12-24 08:59:51 --> CSRF token verified
INFO - 2025-12-24 08:59:51 --> Input Class Initialized
INFO - 2025-12-24 08:59:51 --> Language Class Initialized
INFO - 2025-12-24 08:59:51 --> Loader Class Initialized
INFO - 2025-12-24 08:59:51 --> Helper loaded: url_helper
INFO - 2025-12-24 08:59:51 --> Helper loaded: form_helper
INFO - 2025-12-24 08:59:51 --> Helper loaded: file_helper
INFO - 2025-12-24 08:59:51 --> Helper loaded: html_helper
INFO - 2025-12-24 08:59:51 --> Helper loaded: security_helper
INFO - 2025-12-24 08:59:51 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:59:51 --> Database Driver Class Initialized
INFO - 2025-12-24 08:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:59:51 --> Form Validation Class Initialized
INFO - 2025-12-24 08:59:51 --> Controller Class Initialized
INFO - 2025-12-24 08:59:51 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:59:51 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:59:51 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:59:51 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:59:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:59:51 --> Upload Class Initialized
INFO - 2025-12-24 08:59:52 --> Config Class Initialized
INFO - 2025-12-24 08:59:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 08:59:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 08:59:52 --> Utf8 Class Initialized
INFO - 2025-12-24 08:59:52 --> URI Class Initialized
INFO - 2025-12-24 08:59:52 --> Router Class Initialized
INFO - 2025-12-24 08:59:52 --> Output Class Initialized
INFO - 2025-12-24 08:59:52 --> Security Class Initialized
DEBUG - 2025-12-24 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 08:59:52 --> CSRF cookie sent
INFO - 2025-12-24 08:59:52 --> Input Class Initialized
INFO - 2025-12-24 08:59:52 --> Language Class Initialized
INFO - 2025-12-24 08:59:52 --> Loader Class Initialized
INFO - 2025-12-24 08:59:52 --> Helper loaded: url_helper
INFO - 2025-12-24 08:59:52 --> Helper loaded: form_helper
INFO - 2025-12-24 08:59:52 --> Helper loaded: file_helper
INFO - 2025-12-24 08:59:52 --> Helper loaded: html_helper
INFO - 2025-12-24 08:59:52 --> Helper loaded: security_helper
INFO - 2025-12-24 08:59:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 08:59:52 --> Database Driver Class Initialized
INFO - 2025-12-24 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 08:59:52 --> Form Validation Class Initialized
INFO - 2025-12-24 08:59:52 --> Controller Class Initialized
INFO - 2025-12-24 08:59:52 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 08:59:52 --> Model "Bagian_model" initialized
INFO - 2025-12-24 08:59:52 --> Model "Kategori_model" initialized
INFO - 2025-12-24 08:59:52 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 08:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 08:59:52 --> Upload Class Initialized
INFO - 2025-12-24 08:59:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 08:59:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 08:59:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 08:59:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 08:59:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 08:59:52 --> Final output sent to browser
DEBUG - 2025-12-24 08:59:52 --> Total execution time: 0.0704
INFO - 2025-12-24 09:05:32 --> Config Class Initialized
INFO - 2025-12-24 09:05:32 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:05:32 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:05:32 --> Utf8 Class Initialized
INFO - 2025-12-24 09:05:32 --> URI Class Initialized
INFO - 2025-12-24 09:05:32 --> Router Class Initialized
INFO - 2025-12-24 09:05:32 --> Output Class Initialized
INFO - 2025-12-24 09:05:32 --> Security Class Initialized
DEBUG - 2025-12-24 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:05:32 --> CSRF cookie sent
INFO - 2025-12-24 09:05:32 --> Input Class Initialized
INFO - 2025-12-24 09:05:32 --> Language Class Initialized
INFO - 2025-12-24 09:05:32 --> Loader Class Initialized
INFO - 2025-12-24 09:05:32 --> Helper loaded: url_helper
INFO - 2025-12-24 09:05:32 --> Helper loaded: form_helper
INFO - 2025-12-24 09:05:32 --> Helper loaded: file_helper
INFO - 2025-12-24 09:05:32 --> Helper loaded: html_helper
INFO - 2025-12-24 09:05:32 --> Helper loaded: security_helper
INFO - 2025-12-24 09:05:32 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:05:32 --> Database Driver Class Initialized
INFO - 2025-12-24 09:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:05:32 --> Form Validation Class Initialized
INFO - 2025-12-24 09:05:32 --> Controller Class Initialized
INFO - 2025-12-24 09:05:32 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:05:32 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:05:32 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:05:32 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:05:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:05:32 --> Upload Class Initialized
INFO - 2025-12-24 09:05:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:05:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:05:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:05:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:05:33 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:05:33 --> Final output sent to browser
DEBUG - 2025-12-24 09:05:33 --> Total execution time: 0.4645
INFO - 2025-12-24 09:05:42 --> Config Class Initialized
INFO - 2025-12-24 09:05:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:05:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:05:42 --> Utf8 Class Initialized
INFO - 2025-12-24 09:05:42 --> URI Class Initialized
INFO - 2025-12-24 09:05:42 --> Router Class Initialized
INFO - 2025-12-24 09:05:42 --> Output Class Initialized
INFO - 2025-12-24 09:05:42 --> Security Class Initialized
DEBUG - 2025-12-24 09:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:05:42 --> CSRF cookie sent
INFO - 2025-12-24 09:05:42 --> CSRF token verified
INFO - 2025-12-24 09:05:42 --> Input Class Initialized
INFO - 2025-12-24 09:05:42 --> Language Class Initialized
INFO - 2025-12-24 09:05:42 --> Loader Class Initialized
INFO - 2025-12-24 09:05:42 --> Helper loaded: url_helper
INFO - 2025-12-24 09:05:42 --> Helper loaded: form_helper
INFO - 2025-12-24 09:05:42 --> Helper loaded: file_helper
INFO - 2025-12-24 09:05:42 --> Helper loaded: html_helper
INFO - 2025-12-24 09:05:42 --> Helper loaded: security_helper
INFO - 2025-12-24 09:05:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:05:42 --> Database Driver Class Initialized
INFO - 2025-12-24 09:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:05:42 --> Form Validation Class Initialized
INFO - 2025-12-24 09:05:42 --> Controller Class Initialized
INFO - 2025-12-24 09:05:42 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:05:42 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:05:42 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:05:42 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:05:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:05:42 --> Upload Class Initialized
INFO - 2025-12-24 09:05:43 --> Config Class Initialized
INFO - 2025-12-24 09:05:43 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:05:43 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:05:43 --> Utf8 Class Initialized
INFO - 2025-12-24 09:05:43 --> URI Class Initialized
INFO - 2025-12-24 09:05:43 --> Router Class Initialized
INFO - 2025-12-24 09:05:43 --> Output Class Initialized
INFO - 2025-12-24 09:05:43 --> Security Class Initialized
DEBUG - 2025-12-24 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:05:43 --> CSRF cookie sent
INFO - 2025-12-24 09:05:43 --> Input Class Initialized
INFO - 2025-12-24 09:05:43 --> Language Class Initialized
INFO - 2025-12-24 09:05:43 --> Loader Class Initialized
INFO - 2025-12-24 09:05:43 --> Helper loaded: url_helper
INFO - 2025-12-24 09:05:43 --> Helper loaded: form_helper
INFO - 2025-12-24 09:05:43 --> Helper loaded: file_helper
INFO - 2025-12-24 09:05:43 --> Helper loaded: html_helper
INFO - 2025-12-24 09:05:43 --> Helper loaded: security_helper
INFO - 2025-12-24 09:05:43 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:05:43 --> Database Driver Class Initialized
INFO - 2025-12-24 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:05:43 --> Form Validation Class Initialized
INFO - 2025-12-24 09:05:43 --> Controller Class Initialized
INFO - 2025-12-24 09:05:43 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:05:43 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:05:43 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:05:43 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:05:43 --> Upload Class Initialized
INFO - 2025-12-24 09:05:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:05:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:05:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:05:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:05:43 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:05:43 --> Final output sent to browser
DEBUG - 2025-12-24 09:05:43 --> Total execution time: 0.0751
INFO - 2025-12-24 09:07:53 --> Config Class Initialized
INFO - 2025-12-24 09:07:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:07:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:07:53 --> Utf8 Class Initialized
INFO - 2025-12-24 09:07:53 --> URI Class Initialized
INFO - 2025-12-24 09:07:53 --> Router Class Initialized
INFO - 2025-12-24 09:07:53 --> Output Class Initialized
INFO - 2025-12-24 09:07:53 --> Security Class Initialized
DEBUG - 2025-12-24 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:07:53 --> CSRF cookie sent
INFO - 2025-12-24 09:07:53 --> CSRF token verified
INFO - 2025-12-24 09:07:53 --> Input Class Initialized
INFO - 2025-12-24 09:07:53 --> Language Class Initialized
INFO - 2025-12-24 09:07:53 --> Loader Class Initialized
INFO - 2025-12-24 09:07:53 --> Helper loaded: url_helper
INFO - 2025-12-24 09:07:53 --> Helper loaded: form_helper
INFO - 2025-12-24 09:07:53 --> Helper loaded: file_helper
INFO - 2025-12-24 09:07:53 --> Helper loaded: html_helper
INFO - 2025-12-24 09:07:53 --> Helper loaded: security_helper
INFO - 2025-12-24 09:07:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:07:53 --> Database Driver Class Initialized
INFO - 2025-12-24 09:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:07:53 --> Form Validation Class Initialized
INFO - 2025-12-24 09:07:53 --> Controller Class Initialized
INFO - 2025-12-24 09:07:53 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:07:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:07:53 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:07:53 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:07:53 --> Upload Class Initialized
INFO - 2025-12-24 09:07:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2025-12-24 09:07:53 --> Query error: Unknown column 'no_surat_auto' in 'field list' - Invalid query: INSERT INTO `surat_keluar` (`no_surat`, `no_surat_auto`, `no_surat_asli`, `kode_bagian`, `kode_kategori`, `tujuan`, `perihal`, `tanggal_surat`, `nama_file_surat`, `file_type`, `file_size`, `status_ttd`, `created_by`) VALUES ('04.60/ITM/X/2025', NULL, '04.60/ITM/X/2025', 'ITM', '04', 'Seluruh Mahasiswa', 'Sarasehan Hari Santri', '2025-12-24', 'ddc2537685d256e8cb8ef8ad2173abf6.png', 'png', 207198, 'ditandatangani', 1)
INFO - 2025-12-24 09:07:53 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 09:14:11 --> Config Class Initialized
INFO - 2025-12-24 09:14:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:14:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:14:11 --> Utf8 Class Initialized
INFO - 2025-12-24 09:14:11 --> URI Class Initialized
INFO - 2025-12-24 09:14:11 --> Router Class Initialized
INFO - 2025-12-24 09:14:11 --> Output Class Initialized
INFO - 2025-12-24 09:14:11 --> Security Class Initialized
DEBUG - 2025-12-24 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:14:11 --> CSRF cookie sent
INFO - 2025-12-24 09:14:11 --> Input Class Initialized
INFO - 2025-12-24 09:14:11 --> Language Class Initialized
INFO - 2025-12-24 09:14:11 --> Loader Class Initialized
INFO - 2025-12-24 09:14:11 --> Helper loaded: url_helper
INFO - 2025-12-24 09:14:11 --> Helper loaded: form_helper
INFO - 2025-12-24 09:14:11 --> Helper loaded: file_helper
INFO - 2025-12-24 09:14:11 --> Helper loaded: html_helper
INFO - 2025-12-24 09:14:11 --> Helper loaded: security_helper
INFO - 2025-12-24 09:14:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:14:11 --> Database Driver Class Initialized
INFO - 2025-12-24 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:14:11 --> Form Validation Class Initialized
INFO - 2025-12-24 09:14:11 --> Controller Class Initialized
INFO - 2025-12-24 09:14:11 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:14:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:14:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:14:11 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:14:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:14:11 --> Upload Class Initialized
INFO - 2025-12-24 09:14:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:14:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:14:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:14:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:14:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:14:12 --> Final output sent to browser
DEBUG - 2025-12-24 09:14:12 --> Total execution time: 0.4566
INFO - 2025-12-24 09:14:21 --> Config Class Initialized
INFO - 2025-12-24 09:14:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:14:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:14:21 --> Utf8 Class Initialized
INFO - 2025-12-24 09:14:21 --> URI Class Initialized
INFO - 2025-12-24 09:14:21 --> Router Class Initialized
INFO - 2025-12-24 09:14:21 --> Output Class Initialized
INFO - 2025-12-24 09:14:21 --> Security Class Initialized
DEBUG - 2025-12-24 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:14:21 --> CSRF cookie sent
INFO - 2025-12-24 09:14:21 --> CSRF token verified
INFO - 2025-12-24 09:14:21 --> Input Class Initialized
INFO - 2025-12-24 09:14:21 --> Language Class Initialized
INFO - 2025-12-24 09:14:21 --> Loader Class Initialized
INFO - 2025-12-24 09:14:21 --> Helper loaded: url_helper
INFO - 2025-12-24 09:14:21 --> Helper loaded: form_helper
INFO - 2025-12-24 09:14:21 --> Helper loaded: file_helper
INFO - 2025-12-24 09:14:21 --> Helper loaded: html_helper
INFO - 2025-12-24 09:14:21 --> Helper loaded: security_helper
INFO - 2025-12-24 09:14:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:14:21 --> Database Driver Class Initialized
INFO - 2025-12-24 09:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:14:21 --> Form Validation Class Initialized
INFO - 2025-12-24 09:14:21 --> Controller Class Initialized
INFO - 2025-12-24 09:14:21 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:14:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:14:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:14:21 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:14:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:14:21 --> Upload Class Initialized
INFO - 2025-12-24 09:14:22 --> Config Class Initialized
INFO - 2025-12-24 09:14:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:14:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:14:22 --> Utf8 Class Initialized
INFO - 2025-12-24 09:14:22 --> URI Class Initialized
INFO - 2025-12-24 09:14:22 --> Router Class Initialized
INFO - 2025-12-24 09:14:22 --> Output Class Initialized
INFO - 2025-12-24 09:14:22 --> Security Class Initialized
DEBUG - 2025-12-24 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:14:22 --> CSRF cookie sent
INFO - 2025-12-24 09:14:22 --> Input Class Initialized
INFO - 2025-12-24 09:14:22 --> Language Class Initialized
INFO - 2025-12-24 09:14:22 --> Loader Class Initialized
INFO - 2025-12-24 09:14:22 --> Helper loaded: url_helper
INFO - 2025-12-24 09:14:22 --> Helper loaded: form_helper
INFO - 2025-12-24 09:14:22 --> Helper loaded: file_helper
INFO - 2025-12-24 09:14:22 --> Helper loaded: html_helper
INFO - 2025-12-24 09:14:22 --> Helper loaded: security_helper
INFO - 2025-12-24 09:14:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:14:22 --> Database Driver Class Initialized
INFO - 2025-12-24 09:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:14:22 --> Form Validation Class Initialized
INFO - 2025-12-24 09:14:22 --> Controller Class Initialized
INFO - 2025-12-24 09:14:22 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:14:22 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:14:22 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:14:22 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:14:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:14:22 --> Upload Class Initialized
INFO - 2025-12-24 09:14:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:14:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:14:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:14:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:14:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:14:22 --> Final output sent to browser
DEBUG - 2025-12-24 09:14:22 --> Total execution time: 0.0784
INFO - 2025-12-24 09:18:41 --> Config Class Initialized
INFO - 2025-12-24 09:18:41 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:18:41 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:18:41 --> Utf8 Class Initialized
INFO - 2025-12-24 09:18:41 --> URI Class Initialized
INFO - 2025-12-24 09:18:41 --> Router Class Initialized
INFO - 2025-12-24 09:18:41 --> Output Class Initialized
INFO - 2025-12-24 09:18:41 --> Security Class Initialized
DEBUG - 2025-12-24 09:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:18:41 --> CSRF cookie sent
INFO - 2025-12-24 09:18:41 --> Input Class Initialized
INFO - 2025-12-24 09:18:41 --> Language Class Initialized
INFO - 2025-12-24 09:18:41 --> Loader Class Initialized
INFO - 2025-12-24 09:18:41 --> Helper loaded: url_helper
INFO - 2025-12-24 09:18:41 --> Helper loaded: form_helper
INFO - 2025-12-24 09:18:41 --> Helper loaded: file_helper
INFO - 2025-12-24 09:18:41 --> Helper loaded: html_helper
INFO - 2025-12-24 09:18:41 --> Helper loaded: security_helper
INFO - 2025-12-24 09:18:41 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:18:41 --> Database Driver Class Initialized
INFO - 2025-12-24 09:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:18:41 --> Form Validation Class Initialized
INFO - 2025-12-24 09:18:41 --> Controller Class Initialized
INFO - 2025-12-24 09:18:41 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:18:41 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:18:41 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:18:41 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:18:41 --> Upload Class Initialized
INFO - 2025-12-24 09:18:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:18:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:18:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:18:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:18:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:18:41 --> Final output sent to browser
DEBUG - 2025-12-24 09:18:41 --> Total execution time: 0.0597
INFO - 2025-12-24 09:18:52 --> Config Class Initialized
INFO - 2025-12-24 09:18:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:18:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:18:52 --> Utf8 Class Initialized
INFO - 2025-12-24 09:18:52 --> URI Class Initialized
INFO - 2025-12-24 09:18:52 --> Router Class Initialized
INFO - 2025-12-24 09:18:52 --> Output Class Initialized
INFO - 2025-12-24 09:18:52 --> Security Class Initialized
DEBUG - 2025-12-24 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:18:52 --> CSRF cookie sent
INFO - 2025-12-24 09:18:52 --> CSRF token verified
INFO - 2025-12-24 09:18:52 --> Input Class Initialized
INFO - 2025-12-24 09:18:52 --> Language Class Initialized
INFO - 2025-12-24 09:18:52 --> Loader Class Initialized
INFO - 2025-12-24 09:18:52 --> Helper loaded: url_helper
INFO - 2025-12-24 09:18:52 --> Helper loaded: form_helper
INFO - 2025-12-24 09:18:52 --> Helper loaded: file_helper
INFO - 2025-12-24 09:18:52 --> Helper loaded: html_helper
INFO - 2025-12-24 09:18:52 --> Helper loaded: security_helper
INFO - 2025-12-24 09:18:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:18:52 --> Database Driver Class Initialized
INFO - 2025-12-24 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:18:52 --> Form Validation Class Initialized
INFO - 2025-12-24 09:18:52 --> Controller Class Initialized
INFO - 2025-12-24 09:18:52 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:18:52 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:18:52 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:18:52 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:18:52 --> Upload Class Initialized
INFO - 2025-12-24 09:18:53 --> Config Class Initialized
INFO - 2025-12-24 09:18:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:18:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:18:53 --> Utf8 Class Initialized
INFO - 2025-12-24 09:18:53 --> URI Class Initialized
INFO - 2025-12-24 09:18:53 --> Router Class Initialized
INFO - 2025-12-24 09:18:53 --> Output Class Initialized
INFO - 2025-12-24 09:18:53 --> Security Class Initialized
DEBUG - 2025-12-24 09:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:18:53 --> CSRF cookie sent
INFO - 2025-12-24 09:18:53 --> Input Class Initialized
INFO - 2025-12-24 09:18:53 --> Language Class Initialized
INFO - 2025-12-24 09:18:53 --> Loader Class Initialized
INFO - 2025-12-24 09:18:53 --> Helper loaded: url_helper
INFO - 2025-12-24 09:18:53 --> Helper loaded: form_helper
INFO - 2025-12-24 09:18:53 --> Helper loaded: file_helper
INFO - 2025-12-24 09:18:53 --> Helper loaded: html_helper
INFO - 2025-12-24 09:18:53 --> Helper loaded: security_helper
INFO - 2025-12-24 09:18:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:18:53 --> Database Driver Class Initialized
INFO - 2025-12-24 09:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:18:53 --> Form Validation Class Initialized
INFO - 2025-12-24 09:18:53 --> Controller Class Initialized
INFO - 2025-12-24 09:18:53 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:18:53 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:18:53 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:18:53 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:18:53 --> Upload Class Initialized
INFO - 2025-12-24 09:18:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:18:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:18:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:18:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:18:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:18:53 --> Final output sent to browser
DEBUG - 2025-12-24 09:18:53 --> Total execution time: 0.0775
INFO - 2025-12-24 09:19:48 --> Config Class Initialized
INFO - 2025-12-24 09:19:48 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:19:48 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:19:48 --> Utf8 Class Initialized
INFO - 2025-12-24 09:19:48 --> URI Class Initialized
INFO - 2025-12-24 09:19:48 --> Router Class Initialized
INFO - 2025-12-24 09:19:48 --> Output Class Initialized
INFO - 2025-12-24 09:19:48 --> Security Class Initialized
DEBUG - 2025-12-24 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:19:48 --> CSRF cookie sent
INFO - 2025-12-24 09:19:48 --> Input Class Initialized
INFO - 2025-12-24 09:19:48 --> Language Class Initialized
INFO - 2025-12-24 09:19:48 --> Loader Class Initialized
INFO - 2025-12-24 09:19:48 --> Helper loaded: url_helper
INFO - 2025-12-24 09:19:48 --> Helper loaded: form_helper
INFO - 2025-12-24 09:19:48 --> Helper loaded: file_helper
INFO - 2025-12-24 09:19:48 --> Helper loaded: html_helper
INFO - 2025-12-24 09:19:48 --> Helper loaded: security_helper
INFO - 2025-12-24 09:19:48 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:19:48 --> Database Driver Class Initialized
INFO - 2025-12-24 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:19:48 --> Form Validation Class Initialized
INFO - 2025-12-24 09:19:48 --> Controller Class Initialized
INFO - 2025-12-24 09:19:48 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:19:48 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:19:48 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:19:48 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:19:48 --> Upload Class Initialized
INFO - 2025-12-24 09:19:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:19:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:19:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:19:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:19:48 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:19:48 --> Final output sent to browser
DEBUG - 2025-12-24 09:19:48 --> Total execution time: 0.0600
INFO - 2025-12-24 09:19:56 --> Config Class Initialized
INFO - 2025-12-24 09:19:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:19:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:19:56 --> Utf8 Class Initialized
INFO - 2025-12-24 09:19:56 --> URI Class Initialized
INFO - 2025-12-24 09:19:56 --> Router Class Initialized
INFO - 2025-12-24 09:19:56 --> Output Class Initialized
INFO - 2025-12-24 09:19:56 --> Security Class Initialized
DEBUG - 2025-12-24 09:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:19:56 --> CSRF cookie sent
INFO - 2025-12-24 09:19:56 --> CSRF token verified
INFO - 2025-12-24 09:19:56 --> Input Class Initialized
INFO - 2025-12-24 09:19:56 --> Language Class Initialized
INFO - 2025-12-24 09:19:56 --> Loader Class Initialized
INFO - 2025-12-24 09:19:56 --> Helper loaded: url_helper
INFO - 2025-12-24 09:19:56 --> Helper loaded: form_helper
INFO - 2025-12-24 09:19:56 --> Helper loaded: file_helper
INFO - 2025-12-24 09:19:56 --> Helper loaded: html_helper
INFO - 2025-12-24 09:19:56 --> Helper loaded: security_helper
INFO - 2025-12-24 09:19:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:19:56 --> Database Driver Class Initialized
INFO - 2025-12-24 09:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:19:56 --> Form Validation Class Initialized
INFO - 2025-12-24 09:19:56 --> Controller Class Initialized
INFO - 2025-12-24 09:19:56 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:19:56 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:19:56 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:19:56 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:19:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:19:56 --> Upload Class Initialized
INFO - 2025-12-24 09:19:57 --> Config Class Initialized
INFO - 2025-12-24 09:19:57 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:19:57 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:19:57 --> Utf8 Class Initialized
INFO - 2025-12-24 09:19:57 --> URI Class Initialized
INFO - 2025-12-24 09:19:57 --> Router Class Initialized
INFO - 2025-12-24 09:19:57 --> Output Class Initialized
INFO - 2025-12-24 09:19:57 --> Security Class Initialized
DEBUG - 2025-12-24 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:19:57 --> CSRF cookie sent
INFO - 2025-12-24 09:19:57 --> Input Class Initialized
INFO - 2025-12-24 09:19:57 --> Language Class Initialized
INFO - 2025-12-24 09:19:57 --> Loader Class Initialized
INFO - 2025-12-24 09:19:57 --> Helper loaded: url_helper
INFO - 2025-12-24 09:19:57 --> Helper loaded: form_helper
INFO - 2025-12-24 09:19:57 --> Helper loaded: file_helper
INFO - 2025-12-24 09:19:57 --> Helper loaded: html_helper
INFO - 2025-12-24 09:19:57 --> Helper loaded: security_helper
INFO - 2025-12-24 09:19:57 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:19:57 --> Database Driver Class Initialized
INFO - 2025-12-24 09:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:19:57 --> Form Validation Class Initialized
INFO - 2025-12-24 09:19:57 --> Controller Class Initialized
INFO - 2025-12-24 09:19:57 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:19:57 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:19:57 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:19:57 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:19:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:19:57 --> Upload Class Initialized
INFO - 2025-12-24 09:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:19:57 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:19:57 --> Final output sent to browser
DEBUG - 2025-12-24 09:19:57 --> Total execution time: 0.0814
INFO - 2025-12-24 09:20:06 --> Config Class Initialized
INFO - 2025-12-24 09:20:06 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:06 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:06 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:06 --> URI Class Initialized
INFO - 2025-12-24 09:20:06 --> Router Class Initialized
INFO - 2025-12-24 09:20:06 --> Output Class Initialized
INFO - 2025-12-24 09:20:06 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:06 --> CSRF cookie sent
INFO - 2025-12-24 09:20:06 --> CSRF token verified
INFO - 2025-12-24 09:20:06 --> Input Class Initialized
INFO - 2025-12-24 09:20:06 --> Language Class Initialized
INFO - 2025-12-24 09:20:06 --> Loader Class Initialized
INFO - 2025-12-24 09:20:06 --> Helper loaded: url_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: form_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: file_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: html_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: security_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:20:06 --> Database Driver Class Initialized
INFO - 2025-12-24 09:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:20:06 --> Form Validation Class Initialized
INFO - 2025-12-24 09:20:06 --> Controller Class Initialized
INFO - 2025-12-24 09:20:06 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:20:06 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:20:06 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:20:06 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:20:06 --> Upload Class Initialized
INFO - 2025-12-24 09:20:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:20:06 --> Config Class Initialized
INFO - 2025-12-24 09:20:06 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:06 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:06 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:06 --> URI Class Initialized
INFO - 2025-12-24 09:20:06 --> Router Class Initialized
INFO - 2025-12-24 09:20:06 --> Output Class Initialized
INFO - 2025-12-24 09:20:06 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:06 --> CSRF cookie sent
INFO - 2025-12-24 09:20:06 --> Input Class Initialized
INFO - 2025-12-24 09:20:06 --> Language Class Initialized
INFO - 2025-12-24 09:20:06 --> Loader Class Initialized
INFO - 2025-12-24 09:20:06 --> Helper loaded: url_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: form_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: file_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: html_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: security_helper
INFO - 2025-12-24 09:20:06 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:20:06 --> Database Driver Class Initialized
INFO - 2025-12-24 09:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:20:06 --> Form Validation Class Initialized
INFO - 2025-12-24 09:20:06 --> Controller Class Initialized
INFO - 2025-12-24 09:20:06 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:20:06 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:20:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:20:07 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:20:07 --> Upload Class Initialized
INFO - 2025-12-24 09:20:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:20:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:20:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:20:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:20:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:20:07 --> Final output sent to browser
DEBUG - 2025-12-24 09:20:07 --> Total execution time: 0.0799
INFO - 2025-12-24 09:20:19 --> Config Class Initialized
INFO - 2025-12-24 09:20:19 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:19 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:19 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:19 --> URI Class Initialized
INFO - 2025-12-24 09:20:19 --> Router Class Initialized
INFO - 2025-12-24 09:20:19 --> Output Class Initialized
INFO - 2025-12-24 09:20:19 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:19 --> CSRF cookie sent
INFO - 2025-12-24 09:20:19 --> Input Class Initialized
INFO - 2025-12-24 09:20:19 --> Language Class Initialized
ERROR - 2025-12-24 09:20:19 --> 404 Page Not Found: Surat-keluar/ajukan-ttd
INFO - 2025-12-24 09:20:22 --> Config Class Initialized
INFO - 2025-12-24 09:20:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:22 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:22 --> URI Class Initialized
INFO - 2025-12-24 09:20:22 --> Router Class Initialized
INFO - 2025-12-24 09:20:22 --> Output Class Initialized
INFO - 2025-12-24 09:20:22 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:22 --> CSRF cookie sent
INFO - 2025-12-24 09:20:22 --> Input Class Initialized
INFO - 2025-12-24 09:20:22 --> Language Class Initialized
INFO - 2025-12-24 09:20:22 --> Loader Class Initialized
INFO - 2025-12-24 09:20:22 --> Helper loaded: url_helper
INFO - 2025-12-24 09:20:22 --> Helper loaded: form_helper
INFO - 2025-12-24 09:20:22 --> Helper loaded: file_helper
INFO - 2025-12-24 09:20:22 --> Helper loaded: html_helper
INFO - 2025-12-24 09:20:22 --> Helper loaded: security_helper
INFO - 2025-12-24 09:20:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:20:22 --> Database Driver Class Initialized
INFO - 2025-12-24 09:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:20:22 --> Form Validation Class Initialized
INFO - 2025-12-24 09:20:22 --> Controller Class Initialized
INFO - 2025-12-24 09:20:22 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:20:22 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:20:22 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:20:22 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:20:22 --> Upload Class Initialized
INFO - 2025-12-24 09:20:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:20:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:20:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:20:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:20:22 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:20:22 --> Final output sent to browser
DEBUG - 2025-12-24 09:20:22 --> Total execution time: 0.0664
INFO - 2025-12-24 09:20:25 --> Config Class Initialized
INFO - 2025-12-24 09:20:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:25 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:25 --> URI Class Initialized
INFO - 2025-12-24 09:20:25 --> Router Class Initialized
INFO - 2025-12-24 09:20:25 --> Output Class Initialized
INFO - 2025-12-24 09:20:25 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:25 --> CSRF cookie sent
INFO - 2025-12-24 09:20:25 --> Input Class Initialized
INFO - 2025-12-24 09:20:25 --> Language Class Initialized
INFO - 2025-12-24 09:20:25 --> Loader Class Initialized
INFO - 2025-12-24 09:20:25 --> Helper loaded: url_helper
INFO - 2025-12-24 09:20:25 --> Helper loaded: form_helper
INFO - 2025-12-24 09:20:25 --> Helper loaded: file_helper
INFO - 2025-12-24 09:20:25 --> Helper loaded: html_helper
INFO - 2025-12-24 09:20:25 --> Helper loaded: security_helper
INFO - 2025-12-24 09:20:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:20:25 --> Database Driver Class Initialized
INFO - 2025-12-24 09:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:20:25 --> Form Validation Class Initialized
INFO - 2025-12-24 09:20:25 --> Controller Class Initialized
INFO - 2025-12-24 09:20:25 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:20:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:20:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:20:25 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:20:25 --> Upload Class Initialized
INFO - 2025-12-24 09:20:25 --> Helper loaded: download_helper
INFO - 2025-12-24 09:20:27 --> Config Class Initialized
INFO - 2025-12-24 09:20:27 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:20:27 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:20:27 --> Utf8 Class Initialized
INFO - 2025-12-24 09:20:27 --> URI Class Initialized
INFO - 2025-12-24 09:20:27 --> Router Class Initialized
INFO - 2025-12-24 09:20:27 --> Output Class Initialized
INFO - 2025-12-24 09:20:27 --> Security Class Initialized
DEBUG - 2025-12-24 09:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:20:27 --> CSRF cookie sent
INFO - 2025-12-24 09:20:27 --> Input Class Initialized
INFO - 2025-12-24 09:20:27 --> Language Class Initialized
INFO - 2025-12-24 09:20:27 --> Loader Class Initialized
INFO - 2025-12-24 09:20:27 --> Helper loaded: url_helper
INFO - 2025-12-24 09:20:27 --> Helper loaded: form_helper
INFO - 2025-12-24 09:20:27 --> Helper loaded: file_helper
INFO - 2025-12-24 09:20:27 --> Helper loaded: html_helper
INFO - 2025-12-24 09:20:27 --> Helper loaded: security_helper
INFO - 2025-12-24 09:20:27 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:20:27 --> Database Driver Class Initialized
INFO - 2025-12-24 09:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:20:27 --> Form Validation Class Initialized
INFO - 2025-12-24 09:20:27 --> Controller Class Initialized
INFO - 2025-12-24 09:20:27 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:20:27 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:20:27 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:20:27 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:20:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:20:27 --> Upload Class Initialized
INFO - 2025-12-24 09:20:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:20:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:20:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 09:20:27 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\surat_keluar\detail.php 31
INFO - 2025-12-24 09:20:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-24 09:20:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:20:27 --> Final output sent to browser
DEBUG - 2025-12-24 09:20:27 --> Total execution time: 0.0682
INFO - 2025-12-24 09:21:07 --> Config Class Initialized
INFO - 2025-12-24 09:21:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:21:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:21:07 --> Utf8 Class Initialized
INFO - 2025-12-24 09:21:07 --> URI Class Initialized
INFO - 2025-12-24 09:21:07 --> Router Class Initialized
INFO - 2025-12-24 09:21:07 --> Output Class Initialized
INFO - 2025-12-24 09:21:07 --> Security Class Initialized
DEBUG - 2025-12-24 09:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:21:07 --> CSRF cookie sent
INFO - 2025-12-24 09:21:07 --> Input Class Initialized
INFO - 2025-12-24 09:21:07 --> Language Class Initialized
INFO - 2025-12-24 09:21:07 --> Loader Class Initialized
INFO - 2025-12-24 09:21:07 --> Helper loaded: url_helper
INFO - 2025-12-24 09:21:07 --> Helper loaded: form_helper
INFO - 2025-12-24 09:21:07 --> Helper loaded: file_helper
INFO - 2025-12-24 09:21:07 --> Helper loaded: html_helper
INFO - 2025-12-24 09:21:07 --> Helper loaded: security_helper
INFO - 2025-12-24 09:21:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:21:07 --> Database Driver Class Initialized
INFO - 2025-12-24 09:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:21:07 --> Form Validation Class Initialized
INFO - 2025-12-24 09:21:07 --> Controller Class Initialized
INFO - 2025-12-24 09:21:07 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:21:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:21:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:21:07 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:21:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:21:07 --> Upload Class Initialized
INFO - 2025-12-24 09:21:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:21:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:21:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:21:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-24 09:21:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:21:07 --> Final output sent to browser
DEBUG - 2025-12-24 09:21:07 --> Total execution time: 0.1002
INFO - 2025-12-24 09:22:21 --> Config Class Initialized
INFO - 2025-12-24 09:22:21 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:22:21 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:22:21 --> Utf8 Class Initialized
INFO - 2025-12-24 09:22:21 --> URI Class Initialized
INFO - 2025-12-24 09:22:21 --> Router Class Initialized
INFO - 2025-12-24 09:22:21 --> Output Class Initialized
INFO - 2025-12-24 09:22:21 --> Security Class Initialized
DEBUG - 2025-12-24 09:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:22:21 --> CSRF cookie sent
INFO - 2025-12-24 09:22:21 --> Input Class Initialized
INFO - 2025-12-24 09:22:21 --> Language Class Initialized
INFO - 2025-12-24 09:22:21 --> Loader Class Initialized
INFO - 2025-12-24 09:22:21 --> Helper loaded: url_helper
INFO - 2025-12-24 09:22:21 --> Helper loaded: form_helper
INFO - 2025-12-24 09:22:21 --> Helper loaded: file_helper
INFO - 2025-12-24 09:22:21 --> Helper loaded: html_helper
INFO - 2025-12-24 09:22:21 --> Helper loaded: security_helper
INFO - 2025-12-24 09:22:21 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:22:21 --> Database Driver Class Initialized
INFO - 2025-12-24 09:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:22:21 --> Form Validation Class Initialized
INFO - 2025-12-24 09:22:21 --> Controller Class Initialized
INFO - 2025-12-24 09:22:21 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:22:21 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:22:21 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:22:21 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:22:21 --> Upload Class Initialized
INFO - 2025-12-24 09:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-24 09:22:21 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:22:21 --> Final output sent to browser
DEBUG - 2025-12-24 09:22:21 --> Total execution time: 0.0741
INFO - 2025-12-24 09:22:23 --> Config Class Initialized
INFO - 2025-12-24 09:22:23 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:22:23 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:22:23 --> Utf8 Class Initialized
INFO - 2025-12-24 09:22:23 --> URI Class Initialized
INFO - 2025-12-24 09:22:23 --> Router Class Initialized
INFO - 2025-12-24 09:22:23 --> Output Class Initialized
INFO - 2025-12-24 09:22:23 --> Security Class Initialized
DEBUG - 2025-12-24 09:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:22:23 --> CSRF cookie sent
INFO - 2025-12-24 09:22:23 --> Input Class Initialized
INFO - 2025-12-24 09:22:23 --> Language Class Initialized
INFO - 2025-12-24 09:22:23 --> Loader Class Initialized
INFO - 2025-12-24 09:22:23 --> Helper loaded: url_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: form_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: file_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: html_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: security_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:22:23 --> Database Driver Class Initialized
INFO - 2025-12-24 09:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:22:23 --> Form Validation Class Initialized
INFO - 2025-12-24 09:22:23 --> Controller Class Initialized
INFO - 2025-12-24 09:22:23 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:22:23 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:22:23 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:22:23 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:22:23 --> Upload Class Initialized
INFO - 2025-12-24 09:22:23 --> Helper loaded: text_helper
INFO - 2025-12-24 09:22:23 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:22:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:22:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:22:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:22:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:22:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:22:23 --> Final output sent to browser
DEBUG - 2025-12-24 09:22:23 --> Total execution time: 0.0591
INFO - 2025-12-24 09:22:26 --> Config Class Initialized
INFO - 2025-12-24 09:22:26 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:22:26 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:22:26 --> Utf8 Class Initialized
INFO - 2025-12-24 09:22:26 --> URI Class Initialized
INFO - 2025-12-24 09:22:26 --> Router Class Initialized
INFO - 2025-12-24 09:22:26 --> Output Class Initialized
INFO - 2025-12-24 09:22:26 --> Security Class Initialized
DEBUG - 2025-12-24 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:22:26 --> CSRF cookie sent
INFO - 2025-12-24 09:22:26 --> Input Class Initialized
INFO - 2025-12-24 09:22:26 --> Language Class Initialized
INFO - 2025-12-24 09:22:26 --> Loader Class Initialized
INFO - 2025-12-24 09:22:26 --> Helper loaded: url_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: form_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: file_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: html_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: security_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:22:26 --> Database Driver Class Initialized
INFO - 2025-12-24 09:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:22:26 --> Form Validation Class Initialized
INFO - 2025-12-24 09:22:26 --> Controller Class Initialized
INFO - 2025-12-24 09:22:26 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:22:26 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:22:26 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:22:26 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:22:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:22:26 --> Upload Class Initialized
INFO - 2025-12-24 09:22:26 --> Helper loaded: text_helper
INFO - 2025-12-24 09:22:26 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:22:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:22:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:22:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:22:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/detail.php
INFO - 2025-12-24 09:22:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:22:26 --> Final output sent to browser
DEBUG - 2025-12-24 09:22:26 --> Total execution time: 0.1292
INFO - 2025-12-24 09:22:38 --> Config Class Initialized
INFO - 2025-12-24 09:22:38 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:22:38 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:22:38 --> Utf8 Class Initialized
INFO - 2025-12-24 09:22:38 --> URI Class Initialized
INFO - 2025-12-24 09:22:38 --> Router Class Initialized
INFO - 2025-12-24 09:22:38 --> Output Class Initialized
INFO - 2025-12-24 09:22:38 --> Security Class Initialized
DEBUG - 2025-12-24 09:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:22:38 --> CSRF cookie sent
INFO - 2025-12-24 09:22:38 --> Input Class Initialized
INFO - 2025-12-24 09:22:38 --> Language Class Initialized
INFO - 2025-12-24 09:22:38 --> Loader Class Initialized
INFO - 2025-12-24 09:22:38 --> Helper loaded: url_helper
INFO - 2025-12-24 09:22:38 --> Helper loaded: form_helper
INFO - 2025-12-24 09:22:38 --> Helper loaded: file_helper
INFO - 2025-12-24 09:22:38 --> Helper loaded: html_helper
INFO - 2025-12-24 09:22:38 --> Helper loaded: security_helper
INFO - 2025-12-24 09:22:38 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:22:38 --> Database Driver Class Initialized
INFO - 2025-12-24 09:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:22:38 --> Form Validation Class Initialized
INFO - 2025-12-24 09:22:38 --> Controller Class Initialized
INFO - 2025-12-24 09:22:38 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 09:22:38 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 09:22:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-12-24 09:22:38 --> Query error: Unknown column 'sm.no_surat_auto' in 'field list' - Invalid query: SELECT `d`.*, `sm`.`no_surat_auto`, `sm`.`pengirim`, `sm`.`perihal`
FROM `disposisi` `d`
LEFT JOIN `surat_masuk` `sm` ON `d`.`id_suratmasuk` = `sm`.`id`
ORDER BY `d`.`id_disposisi` DESC
INFO - 2025-12-24 09:22:38 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 09:23:11 --> Config Class Initialized
INFO - 2025-12-24 09:23:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:23:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:23:11 --> Utf8 Class Initialized
INFO - 2025-12-24 09:23:11 --> URI Class Initialized
INFO - 2025-12-24 09:23:11 --> Router Class Initialized
INFO - 2025-12-24 09:23:11 --> Output Class Initialized
INFO - 2025-12-24 09:23:11 --> Security Class Initialized
DEBUG - 2025-12-24 09:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:23:11 --> CSRF cookie sent
INFO - 2025-12-24 09:23:11 --> Input Class Initialized
INFO - 2025-12-24 09:23:11 --> Language Class Initialized
INFO - 2025-12-24 09:23:11 --> Loader Class Initialized
INFO - 2025-12-24 09:23:11 --> Helper loaded: url_helper
INFO - 2025-12-24 09:23:11 --> Helper loaded: form_helper
INFO - 2025-12-24 09:23:11 --> Helper loaded: file_helper
INFO - 2025-12-24 09:23:11 --> Helper loaded: html_helper
INFO - 2025-12-24 09:23:11 --> Helper loaded: security_helper
INFO - 2025-12-24 09:23:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:23:11 --> Database Driver Class Initialized
INFO - 2025-12-24 09:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:23:11 --> Form Validation Class Initialized
INFO - 2025-12-24 09:23:11 --> Controller Class Initialized
INFO - 2025-12-24 09:23:12 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 09:23:12 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 09:23:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:23:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:23:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:23:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:23:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-24 09:23:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:23:12 --> Final output sent to browser
DEBUG - 2025-12-24 09:23:12 --> Total execution time: 0.1348
INFO - 2025-12-24 09:23:14 --> Config Class Initialized
INFO - 2025-12-24 09:23:14 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:23:14 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:23:14 --> Utf8 Class Initialized
INFO - 2025-12-24 09:23:14 --> URI Class Initialized
INFO - 2025-12-24 09:23:14 --> Router Class Initialized
INFO - 2025-12-24 09:23:14 --> Output Class Initialized
INFO - 2025-12-24 09:23:14 --> Security Class Initialized
DEBUG - 2025-12-24 09:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:23:14 --> CSRF cookie sent
INFO - 2025-12-24 09:23:14 --> Input Class Initialized
INFO - 2025-12-24 09:23:14 --> Language Class Initialized
INFO - 2025-12-24 09:23:14 --> Loader Class Initialized
INFO - 2025-12-24 09:23:14 --> Helper loaded: url_helper
INFO - 2025-12-24 09:23:14 --> Helper loaded: form_helper
INFO - 2025-12-24 09:23:14 --> Helper loaded: file_helper
INFO - 2025-12-24 09:23:14 --> Helper loaded: html_helper
INFO - 2025-12-24 09:23:14 --> Helper loaded: security_helper
INFO - 2025-12-24 09:23:14 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:23:14 --> Database Driver Class Initialized
INFO - 2025-12-24 09:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:23:14 --> Form Validation Class Initialized
INFO - 2025-12-24 09:23:14 --> Controller Class Initialized
INFO - 2025-12-24 09:23:14 --> Model "User_model" initialized
INFO - 2025-12-24 09:23:14 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:23:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:23:14 --> Upload Class Initialized
INFO - 2025-12-24 09:23:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:23:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:23:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:23:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-24 09:23:14 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:23:14 --> Final output sent to browser
DEBUG - 2025-12-24 09:23:14 --> Total execution time: 0.0731
INFO - 2025-12-24 09:23:16 --> Config Class Initialized
INFO - 2025-12-24 09:23:16 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:23:16 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:23:16 --> Utf8 Class Initialized
INFO - 2025-12-24 09:23:16 --> URI Class Initialized
INFO - 2025-12-24 09:23:16 --> Router Class Initialized
INFO - 2025-12-24 09:23:16 --> Output Class Initialized
INFO - 2025-12-24 09:23:16 --> Security Class Initialized
DEBUG - 2025-12-24 09:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:23:16 --> CSRF cookie sent
INFO - 2025-12-24 09:23:16 --> Input Class Initialized
INFO - 2025-12-24 09:23:16 --> Language Class Initialized
INFO - 2025-12-24 09:23:16 --> Loader Class Initialized
INFO - 2025-12-24 09:23:16 --> Helper loaded: url_helper
INFO - 2025-12-24 09:23:16 --> Helper loaded: form_helper
INFO - 2025-12-24 09:23:16 --> Helper loaded: file_helper
INFO - 2025-12-24 09:23:16 --> Helper loaded: html_helper
INFO - 2025-12-24 09:23:16 --> Helper loaded: security_helper
INFO - 2025-12-24 09:23:16 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:23:16 --> Database Driver Class Initialized
INFO - 2025-12-24 09:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:23:16 --> Form Validation Class Initialized
INFO - 2025-12-24 09:23:16 --> Controller Class Initialized
INFO - 2025-12-24 09:23:16 --> Model "User_model" initialized
INFO - 2025-12-24 09:23:16 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:23:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:23:16 --> Upload Class Initialized
INFO - 2025-12-24 09:23:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:23:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:23:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 09:23:16 --> Severity: Warning --> Undefined property: stdClass::$tanda_tangan D:\xampp\htdocs\surat_itm\application\views\users\form.php 167
INFO - 2025-12-24 09:23:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-24 09:23:16 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:23:16 --> Final output sent to browser
DEBUG - 2025-12-24 09:23:16 --> Total execution time: 0.2341
INFO - 2025-12-24 09:24:15 --> Config Class Initialized
INFO - 2025-12-24 09:24:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:15 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:15 --> URI Class Initialized
INFO - 2025-12-24 09:24:15 --> Router Class Initialized
INFO - 2025-12-24 09:24:15 --> Output Class Initialized
INFO - 2025-12-24 09:24:15 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:15 --> CSRF cookie sent
INFO - 2025-12-24 09:24:15 --> Input Class Initialized
INFO - 2025-12-24 09:24:15 --> Language Class Initialized
INFO - 2025-12-24 09:24:15 --> Loader Class Initialized
INFO - 2025-12-24 09:24:15 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:15 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:15 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:15 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:15 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:15 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:15 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:15 --> Controller Class Initialized
INFO - 2025-12-24 09:24:15 --> Model "User_model" initialized
INFO - 2025-12-24 09:24:15 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:15 --> Upload Class Initialized
INFO - 2025-12-24 09:24:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-24 09:24:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:15 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:15 --> Total execution time: 0.2583
INFO - 2025-12-24 09:24:25 --> Config Class Initialized
INFO - 2025-12-24 09:24:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:25 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:25 --> URI Class Initialized
INFO - 2025-12-24 09:24:25 --> Router Class Initialized
INFO - 2025-12-24 09:24:25 --> Output Class Initialized
INFO - 2025-12-24 09:24:25 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:25 --> CSRF cookie sent
INFO - 2025-12-24 09:24:25 --> Input Class Initialized
INFO - 2025-12-24 09:24:25 --> Language Class Initialized
INFO - 2025-12-24 09:24:25 --> Loader Class Initialized
INFO - 2025-12-24 09:24:25 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:25 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:25 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:25 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:25 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:25 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:25 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:25 --> Controller Class Initialized
INFO - 2025-12-24 09:24:25 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-24 09:24:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:25 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:25 --> Total execution time: 0.0494
INFO - 2025-12-24 09:24:26 --> Config Class Initialized
INFO - 2025-12-24 09:24:26 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:26 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:26 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:26 --> URI Class Initialized
INFO - 2025-12-24 09:24:26 --> Router Class Initialized
INFO - 2025-12-24 09:24:26 --> Output Class Initialized
INFO - 2025-12-24 09:24:26 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:26 --> CSRF cookie sent
INFO - 2025-12-24 09:24:26 --> Input Class Initialized
INFO - 2025-12-24 09:24:26 --> Language Class Initialized
INFO - 2025-12-24 09:24:26 --> Loader Class Initialized
INFO - 2025-12-24 09:24:26 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:26 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:26 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:26 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:26 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:26 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:26 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:26 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:26 --> Controller Class Initialized
INFO - 2025-12-24 09:24:26 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:24:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:26 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/form.php
INFO - 2025-12-24 09:24:27 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:27 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:27 --> Total execution time: 0.1301
INFO - 2025-12-24 09:24:40 --> Config Class Initialized
INFO - 2025-12-24 09:24:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:40 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:40 --> URI Class Initialized
INFO - 2025-12-24 09:24:40 --> Router Class Initialized
INFO - 2025-12-24 09:24:40 --> Output Class Initialized
INFO - 2025-12-24 09:24:40 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:40 --> CSRF cookie sent
INFO - 2025-12-24 09:24:40 --> CSRF token verified
INFO - 2025-12-24 09:24:40 --> Input Class Initialized
INFO - 2025-12-24 09:24:40 --> Language Class Initialized
INFO - 2025-12-24 09:24:40 --> Loader Class Initialized
INFO - 2025-12-24 09:24:40 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:40 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:40 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:40 --> Controller Class Initialized
INFO - 2025-12-24 09:24:40 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:24:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:24:40 --> Config Class Initialized
INFO - 2025-12-24 09:24:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:40 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:40 --> URI Class Initialized
INFO - 2025-12-24 09:24:40 --> Router Class Initialized
INFO - 2025-12-24 09:24:40 --> Output Class Initialized
INFO - 2025-12-24 09:24:40 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:40 --> CSRF cookie sent
INFO - 2025-12-24 09:24:40 --> Input Class Initialized
INFO - 2025-12-24 09:24:40 --> Language Class Initialized
INFO - 2025-12-24 09:24:40 --> Loader Class Initialized
INFO - 2025-12-24 09:24:40 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:40 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:40 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:40 --> Controller Class Initialized
INFO - 2025-12-24 09:24:40 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:24:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-24 09:24:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:40 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:40 --> Total execution time: 0.0571
INFO - 2025-12-24 09:24:44 --> Config Class Initialized
INFO - 2025-12-24 09:24:44 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:44 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:44 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:44 --> URI Class Initialized
INFO - 2025-12-24 09:24:44 --> Router Class Initialized
INFO - 2025-12-24 09:24:44 --> Output Class Initialized
INFO - 2025-12-24 09:24:44 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:44 --> CSRF cookie sent
INFO - 2025-12-24 09:24:44 --> Input Class Initialized
INFO - 2025-12-24 09:24:44 --> Language Class Initialized
INFO - 2025-12-24 09:24:44 --> Loader Class Initialized
INFO - 2025-12-24 09:24:44 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:44 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:44 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:44 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:44 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:44 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:44 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:44 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:44 --> Controller Class Initialized
INFO - 2025-12-24 09:24:44 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 09:24:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:44 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:44 --> Total execution time: 0.0810
INFO - 2025-12-24 09:24:50 --> Config Class Initialized
INFO - 2025-12-24 09:24:50 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:50 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:50 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:50 --> URI Class Initialized
INFO - 2025-12-24 09:24:50 --> Router Class Initialized
INFO - 2025-12-24 09:24:50 --> Output Class Initialized
INFO - 2025-12-24 09:24:50 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:50 --> CSRF cookie sent
INFO - 2025-12-24 09:24:50 --> Input Class Initialized
INFO - 2025-12-24 09:24:50 --> Language Class Initialized
INFO - 2025-12-24 09:24:50 --> Loader Class Initialized
INFO - 2025-12-24 09:24:50 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:50 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:50 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:50 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:50 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:50 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:50 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:50 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:50 --> Controller Class Initialized
INFO - 2025-12-24 09:24:50 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/form.php
INFO - 2025-12-24 09:24:50 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:50 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:50 --> Total execution time: 0.1278
INFO - 2025-12-24 09:24:53 --> Config Class Initialized
INFO - 2025-12-24 09:24:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:53 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:53 --> URI Class Initialized
INFO - 2025-12-24 09:24:53 --> Router Class Initialized
INFO - 2025-12-24 09:24:53 --> Output Class Initialized
INFO - 2025-12-24 09:24:53 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:53 --> CSRF cookie sent
INFO - 2025-12-24 09:24:53 --> CSRF token verified
INFO - 2025-12-24 09:24:53 --> Input Class Initialized
INFO - 2025-12-24 09:24:53 --> Language Class Initialized
INFO - 2025-12-24 09:24:53 --> Loader Class Initialized
INFO - 2025-12-24 09:24:53 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:53 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:53 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:53 --> Controller Class Initialized
INFO - 2025-12-24 09:24:53 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:24:53 --> Config Class Initialized
INFO - 2025-12-24 09:24:53 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:53 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:53 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:53 --> URI Class Initialized
INFO - 2025-12-24 09:24:53 --> Router Class Initialized
INFO - 2025-12-24 09:24:53 --> Output Class Initialized
INFO - 2025-12-24 09:24:53 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:53 --> CSRF cookie sent
INFO - 2025-12-24 09:24:53 --> Input Class Initialized
INFO - 2025-12-24 09:24:53 --> Language Class Initialized
INFO - 2025-12-24 09:24:53 --> Loader Class Initialized
INFO - 2025-12-24 09:24:53 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:53 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:53 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:53 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:53 --> Controller Class Initialized
INFO - 2025-12-24 09:24:53 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 09:24:53 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:53 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:53 --> Total execution time: 0.0495
INFO - 2025-12-24 09:24:55 --> Config Class Initialized
INFO - 2025-12-24 09:24:55 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:55 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:55 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:55 --> URI Class Initialized
INFO - 2025-12-24 09:24:55 --> Router Class Initialized
INFO - 2025-12-24 09:24:55 --> Output Class Initialized
INFO - 2025-12-24 09:24:55 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:55 --> CSRF cookie sent
INFO - 2025-12-24 09:24:55 --> Input Class Initialized
INFO - 2025-12-24 09:24:55 --> Language Class Initialized
INFO - 2025-12-24 09:24:55 --> Loader Class Initialized
INFO - 2025-12-24 09:24:55 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:55 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:55 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:55 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:55 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:55 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:55 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:55 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:55 --> Controller Class Initialized
INFO - 2025-12-24 09:24:55 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/form.php
INFO - 2025-12-24 09:24:55 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:55 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:55 --> Total execution time: 0.0533
INFO - 2025-12-24 09:24:58 --> Config Class Initialized
INFO - 2025-12-24 09:24:58 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:58 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:58 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:58 --> URI Class Initialized
INFO - 2025-12-24 09:24:58 --> Router Class Initialized
INFO - 2025-12-24 09:24:58 --> Output Class Initialized
INFO - 2025-12-24 09:24:58 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:58 --> CSRF cookie sent
INFO - 2025-12-24 09:24:58 --> CSRF token verified
INFO - 2025-12-24 09:24:58 --> Input Class Initialized
INFO - 2025-12-24 09:24:58 --> Language Class Initialized
INFO - 2025-12-24 09:24:58 --> Loader Class Initialized
INFO - 2025-12-24 09:24:58 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:58 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:58 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:58 --> Controller Class Initialized
INFO - 2025-12-24 09:24:58 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:24:58 --> Config Class Initialized
INFO - 2025-12-24 09:24:58 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:58 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:58 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:58 --> URI Class Initialized
INFO - 2025-12-24 09:24:58 --> Router Class Initialized
INFO - 2025-12-24 09:24:58 --> Output Class Initialized
INFO - 2025-12-24 09:24:58 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:58 --> CSRF cookie sent
INFO - 2025-12-24 09:24:58 --> Input Class Initialized
INFO - 2025-12-24 09:24:58 --> Language Class Initialized
INFO - 2025-12-24 09:24:58 --> Loader Class Initialized
INFO - 2025-12-24 09:24:58 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:58 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:58 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:58 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:58 --> Controller Class Initialized
INFO - 2025-12-24 09:24:58 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 09:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:24:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:24:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 09:24:58 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:58 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:58 --> Total execution time: 0.0516
INFO - 2025-12-24 09:24:59 --> Config Class Initialized
INFO - 2025-12-24 09:24:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:24:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:24:59 --> Utf8 Class Initialized
INFO - 2025-12-24 09:24:59 --> URI Class Initialized
INFO - 2025-12-24 09:24:59 --> Router Class Initialized
INFO - 2025-12-24 09:24:59 --> Output Class Initialized
INFO - 2025-12-24 09:24:59 --> Security Class Initialized
DEBUG - 2025-12-24 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:24:59 --> CSRF cookie sent
INFO - 2025-12-24 09:24:59 --> Input Class Initialized
INFO - 2025-12-24 09:24:59 --> Language Class Initialized
INFO - 2025-12-24 09:24:59 --> Loader Class Initialized
INFO - 2025-12-24 09:24:59 --> Helper loaded: url_helper
INFO - 2025-12-24 09:24:59 --> Helper loaded: form_helper
INFO - 2025-12-24 09:24:59 --> Helper loaded: file_helper
INFO - 2025-12-24 09:24:59 --> Helper loaded: html_helper
INFO - 2025-12-24 09:24:59 --> Helper loaded: security_helper
INFO - 2025-12-24 09:24:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:24:59 --> Database Driver Class Initialized
INFO - 2025-12-24 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:24:59 --> Form Validation Class Initialized
INFO - 2025-12-24 09:24:59 --> Controller Class Initialized
INFO - 2025-12-24 09:24:59 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:24:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:24:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:24:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:24:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
ERROR - 2025-12-24 09:24:59 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\laporan\surat_masuk.php 105
INFO - 2025-12-24 09:24:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 09:24:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:24:59 --> Final output sent to browser
DEBUG - 2025-12-24 09:24:59 --> Total execution time: 0.1318
INFO - 2025-12-24 09:26:09 --> Config Class Initialized
INFO - 2025-12-24 09:26:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:26:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:26:09 --> Utf8 Class Initialized
INFO - 2025-12-24 09:26:09 --> URI Class Initialized
INFO - 2025-12-24 09:26:09 --> Router Class Initialized
INFO - 2025-12-24 09:26:09 --> Output Class Initialized
INFO - 2025-12-24 09:26:09 --> Security Class Initialized
DEBUG - 2025-12-24 09:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:26:09 --> CSRF cookie sent
INFO - 2025-12-24 09:26:09 --> Input Class Initialized
INFO - 2025-12-24 09:26:09 --> Language Class Initialized
INFO - 2025-12-24 09:26:09 --> Loader Class Initialized
INFO - 2025-12-24 09:26:09 --> Helper loaded: url_helper
INFO - 2025-12-24 09:26:09 --> Helper loaded: form_helper
INFO - 2025-12-24 09:26:09 --> Helper loaded: file_helper
INFO - 2025-12-24 09:26:09 --> Helper loaded: html_helper
INFO - 2025-12-24 09:26:09 --> Helper loaded: security_helper
INFO - 2025-12-24 09:26:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:26:09 --> Database Driver Class Initialized
INFO - 2025-12-24 09:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:26:09 --> Form Validation Class Initialized
INFO - 2025-12-24 09:26:09 --> Controller Class Initialized
INFO - 2025-12-24 09:26:09 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:26:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:26:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:26:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:26:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:26:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 09:26:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:26:09 --> Final output sent to browser
DEBUG - 2025-12-24 09:26:09 --> Total execution time: 0.1466
INFO - 2025-12-24 09:26:12 --> Config Class Initialized
INFO - 2025-12-24 09:26:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:26:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:26:12 --> Utf8 Class Initialized
INFO - 2025-12-24 09:26:12 --> URI Class Initialized
INFO - 2025-12-24 09:26:12 --> Router Class Initialized
INFO - 2025-12-24 09:26:12 --> Output Class Initialized
INFO - 2025-12-24 09:26:12 --> Security Class Initialized
DEBUG - 2025-12-24 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:26:12 --> CSRF cookie sent
INFO - 2025-12-24 09:26:12 --> Input Class Initialized
INFO - 2025-12-24 09:26:12 --> Language Class Initialized
INFO - 2025-12-24 09:26:12 --> Loader Class Initialized
INFO - 2025-12-24 09:26:12 --> Helper loaded: url_helper
INFO - 2025-12-24 09:26:12 --> Helper loaded: form_helper
INFO - 2025-12-24 09:26:12 --> Helper loaded: file_helper
INFO - 2025-12-24 09:26:12 --> Helper loaded: html_helper
INFO - 2025-12-24 09:26:12 --> Helper loaded: security_helper
INFO - 2025-12-24 09:26:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:26:12 --> Database Driver Class Initialized
INFO - 2025-12-24 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:26:12 --> Form Validation Class Initialized
INFO - 2025-12-24 09:26:12 --> Controller Class Initialized
INFO - 2025-12-24 09:26:12 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:26:12 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 09:26:12 --> Severity: Warning --> Undefined property: stdClass::$no_surat_auto D:\xampp\htdocs\surat_itm\application\views\laporan\print_masuk.php 109
INFO - 2025-12-24 09:26:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_masuk.php
INFO - 2025-12-24 09:26:12 --> Final output sent to browser
DEBUG - 2025-12-24 09:26:12 --> Total execution time: 0.0679
INFO - 2025-12-24 09:27:15 --> Config Class Initialized
INFO - 2025-12-24 09:27:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:15 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:15 --> URI Class Initialized
INFO - 2025-12-24 09:27:15 --> Router Class Initialized
INFO - 2025-12-24 09:27:15 --> Output Class Initialized
INFO - 2025-12-24 09:27:15 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:15 --> CSRF cookie sent
INFO - 2025-12-24 09:27:15 --> Input Class Initialized
INFO - 2025-12-24 09:27:15 --> Language Class Initialized
INFO - 2025-12-24 09:27:15 --> Loader Class Initialized
INFO - 2025-12-24 09:27:15 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:15 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:15 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:15 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:15 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:15 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:15 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:15 --> Controller Class Initialized
INFO - 2025-12-24 09:27:15 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:27:15 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_masuk.php
INFO - 2025-12-24 09:27:15 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:15 --> Total execution time: 0.1013
INFO - 2025-12-24 09:27:34 --> Config Class Initialized
INFO - 2025-12-24 09:27:34 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:34 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:34 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:34 --> URI Class Initialized
INFO - 2025-12-24 09:27:34 --> Router Class Initialized
INFO - 2025-12-24 09:27:34 --> Output Class Initialized
INFO - 2025-12-24 09:27:34 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:34 --> CSRF cookie sent
INFO - 2025-12-24 09:27:34 --> Input Class Initialized
INFO - 2025-12-24 09:27:34 --> Language Class Initialized
INFO - 2025-12-24 09:27:34 --> Loader Class Initialized
INFO - 2025-12-24 09:27:34 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:34 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:34 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:34 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:34 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:34 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:34 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:34 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:34 --> Controller Class Initialized
INFO - 2025-12-24 09:27:34 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 09:27:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\bagian/index.php
INFO - 2025-12-24 09:27:34 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:34 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:34 --> Total execution time: 0.0483
INFO - 2025-12-24 09:27:35 --> Config Class Initialized
INFO - 2025-12-24 09:27:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:35 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:35 --> URI Class Initialized
INFO - 2025-12-24 09:27:35 --> Router Class Initialized
INFO - 2025-12-24 09:27:35 --> Output Class Initialized
INFO - 2025-12-24 09:27:35 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:35 --> CSRF cookie sent
INFO - 2025-12-24 09:27:35 --> Input Class Initialized
INFO - 2025-12-24 09:27:35 --> Language Class Initialized
INFO - 2025-12-24 09:27:35 --> Loader Class Initialized
INFO - 2025-12-24 09:27:35 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:35 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:35 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:35 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:35 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:35 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:35 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:35 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:35 --> Controller Class Initialized
INFO - 2025-12-24 09:27:35 --> Model "Disposisi_model" initialized
INFO - 2025-12-24 09:27:35 --> Model "Surat_masuk_model" initialized
DEBUG - 2025-12-24 09:27:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\disposisi/index.php
INFO - 2025-12-24 09:27:35 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:35 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:35 --> Total execution time: 0.0588
INFO - 2025-12-24 09:27:36 --> Config Class Initialized
INFO - 2025-12-24 09:27:36 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:36 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:36 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:36 --> URI Class Initialized
INFO - 2025-12-24 09:27:36 --> Router Class Initialized
INFO - 2025-12-24 09:27:36 --> Output Class Initialized
INFO - 2025-12-24 09:27:36 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:36 --> CSRF cookie sent
INFO - 2025-12-24 09:27:36 --> Input Class Initialized
INFO - 2025-12-24 09:27:36 --> Language Class Initialized
INFO - 2025-12-24 09:27:36 --> Loader Class Initialized
INFO - 2025-12-24 09:27:36 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:36 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:36 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:36 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:36 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:36 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:36 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:36 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:36 --> Controller Class Initialized
INFO - 2025-12-24 09:27:36 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:27:36 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:36 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:36 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:36 --> Upload Class Initialized
INFO - 2025-12-24 09:27:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:27:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:36 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:36 --> Total execution time: 0.0540
INFO - 2025-12-24 09:27:36 --> Config Class Initialized
INFO - 2025-12-24 09:27:36 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:36 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:36 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:36 --> URI Class Initialized
INFO - 2025-12-24 09:27:36 --> Router Class Initialized
INFO - 2025-12-24 09:27:36 --> Output Class Initialized
INFO - 2025-12-24 09:27:37 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:37 --> CSRF cookie sent
INFO - 2025-12-24 09:27:37 --> Input Class Initialized
INFO - 2025-12-24 09:27:37 --> Language Class Initialized
INFO - 2025-12-24 09:27:37 --> Loader Class Initialized
INFO - 2025-12-24 09:27:37 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:37 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:37 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:37 --> Controller Class Initialized
INFO - 2025-12-24 09:27:37 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:27:37 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:37 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:37 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:27:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:37 --> Upload Class Initialized
INFO - 2025-12-24 09:27:37 --> Helper loaded: text_helper
INFO - 2025-12-24 09:27:37 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:27:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:27:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:37 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:37 --> Total execution time: 0.0562
INFO - 2025-12-24 09:27:39 --> Config Class Initialized
INFO - 2025-12-24 09:27:39 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:39 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:39 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:39 --> URI Class Initialized
INFO - 2025-12-24 09:27:39 --> Router Class Initialized
INFO - 2025-12-24 09:27:39 --> Output Class Initialized
INFO - 2025-12-24 09:27:39 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:39 --> CSRF cookie sent
INFO - 2025-12-24 09:27:39 --> Input Class Initialized
INFO - 2025-12-24 09:27:39 --> Language Class Initialized
INFO - 2025-12-24 09:27:39 --> Loader Class Initialized
INFO - 2025-12-24 09:27:39 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:39 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:39 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:39 --> Controller Class Initialized
INFO - 2025-12-24 09:27:39 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:27:39 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:39 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:39 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:27:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:39 --> Upload Class Initialized
INFO - 2025-12-24 09:27:39 --> Helper loaded: text_helper
INFO - 2025-12-24 09:27:39 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:27:39 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:39 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:39 --> Total execution time: 0.0584
INFO - 2025-12-24 09:27:41 --> Config Class Initialized
INFO - 2025-12-24 09:27:41 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:41 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:41 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:41 --> URI Class Initialized
INFO - 2025-12-24 09:27:41 --> Router Class Initialized
INFO - 2025-12-24 09:27:41 --> Output Class Initialized
INFO - 2025-12-24 09:27:41 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:41 --> CSRF cookie sent
INFO - 2025-12-24 09:27:41 --> Input Class Initialized
INFO - 2025-12-24 09:27:41 --> Language Class Initialized
INFO - 2025-12-24 09:27:41 --> Loader Class Initialized
INFO - 2025-12-24 09:27:41 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:41 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:41 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:41 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:41 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:41 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:41 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:41 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:41 --> Controller Class Initialized
INFO - 2025-12-24 09:27:41 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:27:41 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:41 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:41 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:27:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:41 --> Upload Class Initialized
INFO - 2025-12-24 09:27:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:27:41 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:41 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:41 --> Total execution time: 0.0584
INFO - 2025-12-24 09:27:44 --> Config Class Initialized
INFO - 2025-12-24 09:27:44 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:44 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:44 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:44 --> URI Class Initialized
INFO - 2025-12-24 09:27:44 --> Router Class Initialized
INFO - 2025-12-24 09:27:44 --> Output Class Initialized
INFO - 2025-12-24 09:27:44 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:44 --> CSRF cookie sent
INFO - 2025-12-24 09:27:44 --> Input Class Initialized
INFO - 2025-12-24 09:27:44 --> Language Class Initialized
INFO - 2025-12-24 09:27:44 --> Loader Class Initialized
INFO - 2025-12-24 09:27:44 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:44 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:44 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:44 --> Controller Class Initialized
INFO - 2025-12-24 09:27:44 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:27:44 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:44 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:44 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:27:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:44 --> Upload Class Initialized
INFO - 2025-12-24 09:27:44 --> Helper loaded: text_helper
INFO - 2025-12-24 09:27:44 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:27:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:27:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:44 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:44 --> Total execution time: 0.0662
INFO - 2025-12-24 09:27:47 --> Config Class Initialized
INFO - 2025-12-24 09:27:47 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:47 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:47 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:47 --> URI Class Initialized
INFO - 2025-12-24 09:27:47 --> Router Class Initialized
INFO - 2025-12-24 09:27:47 --> Output Class Initialized
INFO - 2025-12-24 09:27:47 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:47 --> CSRF cookie sent
INFO - 2025-12-24 09:27:47 --> Input Class Initialized
INFO - 2025-12-24 09:27:47 --> Language Class Initialized
INFO - 2025-12-24 09:27:47 --> Loader Class Initialized
INFO - 2025-12-24 09:27:47 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:47 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:47 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:47 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:47 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:47 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:47 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:47 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:47 --> Controller Class Initialized
INFO - 2025-12-24 09:27:47 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:27:47 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:47 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:47 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:27:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:47 --> Upload Class Initialized
INFO - 2025-12-24 09:27:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:27:47 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:47 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:47 --> Total execution time: 0.0542
INFO - 2025-12-24 09:27:49 --> Config Class Initialized
INFO - 2025-12-24 09:27:49 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:27:49 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:27:49 --> Utf8 Class Initialized
INFO - 2025-12-24 09:27:49 --> URI Class Initialized
INFO - 2025-12-24 09:27:49 --> Router Class Initialized
INFO - 2025-12-24 09:27:49 --> Output Class Initialized
INFO - 2025-12-24 09:27:49 --> Security Class Initialized
DEBUG - 2025-12-24 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:27:49 --> CSRF cookie sent
INFO - 2025-12-24 09:27:49 --> Input Class Initialized
INFO - 2025-12-24 09:27:49 --> Language Class Initialized
INFO - 2025-12-24 09:27:49 --> Loader Class Initialized
INFO - 2025-12-24 09:27:49 --> Helper loaded: url_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: form_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: file_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: html_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: security_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:27:49 --> Database Driver Class Initialized
INFO - 2025-12-24 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:27:49 --> Form Validation Class Initialized
INFO - 2025-12-24 09:27:49 --> Controller Class Initialized
INFO - 2025-12-24 09:27:49 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:27:49 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:27:49 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:27:49 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:27:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:27:49 --> Upload Class Initialized
INFO - 2025-12-24 09:27:49 --> Helper loaded: text_helper
INFO - 2025-12-24 09:27:49 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:27:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:27:49 --> Final output sent to browser
DEBUG - 2025-12-24 09:27:49 --> Total execution time: 0.0559
INFO - 2025-12-24 09:31:31 --> Config Class Initialized
INFO - 2025-12-24 09:31:31 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:31:31 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:31:31 --> Utf8 Class Initialized
INFO - 2025-12-24 09:31:31 --> URI Class Initialized
INFO - 2025-12-24 09:31:31 --> Router Class Initialized
INFO - 2025-12-24 09:31:31 --> Output Class Initialized
INFO - 2025-12-24 09:31:31 --> Security Class Initialized
DEBUG - 2025-12-24 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:31:31 --> CSRF cookie sent
INFO - 2025-12-24 09:31:31 --> Input Class Initialized
INFO - 2025-12-24 09:31:31 --> Language Class Initialized
INFO - 2025-12-24 09:31:31 --> Loader Class Initialized
INFO - 2025-12-24 09:31:31 --> Helper loaded: url_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: form_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: file_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: html_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: security_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:31:31 --> Database Driver Class Initialized
INFO - 2025-12-24 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:31:31 --> Form Validation Class Initialized
INFO - 2025-12-24 09:31:31 --> Controller Class Initialized
INFO - 2025-12-24 09:31:31 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:31:31 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:31:31 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:31:31 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:31:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:31:31 --> Upload Class Initialized
INFO - 2025-12-24 09:31:31 --> Helper loaded: text_helper
INFO - 2025-12-24 09:31:31 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:31:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:31:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:31:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:31:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:31:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:31:32 --> Final output sent to browser
DEBUG - 2025-12-24 09:31:32 --> Total execution time: 0.3562
INFO - 2025-12-24 09:31:49 --> Config Class Initialized
INFO - 2025-12-24 09:31:49 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:31:49 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:31:49 --> Utf8 Class Initialized
INFO - 2025-12-24 09:31:49 --> URI Class Initialized
INFO - 2025-12-24 09:31:49 --> Router Class Initialized
INFO - 2025-12-24 09:31:49 --> Output Class Initialized
INFO - 2025-12-24 09:31:49 --> Security Class Initialized
DEBUG - 2025-12-24 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:31:49 --> CSRF cookie sent
INFO - 2025-12-24 09:31:49 --> Input Class Initialized
INFO - 2025-12-24 09:31:49 --> Language Class Initialized
INFO - 2025-12-24 09:31:49 --> Loader Class Initialized
INFO - 2025-12-24 09:31:49 --> Helper loaded: url_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: form_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: file_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: html_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: security_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:31:49 --> Database Driver Class Initialized
INFO - 2025-12-24 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:31:49 --> Form Validation Class Initialized
INFO - 2025-12-24 09:31:49 --> Controller Class Initialized
INFO - 2025-12-24 09:31:49 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:31:49 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:31:49 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:31:49 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:31:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:31:49 --> Upload Class Initialized
INFO - 2025-12-24 09:31:49 --> Helper loaded: text_helper
INFO - 2025-12-24 09:31:49 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:31:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:31:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:31:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:31:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:31:49 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:31:49 --> Final output sent to browser
DEBUG - 2025-12-24 09:31:49 --> Total execution time: 0.3556
INFO - 2025-12-24 09:31:52 --> Config Class Initialized
INFO - 2025-12-24 09:31:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:31:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:31:52 --> Utf8 Class Initialized
INFO - 2025-12-24 09:31:52 --> URI Class Initialized
INFO - 2025-12-24 09:31:52 --> Router Class Initialized
INFO - 2025-12-24 09:31:52 --> Output Class Initialized
INFO - 2025-12-24 09:31:52 --> Security Class Initialized
DEBUG - 2025-12-24 09:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:31:52 --> CSRF cookie sent
INFO - 2025-12-24 09:31:52 --> Input Class Initialized
INFO - 2025-12-24 09:31:52 --> Language Class Initialized
INFO - 2025-12-24 09:31:52 --> Loader Class Initialized
INFO - 2025-12-24 09:31:52 --> Helper loaded: url_helper
INFO - 2025-12-24 09:31:52 --> Helper loaded: form_helper
INFO - 2025-12-24 09:31:52 --> Helper loaded: file_helper
INFO - 2025-12-24 09:31:52 --> Helper loaded: html_helper
INFO - 2025-12-24 09:31:52 --> Helper loaded: security_helper
INFO - 2025-12-24 09:31:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:31:52 --> Database Driver Class Initialized
INFO - 2025-12-24 09:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:31:52 --> Form Validation Class Initialized
INFO - 2025-12-24 09:31:52 --> Controller Class Initialized
INFO - 2025-12-24 09:31:52 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:31:52 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:31:52 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:31:52 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:31:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:31:52 --> Upload Class Initialized
INFO - 2025-12-24 09:31:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:31:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:31:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:31:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:31:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:31:52 --> Final output sent to browser
DEBUG - 2025-12-24 09:31:52 --> Total execution time: 0.0989
INFO - 2025-12-24 09:31:59 --> Config Class Initialized
INFO - 2025-12-24 09:31:59 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:31:59 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:31:59 --> Utf8 Class Initialized
INFO - 2025-12-24 09:31:59 --> URI Class Initialized
INFO - 2025-12-24 09:31:59 --> Router Class Initialized
INFO - 2025-12-24 09:31:59 --> Output Class Initialized
INFO - 2025-12-24 09:31:59 --> Security Class Initialized
DEBUG - 2025-12-24 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:31:59 --> CSRF cookie sent
INFO - 2025-12-24 09:31:59 --> Input Class Initialized
INFO - 2025-12-24 09:31:59 --> Language Class Initialized
INFO - 2025-12-24 09:31:59 --> Loader Class Initialized
INFO - 2025-12-24 09:31:59 --> Helper loaded: url_helper
INFO - 2025-12-24 09:31:59 --> Helper loaded: form_helper
INFO - 2025-12-24 09:31:59 --> Helper loaded: file_helper
INFO - 2025-12-24 09:31:59 --> Helper loaded: html_helper
INFO - 2025-12-24 09:31:59 --> Helper loaded: security_helper
INFO - 2025-12-24 09:31:59 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:31:59 --> Database Driver Class Initialized
INFO - 2025-12-24 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:31:59 --> Form Validation Class Initialized
INFO - 2025-12-24 09:31:59 --> Controller Class Initialized
INFO - 2025-12-24 09:31:59 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:31:59 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:31:59 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:31:59 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:31:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:31:59 --> Upload Class Initialized
INFO - 2025-12-24 09:31:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:31:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:31:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:31:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/detail.php
INFO - 2025-12-24 09:31:59 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:31:59 --> Final output sent to browser
DEBUG - 2025-12-24 09:31:59 --> Total execution time: 0.0546
INFO - 2025-12-24 09:32:03 --> Config Class Initialized
INFO - 2025-12-24 09:32:03 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:03 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:03 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:03 --> URI Class Initialized
INFO - 2025-12-24 09:32:03 --> Router Class Initialized
INFO - 2025-12-24 09:32:03 --> Output Class Initialized
INFO - 2025-12-24 09:32:03 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:03 --> CSRF cookie sent
INFO - 2025-12-24 09:32:03 --> Input Class Initialized
INFO - 2025-12-24 09:32:03 --> Language Class Initialized
INFO - 2025-12-24 09:32:03 --> Loader Class Initialized
INFO - 2025-12-24 09:32:03 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:03 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:03 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:03 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:03 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:03 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:03 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:03 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:03 --> Controller Class Initialized
INFO - 2025-12-24 09:32:03 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:32:03 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:03 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:03 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:32:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:03 --> Upload Class Initialized
INFO - 2025-12-24 09:32:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:32:03 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:03 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:03 --> Total execution time: 0.0784
INFO - 2025-12-24 09:32:07 --> Config Class Initialized
INFO - 2025-12-24 09:32:07 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:07 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:07 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:07 --> URI Class Initialized
INFO - 2025-12-24 09:32:07 --> Router Class Initialized
INFO - 2025-12-24 09:32:07 --> Output Class Initialized
INFO - 2025-12-24 09:32:07 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:07 --> CSRF cookie sent
INFO - 2025-12-24 09:32:07 --> Input Class Initialized
INFO - 2025-12-24 09:32:07 --> Language Class Initialized
INFO - 2025-12-24 09:32:07 --> Loader Class Initialized
INFO - 2025-12-24 09:32:07 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:07 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:07 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:07 --> Controller Class Initialized
INFO - 2025-12-24 09:32:07 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:07 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:07 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:07 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:07 --> Upload Class Initialized
INFO - 2025-12-24 09:32:07 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:07 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:32:07 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:07 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:07 --> Total execution time: 0.0707
INFO - 2025-12-24 09:32:09 --> Config Class Initialized
INFO - 2025-12-24 09:32:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:09 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:09 --> URI Class Initialized
INFO - 2025-12-24 09:32:09 --> Router Class Initialized
INFO - 2025-12-24 09:32:09 --> Output Class Initialized
INFO - 2025-12-24 09:32:09 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:09 --> CSRF cookie sent
INFO - 2025-12-24 09:32:09 --> Input Class Initialized
INFO - 2025-12-24 09:32:09 --> Language Class Initialized
INFO - 2025-12-24 09:32:09 --> Loader Class Initialized
INFO - 2025-12-24 09:32:09 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:09 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:09 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:09 --> Controller Class Initialized
INFO - 2025-12-24 09:32:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:09 --> Upload Class Initialized
INFO - 2025-12-24 09:32:09 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 09:32:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:09 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:09 --> Total execution time: 0.0802
INFO - 2025-12-24 09:32:24 --> Config Class Initialized
INFO - 2025-12-24 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:24 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:24 --> URI Class Initialized
INFO - 2025-12-24 09:32:24 --> Router Class Initialized
INFO - 2025-12-24 09:32:24 --> Output Class Initialized
INFO - 2025-12-24 09:32:24 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:24 --> CSRF cookie sent
INFO - 2025-12-24 09:32:24 --> CSRF token verified
INFO - 2025-12-24 09:32:24 --> Input Class Initialized
INFO - 2025-12-24 09:32:24 --> Language Class Initialized
INFO - 2025-12-24 09:32:24 --> Loader Class Initialized
INFO - 2025-12-24 09:32:24 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:24 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:24 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:24 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:24 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:24 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:25 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:25 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:25 --> Controller Class Initialized
INFO - 2025-12-24 09:32:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:25 --> Upload Class Initialized
INFO - 2025-12-24 09:32:25 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:25 --> Config Class Initialized
INFO - 2025-12-24 09:32:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:25 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:25 --> URI Class Initialized
INFO - 2025-12-24 09:32:25 --> Router Class Initialized
INFO - 2025-12-24 09:32:25 --> Output Class Initialized
INFO - 2025-12-24 09:32:25 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:25 --> CSRF cookie sent
INFO - 2025-12-24 09:32:25 --> Input Class Initialized
INFO - 2025-12-24 09:32:25 --> Language Class Initialized
INFO - 2025-12-24 09:32:25 --> Loader Class Initialized
INFO - 2025-12-24 09:32:25 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:25 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:25 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:25 --> Controller Class Initialized
INFO - 2025-12-24 09:32:25 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:25 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:25 --> Upload Class Initialized
INFO - 2025-12-24 09:32:25 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:25 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 09:32:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:25 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:25 --> Total execution time: 0.0823
INFO - 2025-12-24 09:32:42 --> Config Class Initialized
INFO - 2025-12-24 09:32:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:42 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:42 --> URI Class Initialized
INFO - 2025-12-24 09:32:42 --> Router Class Initialized
INFO - 2025-12-24 09:32:42 --> Output Class Initialized
INFO - 2025-12-24 09:32:42 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:42 --> CSRF cookie sent
INFO - 2025-12-24 09:32:42 --> Input Class Initialized
INFO - 2025-12-24 09:32:42 --> Language Class Initialized
INFO - 2025-12-24 09:32:42 --> Loader Class Initialized
INFO - 2025-12-24 09:32:42 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:42 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:42 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:42 --> Controller Class Initialized
INFO - 2025-12-24 09:32:42 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:42 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:42 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:42 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:42 --> Upload Class Initialized
INFO - 2025-12-24 09:32:42 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:42 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:32:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:42 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:42 --> Total execution time: 0.0662
INFO - 2025-12-24 09:32:44 --> Config Class Initialized
INFO - 2025-12-24 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:44 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:44 --> URI Class Initialized
INFO - 2025-12-24 09:32:44 --> Router Class Initialized
INFO - 2025-12-24 09:32:44 --> Output Class Initialized
INFO - 2025-12-24 09:32:44 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:44 --> CSRF cookie sent
INFO - 2025-12-24 09:32:44 --> Input Class Initialized
INFO - 2025-12-24 09:32:44 --> Language Class Initialized
INFO - 2025-12-24 09:32:44 --> Loader Class Initialized
INFO - 2025-12-24 09:32:44 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:44 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:44 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:44 --> Controller Class Initialized
INFO - 2025-12-24 09:32:44 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:32:44 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:32:44 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:32:44 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:32:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:32:44 --> Upload Class Initialized
INFO - 2025-12-24 09:32:44 --> Helper loaded: text_helper
INFO - 2025-12-24 09:32:44 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:32:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 09:32:44 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:44 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:44 --> Total execution time: 0.0553
INFO - 2025-12-24 09:32:56 --> Config Class Initialized
INFO - 2025-12-24 09:32:56 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:32:56 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:32:56 --> Utf8 Class Initialized
INFO - 2025-12-24 09:32:56 --> URI Class Initialized
INFO - 2025-12-24 09:32:56 --> Router Class Initialized
INFO - 2025-12-24 09:32:56 --> Output Class Initialized
INFO - 2025-12-24 09:32:56 --> Security Class Initialized
DEBUG - 2025-12-24 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:32:56 --> CSRF cookie sent
INFO - 2025-12-24 09:32:56 --> Input Class Initialized
INFO - 2025-12-24 09:32:56 --> Language Class Initialized
INFO - 2025-12-24 09:32:56 --> Loader Class Initialized
INFO - 2025-12-24 09:32:56 --> Helper loaded: url_helper
INFO - 2025-12-24 09:32:56 --> Helper loaded: form_helper
INFO - 2025-12-24 09:32:56 --> Helper loaded: file_helper
INFO - 2025-12-24 09:32:56 --> Helper loaded: html_helper
INFO - 2025-12-24 09:32:56 --> Helper loaded: security_helper
INFO - 2025-12-24 09:32:56 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:32:56 --> Database Driver Class Initialized
INFO - 2025-12-24 09:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:32:56 --> Form Validation Class Initialized
INFO - 2025-12-24 09:32:56 --> Controller Class Initialized
INFO - 2025-12-24 09:32:56 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 09:32:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:32:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:32:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:32:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 09:32:56 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:32:56 --> Final output sent to browser
DEBUG - 2025-12-24 09:32:56 --> Total execution time: 0.0714
INFO - 2025-12-24 09:47:46 --> Config Class Initialized
INFO - 2025-12-24 09:47:46 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:47:46 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:47:46 --> Utf8 Class Initialized
INFO - 2025-12-24 09:47:46 --> URI Class Initialized
INFO - 2025-12-24 09:47:46 --> Router Class Initialized
INFO - 2025-12-24 09:47:46 --> Output Class Initialized
INFO - 2025-12-24 09:47:46 --> Security Class Initialized
DEBUG - 2025-12-24 09:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:47:46 --> CSRF cookie sent
INFO - 2025-12-24 09:47:46 --> Input Class Initialized
INFO - 2025-12-24 09:47:46 --> Language Class Initialized
INFO - 2025-12-24 09:47:46 --> Loader Class Initialized
INFO - 2025-12-24 09:47:46 --> Helper loaded: url_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: form_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: file_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: html_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: security_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:47:46 --> Database Driver Class Initialized
INFO - 2025-12-24 09:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:47:46 --> Form Validation Class Initialized
INFO - 2025-12-24 09:47:46 --> Controller Class Initialized
INFO - 2025-12-24 09:47:46 --> Model "User_model" initialized
DEBUG - 2025-12-24 09:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:47:46 --> Config Class Initialized
INFO - 2025-12-24 09:47:46 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:47:46 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:47:46 --> Utf8 Class Initialized
INFO - 2025-12-24 09:47:46 --> URI Class Initialized
INFO - 2025-12-24 09:47:46 --> Router Class Initialized
INFO - 2025-12-24 09:47:46 --> Output Class Initialized
INFO - 2025-12-24 09:47:46 --> Security Class Initialized
DEBUG - 2025-12-24 09:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:47:46 --> CSRF cookie sent
INFO - 2025-12-24 09:47:46 --> Input Class Initialized
INFO - 2025-12-24 09:47:46 --> Language Class Initialized
INFO - 2025-12-24 09:47:46 --> Loader Class Initialized
INFO - 2025-12-24 09:47:46 --> Helper loaded: url_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: form_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: file_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: html_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: security_helper
INFO - 2025-12-24 09:47:46 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:47:46 --> Database Driver Class Initialized
INFO - 2025-12-24 09:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:47:46 --> Form Validation Class Initialized
INFO - 2025-12-24 09:47:46 --> Controller Class Initialized
INFO - 2025-12-24 09:47:46 --> Model "User_model" initialized
DEBUG - 2025-12-24 09:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:47:46 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\auth/login.php
INFO - 2025-12-24 09:47:46 --> Final output sent to browser
DEBUG - 2025-12-24 09:47:46 --> Total execution time: 0.0568
INFO - 2025-12-24 09:51:11 --> Config Class Initialized
INFO - 2025-12-24 09:51:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:51:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:51:11 --> Utf8 Class Initialized
INFO - 2025-12-24 09:51:11 --> URI Class Initialized
INFO - 2025-12-24 09:51:11 --> Router Class Initialized
INFO - 2025-12-24 09:51:11 --> Output Class Initialized
INFO - 2025-12-24 09:51:11 --> Security Class Initialized
DEBUG - 2025-12-24 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:51:11 --> CSRF cookie sent
INFO - 2025-12-24 09:51:11 --> CSRF token verified
INFO - 2025-12-24 09:51:11 --> Input Class Initialized
INFO - 2025-12-24 09:51:11 --> Language Class Initialized
INFO - 2025-12-24 09:51:11 --> Loader Class Initialized
INFO - 2025-12-24 09:51:11 --> Helper loaded: url_helper
INFO - 2025-12-24 09:51:11 --> Helper loaded: form_helper
INFO - 2025-12-24 09:51:11 --> Helper loaded: file_helper
INFO - 2025-12-24 09:51:11 --> Helper loaded: html_helper
INFO - 2025-12-24 09:51:11 --> Helper loaded: security_helper
INFO - 2025-12-24 09:51:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:51:11 --> Database Driver Class Initialized
INFO - 2025-12-24 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:51:11 --> Form Validation Class Initialized
INFO - 2025-12-24 09:51:11 --> Controller Class Initialized
INFO - 2025-12-24 09:51:11 --> Model "User_model" initialized
DEBUG - 2025-12-24 09:51:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:51:12 --> Config Class Initialized
INFO - 2025-12-24 09:51:12 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:51:12 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:51:12 --> Utf8 Class Initialized
INFO - 2025-12-24 09:51:12 --> URI Class Initialized
INFO - 2025-12-24 09:51:12 --> Router Class Initialized
INFO - 2025-12-24 09:51:12 --> Output Class Initialized
INFO - 2025-12-24 09:51:12 --> Security Class Initialized
DEBUG - 2025-12-24 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:51:12 --> CSRF cookie sent
INFO - 2025-12-24 09:51:12 --> Input Class Initialized
INFO - 2025-12-24 09:51:12 --> Language Class Initialized
INFO - 2025-12-24 09:51:12 --> Loader Class Initialized
INFO - 2025-12-24 09:51:12 --> Helper loaded: url_helper
INFO - 2025-12-24 09:51:12 --> Helper loaded: form_helper
INFO - 2025-12-24 09:51:12 --> Helper loaded: file_helper
INFO - 2025-12-24 09:51:12 --> Helper loaded: html_helper
INFO - 2025-12-24 09:51:12 --> Helper loaded: security_helper
INFO - 2025-12-24 09:51:12 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:51:12 --> Database Driver Class Initialized
INFO - 2025-12-24 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:51:12 --> Form Validation Class Initialized
INFO - 2025-12-24 09:51:12 --> Controller Class Initialized
INFO - 2025-12-24 09:51:12 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 09:51:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:51:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:51:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:51:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 09:51:12 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:51:12 --> Final output sent to browser
DEBUG - 2025-12-24 09:51:12 --> Total execution time: 0.0659
INFO - 2025-12-24 09:51:25 --> Config Class Initialized
INFO - 2025-12-24 09:51:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:51:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:51:25 --> Utf8 Class Initialized
INFO - 2025-12-24 09:51:25 --> URI Class Initialized
INFO - 2025-12-24 09:51:25 --> Router Class Initialized
INFO - 2025-12-24 09:51:25 --> Output Class Initialized
INFO - 2025-12-24 09:51:25 --> Security Class Initialized
DEBUG - 2025-12-24 09:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:51:25 --> CSRF cookie sent
INFO - 2025-12-24 09:51:25 --> Input Class Initialized
INFO - 2025-12-24 09:51:25 --> Language Class Initialized
INFO - 2025-12-24 09:51:25 --> Loader Class Initialized
INFO - 2025-12-24 09:51:25 --> Helper loaded: url_helper
INFO - 2025-12-24 09:51:25 --> Helper loaded: form_helper
INFO - 2025-12-24 09:51:25 --> Helper loaded: file_helper
INFO - 2025-12-24 09:51:25 --> Helper loaded: html_helper
INFO - 2025-12-24 09:51:25 --> Helper loaded: security_helper
INFO - 2025-12-24 09:51:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:51:25 --> Database Driver Class Initialized
INFO - 2025-12-24 09:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:51:25 --> Form Validation Class Initialized
INFO - 2025-12-24 09:51:25 --> Controller Class Initialized
INFO - 2025-12-24 09:51:25 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 09:51:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:51:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:51:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:51:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 09:51:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:51:25 --> Final output sent to browser
DEBUG - 2025-12-24 09:51:25 --> Total execution time: 0.0511
INFO - 2025-12-24 09:51:32 --> Config Class Initialized
INFO - 2025-12-24 09:51:32 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:51:32 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:51:32 --> Utf8 Class Initialized
INFO - 2025-12-24 09:51:32 --> URI Class Initialized
INFO - 2025-12-24 09:51:32 --> Router Class Initialized
INFO - 2025-12-24 09:51:32 --> Output Class Initialized
INFO - 2025-12-24 09:51:32 --> Security Class Initialized
DEBUG - 2025-12-24 09:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:51:32 --> CSRF cookie sent
INFO - 2025-12-24 09:51:32 --> Input Class Initialized
INFO - 2025-12-24 09:51:32 --> Language Class Initialized
INFO - 2025-12-24 09:51:32 --> Loader Class Initialized
INFO - 2025-12-24 09:51:32 --> Helper loaded: url_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: form_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: file_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: html_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: security_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:51:32 --> Database Driver Class Initialized
INFO - 2025-12-24 09:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:51:32 --> Form Validation Class Initialized
INFO - 2025-12-24 09:51:32 --> Controller Class Initialized
INFO - 2025-12-24 09:51:32 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:51:32 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:51:32 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:51:32 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:51:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:51:32 --> Upload Class Initialized
INFO - 2025-12-24 09:51:32 --> Helper loaded: text_helper
INFO - 2025-12-24 09:51:32 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:51:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:51:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:51:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:51:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/index.php
INFO - 2025-12-24 09:51:32 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:51:32 --> Final output sent to browser
DEBUG - 2025-12-24 09:51:32 --> Total execution time: 0.0640
INFO - 2025-12-24 09:51:42 --> Config Class Initialized
INFO - 2025-12-24 09:51:42 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:51:42 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:51:42 --> Utf8 Class Initialized
INFO - 2025-12-24 09:51:42 --> URI Class Initialized
INFO - 2025-12-24 09:51:42 --> Router Class Initialized
INFO - 2025-12-24 09:51:42 --> Output Class Initialized
INFO - 2025-12-24 09:51:42 --> Security Class Initialized
DEBUG - 2025-12-24 09:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:51:42 --> CSRF cookie sent
INFO - 2025-12-24 09:51:42 --> Input Class Initialized
INFO - 2025-12-24 09:51:42 --> Language Class Initialized
INFO - 2025-12-24 09:51:42 --> Loader Class Initialized
INFO - 2025-12-24 09:51:42 --> Helper loaded: url_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: form_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: file_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: html_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: security_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:51:42 --> Database Driver Class Initialized
INFO - 2025-12-24 09:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:51:42 --> Form Validation Class Initialized
INFO - 2025-12-24 09:51:42 --> Controller Class Initialized
INFO - 2025-12-24 09:51:42 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:51:42 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:51:42 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:51:42 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:51:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:51:42 --> Upload Class Initialized
INFO - 2025-12-24 09:51:42 --> Helper loaded: text_helper
INFO - 2025-12-24 09:51:42 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:51:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:51:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:51:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:51:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 09:51:42 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:51:42 --> Final output sent to browser
DEBUG - 2025-12-24 09:51:42 --> Total execution time: 0.0750
INFO - 2025-12-24 09:52:08 --> Config Class Initialized
INFO - 2025-12-24 09:52:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:52:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:52:08 --> Utf8 Class Initialized
INFO - 2025-12-24 09:52:08 --> URI Class Initialized
INFO - 2025-12-24 09:52:08 --> Router Class Initialized
INFO - 2025-12-24 09:52:08 --> Output Class Initialized
INFO - 2025-12-24 09:52:08 --> Security Class Initialized
DEBUG - 2025-12-24 09:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:52:08 --> CSRF cookie sent
INFO - 2025-12-24 09:52:08 --> CSRF token verified
INFO - 2025-12-24 09:52:08 --> Input Class Initialized
INFO - 2025-12-24 09:52:08 --> Language Class Initialized
INFO - 2025-12-24 09:52:08 --> Loader Class Initialized
INFO - 2025-12-24 09:52:08 --> Helper loaded: url_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: form_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: file_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: html_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: security_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:52:08 --> Database Driver Class Initialized
INFO - 2025-12-24 09:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:52:08 --> Form Validation Class Initialized
INFO - 2025-12-24 09:52:08 --> Controller Class Initialized
INFO - 2025-12-24 09:52:08 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:52:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:52:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:52:08 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:52:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:52:08 --> Upload Class Initialized
INFO - 2025-12-24 09:52:08 --> Helper loaded: text_helper
INFO - 2025-12-24 09:52:08 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:52:09 --> Config Class Initialized
INFO - 2025-12-24 09:52:09 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:52:09 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:52:09 --> Utf8 Class Initialized
INFO - 2025-12-24 09:52:09 --> URI Class Initialized
INFO - 2025-12-24 09:52:09 --> Router Class Initialized
INFO - 2025-12-24 09:52:09 --> Output Class Initialized
INFO - 2025-12-24 09:52:09 --> Security Class Initialized
DEBUG - 2025-12-24 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:52:09 --> CSRF cookie sent
INFO - 2025-12-24 09:52:09 --> Input Class Initialized
INFO - 2025-12-24 09:52:09 --> Language Class Initialized
INFO - 2025-12-24 09:52:09 --> Loader Class Initialized
INFO - 2025-12-24 09:52:09 --> Helper loaded: url_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: form_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: file_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: html_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: security_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:52:09 --> Database Driver Class Initialized
INFO - 2025-12-24 09:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:52:09 --> Form Validation Class Initialized
INFO - 2025-12-24 09:52:09 --> Controller Class Initialized
INFO - 2025-12-24 09:52:09 --> Model "Surat_masuk_model" initialized
INFO - 2025-12-24 09:52:09 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:52:09 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:52:09 --> Model "Disposisi_model" initialized
DEBUG - 2025-12-24 09:52:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:52:09 --> Upload Class Initialized
INFO - 2025-12-24 09:52:09 --> Helper loaded: text_helper
INFO - 2025-12-24 09:52:09 --> Helper loaded: custom_helper
INFO - 2025-12-24 09:52:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:52:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:52:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:52:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_masuk/form.php
INFO - 2025-12-24 09:52:09 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:52:09 --> Final output sent to browser
DEBUG - 2025-12-24 09:52:09 --> Total execution time: 0.0761
INFO - 2025-12-24 09:53:11 --> Config Class Initialized
INFO - 2025-12-24 09:53:11 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:53:11 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:53:11 --> Utf8 Class Initialized
INFO - 2025-12-24 09:53:11 --> URI Class Initialized
INFO - 2025-12-24 09:53:11 --> Router Class Initialized
INFO - 2025-12-24 09:53:11 --> Output Class Initialized
INFO - 2025-12-24 09:53:11 --> Security Class Initialized
DEBUG - 2025-12-24 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:53:11 --> CSRF cookie sent
INFO - 2025-12-24 09:53:11 --> Input Class Initialized
INFO - 2025-12-24 09:53:11 --> Language Class Initialized
INFO - 2025-12-24 09:53:11 --> Loader Class Initialized
INFO - 2025-12-24 09:53:11 --> Helper loaded: url_helper
INFO - 2025-12-24 09:53:11 --> Helper loaded: form_helper
INFO - 2025-12-24 09:53:11 --> Helper loaded: file_helper
INFO - 2025-12-24 09:53:11 --> Helper loaded: html_helper
INFO - 2025-12-24 09:53:11 --> Helper loaded: security_helper
INFO - 2025-12-24 09:53:11 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:53:11 --> Database Driver Class Initialized
INFO - 2025-12-24 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:53:11 --> Form Validation Class Initialized
INFO - 2025-12-24 09:53:11 --> Controller Class Initialized
INFO - 2025-12-24 09:53:11 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:53:11 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:53:11 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:53:11 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:53:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:53:11 --> Upload Class Initialized
INFO - 2025-12-24 09:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:53:11 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:53:11 --> Final output sent to browser
DEBUG - 2025-12-24 09:53:11 --> Total execution time: 0.0909
INFO - 2025-12-24 09:53:15 --> Config Class Initialized
INFO - 2025-12-24 09:53:15 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:53:15 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:53:15 --> Utf8 Class Initialized
INFO - 2025-12-24 09:53:15 --> URI Class Initialized
INFO - 2025-12-24 09:53:15 --> Router Class Initialized
INFO - 2025-12-24 09:53:15 --> Output Class Initialized
INFO - 2025-12-24 09:53:15 --> Security Class Initialized
DEBUG - 2025-12-24 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:53:15 --> CSRF cookie sent
INFO - 2025-12-24 09:53:15 --> Input Class Initialized
INFO - 2025-12-24 09:53:15 --> Language Class Initialized
INFO - 2025-12-24 09:53:15 --> Loader Class Initialized
INFO - 2025-12-24 09:53:15 --> Helper loaded: url_helper
INFO - 2025-12-24 09:53:15 --> Helper loaded: form_helper
INFO - 2025-12-24 09:53:15 --> Helper loaded: file_helper
INFO - 2025-12-24 09:53:15 --> Helper loaded: html_helper
INFO - 2025-12-24 09:53:15 --> Helper loaded: security_helper
INFO - 2025-12-24 09:53:15 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:53:15 --> Database Driver Class Initialized
INFO - 2025-12-24 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:53:15 --> Form Validation Class Initialized
INFO - 2025-12-24 09:53:15 --> Controller Class Initialized
INFO - 2025-12-24 09:53:15 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:53:15 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:53:15 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:53:15 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:53:15 --> Upload Class Initialized
INFO - 2025-12-24 09:53:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:53:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:53:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:53:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:53:15 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:53:15 --> Final output sent to browser
DEBUG - 2025-12-24 09:53:15 --> Total execution time: 0.0515
INFO - 2025-12-24 09:53:31 --> Config Class Initialized
INFO - 2025-12-24 09:53:31 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:53:31 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:53:31 --> Utf8 Class Initialized
INFO - 2025-12-24 09:53:31 --> URI Class Initialized
INFO - 2025-12-24 09:53:31 --> Router Class Initialized
INFO - 2025-12-24 09:53:31 --> Output Class Initialized
INFO - 2025-12-24 09:53:31 --> Security Class Initialized
DEBUG - 2025-12-24 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:53:31 --> CSRF cookie sent
INFO - 2025-12-24 09:53:31 --> CSRF token verified
INFO - 2025-12-24 09:53:31 --> Input Class Initialized
INFO - 2025-12-24 09:53:31 --> Language Class Initialized
INFO - 2025-12-24 09:53:31 --> Loader Class Initialized
INFO - 2025-12-24 09:53:31 --> Helper loaded: url_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: form_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: file_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: html_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: security_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:53:31 --> Database Driver Class Initialized
INFO - 2025-12-24 09:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:53:31 --> Form Validation Class Initialized
INFO - 2025-12-24 09:53:31 --> Controller Class Initialized
INFO - 2025-12-24 09:53:31 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:53:31 --> Upload Class Initialized
INFO - 2025-12-24 09:53:31 --> Config Class Initialized
INFO - 2025-12-24 09:53:31 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:53:31 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:53:31 --> Utf8 Class Initialized
INFO - 2025-12-24 09:53:31 --> URI Class Initialized
INFO - 2025-12-24 09:53:31 --> Router Class Initialized
INFO - 2025-12-24 09:53:31 --> Output Class Initialized
INFO - 2025-12-24 09:53:31 --> Security Class Initialized
DEBUG - 2025-12-24 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:53:31 --> CSRF cookie sent
INFO - 2025-12-24 09:53:31 --> Input Class Initialized
INFO - 2025-12-24 09:53:31 --> Language Class Initialized
INFO - 2025-12-24 09:53:31 --> Loader Class Initialized
INFO - 2025-12-24 09:53:31 --> Helper loaded: url_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: form_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: file_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: html_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: security_helper
INFO - 2025-12-24 09:53:31 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:53:31 --> Database Driver Class Initialized
INFO - 2025-12-24 09:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:53:31 --> Form Validation Class Initialized
INFO - 2025-12-24 09:53:31 --> Controller Class Initialized
INFO - 2025-12-24 09:53:31 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:53:31 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:53:31 --> Upload Class Initialized
INFO - 2025-12-24 09:53:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:53:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:53:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:53:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/form.php
INFO - 2025-12-24 09:53:31 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:53:31 --> Final output sent to browser
DEBUG - 2025-12-24 09:53:31 --> Total execution time: 0.0519
INFO - 2025-12-24 09:56:08 --> Config Class Initialized
INFO - 2025-12-24 09:56:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:08 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:08 --> URI Class Initialized
INFO - 2025-12-24 09:56:08 --> Router Class Initialized
INFO - 2025-12-24 09:56:08 --> Output Class Initialized
INFO - 2025-12-24 09:56:08 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:08 --> CSRF cookie sent
INFO - 2025-12-24 09:56:08 --> CSRF token verified
INFO - 2025-12-24 09:56:08 --> Input Class Initialized
INFO - 2025-12-24 09:56:08 --> Language Class Initialized
INFO - 2025-12-24 09:56:08 --> Loader Class Initialized
INFO - 2025-12-24 09:56:08 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:08 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:08 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:08 --> Controller Class Initialized
INFO - 2025-12-24 09:56:08 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:56:08 --> Upload Class Initialized
INFO - 2025-12-24 09:56:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-12-24 09:56:08 --> Config Class Initialized
INFO - 2025-12-24 09:56:08 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:08 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:08 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:08 --> URI Class Initialized
INFO - 2025-12-24 09:56:08 --> Router Class Initialized
INFO - 2025-12-24 09:56:08 --> Output Class Initialized
INFO - 2025-12-24 09:56:08 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:08 --> CSRF cookie sent
INFO - 2025-12-24 09:56:08 --> Input Class Initialized
INFO - 2025-12-24 09:56:08 --> Language Class Initialized
INFO - 2025-12-24 09:56:08 --> Loader Class Initialized
INFO - 2025-12-24 09:56:08 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:08 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:08 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:08 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:08 --> Controller Class Initialized
INFO - 2025-12-24 09:56:08 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:56:08 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:56:08 --> Upload Class Initialized
INFO - 2025-12-24 09:56:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:56:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:56:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:56:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:56:08 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:56:08 --> Final output sent to browser
DEBUG - 2025-12-24 09:56:08 --> Total execution time: 0.0768
INFO - 2025-12-24 09:56:14 --> Config Class Initialized
INFO - 2025-12-24 09:56:14 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:14 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:14 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:14 --> URI Class Initialized
INFO - 2025-12-24 09:56:14 --> Router Class Initialized
INFO - 2025-12-24 09:56:14 --> Output Class Initialized
INFO - 2025-12-24 09:56:14 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:14 --> CSRF cookie sent
INFO - 2025-12-24 09:56:14 --> Input Class Initialized
INFO - 2025-12-24 09:56:14 --> Language Class Initialized
INFO - 2025-12-24 09:56:14 --> Loader Class Initialized
INFO - 2025-12-24 09:56:14 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:14 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:14 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:14 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:14 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:14 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:14 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:14 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:14 --> Controller Class Initialized
INFO - 2025-12-24 09:56:14 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:56:14 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 09:56:14 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-24 09:56:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 09:56:17 --> Config Class Initialized
INFO - 2025-12-24 09:56:17 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:17 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:17 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:17 --> URI Class Initialized
INFO - 2025-12-24 09:56:17 --> Router Class Initialized
INFO - 2025-12-24 09:56:17 --> Output Class Initialized
INFO - 2025-12-24 09:56:17 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:17 --> CSRF cookie sent
INFO - 2025-12-24 09:56:17 --> Input Class Initialized
INFO - 2025-12-24 09:56:17 --> Language Class Initialized
INFO - 2025-12-24 09:56:17 --> Loader Class Initialized
INFO - 2025-12-24 09:56:17 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:17 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:17 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:17 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:17 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:17 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:17 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:17 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:17 --> Controller Class Initialized
INFO - 2025-12-24 09:56:17 --> Model "Surat_keluar_model" initialized
INFO - 2025-12-24 09:56:17 --> Model "Bagian_model" initialized
INFO - 2025-12-24 09:56:17 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:56:17 --> Model "Nomor_surat_model" initialized
DEBUG - 2025-12-24 09:56:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 09:56:17 --> Upload Class Initialized
INFO - 2025-12-24 09:56:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:56:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:56:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:56:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\surat_keluar/index.php
INFO - 2025-12-24 09:56:17 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:56:17 --> Final output sent to browser
DEBUG - 2025-12-24 09:56:17 --> Total execution time: 0.0523
INFO - 2025-12-24 09:56:19 --> Config Class Initialized
INFO - 2025-12-24 09:56:19 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:19 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:19 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:19 --> URI Class Initialized
INFO - 2025-12-24 09:56:19 --> Router Class Initialized
INFO - 2025-12-24 09:56:19 --> Output Class Initialized
INFO - 2025-12-24 09:56:19 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:19 --> CSRF cookie sent
INFO - 2025-12-24 09:56:19 --> Input Class Initialized
INFO - 2025-12-24 09:56:19 --> Language Class Initialized
INFO - 2025-12-24 09:56:19 --> Loader Class Initialized
INFO - 2025-12-24 09:56:19 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:19 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:19 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:19 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:19 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:19 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:19 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:19 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:19 --> Controller Class Initialized
INFO - 2025-12-24 09:56:19 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:56:19 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:56:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:56:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:56:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:56:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 09:56:19 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:56:19 --> Final output sent to browser
DEBUG - 2025-12-24 09:56:19 --> Total execution time: 0.0500
INFO - 2025-12-24 09:56:26 --> Config Class Initialized
INFO - 2025-12-24 09:56:26 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:26 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:26 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:26 --> URI Class Initialized
INFO - 2025-12-24 09:56:26 --> Router Class Initialized
INFO - 2025-12-24 09:56:26 --> Output Class Initialized
INFO - 2025-12-24 09:56:26 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:26 --> CSRF cookie sent
INFO - 2025-12-24 09:56:26 --> Input Class Initialized
INFO - 2025-12-24 09:56:26 --> Language Class Initialized
INFO - 2025-12-24 09:56:26 --> Loader Class Initialized
INFO - 2025-12-24 09:56:26 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:26 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:26 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:26 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:26 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:26 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:26 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:26 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:26 --> Controller Class Initialized
INFO - 2025-12-24 09:56:26 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:56:26 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 09:56:26 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-24 09:56:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 09:56:35 --> Config Class Initialized
INFO - 2025-12-24 09:56:35 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:56:35 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:56:35 --> Utf8 Class Initialized
INFO - 2025-12-24 09:56:35 --> URI Class Initialized
INFO - 2025-12-24 09:56:36 --> Router Class Initialized
INFO - 2025-12-24 09:56:36 --> Output Class Initialized
INFO - 2025-12-24 09:56:36 --> Security Class Initialized
DEBUG - 2025-12-24 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:56:36 --> CSRF cookie sent
INFO - 2025-12-24 09:56:36 --> Input Class Initialized
INFO - 2025-12-24 09:56:36 --> Language Class Initialized
INFO - 2025-12-24 09:56:36 --> Loader Class Initialized
INFO - 2025-12-24 09:56:36 --> Helper loaded: url_helper
INFO - 2025-12-24 09:56:36 --> Helper loaded: form_helper
INFO - 2025-12-24 09:56:36 --> Helper loaded: file_helper
INFO - 2025-12-24 09:56:36 --> Helper loaded: html_helper
INFO - 2025-12-24 09:56:36 --> Helper loaded: security_helper
INFO - 2025-12-24 09:56:36 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:56:36 --> Database Driver Class Initialized
INFO - 2025-12-24 09:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:56:36 --> Form Validation Class Initialized
INFO - 2025-12-24 09:56:36 --> Controller Class Initialized
INFO - 2025-12-24 09:56:36 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:56:36 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:56:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:56:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:56:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:56:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 09:56:36 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:56:36 --> Final output sent to browser
DEBUG - 2025-12-24 09:56:36 --> Total execution time: 0.0490
INFO - 2025-12-24 09:57:44 --> Config Class Initialized
INFO - 2025-12-24 09:57:44 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:57:44 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:57:44 --> Utf8 Class Initialized
INFO - 2025-12-24 09:57:44 --> URI Class Initialized
INFO - 2025-12-24 09:57:44 --> Router Class Initialized
INFO - 2025-12-24 09:57:44 --> Output Class Initialized
INFO - 2025-12-24 09:57:44 --> Security Class Initialized
DEBUG - 2025-12-24 09:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:57:44 --> CSRF cookie sent
INFO - 2025-12-24 09:57:44 --> Input Class Initialized
INFO - 2025-12-24 09:57:44 --> Language Class Initialized
INFO - 2025-12-24 09:57:44 --> Loader Class Initialized
INFO - 2025-12-24 09:57:44 --> Helper loaded: url_helper
INFO - 2025-12-24 09:57:44 --> Helper loaded: form_helper
INFO - 2025-12-24 09:57:44 --> Helper loaded: file_helper
INFO - 2025-12-24 09:57:44 --> Helper loaded: html_helper
INFO - 2025-12-24 09:57:44 --> Helper loaded: security_helper
INFO - 2025-12-24 09:57:44 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:57:44 --> Database Driver Class Initialized
INFO - 2025-12-24 09:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:57:44 --> Form Validation Class Initialized
INFO - 2025-12-24 09:57:44 --> Controller Class Initialized
INFO - 2025-12-24 09:57:44 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:57:44 --> Model "Kategori_model" initialized
ERROR - 2025-12-24 09:57:44 --> Query error: Unknown column 'sk.id_penandatangan' in 'on clause' - Invalid query: SELECT `sk`.*, `k`.`nama_kategori`, `b`.`nama_bagian`, `u`.`nama` AS `nama_penandatangan`
FROM `surat_keluar` `sk`
LEFT JOIN `kategori` `k` ON `k`.`kode_kategori` = `sk`.`kode_kategori`
LEFT JOIN `bagian` `b` ON `b`.`kode_bagian`   = `sk`.`kode_bagian`
LEFT JOIN `user` `u` ON `u`.`id`            = `sk`.`id_penandatangan`
ORDER BY `sk`.`tanggal_surat` DESC
INFO - 2025-12-24 09:57:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-12-24 09:58:04 --> Config Class Initialized
INFO - 2025-12-24 09:58:04 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:58:04 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:58:04 --> Utf8 Class Initialized
INFO - 2025-12-24 09:58:04 --> URI Class Initialized
INFO - 2025-12-24 09:58:04 --> Router Class Initialized
INFO - 2025-12-24 09:58:04 --> Output Class Initialized
INFO - 2025-12-24 09:58:04 --> Security Class Initialized
DEBUG - 2025-12-24 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:58:04 --> CSRF cookie sent
INFO - 2025-12-24 09:58:04 --> Input Class Initialized
INFO - 2025-12-24 09:58:04 --> Language Class Initialized
INFO - 2025-12-24 09:58:04 --> Loader Class Initialized
INFO - 2025-12-24 09:58:04 --> Helper loaded: url_helper
INFO - 2025-12-24 09:58:04 --> Helper loaded: form_helper
INFO - 2025-12-24 09:58:04 --> Helper loaded: file_helper
INFO - 2025-12-24 09:58:04 --> Helper loaded: html_helper
INFO - 2025-12-24 09:58:04 --> Helper loaded: security_helper
INFO - 2025-12-24 09:58:04 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:58:04 --> Database Driver Class Initialized
INFO - 2025-12-24 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:58:04 --> Form Validation Class Initialized
INFO - 2025-12-24 09:58:04 --> Controller Class Initialized
INFO - 2025-12-24 09:58:04 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:58:04 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:58:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 09:58:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 09:58:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 09:58:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 09:58:04 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 09:58:04 --> Final output sent to browser
DEBUG - 2025-12-24 09:58:04 --> Total execution time: 0.0487
INFO - 2025-12-24 09:59:45 --> Config Class Initialized
INFO - 2025-12-24 09:59:45 --> Hooks Class Initialized
DEBUG - 2025-12-24 09:59:45 --> UTF-8 Support Enabled
INFO - 2025-12-24 09:59:45 --> Utf8 Class Initialized
INFO - 2025-12-24 09:59:45 --> URI Class Initialized
INFO - 2025-12-24 09:59:45 --> Router Class Initialized
INFO - 2025-12-24 09:59:45 --> Output Class Initialized
INFO - 2025-12-24 09:59:45 --> Security Class Initialized
DEBUG - 2025-12-24 09:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 09:59:45 --> CSRF cookie sent
INFO - 2025-12-24 09:59:45 --> Input Class Initialized
INFO - 2025-12-24 09:59:45 --> Language Class Initialized
INFO - 2025-12-24 09:59:45 --> Loader Class Initialized
INFO - 2025-12-24 09:59:45 --> Helper loaded: url_helper
INFO - 2025-12-24 09:59:45 --> Helper loaded: form_helper
INFO - 2025-12-24 09:59:45 --> Helper loaded: file_helper
INFO - 2025-12-24 09:59:45 --> Helper loaded: html_helper
INFO - 2025-12-24 09:59:45 --> Helper loaded: security_helper
INFO - 2025-12-24 09:59:45 --> Helper loaded: surat_helper
INFO - 2025-12-24 09:59:45 --> Database Driver Class Initialized
INFO - 2025-12-24 09:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 09:59:45 --> Form Validation Class Initialized
INFO - 2025-12-24 09:59:45 --> Controller Class Initialized
INFO - 2025-12-24 09:59:45 --> Model "Laporan_model" initialized
INFO - 2025-12-24 09:59:45 --> Model "Kategori_model" initialized
INFO - 2025-12-24 09:59:45 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_masuk.php
INFO - 2025-12-24 09:59:45 --> Final output sent to browser
DEBUG - 2025-12-24 09:59:45 --> Total execution time: 0.0581
INFO - 2025-12-24 10:01:40 --> Config Class Initialized
INFO - 2025-12-24 10:01:40 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:01:40 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:01:40 --> Utf8 Class Initialized
INFO - 2025-12-24 10:01:40 --> URI Class Initialized
INFO - 2025-12-24 10:01:40 --> Router Class Initialized
INFO - 2025-12-24 10:01:40 --> Output Class Initialized
INFO - 2025-12-24 10:01:40 --> Security Class Initialized
DEBUG - 2025-12-24 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:01:40 --> CSRF cookie sent
INFO - 2025-12-24 10:01:40 --> Input Class Initialized
INFO - 2025-12-24 10:01:40 --> Language Class Initialized
INFO - 2025-12-24 10:01:40 --> Loader Class Initialized
INFO - 2025-12-24 10:01:40 --> Helper loaded: url_helper
INFO - 2025-12-24 10:01:40 --> Helper loaded: form_helper
INFO - 2025-12-24 10:01:40 --> Helper loaded: file_helper
INFO - 2025-12-24 10:01:40 --> Helper loaded: html_helper
INFO - 2025-12-24 10:01:40 --> Helper loaded: security_helper
INFO - 2025-12-24 10:01:40 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:01:40 --> Database Driver Class Initialized
INFO - 2025-12-24 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:01:40 --> Form Validation Class Initialized
INFO - 2025-12-24 10:01:40 --> Controller Class Initialized
INFO - 2025-12-24 10:01:40 --> Model "Kategori_model" initialized
DEBUG - 2025-12-24 10:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 10:01:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:01:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:01:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:01:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\kategori/index.php
INFO - 2025-12-24 10:01:40 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:01:40 --> Final output sent to browser
DEBUG - 2025-12-24 10:01:40 --> Total execution time: 0.0700
INFO - 2025-12-24 10:03:22 --> Config Class Initialized
INFO - 2025-12-24 10:03:22 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:03:22 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:03:22 --> Utf8 Class Initialized
INFO - 2025-12-24 10:03:22 --> URI Class Initialized
INFO - 2025-12-24 10:03:22 --> Router Class Initialized
INFO - 2025-12-24 10:03:22 --> Output Class Initialized
INFO - 2025-12-24 10:03:22 --> Security Class Initialized
DEBUG - 2025-12-24 10:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:03:22 --> CSRF cookie sent
INFO - 2025-12-24 10:03:22 --> Input Class Initialized
INFO - 2025-12-24 10:03:22 --> Language Class Initialized
INFO - 2025-12-24 10:03:22 --> Loader Class Initialized
INFO - 2025-12-24 10:03:22 --> Helper loaded: url_helper
INFO - 2025-12-24 10:03:22 --> Helper loaded: form_helper
INFO - 2025-12-24 10:03:22 --> Helper loaded: file_helper
INFO - 2025-12-24 10:03:22 --> Helper loaded: html_helper
INFO - 2025-12-24 10:03:22 --> Helper loaded: security_helper
INFO - 2025-12-24 10:03:22 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:03:22 --> Database Driver Class Initialized
INFO - 2025-12-24 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:03:22 --> Form Validation Class Initialized
INFO - 2025-12-24 10:03:23 --> Controller Class Initialized
INFO - 2025-12-24 10:03:23 --> Model "User_model" initialized
INFO - 2025-12-24 10:03:23 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 10:03:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 10:03:23 --> Upload Class Initialized
INFO - 2025-12-24 10:03:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:03:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:03:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:03:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/index.php
INFO - 2025-12-24 10:03:23 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:03:23 --> Final output sent to browser
DEBUG - 2025-12-24 10:03:23 --> Total execution time: 0.0886
INFO - 2025-12-24 10:03:25 --> Config Class Initialized
INFO - 2025-12-24 10:03:25 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:03:25 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:03:25 --> Utf8 Class Initialized
INFO - 2025-12-24 10:03:25 --> URI Class Initialized
INFO - 2025-12-24 10:03:25 --> Router Class Initialized
INFO - 2025-12-24 10:03:25 --> Output Class Initialized
INFO - 2025-12-24 10:03:25 --> Security Class Initialized
DEBUG - 2025-12-24 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:03:25 --> CSRF cookie sent
INFO - 2025-12-24 10:03:25 --> Input Class Initialized
INFO - 2025-12-24 10:03:25 --> Language Class Initialized
INFO - 2025-12-24 10:03:25 --> Loader Class Initialized
INFO - 2025-12-24 10:03:25 --> Helper loaded: url_helper
INFO - 2025-12-24 10:03:25 --> Helper loaded: form_helper
INFO - 2025-12-24 10:03:25 --> Helper loaded: file_helper
INFO - 2025-12-24 10:03:25 --> Helper loaded: html_helper
INFO - 2025-12-24 10:03:25 --> Helper loaded: security_helper
INFO - 2025-12-24 10:03:25 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:03:25 --> Database Driver Class Initialized
INFO - 2025-12-24 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:03:25 --> Form Validation Class Initialized
INFO - 2025-12-24 10:03:25 --> Controller Class Initialized
INFO - 2025-12-24 10:03:25 --> Model "User_model" initialized
INFO - 2025-12-24 10:03:25 --> Model "Bagian_model" initialized
DEBUG - 2025-12-24 10:03:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-12-24 10:03:25 --> Upload Class Initialized
INFO - 2025-12-24 10:03:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:03:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:03:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:03:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\users/form.php
INFO - 2025-12-24 10:03:25 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:03:25 --> Final output sent to browser
DEBUG - 2025-12-24 10:03:25 --> Total execution time: 0.0511
INFO - 2025-12-24 10:03:37 --> Config Class Initialized
INFO - 2025-12-24 10:03:37 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:03:37 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:03:37 --> Utf8 Class Initialized
INFO - 2025-12-24 10:03:37 --> URI Class Initialized
INFO - 2025-12-24 10:03:37 --> Router Class Initialized
INFO - 2025-12-24 10:03:37 --> Output Class Initialized
INFO - 2025-12-24 10:03:37 --> Security Class Initialized
DEBUG - 2025-12-24 10:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:03:37 --> CSRF cookie sent
INFO - 2025-12-24 10:03:37 --> Input Class Initialized
INFO - 2025-12-24 10:03:37 --> Language Class Initialized
INFO - 2025-12-24 10:03:37 --> Loader Class Initialized
INFO - 2025-12-24 10:03:37 --> Helper loaded: url_helper
INFO - 2025-12-24 10:03:37 --> Helper loaded: form_helper
INFO - 2025-12-24 10:03:37 --> Helper loaded: file_helper
INFO - 2025-12-24 10:03:37 --> Helper loaded: html_helper
INFO - 2025-12-24 10:03:37 --> Helper loaded: security_helper
INFO - 2025-12-24 10:03:37 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:03:37 --> Database Driver Class Initialized
INFO - 2025-12-24 10:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:03:37 --> Form Validation Class Initialized
INFO - 2025-12-24 10:03:37 --> Controller Class Initialized
INFO - 2025-12-24 10:03:37 --> Model "Dashboard_model" initialized
INFO - 2025-12-24 10:03:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:03:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:03:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:03:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\dashboard/index.php
INFO - 2025-12-24 10:03:37 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:03:37 --> Final output sent to browser
DEBUG - 2025-12-24 10:03:37 --> Total execution time: 0.0529
INFO - 2025-12-24 10:03:51 --> Config Class Initialized
INFO - 2025-12-24 10:03:51 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:03:51 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:03:51 --> Utf8 Class Initialized
INFO - 2025-12-24 10:03:51 --> URI Class Initialized
INFO - 2025-12-24 10:03:51 --> Router Class Initialized
INFO - 2025-12-24 10:03:51 --> Output Class Initialized
INFO - 2025-12-24 10:03:51 --> Security Class Initialized
DEBUG - 2025-12-24 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:03:51 --> CSRF cookie sent
INFO - 2025-12-24 10:03:51 --> Input Class Initialized
INFO - 2025-12-24 10:03:51 --> Language Class Initialized
INFO - 2025-12-24 10:03:51 --> Loader Class Initialized
INFO - 2025-12-24 10:03:51 --> Helper loaded: url_helper
INFO - 2025-12-24 10:03:51 --> Helper loaded: form_helper
INFO - 2025-12-24 10:03:51 --> Helper loaded: file_helper
INFO - 2025-12-24 10:03:51 --> Helper loaded: html_helper
INFO - 2025-12-24 10:03:51 --> Helper loaded: security_helper
INFO - 2025-12-24 10:03:51 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:03:51 --> Database Driver Class Initialized
INFO - 2025-12-24 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:03:51 --> Form Validation Class Initialized
INFO - 2025-12-24 10:03:51 --> Controller Class Initialized
INFO - 2025-12-24 10:03:51 --> Model "Laporan_model" initialized
INFO - 2025-12-24 10:03:51 --> Model "Kategori_model" initialized
INFO - 2025-12-24 10:03:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:03:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:03:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:03:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 10:03:51 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:03:51 --> Final output sent to browser
DEBUG - 2025-12-24 10:03:51 --> Total execution time: 0.0523
INFO - 2025-12-24 10:06:52 --> Config Class Initialized
INFO - 2025-12-24 10:06:52 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:06:52 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:06:52 --> Utf8 Class Initialized
INFO - 2025-12-24 10:06:52 --> URI Class Initialized
INFO - 2025-12-24 10:06:52 --> Router Class Initialized
INFO - 2025-12-24 10:06:52 --> Output Class Initialized
INFO - 2025-12-24 10:06:52 --> Security Class Initialized
DEBUG - 2025-12-24 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:06:52 --> CSRF cookie sent
INFO - 2025-12-24 10:06:52 --> Input Class Initialized
INFO - 2025-12-24 10:06:52 --> Language Class Initialized
INFO - 2025-12-24 10:06:52 --> Loader Class Initialized
INFO - 2025-12-24 10:06:52 --> Helper loaded: url_helper
INFO - 2025-12-24 10:06:52 --> Helper loaded: form_helper
INFO - 2025-12-24 10:06:52 --> Helper loaded: file_helper
INFO - 2025-12-24 10:06:52 --> Helper loaded: html_helper
INFO - 2025-12-24 10:06:52 --> Helper loaded: security_helper
INFO - 2025-12-24 10:06:52 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:06:52 --> Database Driver Class Initialized
INFO - 2025-12-24 10:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:06:52 --> Form Validation Class Initialized
INFO - 2025-12-24 10:06:52 --> Controller Class Initialized
INFO - 2025-12-24 10:06:52 --> Model "Laporan_model" initialized
INFO - 2025-12-24 10:06:52 --> Model "Kategori_model" initialized
INFO - 2025-12-24 10:06:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/header.php
INFO - 2025-12-24 10:06:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/navbar.php
INFO - 2025-12-24 10:06:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/sidebar.php
INFO - 2025-12-24 10:06:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/surat_masuk.php
INFO - 2025-12-24 10:06:52 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\layouts/footer.php
INFO - 2025-12-24 10:06:52 --> Final output sent to browser
DEBUG - 2025-12-24 10:06:52 --> Total execution time: 0.0514
INFO - 2025-12-24 10:06:54 --> Config Class Initialized
INFO - 2025-12-24 10:06:54 --> Hooks Class Initialized
DEBUG - 2025-12-24 10:06:54 --> UTF-8 Support Enabled
INFO - 2025-12-24 10:06:54 --> Utf8 Class Initialized
INFO - 2025-12-24 10:06:54 --> URI Class Initialized
INFO - 2025-12-24 10:06:54 --> Router Class Initialized
INFO - 2025-12-24 10:06:54 --> Output Class Initialized
INFO - 2025-12-24 10:06:54 --> Security Class Initialized
DEBUG - 2025-12-24 10:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-12-24 10:06:54 --> CSRF cookie sent
INFO - 2025-12-24 10:06:54 --> Input Class Initialized
INFO - 2025-12-24 10:06:54 --> Language Class Initialized
INFO - 2025-12-24 10:06:54 --> Loader Class Initialized
INFO - 2025-12-24 10:06:54 --> Helper loaded: url_helper
INFO - 2025-12-24 10:06:54 --> Helper loaded: form_helper
INFO - 2025-12-24 10:06:54 --> Helper loaded: file_helper
INFO - 2025-12-24 10:06:54 --> Helper loaded: html_helper
INFO - 2025-12-24 10:06:54 --> Helper loaded: security_helper
INFO - 2025-12-24 10:06:54 --> Helper loaded: surat_helper
INFO - 2025-12-24 10:06:54 --> Database Driver Class Initialized
INFO - 2025-12-24 10:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-12-24 10:06:54 --> Form Validation Class Initialized
INFO - 2025-12-24 10:06:54 --> Controller Class Initialized
INFO - 2025-12-24 10:06:54 --> Model "Laporan_model" initialized
INFO - 2025-12-24 10:06:54 --> Model "Kategori_model" initialized
INFO - 2025-12-24 10:06:54 --> File loaded: D:\xampp\htdocs\surat_itm\application\views\laporan/print_masuk.php
INFO - 2025-12-24 10:06:54 --> Final output sent to browser
DEBUG - 2025-12-24 10:06:54 --> Total execution time: 0.0735
