<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_ocr extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        // Comment ini jika ingin akses tanpa login
        // $this->_must_login();
        
        $this->load->library('document_extractor');
    }
    
    /**
     * Cek login (optional)
     */
    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }
    
    /**
     * Halaman test OCR
     */
    public function index()
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Test OCR - SIMAS ITM</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
                .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                h2 { color: #17a2b8; border-bottom: 2px solid #17a2b8; padding-bottom: 10px; }
                .upload-form { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
                input[type="file"] { padding: 10px; border: 2px dashed #17a2b8; width: 100%; box-sizing: border-box; }
                button { background: #17a2b8; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 10px; }
                button:hover { background: #138496; }
                .result { background: #e8f5e9; padding: 20px; border-radius: 5px; margin-top: 20px; border-left: 4px solid #28a745; }
                .error { background: #ffebee; padding: 20px; border-radius: 5px; margin-top: 20px; border-left: 4px solid #dc3545; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; }
                table td { padding: 10px; border: 1px solid #ddd; }
                table td:first-child { background: #f8f9fa; font-weight: bold; width: 150px; }
                pre { background: #263238; color: #aed581; padding: 15px; border-radius: 5px; overflow-x: auto; }
                .badge { display: inline-block; padding: 5px 10px; border-radius: 3px; font-size: 12px; }
                .badge-success { background: #28a745; color: white; }
                .badge-warning { background: #ffc107; color: #000; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>🔍 Test Document Extractor - SIMAS ITM</h2>
                
                <div class="upload-form">
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" 
                               value="<?php echo $this->security->get_csrf_hash(); ?>">
                        
                        <label for="test_file"><strong>Upload File Surat untuk Test OCR:</strong></label>
                        <input type="file" 
                               id="test_file"
                               name="test_file" 
                               accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                               required>
                        
                        <p style="color: #666; font-size: 13px; margin-top: 10px;">
                            ✅ Format: PDF, Word (DOC/DOCX), Foto (JPG/PNG) | Max: 10 MB
                        </p>
                        
                        <button type="submit">
                            📤 Upload & Test Ekstraksi
                        </button>
                    </form>
                </div>
                
                <?php
                // Proses upload jika ada file
                if ($this->input->post() && !empty($_FILES['test_file']['tmp_name'])) {
                    $this->_process_test();
                }
                ?>
                
                <hr style="margin: 30px 0;">
                
                <h3>📖 Cara Penggunaan:</h3>
                <ol>
                    <li>Pilih file surat (PDF/Word/Foto)</li>
                    <li>Klik tombol "Upload & Test Ekstraksi"</li>
                    <li>Lihat hasil ekstraksi data surat di bawah</li>
                    <li>Cek apakah nomor surat, tanggal, pengirim, dan perihal terdeteksi</li>
                </ol>
                
                <p style="color: #666; margin-top: 20px;">
                    <strong>Tips:</strong> Gunakan file surat yang jelas dan berkualitas baik untuk hasil ekstraksi optimal.
                </p>
            </div>
        </body>
        </html>
        <?php
    }
    
    /**
     * Process test upload
     */
    private function _process_test()
    {
        try {
            // Validasi file upload
            if ($_FILES['test_file']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('Error upload file: ' . $_FILES['test_file']['error']);
            }
            
            // Buat folder temp jika belum ada
            $temp_dir = FCPATH . 'uploads/temp/';
            if (!is_dir($temp_dir)) {
                mkdir($temp_dir, 0755, TRUE);
            }
            
            // Generate nama file unik
            $file_ext = pathinfo($_FILES['test_file']['name'], PATHINFO_EXTENSION);
            $file_name = 'test_' . time() . '_' . uniqid() . '.' . $file_ext;
            $upload_path = $temp_dir . $file_name;
            
            // Move uploaded file
            if (!move_uploaded_file($_FILES['test_file']['tmp_name'], $upload_path)) {
                throw new Exception('Gagal memindahkan file upload');
            }
            
            echo '<div class="result">';
            echo '<h3>✅ Hasil Test Ekstraksi</h3>';
            
            // Info file
            $file_size = filesize($upload_path);
            echo '<p><strong>File:</strong> ' . htmlspecialchars($_FILES['test_file']['name']) . '</p>';
            echo '<p><strong>Ukuran:</strong> ' . $this->_format_bytes($file_size) . '</p>';
            echo '<p><strong>Tipe:</strong> ' . htmlspecialchars($file_ext) . '</p>';
            echo '<hr>';
            
            // STEP 1: Ekstrak teks
            echo '<h4>📄 Step 1: Ekstraksi Teks</h4>';
            $start_time = microtime(true);
            
            $text = $this->document_extractor->extract_text($upload_path);
            
            $extract_time = round((microtime(true) - $start_time) * 1000, 2);
            
            if ($text === false || empty(trim($text))) {
                echo '<div class="error">❌ Gagal mengekstrak teks dari file. File mungkin kosong, rusak, atau format tidak didukung.</div>';
                @unlink($upload_path);
                echo '</div>';
                return;
            }
            
            echo '<p><span class="badge badge-success">Berhasil</span> Waktu: ' . $extract_time . ' ms</p>';
            echo '<p><strong>Panjang teks:</strong> ' . strlen($text) . ' karakter</p>';
            
            // Preview teks
            echo '<p><strong>Preview (500 karakter pertama):</strong></p>';
            echo '<pre>' . htmlspecialchars(substr($text, 0, 500)) . '...</pre>';
            
            // STEP 2: Ekstrak data surat
            echo '<hr>';
            echo '<h4>📋 Step 2: Ekstraksi Data Surat</h4>';
            
            $data = $this->document_extractor->extract_surat_data($text);
            
            // Tampilkan hasil
            echo '<table>';
            echo '<tr>';
            echo '<td>Nomor Surat</td>';
            echo '<td>' . (!empty($data['no_surat_asli']) 
                    ? '<strong style="color: #28a745;">' . htmlspecialchars($data['no_surat_asli']) . '</strong>' 
                    : '<em style="color: #dc3545;">Tidak terdeteksi</em>') . '</td>';
            echo '</tr>';
            
            echo '<tr>';
            echo '<td>Tanggal Surat</td>';
            echo '<td>' . (!empty($data['tanggal_surat']) 
                    ? '<strong style="color: #28a745;">' . htmlspecialchars($data['tanggal_surat']) . '</strong>' 
                    : '<em style="color: #dc3545;">Tidak terdeteksi</em>') . '</td>';
            echo '</tr>';
            
            echo '<tr>';
            echo '<td>Pengirim</td>';
            echo '<td>' . (!empty($data['pengirim']) 
                    ? htmlspecialchars($data['pengirim']) 
                    : '<em style="color: #dc3545;">Tidak terdeteksi</em>') . '</td>';
            echo '</tr>';
            
            echo '<tr>';
            echo '<td>Perihal</td>';
            echo '<td>' . (!empty($data['perihal']) 
                    ? htmlspecialchars($data['perihal']) 
                    : '<em style="color: #dc3545;">Tidak terdeteksi</em>') . '</td>';
            echo '</tr>';
            
            echo '<tr>';
            echo '<td>Confidence (Akurasi)</td>';
            echo '<td>';
            $confidence = $data['confidence'];
            if ($confidence >= 80) {
                echo '<span class="badge badge-success">' . $confidence . '%</span> Sangat Baik';
            } elseif ($confidence >= 50) {
                echo '<span class="badge badge-warning">' . $confidence . '%</span> Cukup Baik';
            } else {
                echo '<span class="badge" style="background:#dc3545;color:white;">' . $confidence . '%</span> Kurang Akurat';
            }
            echo '</td>';
            echo '</tr>';
            echo '</table>';
            
            // Cleanup
            @unlink($upload_path);
            
            echo '</div>';
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '<h3>❌ Error</h3>';
            echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '</div>';
            
            if (isset($upload_path) && file_exists($upload_path)) {
                @unlink($upload_path);
            }
        }
    }
    
    /**
     * Format bytes to human readable
     */
    private function _format_bytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
}
