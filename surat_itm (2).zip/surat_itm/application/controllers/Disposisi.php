<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Disposisi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->load->model('Disposisi_model', 'dis');
        $this->load->model('Surat_masuk_model', 'sm');
        $this->load->library('form_validation');
    }

    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    // daftar semua disposisi (opsional)
    public function index()
    {
        $data['title']     = 'Disposisi Surat';
        $data['disposisi'] = $this->dis->get_all();

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('disposisi/index', $data);
        $this->load->view('layouts/footer');
    }

    // tambah disposisi untuk 1 surat masuk
    public function tambah($id_suratmasuk)
    {
        $surat = $this->sm->get_by_id($id_suratmasuk);
        if (!$surat) show_404();

        $data['title'] = 'Disposisi Surat Masuk';
        $data['surat'] = $surat;

        if ($this->input->post()) {
            $this->form_validation->set_rules('tanggal', 'Tanggal Disposisi', 'required');
            $this->form_validation->set_rules('dari', 'Dari', 'required');
            $this->form_validation->set_rules('kepada', 'Kepada', 'required');
            $this->form_validation->set_rules('instruksi', 'Instruksi', 'required');

            if ($this->form_validation->run()) {

                $insert = [
                    'id_suratmasuk' => $id_suratmasuk,
                    'tanggal'       => $this->input->post('tanggal'),
                    'dari'          => $this->input->post('dari', TRUE),
                    'kepada'        => $this->input->post('kepada', TRUE),
                    'instruksi'     => $this->input->post('instruksi', TRUE),
                    'keterangan'    => $this->input->post('keterangan', TRUE),
                ];

                $this->dis->insert($insert);
                $this->session->set_flashdata('success', 'Disposisi berhasil disimpan');
                redirect('surat-masuk/detail/'.$id_suratmasuk);
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('disposisi/form', $data);
        $this->load->view('layouts/footer');
    }

    public function delete($id, $id_suratmasuk)
    {
        $this->dis->delete($id);
        $this->session->set_flashdata('success', 'Disposisi dihapus');
        redirect('surat-masuk/detail/'.$id_suratmasuk);
    }
}
