<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_keluar extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();

        $this->load->model('Surat_keluar_model', 'sk');
        $this->load->model('Bagian_model', 'bagian');
        $this->load->model('Kategori_model', 'kategori');
        $this->load->model('Nomor_surat_model', 'nomor');

        $this->load->library(['form_validation', 'upload']);
    }

    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    private function _bulan_roman($bulan)
    {
        $map = [1=>'I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
        return $map[(int)$bulan];
    }

    // LIST + FILTER
    public function index()
    {
        // Initialize the filter array with GET parameters
        $filter = [
            'tgl_awal'   => $this->input->get('tgl_awal'),
            'tgl_akhir'  => $this->input->get('tgl_akhir'),
            'kategori'   => $this->input->get('kategori'),
            'bagian'     => $this->input->get('bagian'),
            'status_pengesahan' => $this->input->get('status_pengesahan'),
            'search'     => $this->input->get('search') // Add search parameter
        ];

        // Fetch Surat Keluar based on filter
        $data['surat_keluar'] = $this->sk->get_all($filter); 

        // Additional data passed to view
        $data['title']        = 'Surat Keluar';
        $data['kategori']     = $this->kategori->get_active();
        $data['bagian']       = $this->bagian->get_active();
        $data['filter']       = $filter; // Pass the filter to the view

        // Load views
        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('surat_keluar/index', $data); // Ensure this line passes data to view
        $this->load->view('layouts/footer');
    }


    /**
     * UPLOAD & EXTRACT - Proses upload file dan ekstrak data surat keluar
     */
    public function upload_extract()
    {
        if (empty($_FILES['file_surat']['name'])) {
            $this->session->set_flashdata('error', 'Tidak ada file yang diupload');
            redirect('surat-keluar/create');
            return;
        }
        
        $config['upload_path']   = FCPATH . 'uploads/surat_keluar/';
        $config['allowed_types'] = 'pdf|doc|docx|jpg|jpeg|png';
        $config['max_size']      = 10240;
        $config['encrypt_name']  = TRUE;
        
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, TRUE);
        }
        
        $this->upload->initialize($config);
        
        if (!$this->upload->do_upload('file_surat')) {
            $error = $this->upload->display_errors('', '');
            $this->session->set_flashdata('error', 'Upload gagal: ' . $error);
            redirect('surat-keluar/create');
            return;
        }
        
        $file_data = $this->upload->data();
        $file_path = $file_data['full_path'];
        $file_name = $file_data['file_name'];
        
        // Ekstrak data dari file
        try {
            $this->load->library('document_extractor');
            
            $raw_text = $this->document_extractor->extract_text($file_path);
            
            if ($raw_text && strlen(trim($raw_text)) > 50) {
                // Ekstrak data khusus untuk surat keluar
                $extracted = $this->document_extractor->extract_surat_keluar_data($raw_text);
                
                $this->session->set_flashdata('extracted_data', $extracted);
                $this->session->set_flashdata('uploaded_file', $file_name);
                
                $this->session->set_flashdata('success', 
                    'File berhasil diupload! Data terisi otomatis (Akurasi: ' . $extracted['confidence'] . '%). Silakan periksa dan lengkapi jika perlu.');
            } else {
                $this->session->set_flashdata('uploaded_file', $file_name);
                $this->session->set_flashdata('warning', 
                    'File berhasil diupload, namun gagal mengekstrak data. Silakan isi form manual.');
            }
            
        } catch (Exception $e) {
            $this->session->set_flashdata('uploaded_file', $file_name);
            $this->session->set_flashdata('warning', 
                'File berhasil diupload, namun terjadi error saat ekstraksi: ' . $e->getMessage());
        }
        
        redirect('surat-keluar/create');
    }

    /**
     * CREATE - Form tambah surat keluar
     */
    public function create()
    {
        $data['title']     = 'Input Surat Keluar';
        $data['bagian']    = $this->bagian->get_active();
        $data['kategori']  = $this->kategori->get_active();
        
        // Data extracted (jika ada upload sebelumnya)
        $data['extracted']     = $this->session->flashdata('extracted_data');
        $data['uploaded_file'] = $this->session->flashdata('uploaded_file');

        if ($this->input->post()) {

            $this->form_validation->set_rules('kode_bagian', 'Bagian', 'required');
            $this->form_validation->set_rules('kode_kategori', 'Kategori', 'required');
            $this->form_validation->set_rules('tujuan', 'Tujuan', 'required');
            $this->form_validation->set_rules('perihal', 'Perihal', 'required');
            $this->form_validation->set_rules('tanggal_surat', 'Tanggal Surat', 'required');

            if ($this->form_validation->run()) {

                $tglSurat    = $this->input->post('tanggal_surat');
                $tahun       = (int)date('Y', strtotime($tglSurat));
                $bulan       = (int)date('n', strtotime($tglSurat));

                $kode_bagian = $this->input->post('kode_bagian');
                $kode_kat    = $this->input->post('kode_kategori');

                // 1. Cek nomor manual (no_surat)
                $no_surat_manual = trim($this->input->post('no_surat'));
                $nomor_type      = 'auto';

                if ($no_surat_manual !== '') {
                    // Validate duplicate
                    $this->db->where('no_surat', $no_surat_manual);
                    $exists = $this->db->get('surat_keluar')->row();
                    if ($exists) {
                        $this->session->set_flashdata(
                            'error',
                            'Nomor surat <strong>'.$no_surat_manual.'</strong> sudah digunakan, ganti nomor atau kosongkan untuk auto-generate.'
                        );
                        
                        $this->load->view('layouts/header', $data);
                        $this->load->view('layouts/navbar');
                        $this->load->view('layouts/sidebar');
                        $this->load->view('surat_keluar/form', $data);
                        $this->load->view('layouts/footer');
                        return;
                    }
                    $no_surat   = $no_surat_manual;
                    $nomor_type = 'manual';
                } else {
                    // 2. Generate nomor otomatis pakai Nomor_surat_model
                    $urut        = $this->nomor->update_last_number($kode_bagian, $tahun);
                    $no_urut     = sprintf('%03d', $urut); // Format 001, 002, dst
                    $bulanRoman  = $this->_bulan_roman($bulan);
                    $no_surat    = $no_urut.'/'.$kode_bagian.'/'.$kode_kat.'/'.$bulanRoman.'/'.$tahun;
                }

                // 3. Ambil file yang sudah diupload atau upload baru
                $nama_file = $this->input->post('uploaded_file_name');
                $file_type = '';
                $file_size = 0;
                
                if (empty($nama_file) && !empty($_FILES['file_surat']['name'])) {

                    $config['upload_path']   = './uploads/surat_keluar/';
                    $config['allowed_types'] = 'pdf|doc|docx|jpg|jpeg|png';
                    $config['max_size']      = 10240;
                    $config['file_name']     = 'SK_'.$tahun.'_'.time();

                    if (!is_dir($config['upload_path'])) {
                        mkdir($config['upload_path'], 0755, TRUE);
                    }

                    $this->upload->initialize($config);

                    if (!$this->upload->do_upload('file_surat')) {
                        $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
                        
                        $this->load->view('layouts/header', $data);
                        $this->load->view('layouts/navbar');
                        $this->load->view('layouts/sidebar');
                        $this->load->view('surat_keluar/form', $data);
                        $this->load->view('layouts/footer');
                        return;
                    } else {
                        $up         = $this->upload->data();
                        $nama_file  = $up['file_name'];
                        $file_type  = strtolower(ltrim($up['file_ext'], '.'));
                        $file_size  = $up['file_size'] * 1024;
                    }
                } else if (!empty($nama_file)) {
                    // File sudah diupload sebelumnya
                    $path = FCPATH . 'uploads/surat_keluar/' . $nama_file;
                    if (file_exists($path)) {
                        $file_info = pathinfo($nama_file);
                        $file_type = strtolower($file_info['extension']);
                        $file_size = filesize($path);
                    }
                }

                // 4. Simpan ke DB - SESUAI STRUKTUR DATABASE BARU
                $insert = [
                    'no_surat'       => $no_surat,
                    'kode_bagian'    => $kode_bagian,
                    'kode_kategori'  => $kode_kat,
                    'tujuan'         => $this->input->post('tujuan', TRUE),
                    'perihal'        => $this->input->post('perihal', TRUE),
                    'tanggal_surat'  => $tglSurat,
                    'nama_file_surat'=> $nama_file,
                    'file_type'      => $file_type,
                    'file_size'      => $file_size,
                    'status_pengesahan'     => $this->input->post('status_pengesahan', TRUE) ?: 'draft',
                    'created_by'     => (int)$this->session->userdata('id'),
                ];

                $this->sk->insert($insert);

                $badge = $nomor_type == 'auto'
                    ? ' <span class="badge badge-success">Auto</span>'
                    : ' <span class="badge badge-info">Manual</span>';

                $this->session->set_flashdata(
                    'success',
                    'Surat keluar tersimpan dengan nomor: <strong>'.$no_surat.'</strong>'.$badge
                );
                redirect('surat-keluar');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('surat_keluar/form', $data);
        $this->load->view('layouts/footer');
    }

    // DETAIL
    public function detail($id)
    {
        $surat = $this->sk->get_by_id($id);
        if (!$surat) show_404();

        $data['title'] = 'Detail Surat Keluar';
        $data['surat'] = $surat;

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('surat_keluar/detail', $data);
        $this->load->view('layouts/footer');
    }

    // DOWNLOAD FILE
    public function download($id)
    {
        $surat = $this->sk->get_by_id($id);
        if (!$surat || !$surat->nama_file_surat) show_404();

        $path = FCPATH.'uploads/surat_keluar/'.$surat->nama_file_surat;
        if (!file_exists($path)) show_404();

        $this->load->helper('download');
        force_download($path, NULL);
    }

    // HAPUS
    public function delete($id)
    {
        $surat = $this->sk->get_by_id($id);
        if (!$surat) {
            $this->session->set_flashdata('error', 'Data surat tidak ditemukan');
            redirect('surat-keluar');
        }

        if (!empty($surat->nama_file_surat)) {
            $path = FCPATH.'uploads/surat_keluar/'.$surat->nama_file_surat;
            if (file_exists($path)) {
                unlink($path);
            }
        }

        $this->sk->delete($id);
        $this->session->set_flashdata('success', 'Surat keluar dihapus');
        redirect('surat-keluar');
    }
}
