<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_masuk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        // Check login
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('error', 'Silakan login terlebih dahulu');
            redirect('login');
        }
        
        // Load models
        $this->load->model('Surat_masuk_model', 'sm');
        $this->load->model('Bagian_model', 'bagian');
        $this->load->model('Kategori_model', 'kategori');
        $this->load->model('Disposisi_model', 'disposisi');
        
        // Load libraries
        $this->load->library(['form_validation', 'upload']);
        $this->load->helper(['text', 'custom']);
    }

    /**
     * INDEX - Daftar surat masuk
     */
    public function index()
    {
        $filter = [
            'tgl_awal'  => $this->input->get('tgl_awal'),
            'tgl_akhir' => $this->input->get('tgl_akhir'),
            'kategori'  => $this->input->get('kategori'),
            'bagian'    => $this->input->get('bagian'),
            'search'    => $this->input->get('search') // Add search parameter
        ];

        $data['title']       = 'Surat Masuk';
        $data['surat_masuk'] = $this->sm->get_all($filter); // Filter by search query
        $data['kategori']    = $this->kategori->get_active();
        $data['bagian']      = $this->bagian->get_active();
        $data['filter']      = $filter;

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('surat_masuk/index', $data);
        $this->load->view('layouts/footer');
    }


    /**
     * CREATE - Form tambah surat masuk
     */
    public function create()
    {
        $data['title']    = 'Input Surat Masuk';
        $data['bagian']   = $this->bagian->get_active();
        $data['kategori'] = $this->kategori->get_active();
        
        // Data extracted (jika ada upload sebelumnya)
        $data['extracted'] = $this->session->flashdata('extracted_data');
        $data['uploaded_file'] = $this->session->flashdata('uploaded_file');
        
        if ($this->input->post()) {
            
            // Validasi form
            $this->form_validation->set_rules('kode_bagian', 'Bagian', 'required');
            $this->form_validation->set_rules('kode_kategori', 'Kategori', 'required');
            $this->form_validation->set_rules('tanggal_terima', 'Tanggal Terima', 'required');
            
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('layouts/header', $data);
                $this->load->view('layouts/navbar');
                $this->load->view('layouts/sidebar');
                $this->load->view('surat_masuk/form', $data);
                $this->load->view('layouts/footer');
                return;
            }
            
            // Ambil nama file yang sudah diupload
            $nama_file = $this->input->post('uploaded_file_name');
            $file_type = '';
            $file_size = 0;
            
            // Jika belum upload, upload sekarang
            if (empty($nama_file) && !empty($_FILES['file_surat']['name'])) {
                
                $config['upload_path']   = FCPATH . 'uploads/surat_masuk/';
                $config['allowed_types'] = 'pdf|doc|docx|jpg|jpeg|png';
                $config['max_size']      = 10240;
                $config['encrypt_name']  = TRUE;
                
                if (!is_dir($config['upload_path'])) {
                    mkdir($config['upload_path'], 0755, TRUE);
                }
                
                $this->upload->initialize($config);
                
                if ($this->upload->do_upload('file_surat')) {
                    $upload_data = $this->upload->data();
                    $nama_file = $upload_data['file_name'];
                    $file_type = strtolower(ltrim($upload_data['file_ext'], '.'));
                    $file_size = $upload_data['file_size'] * 1024;
                } else {
                    $error = $this->upload->display_errors('', '');
                    $this->session->set_flashdata('error', 'Gagal upload file: ' . $error);
                    
                    $this->load->view('layouts/header', $data);
                    $this->load->view('layouts/navbar');
                    $this->load->view('layouts/sidebar');
                    $this->load->view('surat_masuk/form', $data);
                    $this->load->view('layouts/footer');
                    return;
                }
            }
            
            $kode_bagian = $this->input->post('kode_bagian');
            $kode_kategori = $this->input->post('kode_kategori');
            
            // CEK: Apakah nomor surat manual diisi?
            $no_surat_manual = trim($this->input->post('no_surat_manual'));
            
            if (!empty($no_surat_manual)) {
                // Gunakan nomor manual
                $no_surat = $no_surat_manual;
                $nomor_type = 'manual';
                
                // Validasi duplikat nomor manual
                $this->db->where('no_surat', $no_surat);
                $exists = $this->db->get('surat_masuk')->row();
                
                if ($exists) {
                    $this->session->set_flashdata('error', 
                        'Nomor surat <strong>' . $no_surat . '</strong> sudah ada dalam database. Gunakan nomor lain atau kosongkan untuk auto-generate.');
                    
                    $this->load->view('layouts/header', $data);
                    $this->load->view('layouts/navbar');
                    $this->load->view('layouts/sidebar');
                    $this->load->view('surat_masuk/form', $data);
                    $this->load->view('layouts/footer');
                    return;
                }
                
            } else {
                // Generate nomor otomatis
                $no_surat = $this->sm->generate_nomor($kode_bagian, $kode_kategori);
                $nomor_type = 'auto';
            }
            
            // Data insert
            $insert = [
                'no_surat'         => $no_surat,
                'kode_bagian'      => $kode_bagian,
                'kode_kategori'    => $kode_kategori,
                'pengirim'         => $this->input->post('pengirim', TRUE) ?: '-',
                'perihal'          => $this->input->post('perihal', TRUE) ?: '-',
                'tanggal_surat'    => $this->input->post('tanggal_surat') ?: date('Y-m-d'),
                'tanggal_terima'   => $this->input->post('tanggal_terima'),
                'nama_file_surat'  => $nama_file,
                'file_type'        => $file_type,
                'file_size'        => $file_size,
                'status'           => 'diterima',
                'created_by'       => $this->session->userdata('id')
            ];
            
            // Insert ke database
            if ($this->sm->insert($insert)) {
                
                $msg = 'Surat masuk berhasil disimpan dengan nomor: <strong>' . $no_surat . '</strong>';
                
                if ($nomor_type == 'auto') {
                    $msg .= ' <span class="badge badge-success">Auto Generate</span>';
                } else {
                    $msg .= ' <span class="badge badge-info">Manual</span>';
                }
                
                $this->session->set_flashdata('success', $msg);
                redirect('surat-masuk');
                
            } else {
                $this->session->set_flashdata('error', 'Gagal menyimpan data. Silakan coba lagi.');
                
                $this->load->view('layouts/header', $data);
                $this->load->view('layouts/navbar');
                $this->load->view('layouts/sidebar');
                $this->load->view('surat_masuk/form', $data);
                $this->load->view('layouts/footer');
            }
            
        } else {
            // Tampilkan form kosong
            $this->load->view('layouts/header', $data);
            $this->load->view('layouts/navbar');
            $this->load->view('layouts/sidebar');
            $this->load->view('surat_masuk/form', $data);
            $this->load->view('layouts/footer');
        }
    }


    /**
     * UPLOAD & EXTRACT - Proses upload file dan ekstrak data
     */
    public function upload_extract()
    {
        if (empty($_FILES['file_surat']['name'])) {
            $this->session->set_flashdata('error', 'Tidak ada file yang diupload');
            redirect('surat-masuk/create');
            return;
        }
        
        $config['upload_path']   = FCPATH . 'uploads/surat_masuk/';
        $config['allowed_types'] = 'pdf|doc|docx|jpg|jpeg|png';
        $config['max_size']      = 10240;
        $config['encrypt_name']  = TRUE;
        
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, TRUE);
        }
        
        $this->upload->initialize($config);
        
        if (!$this->upload->do_upload('file_surat')) {
            $error = $this->upload->display_errors('', '');
            $this->session->set_flashdata('error', 'Upload gagal: ' . $error);
            redirect('surat-masuk/create');
            return;
        }
        
        $file_data = $this->upload->data();
        $file_path = $file_data['full_path'];
        $file_name = $file_data['file_name'];
        
        // Ekstrak data dari file
        try {
            $this->load->library('document_extractor');
            
            $raw_text = $this->document_extractor->extract_text($file_path);
            
            if ($raw_text && strlen(trim($raw_text)) > 50) {
                
                $extracted = $this->document_extractor->extract_surat_data($raw_text);
                
                $this->session->set_flashdata('extracted_data', $extracted);
                $this->session->set_flashdata('uploaded_file', $file_name);
                
                $this->session->set_flashdata('success', 
                    'File berhasil diupload! Data terisi otomatis (Akurasi: ' . $extracted['confidence'] . '%). Silakan periksa dan lengkapi jika perlu.');
                
            } else {
                $this->session->set_flashdata('uploaded_file', $file_name);
                $this->session->set_flashdata('warning', 
                    'File berhasil diupload, namun gagal mengekstrak data. Silakan isi form manual.');
            }
            
        } catch (Exception $e) {
            $this->session->set_flashdata('uploaded_file', $file_name);
            $this->session->set_flashdata('warning', 
                'File berhasil diupload, namun terjadi error saat ekstraksi: ' . $e->getMessage());
        }
        
        redirect('surat-masuk/create');
    }

    /**
     * DETAIL - Lihat detail surat masuk
     */
    public function detail($id)
    {
        $surat = $this->sm->get_by_id($id);
        
        if (!$surat) {
            $this->session->set_flashdata('error', 'Data surat tidak ditemukan');
            redirect('surat-masuk');
        }

        $disposisi = $this->disposisi->get_by_surat($id);

        $data['title']     = 'Detail Surat Masuk';
        $data['surat']     = $surat;
        $data['disposisi'] = $disposisi;

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('surat_masuk/detail', $data);
        $this->load->view('layouts/footer');
    }

    /**
     * DOWNLOAD - Download file surat
     */
    public function download($id)
    {
        $surat = $this->sm->get_by_id($id);
        
        if (!$surat || !$surat->nama_file_surat) {
            show_404();
        }

        $path = FCPATH . 'uploads/surat_masuk/' . $surat->nama_file_surat;
        
        if (!file_exists($path)) {
            $this->session->set_flashdata('error', 'File tidak ditemukan');
            redirect('surat-masuk/detail/' . $id);
        }

        $this->load->helper('download');
        force_download($path, NULL);
    }

    /**
     * EDIT - Update surat masuk
     */
    public function edit($id)
    {
        $surat = $this->sm->get_by_id($id);
        
        if (!$surat) {
            $this->session->set_flashdata('error', 'Data surat tidak ditemukan');
            redirect('surat-masuk');
        }

        $data['title']    = 'Edit Surat Masuk';
        $data['surat']    = $surat;
        $data['bagian']   = $this->bagian->get_active();
        $data['kategori'] = $this->kategori->get_active();

        if ($this->input->post()) {
            
            $this->form_validation->set_rules('pengirim', 'Pengirim', 'required');
            $this->form_validation->set_rules('perihal', 'Perihal', 'required');
            $this->form_validation->set_rules('tanggal_surat', 'Tanggal Surat', 'required');
            $this->form_validation->set_rules('tanggal_terima', 'Tanggal Terima', 'required');
            
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('layouts/header', $data);
                $this->load->view('layouts/navbar');
                $this->load->view('layouts/sidebar');
                $this->load->view('surat_masuk/form_edit', $data);
                $this->load->view('layouts/footer');
                return;
            }
            
            $update = [
                'pengirim'       => $this->input->post('pengirim', TRUE),
                'perihal'        => $this->input->post('perihal', TRUE),
                'tanggal_surat'  => $this->input->post('tanggal_surat'),
                'tanggal_terima' => $this->input->post('tanggal_terima')
            ];
            
            if ($this->sm->update($id, $update)) {
                
                $this->session->set_flashdata('success', 'Surat masuk berhasil diupdate');
                redirect('surat-masuk/detail/' . $id);
            } else {
                $this->session->set_flashdata('error', 'Gagal update data');
                
                $this->load->view('layouts/header', $data);
                $this->load->view('layouts/navbar');
                $this->load->view('layouts/sidebar');
                $this->load->view('surat_masuk/form_edit', $data);
                $this->load->view('layouts/footer');
            }
        } else {
            $this->load->view('layouts/header', $data);
            $this->load->view('layouts/navbar');
            $this->load->view('layouts/sidebar');
            $this->load->view('surat_masuk/form_edit', $data);
            $this->load->view('layouts/footer');
        }
    }

    /**
     * DELETE - Hapus surat masuk
     */
    public function delete($id)
    {
        $surat = $this->sm->get_by_id($id);
        
        if (!$surat) {
            $this->session->set_flashdata('error', 'Data surat tidak ditemukan');
            redirect('surat-masuk');
        }

        // Hapus file fisik jika ada
        if (!empty($surat->nama_file_surat)) {
            $path = FCPATH . 'uploads/surat_masuk/' . $surat->nama_file_surat;
            if (file_exists($path)) {
                @unlink($path);
            }
        }

        // Hapus dari database
        if ($this->sm->delete($id)) {
            $this->session->set_flashdata('success', 'Surat masuk berhasil dihapus');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus data');
        }

        redirect('surat-masuk');
    }

}
