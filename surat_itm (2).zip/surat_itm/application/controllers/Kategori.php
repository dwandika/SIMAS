<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->_must_admin();
        $this->load->model('Kategori_model', 'kategori');
        $this->load->library('form_validation');
    }

    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    private function _must_admin()
    {
        if ($this->session->userdata('role') != 'admin') {
            show_error('Anda tidak memiliki hak akses ke halaman ini.', 403, 'Akses Ditolak');
        }
    }

    public function index()
    {
        $data['title']    = 'Master Jenis Surat';
        $data['kategori'] = $this->kategori->get_all();

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('kategori/index', $data);
        $this->load->view('layouts/footer');
    }

    public function tambah()
    {
        $data['title'] = 'Tambah Jenis Surat';

        if ($this->input->post()) {
            $this->form_validation->set_rules('kode_kategori', 'Kode Kategori', 'required|trim|is_unique[kategori.kode_kategori]');
            $this->form_validation->set_rules('nama_kategori', 'Nama Kategori', 'required|trim');

            if ($this->form_validation->run() == TRUE) {
                $insert = [
                    'kode_kategori' => strtoupper($this->input->post('kode_kategori', TRUE)),
                    'nama_kategori' => $this->input->post('nama_kategori', TRUE),
                    'status'        => $this->input->post('status') ?? '1'
                ];

                $this->kategori->insert($insert);
                $this->session->set_flashdata('success', 'Jenis surat berhasil ditambahkan');
                redirect('kategori');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('kategori/form', $data);
        $this->load->view('layouts/footer');
    }

    public function edit($kode)
    {
        $data['title']        = 'Edit Jenis Surat';
        $data['kategori_row'] = $this->kategori->get_by_kode($kode);

        if (!$data['kategori_row']) {
            show_404();
        }

        if ($this->input->post()) {
            $this->form_validation->set_rules('nama_kategori', 'Nama Kategori', 'required|trim');

            if ($this->form_validation->run() == TRUE) {
                $update = [
                    'nama_kategori' => $this->input->post('nama_kategori', TRUE),
                    'status'        => $this->input->post('status') ?? '1'
                ];

                $this->kategori->update($kode, $update);
                $this->session->set_flashdata('success', 'Jenis surat berhasil diupdate');
                redirect('kategori');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('kategori/form', $data);
        $this->load->view('layouts/footer');
    }

    public function delete($kode)
    {
        // Cek apakah kategori ini sudah dipakai di surat
        $this->db->where('kode_kategori', $kode);
        $count_surat_masuk = $this->db->count_all_results('surat_masuk');
        
        $this->db->where('kode_kategori', $kode);
        $count_surat_keluar = $this->db->count_all_results('surat_keluar');

        if ($count_surat_masuk > 0 || $count_surat_keluar > 0) {
            $this->session->set_flashdata('error', 'Jenis surat tidak dapat dihapus karena sudah digunakan dalam surat.');
            redirect('kategori');
        }

        $kategori = $this->kategori->get_by_kode($kode);
        if ($kategori) {
            $this->kategori->delete($kode);
            $this->session->set_flashdata('success', 'Jenis surat berhasil dihapus');
        }
        
        redirect('kategori');
    }
}
