<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->_only_admin();

        $this->load->model('User_model', 'user');
        $this->load->model('Bagian_model', 'bagian');
        $this->load->library(['form_validation', 'upload']);
    }

    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    private function _only_admin()
    {
        if ($this->session->userdata('role') != 'admin') {
            show_error('Akses ditolak', 403);
        }
    }

    public function index()
    {
        $data['title'] = 'Manajemen User';
        $data['users'] = $this->user->get_all();

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('users/index', $data);
        $this->load->view('layouts/footer');
    }

    public function create()
    {
        $data['title']  = 'Tambah User';
        $data['bagian'] = $this->bagian->get_active();

        if ($this->input->post()) {

            $this->form_validation->set_rules('username', 'Username', 'required|is_unique[user.username]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
            $this->form_validation->set_rules('nama', 'Nama', 'required');
            $this->form_validation->set_rules('role', 'Role', 'required');

            if ($this->form_validation->run()) {

                $foto_profil  = $this->_upload_file('foto_profil', 'uploads/foto/', 'FOTO_');

                $insert = [
                    'username'     => $this->input->post('username', TRUE),
                    'password'     => md5($this->input->post('password')),
                    'nama'         => $this->input->post('nama', TRUE),
                    'role'         => $this->input->post('role', TRUE),
                    'jabatan'      => $this->input->post('jabatan', TRUE),
                    'kode_bagian'  => $this->input->post('kode_bagian'),
                    'foto_profil'  => $foto_profil,
                    'status'       => $this->input->post('status') ? '1' : '0',
                ];

                $this->user->insert($insert);
                $this->session->set_flashdata('success', 'User berhasil ditambahkan');
                redirect('users');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('users/form', $data);
        $this->load->view('layouts/footer');
    }

    public function edit($id)
    {
        $user = $this->user->get_by_id($id);
        if (!$user) show_404();

        $data['title']  = 'Edit User';
        $data['bagian'] = $this->bagian->get_active();
        $data['user']   = $user;

        if ($this->input->post()) {

            $this->form_validation->set_rules('nama', 'Nama', 'required');
            $this->form_validation->set_rules('role', 'Role', 'required');

            if ($this->form_validation->run()) {

                $update = [
                    'nama'        => $this->input->post('nama', TRUE),
                    'role'        => $this->input->post('role', TRUE),
                    'jabatan'     => $this->input->post('jabatan', TRUE),
                    'kode_bagian' => $this->input->post('kode_bagian'),
                    'status'      => $this->input->post('status') ? '1' : '0',
                ];

                // password opsional
                if ($this->input->post('password')) {
                    $update['password'] = md5($this->input->post('password'));
                }

                // update foto jika ada upload baru
                $foto_baru = $this->_upload_file('foto_profil', 'uploads/foto/', 'FOTO_');
                if ($foto_baru) {
                    if (!empty($user->foto_profil) && file_exists(FCPATH.'uploads/foto/'.$user->foto_profil)) {
                        unlink(FCPATH.'uploads/foto/'.$user->foto_profil);
                    }
                    $update['foto_profil'] = $foto_baru;
                }

                // update ttd jika ada upload baru
                

                $this->user->update($id, $update);
                $this->session->set_flashdata('success', 'User berhasil diperbarui');
                redirect('users');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('users/form', $data);
        $this->load->view('layouts/footer');
    }

    public function delete($id)
    {
        $user = $this->user->get_by_id($id);
        if (!$user) {
            $this->session->set_flashdata('error', 'User tidak ditemukan');
            redirect('users');
        }

        if (!empty($user->foto_profil) && file_exists(FCPATH.'uploads/foto/'.$user->foto_profil)) {
            unlink(FCPATH.'uploads/foto/'.$user->foto_profil);
        }

        $this->user->delete($id);
        $this->session->set_flashdata('success', 'User dihapus');
        redirect('users');
    }

    private function _upload_file($field, $path, $prefix)
    {
        if (empty($_FILES[$field]['name'])) return NULL;

        $config['upload_path']   = FCPATH.$path;
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size']      = 2048;
        $config['file_name']     = $prefix.time();

        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, TRUE);
        }

        $this->upload->initialize($config);

        if (!$this->upload->do_upload($field)) {
            $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
            return NULL;
        }

        $up = $this->upload->data();
        return $up['file_name'];
    }
}
