<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->load->model('Laporan_model', 'laporan');
        $this->load->model('Kategori_model', 'kategori');
    }

    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['title'] = 'Laporan';

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('laporan/index', $data);
        $this->load->view('layouts/footer');
    }

    /* =========================
       LAPORAN SURAT MASUK
       tabel: surat_masuk
       ========================= */

    public function surat_masuk()
    {
        $data['title']    = 'Laporan Surat Masuk';
        $data['kategori'] = $this->kategori->get_all();

        $dari_tgl        = $this->input->get('dari_tgl');
        $sampai_tgl      = $this->input->get('sampai_tgl');
        $kategori_filter = $this->input->get('kategori');

        $data['dari_tgl']        = $dari_tgl;
        $data['sampai_tgl']      = $sampai_tgl;
        $data['kategori_filter'] = $kategori_filter;

        $data['surat'] = $this->laporan->get_surat_masuk($dari_tgl, $sampai_tgl, $kategori_filter);

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('laporan/surat_masuk', $data);
        $this->load->view('layouts/footer');
    }

    public function export_excel_masuk()
    {
        $dari_tgl   = $this->input->get('dari_tgl');
        $sampai_tgl = $this->input->get('sampai_tgl');
        $kategori   = $this->input->get('kategori');

        $data = $this->laporan->get_surat_masuk($dari_tgl, $sampai_tgl, $kategori);

        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=Laporan_Surat_Masuk_".date('YmdHis').".xls");

        echo '<table border="1">';
        echo '<tr>
                <th>No</th>
                <th>No Surat (Sistem)</th>
                <th>No Surat Asli</th>
                <th>Tanggal Surat</th>
                <th>Tanggal Terima</th>
                <th>Pengirim</th>
                <th>Perihal</th>
                <th>Kategori</th>
                <th>Bagian Tujuan</th>
              </tr>';

        $no = 1;
        foreach ($data as $row) {
            echo '<tr>';
            echo '<td>'.$no++.'</td>';
            echo '<td>'.($row->no_surat_auto ?? '-').'</td>';
            echo '<td>'.($row->no_surat_asli ?? '-').'</td>';
            echo '<td>'.($row->tanggal_surat ? date('d/m/Y', strtotime($row->tanggal_surat)) : '-').'</td>';
            echo '<td>'.($row->tanggal_terima ? date('d/m/Y', strtotime($row->tanggal_terima)) : '-').'</td>';
            echo '<td>'.($row->pengirim ?? '-').'</td>';
            echo '<td>'.($row->perihal ?? '-').'</td>';
            echo '<td>'.($row->nama_kategori ?? $row->kode_kategori ?? '-').'</td>';
            echo '<td>'.($row->nama_bagian ?? $row->kode_bagian ?? '-').'</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    public function print_masuk()
    {
        $dari_tgl   = $this->input->get('dari_tgl');
        $sampai_tgl = $this->input->get('sampai_tgl');
        $kategori   = $this->input->get('kategori');

        $data['dari_tgl']   = $dari_tgl;
        $data['sampai_tgl'] = $sampai_tgl;
        $data['surat']      = $this->laporan->get_surat_masuk($dari_tgl, $sampai_tgl, $kategori);

        $this->load->view('laporan/print_masuk', $data);
    }

    /* =========================
       LAPORAN SURAT KELUAR
       tabel: surat_keluar
       ========================= */

    public function surat_keluar()
    {
        $data['title']    = 'Laporan Surat Keluar';
        $data['kategori'] = $this->kategori->get_all();

        $dari_tgl        = $this->input->get('dari_tgl');
        $sampai_tgl      = $this->input->get('sampai_tgl');
        $kategori_filter = $this->input->get('kategori');
        $status_pengesahan      = $this->input->get('status_pengesahan');

        $data['dari_tgl']        = $dari_tgl;
        $data['sampai_tgl']      = $sampai_tgl;
        $data['kategori_filter'] = $kategori_filter;
        $data['status_pengesahan']      = $status_pengesahan;

        $data['surat'] = $this->laporan->get_surat_keluar(
            $dari_tgl,
            $sampai_tgl,
            $kategori_filter,
            $status_pengesahan
        );

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('laporan/surat_keluar', $data);
        $this->load->view('layouts/footer');
    }

    public function export_excel_keluar()
    {
        $dari_tgl   = $this->input->get('dari_tgl');
        $sampai_tgl = $this->input->get('sampai_tgl');
        $kategori   = $this->input->get('kategori');
        $status_pengesahan = $this->input->get('status_pengesahan');

        $data = $this->laporan->get_surat_keluar($dari_tgl, $sampai_tgl, $kategori, $status_pengesahan);

        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=Laporan_Surat_Keluar_".date('YmdHis').".xls");

        echo '<table border="1">';
        echo '<tr>
                <th>No</th>
                <th>No Surat (Sistem)</th>
                <th>Tanggal Surat</th>
                <th>Perihal</th>
                <th>Tujuan</th>
                <th>Kategori</th>
                <th>Penandatangan</th>
                <th>Status TTD</th>
              </tr>';

        $no = 1;
        foreach ($data as $row) {
            echo '<tr>';
            echo '<td>'.$no++.'</td>';
            echo '<td>'.($row->no_surat_auto ?? '-').'</td>';
            echo '<td>'.($row->tanggal_surat ? date('d/m/Y', strtotime($row->tanggal_surat)) : '-').'</td>';
            echo '<td>'.($row->perihal ?? '-').'</td>';
            echo '<td>'.($row->tujuan ?? '-').'</td>';
            echo '<td>'.($row->nama_kategori ?? $row->kode_kategori ?? '-').'</td>';
            echo '<td>'.($row->nama_penandatangan ?? '-').'</td>';
            echo '<td>'.ucfirst($row->status_pengesahan ?? 'draft').'</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    public function print_keluar()
    {
        $dari_tgl   = $this->input->get('dari_tgl');
        $sampai_tgl = $this->input->get('sampai_tgl');
        $kategori   = $this->input->get('kategori');
        $status_pengesahan = $this->input->get('status_pengesahan');

        $data['dari_tgl']   = $dari_tgl;
        $data['sampai_tgl'] = $sampai_tgl;
        $data['surat']      = $this->laporan->get_surat_keluar($dari_tgl, $sampai_tgl, $kategori, $status_pengesahan);

        $this->load->view('laporan/print_keluar', $data);
    }
}
