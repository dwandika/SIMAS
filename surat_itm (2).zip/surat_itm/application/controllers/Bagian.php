<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bagian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->load->model('Bagian_model', 'bagian');
        $this->load->library('form_validation');
    }

    private function _must_login()
    {
        if ($this->session->userdata('logged_in') !== TRUE) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['title']  = 'Master Bagian';
        $data['bagian'] = $this->bagian->get_all();

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('bagian/index', $data);
        $this->load->view('layouts/footer');
    }

    public function tambah()
    {
        $data['title'] = 'Tambah Bagian';

        if ($this->input->post()) {

            $this->form_validation->set_rules('kode_bagian', 'Kode Bagian', 'required|is_unique[bagian.kode_bagian]');
            $this->form_validation->set_rules('nama_bagian', 'Nama Bagian', 'required');

            if ($this->form_validation->run()) {
                $insert = [
                    'kode_bagian' => $this->input->post('kode_bagian', TRUE),
                    'nama_bagian' => $this->input->post('nama_bagian', TRUE),
                    'status'      => $this->input->post('status') ? '1' : '0'
                ];
                $this->bagian->insert($insert);
                $this->session->set_flashdata('success', 'Data bagian berhasil ditambahkan');
                redirect('bagian');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('bagian/form', $data);
        $this->load->view('layouts/footer');
    }

    public function edit($kode)
    {
        $row = $this->bagian->get_by_kode($kode);
        if (!$row) show_404();

        $data['title']  = 'Edit Bagian';
        $data['bagian'] = $row;

        if ($this->input->post()) {

            $this->form_validation->set_rules('nama_bagian', 'Nama Bagian', 'required');

            if ($this->form_validation->run()) {
                $update = [
                    'nama_bagian' => $this->input->post('nama_bagian', TRUE),
                    'status'      => $this->input->post('status') ? '1' : '0'
                ];
                $this->bagian->update($kode, $update);
                $this->session->set_flashdata('success', 'Data bagian berhasil diperbarui');
                redirect('bagian');
            }
        }

        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('bagian/form', $data);
        $this->load->view('layouts/footer');
    }

    public function delete($kode)
    {
        $this->bagian->delete($kode);
        $this->session->set_flashdata('success', 'Data bagian dihapus');
        redirect('bagian');
    }
}
