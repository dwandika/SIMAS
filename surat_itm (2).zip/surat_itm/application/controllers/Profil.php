<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // pastikan library session sudah di-autoload
        $this->_must_login();

        $this->load->model('User_model', 'user');
        $this->load->model('Bagian_model', 'bagian');
        $this->load->library('upload');
    }

    private function _must_login()
    {
        if ($this->session->userdata('logged_in') !== TRUE) {
            redirect('login');
        }
    }

    public function index()
    {
        // ambil id user dari session (wajib diset saat login)
        $id = $this->session->userdata('id');
        if (!$id) {
            // jika id belum ada di session, arahkan ke login lagi
            redirect('login');
        }

        $akun = $this->user->get_by_id($id);
        if (!$akun) {
            show_error('Data user tidak ditemukan di database');
        }

        $data['title']  = 'Profil Saya';
        $data['user']   = $akun;
        $data['bagian'] = $this->bagian->get_active();

        // jika belum submit form, hanya tampilkan view
        if (!$this->input->post()) {
            $this->_load_view($data);
            return;
        }

        // proses update profil
        $update = [
            'nama'        => $this->input->post('nama', TRUE),
            'jabatan'     => $this->input->post('jabatan', TRUE),
            'kode_bagian' => $this->input->post('kode_bagian'),
        ];

        // password opsional
        if ($this->input->post('password')) {
            $update['password'] = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
        }

        // upload foto profil (opsional)
        $foto_baru = $this->_upload_img('foto_profil', 'uploads/foto/', 'FOTO_');
        if ($foto_baru) {
            if (!empty($akun->foto_profil) && file_exists(FCPATH.'uploads/foto/'.$akun->foto_profil)) {
                unlink(FCPATH.'uploads/foto/'.$akun->foto_profil);
            }
            $update['foto_profil'] = $foto_baru;
        }

        // simpan ke database
        $this->user->update($id, $update);
        $this->session->set_flashdata('success', 'Profil berhasil diperbarui');
        redirect('profil');
    }

    private function _load_view($data)
    {
        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('profil/index', $data);
        $this->load->view('layouts/footer');
    }

    private function _upload_img($field, $path, $prefix)
    {
        if (empty($_FILES[$field]['name'])) return NULL;

        $config['upload_path']   = FCPATH.$path;
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size']      = 2048;
        $config['file_name']     = $prefix.time();

        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, TRUE);
        }

        $this->upload->initialize($config);

        if (!$this->upload->do_upload($field)) {
            // jangan hentikan proses profil, hanya tampilkan pesan
            $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
            return NULL;
        }

        $up = $this->upload->data();
        return $up['file_name'];
    }
}
