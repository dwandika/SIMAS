<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model', 'user');
        $this->load->library('form_validation');
    }

    public function index()
    {
        return $this->login();
    }

    public function login()
    {
        if ($this->session->userdata('logged_in')) {
            redirect('dashboard');
        }

        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'Username', 'required|trim');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run()) {

                $username = $this->input->post('username', TRUE);
                $password = $this->input->post('password');

                $user = $this->user->get_by_username($username);

                // masih pakai md5 sesuai kode lama
                if ($user && md5($password) == $user->password) {

                    $sess = [
                        'id'          => $user->id,          // penting untuk profil
                        'username'    => $user->username,
                        'nama'        => $user->nama,
                        'role'        => $user->role,
                        'jabatan'     => $user->jabatan,
                        'kode_bagian' => $user->kode_bagian,
                        'logged_in'   => TRUE
                    ];

                    $this->session->set_userdata($sess);
                    redirect('dashboard');

                } else {
                    $this->session->set_flashdata('error', 'Username atau password salah');
                }
            }
        }

        $this->load->view('auth/login');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
