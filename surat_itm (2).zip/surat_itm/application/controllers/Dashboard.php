<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->_must_login();
        $this->load->model('Dashboard_model', 'dash');
    }

    /**
     * Memastikan user sudah login
     */
    private function _must_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    /**
     * Halaman dashboard utama
     */
    public function index()
    {
        $tahun = date('Y');
        
        $data = [
            'title'                      => 'Dashboard',
            'total_surat_masuk'          => $this->dash->get_total_surat_masuk(),
            'total_surat_keluar'         => $this->dash->get_total_surat_keluar(),
            'total_disposisi'            => $this->dash->get_total_disposisi(),
            'total_belum_disahkan'       => $this->dash->get_total_belum_disahkan(),
            'rekap_masuk'                => $this->dash->get_rekap_masuk_tahunan($tahun),
            'rekap_keluar'               => $this->dash->get_rekap_keluar_tahunan($tahun),
            'bulan_terpadat_masuk'       => $this->dash->get_bulan_terpadat_masuk($tahun),
            'bulan_terpadat_keluar'      => $this->dash->get_bulan_terpadat_keluar($tahun),
            'total_disposisi_selesai'    => $this->dash->get_total_disposisi_selesai()
        ];

        // Load views
        $this->load->view('layouts/header', $data);
        $this->load->view('layouts/navbar');
        $this->load->view('layouts/sidebar');
        $this->load->view('dashboard/index', $data);
        $this->load->view('layouts/footer');
    }
}