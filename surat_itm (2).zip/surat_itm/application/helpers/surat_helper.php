<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Konversi angka bulan ke Romawi: 1 -> I, 12 -> XII */
if ( ! function_exists('roman'))
{
    function roman($month)
    {
        $map = [
            1  => 'I',  2  => 'II', 3  => 'III', 4  => 'IV',
            5  => 'V',  6  => 'VI', 7  => 'VII', 8  => 'VIII',
            9  => 'IX', 10 => 'X',  11 => 'XI',  12 => 'XII'
        ];
        $month = (int) $month;
        return isset($map[$month]) ? $map[$month] : '';
    }
}

/* Format tanggal Indonesia: 2025-12-17 -> 17 Desember 2025 */
if ( ! function_exists('tgl_indo'))
{
    function tgl_indo($tanggal)
    {
        if (!$tanggal || $tanggal == '0000-00-00') return '';
        $bulan = [
            1  => 'Januari', 2  => 'Februari', 3  => 'Maret',
            4  => 'April',   5  => 'Mei',      6  => 'Juni',
            7  => 'Juli',    8  => 'Agustus',  9  => 'September',
            10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];
        $parts = explode('-', $tanggal);
        return (int)$parts[2].' '.$bulan[(int)$parts[1]].' '.$parts[0];
    }
}

/* Format nomor surat generik, bisa disesuaikan dengan pola ITM */
if ( ! function_exists('format_nomor_surat'))
{
    /**
     * @param string $kode_kategori  ex: '01'
     * @param int    $counter        ex: 12
     * @param int    $bulan          ex: 7
     * @param int    $tahun          ex: 2025
     * @return string ex: 01.012/ITM/VII/2025
     */
    function format_nomor_surat($kode_kategori, $counter, $bulan, $tahun)
    {
        $running = sprintf('%03d', $counter);
        return $kode_kategori.'.'.$running.'/ITM/'.roman($bulan).'/'.$tahun;
    }
}

/* Helper untuk aktif sidebar di view */
if ( ! function_exists('is_active_menu'))
{
    function is_active_menu($controller)
    {
        $CI =& get_instance();
        return $CI->router->fetch_class() === $controller ? 'active' : '';
    }
}
