<?php
if (!function_exists('tgl_indo')) {
    function tgl_indo($tanggal) {
        $bulan = array(
            1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
            'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
        );
        
        $pecah = explode('-', $tanggal);
        
        if (count($pecah) == 3) {
            return $pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
        }
        
        return $tanggal;
    }
}
