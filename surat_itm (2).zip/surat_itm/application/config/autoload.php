<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Package, drivers tidak dipakai dulu */
$autoload['packages'] = array();
$autoload['drivers']  = array();

/* Libraries yang selalu dipakai */
$autoload['libraries'] = array(
    'database',
    'session',
    'form_validation'
); // jika perlu: 'encryption','upload','pagination' [web:156][web:159]

/* Helper yang di-load otomatis */
$autoload['helper'] = array(
    'url',
    'form',
    'file',
    'html',
    'security',
    'surat'   // helper kustom untuk format nomor/tanggal
);

$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array(); // model dipanggil di controller sesuai kebutuhan
