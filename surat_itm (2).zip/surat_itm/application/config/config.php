<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['base_url'] = 'http://localhost/surat_itm/';   // ubah sesuai environment Anda [web:154]

$config['index_page'] = '';
$config['uri_protocol']	= 'REQUEST_URI';

$config['url_suffix'] = '';

$config['language']	= 'english';
$config['charset'] = 'UTF-8';

$config['enable_hooks'] = FALSE;
$config['subclass_prefix'] = 'MY_';

$config['composer_autoload'] = FALSE;

$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-';

$config['allow_get_array'] = TRUE;
$config['enable_query_strings'] = FALSE;
$config['controller_trigger'] = 'c';
$config['function_trigger'] = 'm';
$config['directory_trigger'] = 'd';
/*
|--------------------------------------------------------------------------
| Error Logging Threshold
|--------------------------------------------------------------------------
| 0 = Disables logging, Error logging TURNED OFF
| 1 = Error Messages (including PHP errors)
| 2 = Debug Messages
| 3 = Informational Messages
| 4 = All Messages
*/
$config['log_threshold'] = 4; // Ubah jadi 4 untuk log semua

/*
|--------------------------------------------------------------------------
| Error Logging Directory Path
|--------------------------------------------------------------------------
*/
$config['log_path'] = APPPATH . 'logs/';

/*
|--------------------------------------------------------------------------
| Log File Extension
|--------------------------------------------------------------------------
*/
$config['log_file_extension'] = 'php';

/*
|--------------------------------------------------------------------------
| Log File Permissions
|--------------------------------------------------------------------------
*/
$config['log_file_permissions'] = 0644;

/*
|--------------------------------------------------------------------------
| Date Format for Logs
|--------------------------------------------------------------------------
*/
$config['log_date_format'] = 'Y-m-d H:i:s';

$config['cache_path'] = '';
$config['encryption_key'] = 'itmnganjuk_manajemensurat_2025'; // ganti string acak kuat [web:152][web:166]

/* Session */
$config['sess_driver'] = 'files';
$config['sess_cookie_name'] = 'itm_session';
$config['sess_expiration'] = 7200;
$config['sess_save_path'] = APPPATH.'sessions/';  // buat folder application/sessions dan beri permission tulis [web:160][web:168]
$config['sess_match_ip'] = FALSE;
$config['sess_time_to_update'] = 300;
$config['sess_regenerate_destroy'] = FALSE;

/* Cookie */
$config['cookie_prefix']	= '';
$config['cookie_domain']	= '';
$config['cookie_path']		= '/';
$config['cookie_secure']	= FALSE;
$config['cookie_httponly'] 	= TRUE;   // sedikit lebih aman [web:157]

$config['standardize_newlines'] = FALSE;
$config['global_xss_filtering'] = FALSE;
$config['csrf_protection'] = TRUE;
$config['csrf_token_name'] = 'csrf_itm_token';
$config['csrf_cookie_name'] = 'csrf_itm_cookie';
$config['csrf_expire'] = 7200;
$config['csrf_regenerate'] = TRUE;

// Tambahkan ini untuk exclude test_ocr dari CSRF
$config['csrf_exclude_uris'] = array('test_ocr', 'test_ocr/.*');

$config['compress_output'] = FALSE;
$config['time_reference'] = 'local';
$config['rewrite_short_tags'] = FALSE;

$config['proxy_ips'] = '';
