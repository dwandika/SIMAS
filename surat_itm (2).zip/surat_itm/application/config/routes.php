<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/

$route['default_controller'] = 'dashboard';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/*
| -------------------------------------------------------------------------
| AUTH ROUTES
| -------------------------------------------------------------------------
*/
$route['login']  = 'auth/login';
$route['logout'] = 'auth/logout';

/*
| -------------------------------------------------------------------------
| DASHBOARD
| -------------------------------------------------------------------------
*/
$route['dashboard'] = 'dashboard/index';

/*
| -------------------------------------------------------------------------
| SURAT MASUK ROUTES
| -------------------------------------------------------------------------
*/
$route['surat-masuk'] = 'surat_masuk/index';
$route['surat-masuk/create'] = 'surat_masuk/create';
$route['surat-masuk/upload_extract'] = 'surat_masuk/upload_extract';
$route['surat-masuk/detail/(:num)'] = 'surat_masuk/detail/$1';
$route['surat-masuk/edit/(:num)'] = 'surat_masuk/edit/$1';
$route['surat-masuk/delete/(:num)'] = 'surat_masuk/delete/$1';
$route['surat-masuk/download/(:num)'] = 'surat_masuk/download/$1';


/*
| -------------------------------------------------------------------------
| SURAT KELUAR ROUTES
| -------------------------------------------------------------------------
*/
$route['surat-keluar']               = 'surat_keluar/index';
$route['surat-keluar/create']        = 'surat_keluar/create';
$route['surat-keluar/upload_extract'] = 'surat_keluar/upload_extract';
$route['surat-keluar/detail/(:num)'] = 'surat_keluar/detail/$1';
$route['surat-keluar/download/(:num)']= 'surat_keluar/download/$1';
$route['surat-keluar/delete/(:num)'] = 'surat_keluar/delete/$1';


/*
| -------------------------------------------------------------------------
| DISPOSISI ROUTES
| -------------------------------------------------------------------------
*/
$route['disposisi']                      = 'disposisi/index';
$route['disposisi/create/(:any)']        = 'disposisi/create/$1';
$route['disposisi/detail/(:num)']        = 'disposisi/detail/$1';
$route['disposisi/ubah_status/(:num)/(:any)'] = 'disposisi/ubah_status/$1/$2';

/*
| -------------------------------------------------------------------------
| MASTER DATA - USERS
| -------------------------------------------------------------------------
*/
$route['users']              = 'users/index';
$route['users/tambah']       = 'users/tambah';
$route['users/edit/(:any)']  = 'users/edit/$1';
$route['users/delete/(:any)']= 'users/delete/$1';

/*
| -------------------------------------------------------------------------
| MASTER DATA - BAGIAN
| -------------------------------------------------------------------------
*/
$route['bagian']           = 'bagian/index';
$route['bagian/tambah']    = 'bagian/tambah';
$route['bagian/edit/(:any)']  = 'bagian/edit/$1';
$route['bagian/delete/(:any)']= 'bagian/delete/$1';


/*
| -------------------------------------------------------------------------
| MASTER DATA - KATEGORI (JENIS SURAT)
| -------------------------------------------------------------------------
*/
$route['kategori']              = 'kategori/index';
$route['kategori/tambah']       = 'kategori/tambah';
$route['kategori/edit/(:any)']  = 'kategori/edit/$1';
$route['kategori/delete/(:any)']= 'kategori/delete/$1';

/*
| -------------------------------------------------------------------------
| LAPORAN
| -------------------------------------------------------------------------
*/
$route['laporan']                    = 'laporan/index';
$route['laporan/surat-masuk']        = 'laporan/surat_masuk';
$route['laporan/surat-keluar']       = 'laporan/surat_keluar';
$route['laporan/export-excel']       = 'laporan/export_excel';
$route['laporan/export-pdf']         = 'laporan/export_pdf';

/*
| -------------------------------------------------------------------------
| PROFIL USER
| -------------------------------------------------------------------------
*/
$route['profil'] = 'profil/index';

