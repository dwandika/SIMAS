<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Document Extractor Library
 * Ekstrak teks dan data dari PDF, Word, dan Gambar
 * - PDF: HYBRID (pdftotext dulu, kalau kosong/jelek fallback OCR)
 * - Support OCR untuk scan dokumen
 * - Support ekstraksi surat masuk DAN surat keluar
 *
 * @author SIMAS ITM
 * @version 2.4 - PDF Hybrid (pdftotext + OCR fallback)
 */
class Document_extractor
{
    private $ci;
    private $tesseract_path;
    private $pdftotext_path;
    private $temp_dir;
    private $debug = true;

    public function __construct()
    {
        $this->ci =& get_instance();
        $this->temp_dir = sys_get_temp_dir();

        // Set path berdasarkan OS
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // Windows
            $this->tesseract_path = 'C:/Program Files/Tesseract-OCR/tesseract.exe';
            $this->pdftotext_path = FCPATH . 'tools/pdftotext.exe';
        } else {
            // Linux/Unix
            $this->tesseract_path = '/usr/bin/tesseract';
            $this->pdftotext_path = '/usr/bin/pdftotext';
        }

        $this->_log('info', 'Document Extractor Library Loaded (PDF Hybrid: pdftotext -> OCR fallback)');
    }

    /**
     * Safe log wrapper
     */
    private function _log($level, $message)
    {
        if ($this->debug) {
            $log_file = APPPATH . 'logs/ocr_' . date('Y-m-d') . '.log';
            $log_entry = date('Y-m-d H:i:s') . ' [' . strtoupper($level) . '] ' . $message . PHP_EOL;
            @file_put_contents($log_file, $log_entry, FILE_APPEND);
        }
    }

    /**
     * Ekstrak teks dari file (PDF/Word/Image)
     *
     * @param string $file_path Path file
     * @return string|false Teks hasil ekstraksi atau false jika gagal
     */
    public function extract_text($file_path)
    {
        if (!file_exists($file_path)) {
            $this->_log('error', 'File tidak ditemukan: ' . $file_path);
            return false;
        }

        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        $this->_log('info', 'Extracting text from: ' . basename($file_path) . ' (' . $ext . ')');

        try {
            switch ($ext) {
                case 'pdf':
                    return $this->_extract_pdf($file_path);

                case 'doc':
                case 'docx':
                    return $this->_extract_docx($file_path);

                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'bmp':
                case 'tiff':
                case 'tif':
                    return $this->_extract_image($file_path);

                default:
                    $this->_log('error', 'Format tidak didukung: ' . $ext);
                    return false;
            }
        } catch (Exception $e) {
            $this->_log('error', 'Exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Ekstrak data lengkap surat MASUK (nomor, tanggal, pengirim, perihal)
     *
     * @param string $text Teks yang sudah diekstrak
     * @return array Data surat masuk
     */
    public function extract_surat_data($text)
    {
        $data = [
            'no_surat_asli' => '',
            'tanggal_surat' => '',
            'pengirim'      => '',
            'perihal'       => '',
            'confidence'    => 0
        ];

        if (empty($text)) {
            return $data;
        }

        $text = $this->_clean_text($text);

        // 1. Ekstrak Nomor Surat
        $nomor_result = $this->extract_nomor_surat($text);
        $data['no_surat_asli'] = $nomor_result['nomor'];
        $confidence_nomor = $nomor_result['confidence'];

        // 2. Ekstrak Tanggal
        $data['tanggal_surat'] = $this->_extract_tanggal($text);

        // 3. Ekstrak Perihal
        $data['perihal'] = $this->_extract_perihal($text);

        // 4. Ekstrak Pengirim
        $data['pengirim'] = $this->_extract_pengirim($text);

        // Hitung confidence keseluruhan
        $filled = 0;
        if (!empty($data['no_surat_asli'])) $filled++;
        if (!empty($data['tanggal_surat'])) $filled++;
        if (!empty($data['perihal'])) $filled++;
        if (!empty($data['pengirim'])) $filled++;

        // Average confidence
        $data['confidence'] = round(($confidence_nomor + ($filled * 20)) / 2);
        $data['confidence'] = min($data['confidence'], 100);

        $this->_log('info', 'Ekstraksi surat masuk selesai. Confidence: ' . $data['confidence'] . '%');

        return $data;
    }

    /**
     * Ekstrak data lengkap surat KELUAR (nomor, tanggal, tujuan, perihal)
     *
     * @param string $text Teks yang sudah diekstrak
     * @return array Data surat keluar
     */
    public function extract_surat_keluar_data($text)
    {
        $data = [
            'no_surat'      => '',
            'tanggal_surat' => '',
            'tujuan'        => '',
            'perihal'       => '',
            'confidence'    => 0
        ];

        if (empty($text)) {
            return $data;
        }

        $text = $this->_clean_text($text);

        // 1. Ekstrak Nomor Surat
        $nomor_result = $this->extract_nomor_surat($text);
        $data['no_surat'] = $nomor_result['nomor'];
        $confidence_nomor = $nomor_result['confidence'];

        // 2. Ekstrak Tanggal
        $data['tanggal_surat'] = $this->_extract_tanggal($text);

        // 3. Ekstrak Perihal
        $data['perihal'] = $this->_extract_perihal($text);

        // 4. Ekstrak Tujuan (khusus surat keluar)
        $data['tujuan'] = $this->_extract_tujuan($text);

        // Hitung confidence keseluruhan
        $filled = 0;
        if (!empty($data['no_surat'])) $filled++;
        if (!empty($data['tanggal_surat'])) $filled++;
        if (!empty($data['perihal'])) $filled++;
        if (!empty($data['tujuan'])) $filled++;

        // Average confidence
        $data['confidence'] = round(($confidence_nomor + ($filled * 20)) / 2);
        $data['confidence'] = min($data['confidence'], 100);

        $this->_log('info', 'Ekstraksi surat keluar selesai. Confidence: ' . $data['confidence'] . '%');

        return $data;
    }

    /**
     * Ekstrak nomor surat dengan berbagai pattern
     *
     * @param string $text
     * @return array ['nomor' => string|null, 'confidence' => int]
     */
    public function extract_nomor_surat($text)
    {
        if (empty($text)) {
            return ['nomor' => null, 'confidence' => 0];
        }

        $text = $this->_clean_text($text);

        // Pattern nomor surat ITM dan umum
        $patterns = [
            // Pattern ITM: 04.60/ITM/X/2025 (dengan titik di tengah)
            '/(?:Nomor|No\.?|Number)\s*:?\s*([0-9]{2}\.[0-9]{2,3}\/[A-Z]{2,10}\/[IVX]{1,5}\/[0-9]{4})/i' => 98,

            // Pattern ITM tanpa prefix
            '/([0-9]{2}\.[0-9]{2,3}\/[A-Z]{2,10}\/[IVX]{1,5}\/[0-9]{4})/i' => 95,

            // Pattern ITM lama: 01.001/ADM/XII/2025
            '/([0-9]{2}\.[0-9]{3}\/[A-Z]{2,10}\/[IVX]{1,5}\/[0-9]{4})/i' => 93,

            // Pattern dengan prefix dan format umum
            '/(?:Nomor|No\.?|Number)\s*:?\s*([0-9]{2}\.[0-9]{2,4}\/[A-Z0-9]{2,10}\/[A-Z0-9]{1,10}\/[0-9]{4})/i' => 92,

            // Pattern B/ atau S/ (surat resmi)
            '/([BS]\/[0-9]{1,5}\/[A-Z0-9\/\.\-]{5,50}\/[0-9]{4})/i' => 90,

            // Pattern umum dengan prefix
            '/(?:Nomor|No\.?)\s*:?\s*([A-Z0-9]{2,5}\/[A-Z0-9\/\.\-]{8,60})/i' => 85,

            // Pattern format XXX/YYY/MMM/YYYY
            '/([A-Z0-9]{2,5}\/[0-9]{1,5}\/[A-Z0-9\-]{2,10}\/[IVX]{1,5}\/[0-9]{4})/i' => 80,

            // Pattern dengan titik dan slash: XX.XX/YYY/YYYY
            '/([0-9]{2}\.[0-9]{2,4}\/[A-Z]{2,10}\/[0-9]{4})/i' => 75,

            // Pattern sederhana
            '/([0-9]{2,5}\/[A-Z]{2,10}\/[0-9]{4})/i' => 70,
        ];

        $best_match = null;
        $best_confidence = 0;

        foreach ($patterns as $pattern => $confidence) {
            if (preg_match($pattern, $text, $match)) {
                $nomor = trim($match[1]);
                $score = $confidence;

                // Bonus untuk format ITM spesifik
                if (preg_match('/[0-9]{2}\.[0-9]{2,3}\/[A-Z]{2,10}\/[IVX]{1,5}\/[0-9]{4}/i', $nomor)) {
                    $score += 10;
                }

                // Bonus jika ada kata "ITM"
                if (stripos($nomor, 'ITM') !== false) {
                    $score += 5;
                }

                // Validasi panjang
                if (strlen($nomor) >= 10 && strlen($nomor) <= 80) {

                    // Harus ada angka dan huruf
                    if (preg_match('/[0-9]/', $nomor) && preg_match('/[A-Z]/i', $nomor)) {

                        // Bonus jika ada tahun 2024-2026
                        if (preg_match('/202[4-6]/', $nomor)) {
                            $score += 3;
                        }

                        // Bonus jika ada bulan romawi
                        if (preg_match('/\/(I|II|III|IV|V|VI|VII|VIII|IX|X|XI|XII)\//i', $nomor)) {
                            $score += 2;
                        }

                        if ($score > $best_confidence) {
                            $best_match = $nomor;
                            $best_confidence = $score;
                        }
                    }
                }
            }
        }

        if ($best_match) {
            $this->_log('info', 'Nomor surat ditemukan: ' . $best_match . ' (Confidence: ' . $best_confidence . '%)');
        } else {
            $this->_log('warning', 'Nomor surat tidak ditemukan dalam teks');
        }

        return [
            'nomor' => $best_match,
            'confidence' => min($best_confidence, 100)
        ];
    }

    /**
     * Ekstrak tanggal dari teks
     */
    private function _extract_tanggal($text)
    {
        $patterns = [
            // Format: 24 Desember 2025
            '/([0-9]{1,2}[\s\-\/](?:Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember|Jan|Feb|Mar|Apr|Mei|Jun|Jul|Agu|Sep|Okt|Nov|Des)[\s\-\/][0-9]{2,4})/i',

            // Format: 24-12-2025
            '/([0-9]{1,2}[\-\/][0-9]{1,2}[\-\/][0-9]{2,4})/',

            // Format dengan prefix
            '/(?:Tanggal|Tgl\.?|Date)\s*:?\s*([0-9]{1,2}[\s\-\/][A-Za-z]{3,9}[\s\-\/][0-9]{2,4})/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $match)) {
                $tgl = $this->_convert_tanggal($match[1]);
                if ($tgl) return $tgl;
            }
        }

        // fallback: hari ini
        return date('Y-m-d');
    }

    /**
     * Ekstrak perihal
     */
    private function _extract_perihal($text)
    {
        $patterns = [
            '/(?:Perihal|Hal)\s*:?\s*([^\n]{10,300})/i',
            '/(?:Tentang)\s*:?\s*([^\n]{10,300})/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $match)) {
                $perihal = trim($match[1]);
                $perihal = preg_replace('/\s+/', ' ', $perihal);
                if (strlen($perihal) >= 10) {
                    return substr($perihal, 0, 300);
                }
            }
        }

        return '';
    }

    /**
     * Ekstrak pengirim (untuk surat masuk)
     */
    private function _extract_pengirim($text)
    {
        $patterns = [
            '/(?:Dari|From|Pengirim)\s*:?\s*([^\n]{5,200})/i',
            '/(?:Yth\.?|Kepada)\s*:?\s*([^\n]{5,200})/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $match)) {
                $pengirim = trim($match[1]);
                $pengirim = preg_replace('/\s+/', ' ', $pengirim);
                if (strlen($pengirim) >= 5) {
                    return substr($pengirim, 0, 200);
                }
            }
        }

        return '';
    }

    /**
     * Ekstrak tujuan (untuk surat keluar)
     */
    private function _extract_tujuan($text)
    {
        $patterns = [
            // Pattern 1: Kepada Yth / Yth.
            '/(?:Kepada\s+)?Yth\.?\s*:?\s*([^\n]{5,200})/i',

            // Pattern 2: Kepada
            '/(?:Kepada|Tujuan)\s*:?\s*([^\n]{5,200})/i',

            // Pattern 3: Jabatan (Direktur, Kepala, dll)
            '/(?:Kepala|Direktur|Manager|Ketua|Rektor|Dekan)\s+([^\n]{5,200})/i',

            // Pattern 4: Di tempat / alamat
            '/([^\n]{10,200})\s+(?:Di\s+tempat|di\s+tempat)/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $match)) {
                $tujuan = trim($match[1]);

                // Bersihkan dari kata-kata yang tidak perlu
                $tujuan = preg_replace('/\s+/', ' ', $tujuan);
                $tujuan = preg_replace('/^(Bapak|Ibu|Saudara)\s+/i', '', $tujuan);

                if (strlen($tujuan) >= 5 && strlen($tujuan) <= 200) {
                    return $tujuan;
                }
            }
        }

        return '';
    }

    /**
     * Ekstrak dari PDF - HYBRID (pdftotext dulu, fallback OCR jika perlu)
     */
    private function _extract_pdf($file_path)
    {
        $this->_log('info', 'Extracting PDF using HYBRID: pdftotext -> OCR fallback');

        // 1) Coba text-based dulu (cepat & akurat untuk PDF digital)
        $text = $this->_extract_pdf_text($file_path);

        // Kalau hasilnya sudah layak, pakai itu
        if ($this->_is_text_good($text)) {
            $this->_log('info', 'pdftotext extraction OK. Using text-based result.');
            return $text;
        }

        // 2) Kalau hasilnya kosong/jelek => fallback OCR (untuk PDF scan)
        $this->_log('warning', 'pdftotext result weak/empty. Falling back to OCR.');
        return $this->_extract_pdf_ocr($file_path);
    }

    /**
     * Ekstrak PDF text-based menggunakan pdftotext
     */
    private function _extract_pdf_text($file_path)
    {
        if (!file_exists($this->pdftotext_path)) {
            $this->_log('warning', 'pdftotext not found at: ' . $this->pdftotext_path);
            return '';
        }

        $run_id = time() . '_' . mt_rand(1000, 9999);
        $output_base = $this->temp_dir . "/pdftotext_{$run_id}";
        $result_file = $output_base . ".txt";

        // Gunakan escapeshellarg untuk keamanan path
        $cmd = '"' . $this->pdftotext_path . '" -layout -enc UTF-8 '
             . escapeshellarg($file_path) . ' '
             . escapeshellarg($result_file) . ' 2>&1';

        $this->_log('info', "Running pdftotext command: {$cmd}");

        exec($cmd, $output, $return_code);

        $this->_log('info', "pdftotext return code: {$return_code}");

        if (!file_exists($result_file)) {
            $this->_log('warning', 'pdftotext result file not found: ' . $result_file);
            return '';
        }

        $text = file_get_contents($result_file);
        @unlink($result_file);

        $text = $this->_clean_text($text);

        $this->_log('info', 'pdftotext extraction done. Text length: ' . strlen($text));

        return $text;
    }

    /**
     * Heuristik sederhana: menentukan teks hasil ekstraksi sudah "layak"
     */
    private function _is_text_good($text)
    {
        if (empty($text)) return false;

        $text = trim($text);
        $len  = strlen($text);

        // terlalu pendek: biasanya PDF scan (atau pdftotext gagal)
        if ($len < 200) return false;

        // harus ada beberapa kata
        if (str_word_count($text) < 30) return false;

        // kalau kebanyakan karakter aneh, biasanya hasil buruk
        $printable = preg_replace('/[^\x20-\x7E]/', '', $text);
        if (strlen($printable) / max($len, 1) < 0.6) return false;

        return true;
    }

    /**
     * Ekstrak PDF dengan OCR (Imagick -> Tesseract)
     */
    private function _extract_pdf_ocr($file_path)
    {
        if (!extension_loaded('imagick')) {
            $this->_log('error', 'Imagick extension not loaded');
            return 'Imagick extension tidak tersedia. Silakan install php-imagick.';
        }

        if (!file_exists($this->tesseract_path)) {
            $this->_log('error', 'Tesseract not found at: ' . $this->tesseract_path);
            return 'Tesseract OCR belum terinstall di: ' . $this->tesseract_path;
        }

        try {
            $this->_log('info', 'Starting OCR extraction from PDF');

            $run_id = time() . '_' . mt_rand(1000, 9999);

            // Load PDF dengan Imagick
            $images = new \Imagick();
            $images->setResolution(300, 300); // resolusi tinggi untuk OCR lebih baik
            $images->readImage($file_path);

            $text = '';
            $total_pages = $images->getNumberImages();

            $this->_log('info', "Total pages to process: {$total_pages}");

            foreach ($images as $i => $image) {
                $page_num = $i + 1;
                $this->_log('info', "Processing page {$page_num}/{$total_pages}");

                $image->setImageFormat('png');
                $image->setImageCompressionQuality(100);

                // Enhance image untuk OCR lebih baik
                $image->normalizeImage();
                $image->sharpenImage(0, 1);

                // Save temporary image
                $temp_image = $this->temp_dir . "/ocr_page_{$run_id}_{$i}.png";
                $image->writeImage($temp_image);

                $this->_log('info', "Temp image saved: {$temp_image}");

                // Output base (tesseract akan menambah .txt)
                $output_base = $this->temp_dir . "/ocr_output_{$run_id}_{$i}";

                $cmd = '"' . $this->tesseract_path . '" '
                     . escapeshellarg($temp_image) . ' '
                     . escapeshellarg($output_base)
                     . ' -l ind+eng --psm 6 2>&1';

                $this->_log('info', "Running OCR command: {$cmd}");

                exec($cmd, $output, $return_code);

                $this->_log('info', "OCR return code: {$return_code}");

                $result_file = $output_base . '.txt';

                if (file_exists($result_file)) {
                    $ocr_text = file_get_contents($result_file);
                    $text .= $ocr_text . "\n\n--- Halaman {$page_num} ---\n\n";
                    $this->_log('info', "OCR successful for page {$page_num}. Text length: " . strlen($ocr_text));
                    @unlink($result_file);
                } else {
                    $this->_log('warning', "OCR result file not found: {$result_file}");
                }

                @unlink($temp_image);
            }

            $images->clear();
            $images->destroy();

            $this->_log('info', 'OCR extraction completed. Total text length: ' . strlen($text));

            return trim($text);

        } catch (Exception $e) {
            $this->_log('error', 'OCR failed: ' . $e->getMessage());
            return 'OCR gagal: ' . $e->getMessage();
        }
    }

    /**
     * Ekstrak dari DOCX
     */
    private function _extract_docx($file_path)
    {
        if (!class_exists('ZipArchive')) {
            $this->_log('error', 'ZipArchive not available');
            return false;
        }

        $zip = new ZipArchive();

        if ($zip->open($file_path) !== TRUE) {
            return false;
        }

        $xml_content = $zip->getFromName('word/document.xml');
        $zip->close();

        if ($xml_content === false) {
            return false;
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xml_content);

        if ($xml === false) {
            return false;
        }

        $xml->registerXPathNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
        $text_nodes = $xml->xpath('//w:t');
        $text = '';

        if ($text_nodes) {
            foreach ($text_nodes as $node) {
                $text .= (string)$node . ' ';
            }
        }

        return $this->_clean_text($text);
    }

    /**
     * Ekstrak dari gambar
     */
    private function _extract_image($file_path)
    {
        if (!file_exists($this->tesseract_path)) {
            return 'Tesseract OCR belum terinstall di: ' . $this->tesseract_path;
        }

        $run_id = time() . '_' . mt_rand(1000, 9999);
        $output_base = $this->temp_dir . "/ocr_img_{$run_id}";

        $cmd = '"' . $this->tesseract_path . '" '
             . escapeshellarg($file_path) . ' '
             . escapeshellarg($output_base)
             . ' -l ind+eng --psm 6 2>&1';

        exec($cmd, $output, $return);

        $result_file = $output_base . '.txt';

        if (!file_exists($result_file)) {
            return false;
        }

        $text = file_get_contents($result_file);
        @unlink($result_file);

        return $this->_clean_text($text);
    }

    /**
     * Clean text
     */
    private function _clean_text($text)
    {
        if ($text === null) return '';
        $text = preg_replace('/[^\x20-\x7E\n\r\t]/u', '', $text);
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\n\s*\n/', "\n", $text);
        return trim($text);
    }

    /**
     * Convert tanggal Indonesia ke Y-m-d
     */
    private function _convert_tanggal($tgl_text)
    {
        $bulan_indo = [
            'januari' => '01', 'februari' => '02', 'maret' => '03',
            'april'   => '04', 'mei'      => '05', 'juni'   => '06',
            'juli'    => '07', 'agustus'  => '08', 'september' => '09',
            'oktober' => '10', 'november' => '11', 'desember'  => '12',
            'jan' => '01', 'feb' => '02', 'mar' => '03',
            'apr' => '04', 'jun' => '06', 'jul' => '07',
            'agu' => '08', 'sep' => '09', 'okt' => '10',
            'nov' => '11', 'des' => '12'
        ];

        $tgl_text = strtolower($tgl_text);

        foreach ($bulan_indo as $nama => $angka) {
            $tgl_text = str_replace($nama, $angka, $tgl_text);
        }

        $timestamp = strtotime($tgl_text);
        if ($timestamp && $timestamp > strtotime('2020-01-01')) {
            return date('Y-m-d', $timestamp);
        }

        return null;
    }
}
