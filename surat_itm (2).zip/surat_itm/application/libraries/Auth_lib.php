<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_lib {

    protected $CI;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->model('User_model', 'user');
    }

    public function login($username, $password)
    {
        $user = $this->CI->user->get_by_username($username);
        if (!$user) {
            return FALSE;
        }

        // Sederhana: md5, bisa ganti password_hash/password_verify.
        if (md5($password) !== $user->password) {
            return FALSE;
        }

        $sess = [
            'username'    => $user->username,
            'nama'        => $user->nama,
            'role'        => $user->role,
            'tipe'        => $user->tipe,
            'jabatan'     => $user->jabatan,
            'kode_bagian' => $user->kode_bagian,
            'logged_in'   => TRUE
        ];
        $this->CI->session->set_userdata($sess);
        return TRUE;
    }

    public function logout()
    {
        $this->CI->session->sess_destroy();
    }

    public function has_role($roles)
    {
        if (!is_array($roles)) {
            $roles = [$roles];
        }
        return in_array($this->CI->session->userdata('role'), $roles, TRUE);
    }

    public function is_logged_in()
    {
        return (bool) $this->CI->session->userdata('logged_in');
    }
}
