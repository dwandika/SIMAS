<div class="content-wrapper dashboard-itm-wrapper">
  <!-- Hero Header -->
  <section class="content-header pb-0">
    <div class="container-fluid">
      <div class="dashboard-hero-itm">
        <div>
          <h1 class="h4 mb-1 text-white">Selamat datang di SIMAS ITM</h1>
          <p class="text-white-50 small mb-2">
            Sistem Informasi Manajemen Surat Institut Teknologi Mojosari.
          </p>
          <span class="badge badge-pill badge-light text-primary-itm small">
            <?php echo tgl_indo(date('Y-m-d')); ?>
          </span>
        </div>
        <div class="text-right d-none d-md-block">
          <div class="text-white-50 small mb-1">Login sebagai</div>
          <div class="text-white font-weight-semibold">
            <?php echo $this->session->userdata('nama'); ?>
          </div>
          <div class="text-white-50 small">
            <?php echo ucfirst($this->session->userdata('role')); ?>
            <?php echo $this->session->userdata('jabatan') ? ' • '.$this->session->userdata('jabatan') : ''; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content pt-0">
    <div class="container-fluid">

      <!-- Info cards -->
      <div class="row mt-3">
        <!-- Surat Masuk -->
        <div class="col-md-3 col-6">
          <div class="card card-stat-itm">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <p class="card-stat-label">Surat Masuk</p>
                  <h3 class="card-stat-value">
                    <?php echo isset($total_surat_masuk) ? $total_surat_masuk : 0; ?>
                  </h3>
                </div>
                <div class="card-stat-icon bg-soft-blue">
                  <i class="fas fa-inbox"></i>
                </div>
              </div>
              <a href="<?php echo site_url('surat-masuk'); ?>" class="card-stat-link">
                Lihat surat masuk <i class="fas fa-arrow-right ml-1"></i>
              </a>
            </div>
          </div>
        </div>

        <!-- Surat Keluar -->
        <div class="col-md-3 col-6">
          <div class="card card-stat-itm">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <p class="card-stat-label">Surat Keluar</p>
                  <h3 class="card-stat-value">
                    <?php echo isset($total_surat_keluar) ? $total_surat_keluar : 0; ?>
                  </h3>
                </div>
                <div class="card-stat-icon bg-soft-blue">
                  <i class="fas fa-paper-plane"></i>
                </div>
              </div>
              <a href="<?php echo site_url('surat-keluar'); ?>" class="card-stat-link">
                Lihat surat keluar <i class="fas fa-arrow-right ml-1"></i>
              </a>
            </div>
          </div>
        </div>

        <!-- Disposisi Aktif -->
        <div class="col-md-3 col-6 mt-3 mt-md-0">
          <div class="card card-stat-itm">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <p class="card-stat-label">Disposisi Aktif</p>
                  <h3 class="card-stat-value">
                    <?php echo isset($total_disposisi) ? $total_disposisi : 0; ?>
                  </h3>
                </div>
                <div class="card-stat-icon bg-soft-blue">
                  <i class="fas fa-share-square"></i>
                </div>
              </div>
              <a href="<?php echo site_url('disposisi'); ?>" class="card-stat-link">
                Kelola disposisi <i class="fas fa-arrow-right ml-1"></i>
              </a>
            </div>
          </div>
        </div>

        <!-- Menunggu Pengesahan -->
        <div class="col-md-3 col-6 mt-3 mt-md-0">
          <div class="card card-stat-itm">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <p class="card-stat-label">Menunggu Pengesahan</p>
                  <h3 class="card-stat-value">
                    <?php echo isset($total_belum_disahkan) ? $total_belum_disahkan : 0; ?>
                  </h3>
                </div>
                <div class="card-stat-icon bg-soft-blue">
                  <i class="fas fa-stamp"></i>
                </div>
              </div>
              <a href="<?php echo site_url('surat-keluar?status_pengesahan=menunggu'); ?>" class="card-stat-link">
                Proses sekarang <i class="fas fa-arrow-right ml-1"></i>
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Charts + activity -->
      <div class="row">
        <!-- Chart tren -->
        <div class="col-lg-7">
          <div class="card card-outline card-itm mb-3">
            <div class="card-header border-0">
              <h3 class="card-title h6 mb-0">
                Tren Surat Masuk & Keluar <?php echo date('Y'); ?>
              </h3>
            </div>
            <div class="card-body pt-0">
              <canvas id="chartSurat" height="170"></canvas>
            </div>
          </div>
        </div>

        <!-- Ringkasan & Akses Cepat -->
        <div class="col-lg-5">
          <div class="card card-outline card-itm mb-3">
            <div class="card-header border-0">
              <h3 class="card-title h6 mb-0">Ringkasan Cepat</h3>
            </div>
            <div class="card-body pt-1">
              <ul class="list-unstyled mb-0 small">
                <li class="mb-2">
                  <i class="fas fa-circle text-primary-itm mr-2"></i>
                  Surat masuk terbanyak pada bulan:
                  <strong><?php echo $bulan_terpadat_masuk ?? '-'; ?></strong>
                </li>
                <li class="mb-2">
                  <i class="fas fa-circle text-secondary mr-2"></i>
                  Surat keluar terbanyak pada bulan:
                  <strong><?php echo $bulan_terpadat_keluar ?? '-'; ?></strong>
                </li>
                <li class="mb-2">
                  <i class="fas fa-circle text-muted mr-2"></i>
                  Total disposisi terselesaikan:
                  <strong><?php echo $total_disposisi_selesai ?? 0; ?></strong>
                </li>
              </ul>
            </div>
          </div>

          <div class="card card-outline card-itm">
            <div class="card-header border-0">
              <h3 class="card-title h6 mb-0">Akses Cepat</h3>
            </div>
            <div class="card-body pt-2">
              <div class="d-flex flex-wrap">
                <a href="<?php echo site_url('surat-masuk/create'); ?>"
                   class="btn btn-primary-itm btn-sm mr-2 mb-2">
                  <i class="fas fa-plus mr-1"></i> Surat Masuk
                </a>
                <a href="<?php echo site_url('surat-keluar/tambah'); ?>"
                   class="btn btn-outline-primary-itm btn-sm mr-2 mb-2">
                  <i class="fas fa-plus mr-1"></i> Surat Keluar
                </a>
                <a href="<?php echo site_url('laporan/surat-masuk'); ?>"
                   class="btn btn-light btn-sm mr-2 mb-2">
                  <i class="fas fa-file-alt mr-1"></i> Laporan
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </section>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const dataMasuk  = <?php echo json_encode($rekap_masuk ?? []); ?>;
  const dataKeluar = <?php echo json_encode($rekap_keluar ?? []); ?>;
  const labels     = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];

  function buildData(data) {
    const result = new Array(12).fill(0);
    data.forEach(function(row) {
      const idx = (parseInt(row.bulan) || 0) - 1;
      if (idx >= 0 && idx < 12) {
        result[idx] = parseInt(row.jumlah) || 0;
      }
    });
    return result;
  }

  const ctx = document.getElementById('chartSurat').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Surat Masuk',
          data: buildData(dataMasuk),
          borderColor: '#00a9e0',
          backgroundColor: 'rgba(0,169,224,0.15)',
          borderWidth: 2,
          tension: .35,
          fill: true,
          pointRadius: 3
        },
        {
          label: 'Surat Keluar',
          data: buildData(dataKeluar),
          borderColor: '#005b96',
          backgroundColor: 'rgba(0,91,150,0.12)',
          borderWidth: 2,
          tension: .35,
          fill: true,
          pointRadius: 3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { 
          display: true, 
          labels: { boxWidth: 10 } 
        }
      },
      scales: {
        y: { 
          beginAtZero: true, 
          ticks: { precision: 0 } 
        }
      }
    }
  });
</script>