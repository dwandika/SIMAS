<!-- application/views/laporan/surat_keluar.php -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Laporan Surat Keluar</h1>
          <p class="text-muted small mb-0">Rekap surat keluar berdasarkan periode</p>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <div class="card card-outline card-itm mb-3">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">Filter Laporan</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body py-2">
          <form method="get" action="<?php echo site_url('laporan/surat_keluar'); ?>">
            <div class="row">
              <div class="col-md-3">
                <div class="form-group mb-2">
                  <label class="small text-muted">Dari Tanggal</label>
                  <input type="date" name="dari_tgl" class="form-control form-control-sm"
                         value="<?php echo $dari_tgl; ?>">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group mb-2">
                  <label class="small text-muted">Sampai Tanggal</label>
                  <input type="date" name="sampai_tgl" class="form-control form-control-sm"
                         value="<?php echo $sampai_tgl; ?>">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group mb-2">
                  <label class="small text-muted">Kategori</label>
                  <select name="kategori" class="form-control form-control-sm">
                    <option value="">Semua Kategori</option>
                    <?php foreach($kategori as $k): ?>
                      <option value="<?php echo $k->kode_kategori; ?>"
                        <?php echo ($kategori_filter == $k->kode_kategori) ? 'selected' : ''; ?>>
                        <?php echo $k->kode_kategori.' - '.$k->nama_kategori; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group mb-2">
                  <label class="small text-muted">Status Pengesahan</label>
                  <select name="status_pengesahan" class="form-control form-control-sm">
                    <option value="">Semua Status</option>
                    <option value="draft"          <?php echo $status_pengesahan=='draft'?'selected':''; ?>>Draft</option>
                    <option value="menunggu"       <?php echo $status_pengesahan=='menunggu'?'selected':''; ?>>Menunggu</option>
                    <option value="ditandatangani" <?php echo $status_pengesahan=='ditandatangani'?'selected':''; ?>>Ditandatangani</option>
                    <option value="ditolak"        <?php echo $status_pengesahan=='ditolak'?'selected':''; ?>>Ditolak</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <button type="submit" class="btn btn-primary-itm btn-sm">
                  <i class="fas fa-search mr-1"></i> Tampilkan
                </button>
                <?php if(!empty($surat)): ?>
                <a href="<?php echo site_url('laporan/print_keluar?dari_tgl='.$dari_tgl.'&sampai_tgl='.$sampai_tgl.'&kategori='.$kategori_filter.'&status_pengesahan='.$status_pengesahan); ?>"
                   target="_blank" class="btn btn-outline-secondary btn-sm">
                  <i class="fas fa-print mr-1"></i> Cetak
                </a>
                <a href="<?php echo site_url('laporan/export_excel_keluar?dari_tgl='.$dari_tgl.'&sampai_tgl='.$sampai_tgl.'&kategori='.$kategori_filter.'&status_pengesahan='.$status_pengesahan); ?>"
                   class="btn btn-outline-success btn-sm">
                  <i class="fas fa-file-excel mr-1"></i> Excel
                </a>
                <?php endif; ?>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Hasil Laporan Surat Keluar</h3>
          <div class="card-tools">
            <span class="badge badge-primary-itm">Total: <?php echo count($surat); ?></span>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="4%">No</th>
                <th width="20%">No. Surat</th>
                <th>Tujuan</th>
                <th>Perihal</th>
                <th width="11%">Tgl Surat</th>
                <th width="10%">Kategori</th>
                <th width="10%">Status pengesahan</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($surat)): $no=1; foreach($surat as $s): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td class="small"><?php echo $s->no_surat; ?></td>
                <td><?php echo $s->tujuan; ?></td>
                <td><?php echo $s->perihal; ?></td>
                <td class="small"><?php echo tgl_indo($s->tanggal_surat); ?></td>
                <td class="small"><?php echo $s->nama_kategori ?? $s->kode_kategori; ?></td>
                <td class="small text-capitalize"><?php echo $s->status_pengesahan; ?></td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted py-3">
                  Tidak ada data untuk filter tersebut
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
