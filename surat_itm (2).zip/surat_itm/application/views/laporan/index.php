<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><i class="fas fa-chart-bar text-itm-primary"></i> Laporan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo site_url('dashboard'); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Laporan</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Content -->
  <section class="content">
    <div class="container-fluid">
      
      <div class="row">
        <!-- Laporan Surat Masuk -->
        <div class="col-lg-6">
          <div class="card card-outline card-primary shadow-sm">
            <div class="card-header">
              <h3 class="card-title">
                <i class="fas fa-inbox mr-2"></i>
                <strong>Laporan Surat Masuk</strong>
              </h3>
            </div>
            <div class="card-body">
              <p class="text-muted">
                <i class="fas fa-info-circle"></i> 
                Laporan surat masuk berdasarkan periode, kategori, dan bagian tujuan
              </p>
              <ul class="list-unstyled">
                <li><i class="fas fa-check text-success"></i> Filter berdasarkan tanggal</li>
                <li><i class="fas fa-check text-success"></i> Filter berdasarkan kategori</li>
                <li><i class="fas fa-check text-success"></i> Export ke Excel</li>
                <li><i class="fas fa-check text-success"></i> Print PDF/Cetak</li>
              </ul>
            </div>
            <div class="card-footer">
              <a href="<?php echo site_url('laporan/surat_masuk'); ?>" class="btn btn-primary btn-block">
                <i class="fas fa-file-alt mr-1"></i> Buka Laporan Surat Masuk
              </a>
            </div>
          </div>
        </div>

        <!-- Laporan Surat Keluar -->
        <div class="col-lg-6">
          <div class="card card-outline card-success shadow-sm">
            <div class="card-header">
              <h3 class="card-title">
                <i class="fas fa-paper-plane mr-2"></i>
                <strong>Laporan Surat Keluar</strong>
              </h3>
            </div>
            <div class="card-body">
              <p class="text-muted">
                <i class="fas fa-info-circle"></i> 
                Laporan surat keluar berdasarkan periode, kategori, dan status tanda tangan
              </p>
              <ul class="list-unstyled">
                <li><i class="fas fa-check text-success"></i> Filter berdasarkan tanggal</li>
                <li><i class="fas fa-check text-success"></i> Filter berdasarkan kategori</li>
                <li><i class="fas fa-check text-success"></i> Filter status tanda tangan</li>
                <li><i class="fas fa-check text-success"></i> Export ke Excel</li>
                <li><i class="fas fa-check text-success"></i> Print PDF/Cetak</li>
              </ul>
            </div>
            <div class="card-footer">
              <a href="<?php echo site_url('laporan/surat_keluar'); ?>" class="btn btn-success btn-block">
                <i class="fas fa-file-alt mr-1"></i> Buka Laporan Surat Keluar
              </a>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
</div>
