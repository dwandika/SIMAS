<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Laporan Surat Masuk</title>
  <style>
    body { font-family: "Times New Roman", Arial, sans-serif; font-size: 11px; }

    /* KOP SURAT */
    .kop-container {
      width: 100%;
      margin-bottom: 8px;
    }
    .kop-table {
      width: 100%;
      border-collapse: collapse;
    }
    .kop-table td {
      vertical-align: top;
    }
    .kop-logo {
      width: 80px;
      text-align: center;
    }
    .kop-logo img {
      max-width: 70px;
      max-height: 70px;
    }
    .kop-text {
      text-align: center;
    }
    .kop-text .kampus {
      font-size: 15px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .kop-text .unit {
      font-size: 13px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .kop-text .alamat {
      font-size: 10px;
    }
    .kop-line-1 {
      border-bottom: 2px solid #000;
      margin-top: 4px;
    }
    .kop-line-2 {
      border-bottom: 1px solid #000;
      margin-top: 1px;
      margin-bottom: 10px;
    }

    h3   { margin: 0 0 5px 0; text-align:center; }
    .small { font-size: 10px; }
    table { width:100%; border-collapse: collapse; }
    th,td { border:1px solid #000; padding:4px 6px; }
    th    { background:#f0f0f0; }
  </style>
</head>
<body>

<div class="kop-container">
  <table class="kop-table">
    <tr>
      <td class="kop-logo">
        <img src="<?php echo base_url('assets/images/logo-itm.png'); ?>" alt="Logo">
      </td>
      <td class="kop-text">
        <div class="kampus">INSTITUT TEKNOLOGI MOJOSARI NGANJUK</div>
        <div class="unit">SISTEM INFORMASI PERSURATAN</div>
        <div class="alamat">
          Jl. Contoh Alamat No. 1 Nganjuk, Jawa Timur 64400<br>
          Telp. (0000) 000000 &nbsp; Email: info@itm.ac.id &nbsp; Website: www.itm.ac.id
        </div>
      </td>
      <td style="width:80px;"></td>
    </tr>
  </table>
  <div class="kop-line-1"></div>
  <div class="kop-line-2"></div>
</div>

<h3>LAPORAN SURAT MASUK</h3>
<p class="small" style="text-align:center;">
  Periode: <?php echo $dari_tgl ?: '-'; ?> s/d <?php echo $sampai_tgl ?: '-'; ?>
</p>
<br>

<table>
  <thead>
    <tr>
      <th width="4%">No</th>
      <th width="18%">No. Surat</th>
      <th>Pengirim</th>
      <th>Perihal</th>
      <th width="11%">Tgl Surat</th>
      <th width="11%">Tgl Terima</th>
      <th width="10%">Kategori</th>
      <th width="10%">Bagian</th>
    </tr>
  </thead>
  <tbody>
    <?php if(!empty($surat)): $no=1; foreach($surat as $s): ?>
    <tr>
      <td><?php echo $no++; ?></td>
      <td class="small"><?php echo $s->no_surat ?? '-'; ?></td>
      <td><?php echo $s->pengirim; ?></td>
      <td><?php echo $s->perihal; ?></td>
      <td class="small"><?php echo tgl_indo($s->tanggal_surat); ?></td>
      <td class="small"><?php echo tgl_indo($s->tanggal_terima); ?></td>
      <td class="small"><?php echo $s->nama_kategori ?? $s->kode_kategori; ?></td>
      <td class="small"><?php echo $s->nama_bagian ?? $s->kode_bagian; ?></td>
    </tr>
    <?php endforeach; else: ?>
    <tr>
      <td colspan="9" style="text-align:center;">Tidak ada data</td>
    </tr>
    <?php endif; ?>
  </tbody>
</table>

<script>window.print();</script>
</body>
</html>
