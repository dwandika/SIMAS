<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Login | SIMAS ITM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" href="<?php echo base_url('assets/images/ITM.png'); ?>">
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/ITM.png'); ?>">
  <!-- AdminLTE + Bootstrap -->
  <link rel="stylesheet" href="<?php echo base_url('assets/adminlte/plugins/fontawesome-free/css/all.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/adminlte/dist/css/adminlte.min.css'); ?>">

  <!-- Tema ITM -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/itm-theme.css'); ?>">

  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap">
</head>
<body class="login-page login-light-itm">

<div class="login-container-itm">
  <div class="login-card-light-itm">

    <div class="row no-gutters align-items-center">
      <!-- Kolom kiri: logo dan teks -->
      <div class="col-md-5 text-center border-md-right mb-3 mb-md-0 pr-md-3">
        <img src="<?php echo base_url('assets/images/logo-itm.png'); ?>" alt="ITM"
             class="mb-3" style="height:70px;">
        <h1 class="h5 mb-1 text-primary-itm">SIMAS ITM</h1>
        <p class="text-muted small mb-0">Sistem Informasi Manajemen Surat</p>
        <p class="text-muted small">Institut Teknologi Mojosari</p>
      </div>

      <!-- Kolom kanan: form -->
      <div class="col-md-7 pl-md-3">
        <?php if($this->session->flashdata('error')): ?>
          <div class="alert alert-danger py-1 px-2 small mb-3">
            <i class="fas fa-exclamation-circle mr-1"></i>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php endif; ?>

        <h2 class="h6 mb-3 font-weight-semibold text-dark">Masuk ke akun Anda</h2>

        <form action="<?php echo site_url('login'); ?>" method="post">
          <!-- CSRF token WAJIB saat csrf_protection = TRUE -->
          <input type="hidden"
                 name="<?php echo $this->security->get_csrf_token_name(); ?>"
                 value="<?php echo $this->security->get_csrf_hash(); ?>">

          <div class="form-group mb-3">
            <label class="small text-muted mb-1">Username</label>
            <div class="input-group input-group-sm">
              <div class="input-group-prepend">
                <span class="input-group-text bg-white border-right-0 text-primary-itm">
                  <i class="fas fa-user"></i>
                </span>
              </div>
              <input type="text" name="username" class="form-control border-left-0"
                     placeholder="Masukkan username" required autocomplete="off">
            </div>
          </div>

          <div class="form-group mb-2">
            <label class="small text-muted mb-1">Password</label>
            <div class="input-group input-group-sm">
              <div class="input-group-prepend">
                <span class="input-group-text bg-white border-right-0 text-primary-itm">
                  <i class="fas fa-lock"></i>
                </span>
              </div>
              <input type="password" name="password" id="password"
                     class="form-control border-left-0" placeholder="Masukkan password" required>
              <div class="input-group-append">
                <span class="input-group-text bg-white text-muted" id="togglePassword" style="cursor:pointer;">
                  <i class="fas fa-eye"></i>
                </span>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember" class="small text-muted">Ingat saya</label>
            </div>
            <span class="small text-muted"><?php echo date('d M Y'); ?></span>
          </div>

          <button type="submit" class="btn btn-primary-itm btn-block btn-sm py-2">
            Masuk
          </button>
        </form>

        <div class="mt-3 text-center text-muted small">
          &copy; <?php echo date('Y'); ?> SIMAS ITM • Unit Sistem Informasi
        </div>
      </div>
    </div>

  </div>
</div>

<script src="<?php echo base_url('assets/adminlte/plugins/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/adminlte/dist/js/adminlte.min.js'); ?>"></script>

<script>
  $('#togglePassword').on('click', function () {
    const input = $('#password');
    const type = input.attr('type') === 'password' ? 'text' : 'password';
    input.attr('type', type);
    $(this).find('i').toggleClass('fa-eye fa-eye-slash');
  });
</script>
</body>
</html>
