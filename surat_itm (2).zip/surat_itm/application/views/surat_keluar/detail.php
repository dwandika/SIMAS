<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Detail Surat Keluar</h1>
          <p class="text-muted small mb-0">Informasi lengkap surat keluar</p>
        </div>
        <a href="<?php echo site_url('surat-keluar'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-lg-8">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Informasi Surat</h3>
            </div>
            <div class="card-body">
              <table class="table table-sm table-borderless">
                <tr>
                  <td width="30%" class="text-muted small">No. Surat</td>
                  <td><strong><?php echo $surat->no_surat; ?></strong></td>
                </tr>
                <tr>
                  <td class="text-muted small">Bagian Pengirim</td>
                  <td><?php echo $surat->kode_bagian; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Kategori</td>
                  <td>
                    <span class="badge badge-info">
                      <?php echo $surat->kode_kategori; ?>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td class="text-muted small">Tujuan</td>
                  <td><?php echo $surat->tujuan; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Perihal</td>
                  <td><?php echo $surat->perihal; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Tanggal Surat</td>
                  <td><?php echo tgl_indo($surat->tanggal_surat); ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Status Pengesahan</td>
                  <td>
                    <?php if($surat->status_pengesahan == 'draft'): ?>
                      <span class="badge badge-secondary">Draft</span>
                    <?php elseif($surat->status_pengesahan == 'menunggu'): ?>
                      <span class="badge badge-warning">Menunggu Pengesahan</span>
                    <?php elseif($surat->status_pengesahan == 'ditandatangani'): ?>
                      <span class="badge badge-success">Ditandatangani</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Ditolak</span>
                    <?php endif; ?>
                  </td>
                </tr>
              </table>

              <?php if(!empty($surat->nama_file_surat)): ?>
              <hr>
              <div class="text-center">
                <p class="small text-muted mb-2">File Surat</p>
                <a href="<?php echo site_url('surat-keluar/download/'.$surat->id); ?>"
                   class="btn btn-outline-primary-itm btn-sm" target="_blank">
                  <i class="fas fa-file-download mr-1"></i> Lihat / Download File
                </a>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Jika nanti ada riwayat Pengesahan / log, bisa ditempatkan di kolom kanan -->
        <!--
        <div class="col-lg-4">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Riwayat Tanda Tangan</h3>
            </div>
            <div class="card-body">
              ...
            </div>
          </div>
        </div>
        -->

      </div>

    </div>
  </section>
</div>
