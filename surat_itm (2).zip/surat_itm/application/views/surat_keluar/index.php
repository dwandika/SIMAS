<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Surat Keluar</h1>
          <p class="text-muted small mb-0">Kelola surat keluar yang dibuat institusi</p>
        </div>
        <a href="<?php echo site_url('surat-keluar/create'); ?>" class="btn btn-primary-itm btn-sm">
          <i class="fas fa-plus mr-1"></i> Buat Surat Keluar
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <!-- Flash message -->
      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-exclamation-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
        
    <!-- Filter card -->
    <div class="card card-outline card-itm mb-3">
      <div class="card-header">
        <h3 class="card-title h6 mb-0">Filter & Pencarian Surat Keluar</h3>
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
        </div>
      </div>

      <div class="card-body py-2">
        <form method="get" action="<?php echo site_url('surat-keluar'); ?>">
          <!-- Pencarian -->
          <div class="row mb-2">
            <div class="col-md-12">
              <div class="form-group mb-2">
                <label class="small text-muted">Pencarian</label>
                <input type="text" name="search" class="form-control form-control-sm" 
                      placeholder="Cari berdasarkan no. surat, tujuan, atau perihal..."
                      value="<?php echo $this->input->get('search'); ?>">
              </div>
            </div>
          </div>

          <!-- Filter -->
          <div class="row">
            <div class="col-md-3">
              <div class="form-group mb-2">
                <label class="small text-muted">Tanggal Awal</label>
                <input type="date" name="tgl_awal" class="form-control form-control-sm"
                      value="<?php echo $this->input->get('tgl_awal'); ?>">
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group mb-2">
                <label class="small text-muted">Tanggal Akhir</label>
                <input type="date" name="tgl_akhir" class="form-control form-control-sm"
                      value="<?php echo $this->input->get('tgl_akhir'); ?>">
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group mb-2">
                <label class="small text-muted">Kategori</label>
                <select name="kategori" class="form-control form-control-sm">
                  <option value="">Semua Kategori</option>
                  <?php foreach($kategori as $k): ?>
                    <option value="<?php echo $k->kode_kategori; ?>"
                      <?php echo ($this->input->get('kategori') == $k->kode_kategori) ? 'selected' : ''; ?>>
                      <?php echo $k->kode_kategori.' - '.$k->nama_kategori; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group mb-2">
                <label class="small text-muted">Status Pengesahan</label>
                <select name="status_pengesahan" class="form-control form-control-sm">
                  <option value="">Semua Status</option>
                  <option value="draft"          <?php echo $this->input->get('status_pengesahan')=='draft'?'selected':''; ?>>Draft</option>
                  <option value="menunggu"       <?php echo $this->input->get('status_pengesahan')=='menunggu'?'selected':''; ?>>Menunggu</option>
                  <option value="ditandatangani" <?php echo $this->input->get('status_pengesahan')=='disahkan'?'selected':''; ?>>Ditandatangani</option>
                  <option value="ditolak"        <?php echo $this->input->get('status_pengesahan')=='ditolak'?'selected':''; ?>>Ditolak</option>
                </select>
              </div>
            </div>
          </div>

          <div class="row align-items-center">
            <div class="col-md-12">
              <button type="submit" class="btn btn-primary-itm btn-sm">
                <i class="fas fa-search mr-1"></i> Filter & Cari
              </button>
              <a href="<?php echo site_url('surat-keluar'); ?>" class="btn btn-light btn-sm">
                <i class="fas fa-redo mr-1"></i> Reset
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>

      <!-- Tabel surat keluar -->
      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Daftar Surat Keluar</h3>
          <div class="card-tools">
            <span class="badge badge-primary-itm">
              Total: <?php echo count($surat_keluar); ?>
            </span>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="4%">No</th>
                <th width="16%">No. Surat</th>
                <th>Tujuan</th>
                <th>Perihal</th>
                <th width="10%">Kategori</th>
                <th width="10%">Tgl Surat</th>
                <th width="11%">Status</th>
                <th width="20%">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($surat_keluar)): $no=1; foreach($surat_keluar as $s): ?>
              <tr>
                <td><?php echo $no++; ?></td>
               <td>
                  <span class="badge badge-light text-dark">
                    <?php echo $s->no_surat; ?>
                  </span>
                  <?php if(!empty($s->no_surat_asli) && $s->no_surat_asli != $s->no_surat): ?>
                    <br><small class="text-muted">Asli: <?php echo $s->no_surat_asli; ?></small>
                  <?php endif; ?>
                </td>
                <td><?php echo $s->tujuan; ?></td>
                <td><?php echo $s->perihal; ?></td>
                <td class="small"><?php echo $s->kode_kategori; ?></td>
                <td class="small"><?php echo tgl_indo($s->tanggal_surat); ?></td>
                <td>
                  <?php if($s->status_pengesahan == 'draft'): ?>
                    <span class="badge badge-secondary">Draft</span>
                  <?php elseif($s->status_pengesahan == 'menunggu'): ?>
                    <span class="badge badge-warning">Menunggu</span>
                  <?php elseif($s->status_pengesahan == 'ditandatangani'): ?>
                    <span class="badge badge-success">Ditandatangani</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Ditolak</span>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <!-- Detail -->
                    <a href="<?php echo site_url('surat-keluar/detail/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-info" title="Detail">
                      <i class="fas fa-eye"></i>
                    </a>

                    <!-- Download file jika ada -->
                    <?php if(!empty($s->nama_file_surat)): ?>
                    <a href="<?php echo site_url('surat-keluar/download/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-secondary" title="Download File" target="_blank">
                      <i class="fas fa-download"></i>
                    </a>
                    <?php endif; ?>

                    <!-- Ajukan Pengesahan (role selain pimpinan, status draft) -->
                    <?php if($s->status_pengesahan == 'draft' && $this->session->userdata('role') != 'pimpinan'): ?>
                    <a href="<?php echo site_url('surat-keluar/ajukan-Pengesahan/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-warning"
                       onclick="return confirm('Ajukan surat ini untuk ditandatangani?')"
                       title="Ajukan Pengesahan">
                      <i class="fas fa-paper-plane"></i>
                    </a>
                    <?php endif; ?>

                    <!-- Setujui Pengesahan (role pimpinan, status menunggu) -->
                    <?php if($this->session->userdata('role') == 'pimpinan' && $s->status_pengesahan == 'menunggu'): ?>
                    <a href="<?php echo site_url('surat-keluar/Pengesahan-setujui/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-success"
                       onclick="return confirm('Setujui dan tandatangani surat ini?')"
                       title="Setujui Pengesahan">
                      <i class="fas fa-check"></i>
                    </a>
                    <?php endif; ?>

                    <!-- Hapus jika belum ditandatangani -->
                    <?php if($s->status_pengesahan != 'disahkan'): ?>
                    <a href="<?php echo site_url('surat-keluar/delete/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-danger"
                       onclick="return confirm('Yakin hapus surat ini?')"
                       title="Hapus">
                      <i class="fas fa-trash"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted py-3">
                  <i class="fas fa-paper-plane fa-2x mb-2 d-block"></i>
                  Belum ada data surat keluar
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
