<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Manajemen User</h1>
          <p class="text-muted small mb-0">Kelola akun pengguna SIMAS ITM</p>
        </div>
        <a href="<?php echo site_url('users/create'); ?>" class="btn btn-primary-itm btn-sm">
          <i class="fas fa-plus mr-1"></i> Tambah User
        </a>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert"><span>&times;</span></button>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3">
          <i class="fas fa-exclamation-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
          <button type="button" class="close py-2" data-dismiss="alert"><span>&times;</span></button>
        </div>
      <?php endif; ?>

      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Daftar User</h3>
          <div class="card-tools">
            <span class="badge badge-primary-itm">Total: <?php echo count($users); ?></span>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="4%">No</th>
                <th>Nama</th>
                <th>Username</th>
                <th width="12%">Role</th>
                <th>Jabatan</th>
                <th width="10%">Bagian</th>
                <th width="8%">Status</th>
                <th width="16%">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($users)): $no=1; foreach($users as $u): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $u->nama; ?></td>
                <td><?php echo $u->username; ?></td>
                <td><?php echo ucfirst($u->role); ?></td>
                <td class="small"><?php echo $u->jabatan; ?></td>
                <td class="small"><?php echo $u->kode_bagian ?: '-'; ?></td>
                <td>
                  <?php if($u->status == '1'): ?>
                    <span class="badge badge-success">Aktif</span>
                  <?php else: ?>
                    <span class="badge badge-secondary">Nonaktif</span>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <a href="<?php echo site_url('users/edit/'.$u->id); ?>"
                       class="btn btn-xs btn-outline-info">
                      <i class="fas fa-edit"></i> Ubah
                    </a>
                    <?php if($u->id != 1): // misal admin utama tidak boleh dihapus ?>
                    <a href="<?php echo site_url('users/delete/'.$u->id); ?>"
                       class="btn btn-xs btn-outline-danger"
                       onclick="return confirm('Yakin hapus user ini?')">
                      <i class="fas fa-trash"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted py-3">
                  <i class="fas fa-users fa-2x mb-2 d-block"></i>
                  Belum ada data user
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
