<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">
            <?php echo isset($user) ? 'Edit User' : 'Tambah User'; ?>
          </h1>
          <p class="text-muted small mb-0">Pengaturan akun pengguna</p>
        </div>
        <a href="<?php echo site_url('users'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <div class="card card-outline card-itm">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">Form User</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors('<div class="alert alert-danger py-2 px-3 small">', '</div>'); ?>

          <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-danger py-2 px-3 small">
              <i class="fas fa-exclamation-circle mr-1"></i>
              <?php echo $this->session->flashdata('error'); ?>
            </div>
          <?php endif; ?>

          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                   value="<?php echo $this->security->get_csrf_hash(); ?>">

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">Username <span class="text-danger">*</span></label>
                  <input type="text" name="username"
                         class="form-control form-control-sm"
                         value="<?php echo set_value('username', isset($user)?$user->username:''); ?>"
                         <?php echo isset($user)?'readonly':''; ?> required>
                  <?php if(isset($user)): ?>
                    <small class="text-muted">Username tidak dapat diubah.</small>
                  <?php endif; ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">
                    Password <?php echo isset($user)?'<span class="text-muted">(isi jika ingin mengganti)</span>':'<span class="text-danger">*</span>'; ?>
                  </label>
                  <input type="password" name="password"
                         class="form-control form-control-sm"
                         <?php echo isset($user)?'':"required"; ?>>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">Nama Lengkap <span class="text-danger">*</span></label>
                  <input type="text" name="nama"
                         class="form-control form-control-sm"
                         required
                         value="<?php echo set_value('nama', isset($user)?$user->nama:''); ?>">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted">Role <span class="text-danger">*</span></label>
                  <select name="role" class="form-control form-control-sm" required>
                    <?php
                    $role_val = set_value('role', isset($user)?$user->role:'staf');
                    ?>
                    <option value="admin"    <?php echo $role_val=='admin'?'selected':''; ?>>Admin</option>
                    <option value="pimpinan" <?php echo $role_val=='pimpinan'?'selected':''; ?>>Pimpinan</option>
                    <option value="staf"     <?php echo $role_val=='staf'?'selected':''; ?>>Staf</option>
                  </select>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted">Bagian</label>
                  <select name="kode_bagian" class="form-control form-control-sm">
                    <option value="">-- Tidak terkait bagian --</option>
                    <?php
                    $bagian_val = set_value('kode_bagian', isset($user)?$user->kode_bagian:'');
                    foreach($bagian as $b): ?>
                      <option value="<?php echo $b->kode_bagian; ?>"
                        <?php echo $bagian_val==$b->kode_bagian?'selected':''; ?>>
                        <?php echo $b->kode_bagian.' - '.$b->nama_bagian; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted">Jabatan</label>
                  <input type="text" name="jabatan"
                         class="form-control form-control-sm"
                         value="<?php echo set_value('jabatan', isset($user)?$user->jabatan:''); ?>">
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted">Status</label><br>
                  <?php
                  $status_val = set_value('status', isset($user)?$user->status:'1');
                  ?>
                  <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="statusUser"
                           name="status" value="1"
                           <?php echo $status_val=='1'?'checked':''; ?>>
                    <label class="custom-control-label" for="statusUser">
                      Aktif
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <!-- Foto profil -->
              <div class="col-md-6">
                <div class="form-group">
                  <label class="small text-muted">Foto Profil (JPG/PNG)</label>
                  <div class="custom-file">
                    <input type="file" name="foto_profil"
                           class="custom-file-input" id="fotoProfil"
                           accept=".jpg,.jpeg,.png">
                    <label class="custom-file-label" for="fotoProfil">Pilih file...</label>
                  </div>
                  <small class="text-muted">Max 2 MB.</small>
                  <?php if(isset($user) && $user->foto_profil): ?>
                    <div class="mt-2">
                      <img src="<?php echo base_url('uploads/foto/'.$user->foto_profil); ?>"
                           alt="Foto profil" class="img-thumbnail" style="max-height:80px;">
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>

            <hr>

            <button type="submit" class="btn btn-primary-itm">
              <i class="fas fa-save mr-1"></i> Simpan
            </button>
            <a href="<?php echo site_url('users'); ?>" class="btn btn-light">Batal</a>

          </form>

        </div>
      </div>

    </div>
  </section>
</div>
