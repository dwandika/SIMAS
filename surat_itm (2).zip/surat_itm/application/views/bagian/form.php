<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">
            <?php echo isset($bagian) ? 'Edit Bagian' : 'Tambah Bagian'; ?>
          </h1>
          <p class="text-muted small mb-0">Form pengelolaan data bagian/unit</p>
        </div>
        <a href="<?php echo site_url('bagian'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <div class="card card-outline card-itm">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">Form Bagian</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors('<div class="alert alert-danger py-2 px-3 small">','</div>'); ?>

          <form method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                   value="<?php echo $this->security->get_csrf_hash(); ?>">

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">Kode Bagian <span class="text-danger">*</span></label>
                  <input type="text" name="kode_bagian"
                         class="form-control form-control-sm"
                         value="<?php echo set_value('kode_bagian', isset($bagian)?$bagian->kode_bagian:''); ?>"
                         <?php echo isset($bagian)?'readonly':''; ?> required>
                  <?php if(isset($bagian)): ?>
                    <small class="text-muted">Kode tidak dapat diubah.</small>
                  <?php endif; ?>
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <label class="small text-muted">Nama Bagian <span class="text-danger">*</span></label>
                  <input type="text" name="nama_bagian"
                         class="form-control form-control-sm" required
                         value="<?php echo set_value('nama_bagian', isset($bagian)?$bagian->nama_bagian:''); ?>">
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted d-block">Status</label>
                  <?php
                    $status_val = set_value('status', isset($bagian)?$bagian->status:'1');
                  ?>
                  <div class="custom-control custom-switch mt-1">
                    <input type="checkbox" class="custom-control-input" id="statusBagian"
                           name="status" value="1" <?php echo $status_val=='1'?'checked':''; ?>>
                    <label class="custom-control-label" for="statusBagian">Aktif</label>
                  </div>
                </div>
              </div>
            </div>

            <hr>
            <button type="submit" class="btn btn-primary-itm">
              <i class="fas fa-save mr-1"></i> Simpan
            </button>
            <a href="<?php echo site_url('bagian'); ?>" class="btn btn-light">Batal</a>

          </form>
        </div>
      </div>

    </div>
  </section>
</div>
