<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Detail Surat Masuk</h1>
          <p class="text-muted small mb-0">Informasi lengkap surat masuk</p>
        </div>
        <a href="<?php echo site_url('surat-masuk'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-lg-8">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Informasi Surat</h3>
              <div class="card-tools">
                <a href="<?php echo site_url('disposisi/tambah/'.$surat->id); ?>"
                   class="btn btn-success btn-xs">
                  <i class="fas fa-share mr-1"></i> Buat Disposisi
                </a>
              </div>
            </div>
            <div class="card-body">
              <table class="table table-sm table-borderless">
                <tr>
                  <td class="text-muted small">No. Surat</td>
                  <td> <?php echo $surat->no_surat ?: '-'; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Pengirim</td>
                  <td><?php echo $surat->pengirim; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Perihal</td>
                  <td><?php echo $surat->perihal; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Kategori</td>
                  <td>
                    <span class="badge badge-info">
                      <?php echo $surat->kode_kategori; ?>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td class="text-muted small">Bagian Penerima</td>
                  <td><?php echo $surat->kode_bagian; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Tanggal Surat</td>
                  <td><?php echo $surat->tanggal_surat ? tgl_indo($surat->tanggal_surat) : '-'; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Tanggal Diterima</td>
                  <td><?php echo tgl_indo($surat->tanggal_terima); ?></td>
                </tr>
              </table>

              <?php if(!empty($surat->nama_file_scan)): ?>
              <hr>
              <div class="text-center">
                <p class="small text-muted mb-2">File Surat</p>
                <a href="<?php echo site_url('surat-masuk/download/'.$surat->id); ?>"
                   class="btn btn-outline-primary-itm btn-sm" target="_blank">
                  <i class="fas fa-file-pdf mr-1"></i> Lihat / Download File
                </a>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Riwayat Disposisi</h3>
            </div>
            <div class="card-body">
              <?php if(isset($disposisi) && !empty($disposisi)): ?>
                <ul class="list-unstyled small mb-0">
                  <?php foreach($disposisi as $d): ?>
                  <li class="mb-2">
                    <div class="d-flex justify-content-between">
                      <span class="text-muted"><?php echo tgl_indo($d->tanggal); ?></span>
                      <span class="badge badge-<?php echo ($d->status ?? '') == 'selesai' ? 'success' : 'warning'; ?>">
                        <?php echo ucfirst($d->status ?? 'proses'); ?>
                      </span>
                    </div>
                    <div><?php echo $d->dari; ?> → <?php echo $d->kepada; ?></div>
                    <div class="text-muted"><?php echo $d->instruksi; ?></div>
                  </li>
                  <?php endforeach; ?>
                </ul>
              <?php else: ?>
                <p class="text-muted small text-center mb-0">
                  Belum ada disposisi untuk surat ini
                </p>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
              <?php if(!empty($surat->nama_file_surat)): ?>
              <hr>
              <div class="text-center">
                <p class="small text-muted mb-2">File Surat</p>
                <a href="<?php echo site_url('surat-keluar/download/'.$surat->id); ?>"
                   class="btn btn-outline-primary-itm btn-sm" target="_blank">
                  <i class="fas fa-file-download mr-1"></i> Lihat / Download File
                </a>
              </div>
              <?php endif; ?>
    </div>
  </section>
</div>
