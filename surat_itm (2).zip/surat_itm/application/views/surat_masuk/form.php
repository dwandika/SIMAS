<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Input Surat Masuk</h1>
          <p class="text-muted small mb-0">Upload file dan sistem akan mengisi data otomatis</p>
        </div>
        <a href="<?php echo site_url('surat-masuk'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <!-- Alert Messages -->
      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('warning')): ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <i class="fas fa-exclamation-triangle mr-1"></i>
          <?php echo $this->session->flashdata('warning'); ?>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <i class="fas fa-times-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
        </div>
      <?php endif; ?>

      <?php echo validation_errors('<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>', '</div>'); ?>

      <!-- Card Upload PERTAMA -->
      <?php if(empty($uploaded_file)): ?>
      <div class="card card-outline card-primary mb-3">
        <div class="card-header bg-primary">
          <h3 class="card-title text-white">
            <i class="fas fa-file-upload mr-2"></i> Langkah 1: Upload File Surat
          </h3>
        </div>
        <div class="card-body">
          
          <form method="post" enctype="multipart/form-data" action="<?php echo site_url('surat-masuk/upload_extract'); ?>">
            
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                   value="<?php echo $this->security->get_csrf_hash(); ?>">

            <div class="alert alert-info py-2">
              <i class="fas fa-info-circle mr-1"></i>
              Upload file surat (PDF/Word/Foto) dan sistem akan <strong>otomatis mengisi form</strong> dari data yang terdeteksi.
            </div>

            <div class="form-group">
              <label class="font-weight-bold">Pilih File Surat <span class="text-danger">*</span></label>
              <div class="custom-file">
                <input type="file" 
                       class="custom-file-input" 
                       id="fileSurat" 
                       name="file_surat"
                       accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                       required>
                <label class="custom-file-label" for="fileSurat">Pilih file...</label>
              </div>
              <small class="form-text text-muted">
                <strong>Format:</strong> PDF, Word (DOC/DOCX), Foto (JPG/PNG) | <strong>Max:</strong> 10 MB
              </small>
            </div>

            <button type="submit" class="btn btn-primary btn-lg btn-block">
              <i class="fas fa-upload mr-2"></i> Upload & Ekstrak Data Otomatis
            </button>

          </form>

        </div>
      </div>
      <?php endif; ?>

      <!-- Form Data Surat -->
      <form method="post" action="<?php echo site_url('surat-masuk/create'); ?>">
        
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
               value="<?php echo $this->security->get_csrf_hash(); ?>">
        
        <input type="hidden" name="uploaded_file_name" value="<?php echo $uploaded_file; ?>">

        <div class="card card-outline card-success">
          <div class="card-header <?php echo $uploaded_file ? 'bg-success' : ''; ?>">
            <h3 class="card-title <?php echo $uploaded_file ? 'text-white' : ''; ?>">
              <i class="fas fa-edit mr-2"></i> 
              <?php echo $uploaded_file ? 'Langkah 2: Periksa & Simpan Data' : 'Data Surat Masuk'; ?>
            </h3>
            <?php if($uploaded_file): ?>
            <div class="card-tools">
              <span class="badge badge-light">
                <i class="fas fa-file mr-1"></i> <?php echo $uploaded_file; ?>
              </span>
            </div>
            <?php endif; ?>
          </div>
          <div class="card-body">

            <?php if($uploaded_file && $extracted): ?>
            <div class="alert alert-success py-2">
              <i class="fas fa-robot mr-1"></i>
              <strong>Data berhasil diekstrak!</strong> Periksa data di bawah dan koreksi jika ada yang salah. 
              Field yang terisi otomatis ditandai dengan <i class="fas fa-check-circle text-success"></i>
            </div>
            <?php endif; ?>

          <div class="row">
            
            <!-- Nomor Surat Manual (Opsional) -->
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Nomor Surat Manual (Opsional)
                  <?php if(!empty($extracted['no_surat_asli'])): ?>
                    <i class="fas fa-check-circle text-success" title="Terisi otomatis dari OCR"></i>
                  <?php endif; ?>
                </label>
                <input type="text" 
                      name="no_surat_manual" 
                      id="noSuratManual"
                      class="form-control <?php echo !empty($extracted['no_surat_asli']) ? 'border-success' : ''; ?>"
                      placeholder="Contoh: 04.60/ITM/X/2025"
                      value="<?php echo set_value('no_surat_manual', $extracted['no_surat_asli'] ?? ''); ?>">
                <small class="text-muted">
                  <i class="fas fa-info-circle"></i> 
                  Kosongkan jika ingin nomor otomatis dari sistem
                </small>
              </div>
            </div>

            <!-- Tanggal Surat -->
            <div class="col-md-4">
              <div class="form-group">
                <label>
                  Tanggal Surat
                  <?php if(!empty($extracted['tanggal_surat'])): ?>
                    <i class="fas fa-check-circle text-success" title="Terisi otomatis dari OCR"></i>
                  <?php endif; ?>
                </label>
                <input type="date" 
                      name="tanggal_surat" 
                      id="tanggalSurat"
                      class="form-control <?php echo !empty($extracted['tanggal_surat']) ? 'border-success' : ''; ?>"
                      value="<?php echo set_value('tanggal_surat', $extracted['tanggal_surat'] ?? date('Y-m-d')); ?>">
                <small class="text-muted">Tanggal pada surat asli</small>
              </div>
            </div>

            <!-- Tanggal Terima -->
            <div class="col-md-4">
              <div class="form-group">
                <label>Tanggal Terima <span class="text-danger">*</span></label>
                <input type="date" 
                      name="tanggal_terima" 
                      class="form-control"
                      required
                      value="<?php echo set_value('tanggal_terima', date('Y-m-d')); ?>">
                <small class="text-muted">Tanggal surat diterima</small>
              </div>
            </div>

          </div>


            <div class="row">
              
              <!-- Bagian -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>Bagian Tujuan <span class="text-danger">*</span></label>
                  <select name="kode_bagian" class="form-control" required>
                    <option value="">-- Pilih Bagian --</option>
                    <?php foreach($bagian as $b): ?>
                      <option value="<?php echo $b->kode_bagian; ?>"
                        <?php echo set_select('kode_bagian', $b->kode_bagian); ?>>
                        <?php echo $b->kode_bagian.' - '.$b->nama_bagian; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <small class="text-muted">Wajib diisi</small>
                </div>
              </div>

              <!-- Kategori -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>Kategori <span class="text-danger">*</span></label>
                  <select name="kode_kategori" class="form-control" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach($kategori as $k): ?>
                      <option value="<?php echo $k->kode_kategori; ?>"
                        <?php echo set_select('kode_kategori', $k->kode_kategori); ?>>
                        <?php echo $k->kode_kategori.' - '.$k->nama_kategori; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <small class="text-muted">Wajib diisi</small>
                </div>
              </div>

            </div>

            <!-- Pengirim -->
            <div class="form-group">
              <label>
                Pengirim
                <?php if(!empty($extracted['pengirim'])): ?>
                  <i class="fas fa-check-circle text-success" title="Terisi otomatis dari OCR"></i>
                <?php endif; ?>
              </label>
              <input type="text" 
                     name="pengirim" 
                     class="form-control <?php echo !empty($extracted['pengirim']) ? 'border-success' : ''; ?>"
                     placeholder="Nama instansi/orang pengirim"
                     value="<?php echo set_value('pengirim', $extracted['pengirim'] ?? ''); ?>">
              <small class="text-muted">Opsional - bisa diisi manual</small>
            </div>

            <!-- Perihal -->
            <div class="form-group">
              <label>
                Perihal
                <?php if(!empty($extracted['perihal'])): ?>
                  <i class="fas fa-check-circle text-success" title="Terisi otomatis dari OCR"></i>
                <?php endif; ?>
              </label>
              <textarea name="perihal" 
                        rows="3"
                        class="form-control <?php echo !empty($extracted['perihal']) ? 'border-success' : ''; ?>"
                        placeholder="Perihal/isi singkat surat"><?php echo set_value('perihal', $extracted['perihal'] ?? ''); ?></textarea>
              <small class="text-muted">Opsional - bisa diisi manual</small>
            </div>

            <?php if($extracted): ?>
            <div class="alert alert-info py-2">
              <i class="fas fa-chart-line mr-1"></i>
              <strong>Akurasi Ekstraksi:</strong> <?php echo $extracted['confidence']; ?>%
              <?php if($extracted['confidence'] < 70): ?>
                - <span class="text-warning">Silakan periksa dan koreksi data yang terisi</span>
              <?php endif; ?>
            </div>
            <?php endif; ?>

            <hr>

            <button type="submit" class="btn btn-success btn-lg">
              <i class="fas fa-save mr-2"></i> Simpan Surat Masuk
            </button>
            
            <a href="<?php echo site_url('surat-masuk'); ?>" class="btn btn-secondary btn-lg">
              <i class="fas fa-times mr-2"></i> Batal
            </a>

          </div>
        </div>

      </form>

    </div>
  </section>
</div>

<!-- JavaScript -->
<script>
$(document).ready(function() {
    // Update label custom file input
    $('#fileSurat').on('change', function() {
        var fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').html(fileName || 'Pilih file...');
    });
});
</script>

<style>
.border-success {
    border-color: #28a745 !important;
    box-shadow: 0 0 0 0.1rem rgba(40, 167, 69, 0.25);
}
</style>
