<div class="content-wrapper">
  
  <!-- Content Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Surat Masuk</h1>
          <p class="text-muted small mb-0">Kelola surat masuk yang diterima institusi</p>
        </div>
        <a href="<?php echo site_url('surat-masuk/create'); ?>" class="btn btn-primary-itm btn-sm">
          <i class="fas fa-plus mr-1"></i> Tambah Surat Masuk
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <!-- Flash message -->
      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-exclamation-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <!-- Filter card -->
            <div class="card card-outline card-primary-itm mb-3">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">Filter & Cari Surat Masuk</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body py-2">
          <form method="get" action="<?php echo site_url('surat-masuk'); ?>">
            <div class="row">
              <!-- Search Field -->
              <div class="col-md-4">
                <div class="form-group mb-2">
                  <label class="small text-muted">Cari Surat</label>
                  <input type="text" class="form-control form-control-sm" name="search" placeholder="Cari Surat Masuk..." value="<?php echo isset($filter['search']) ? $filter['search'] : ''; ?>">
                </div>
              </div>

              <!-- Date Filter: Tanggal Awal -->
              <div class="col-md-2">
                <div class="form-group mb-2">
                  <label class="small text-muted">Tanggal Awal</label>
                  <input type="date" name="tgl_awal" class="form-control form-control-sm"
                         value="<?php echo isset($filter['tgl_awal']) ? $filter['tgl_awal'] : ''; ?>">
                </div>
              </div>

              <!-- Date Filter: Tanggal Akhir -->
              <div class="col-md-2">
                <div class="form-group mb-2">
                  <label class="small text-muted">Tanggal Akhir</label>
                  <input type="date" name="tgl_akhir" class="form-control form-control-sm"
                         value="<?php echo isset($filter['tgl_akhir']) ? $filter['tgl_akhir'] : ''; ?>">
                </div>
              </div>

              <!-- Kategori Filter -->
              <div class="col-md-2">
                <div class="form-group mb-2">
                  <label class="small text-muted">Kategori</label>
                  <select name="kategori" class="form-control form-control-sm">
                    <option value="">Semua Kategori</option>
                    <?php foreach($kategori as $k): ?>
                      <option value="<?php echo $k->kode_kategori; ?>"
                        <?php echo ($filter['kategori'] == $k->kode_kategori) ? 'selected' : ''; ?>>
                        <?php echo $k->kode_kategori.' - '.$k->nama_kategori; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <!-- Bagian Filter -->
              <div class="col-md-2">
                <div class="form-group mb-2">
                  <label class="small text-muted">Bagian</label>
                  <select name="bagian" class="form-control form-control-sm">
                    <option value="">Semua Bagian</option>
                    <?php foreach($bagian as $b): ?>
                      <option value="<?php echo $b->kode_bagian; ?>"
                        <?php echo ($filter['bagian'] == $b->kode_bagian) ? 'selected' : ''; ?>>
                        <?php echo $b->kode_bagian.' - '.$b->nama_bagian; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
            </div>

            <div class="row align-items-center">
              <div class="col-md-12">
                <button type="submit" class="btn btn-primary-itm btn-sm">
                  <i class="fas fa-search mr-1"></i> Filter & Cari
                </button>
                <a href="<?php echo site_url('surat-masuk'); ?>" class="btn btn-light btn-sm">
                  Reset
                </a>
              </div>
            </div>
          </form>
        </div>
      </div>

      <!-- Tabel surat masuk -->
      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Daftar Surat Masuk</h3>
          <div class="card-tools">
            <span class="badge badge-primary-itm">
              Total: <?php echo count($surat_masuk); ?>
            </span>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="4%">No</th>
                <th width="16%">No. Surat</th>
                <th>Pengirim</th>
                <th>Perihal</th>
                <th width="10%">Kategori</th>
                <th width="10%">Tgl Terima</th>
                <th width="11%">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($surat_masuk)): $no=1; foreach($surat_masuk as $s): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td>
                  <span class="badge badge-light text-dark">
                    <?php echo $s->no_surat; ?>
                  </span>
                </td>
                <td><?php echo $s->pengirim; ?></td>
                <td><?php echo $s->perihal; ?></td>
                <td class="small"><?php echo $s->kode_kategori; ?></td>
                <td class="small"><?php echo tgl_indo($s->tanggal_terima); ?></td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <a href="<?php echo site_url('surat-masuk/detail/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-info" title="Detail">
                      <i class="fas fa-eye"></i>
                    </a>
                    <?php if(!empty($s->nama_file_surat)): ?>
                    <a href="<?php echo site_url('surat-masuk/download/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-secondary" title="Download" target="_blank">
                      <i class="fas fa-download"></i>
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo site_url('surat-masuk/delete/'.$s->id); ?>"
                       class="btn btn-xs btn-outline-danger"
                       onclick="return confirm('Yakin hapus surat ini?')"
                       title="Hapus">
                      <i class="fas fa-trash"></i>
                    </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted py-3">
                  <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                  Belum ada data surat masuk
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
