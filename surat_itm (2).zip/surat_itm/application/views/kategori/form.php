<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">
            <?php echo isset($kategori_row) ? 'Edit Jenis Surat' : 'Tambah Jenis Surat'; ?>
          </h1>
          <p class="text-muted small mb-0">Atur jenis/kategori surat yang digunakan dalam SIMAS ITM</p>
        </div>
        <a href="<?php echo site_url('kategori'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <div class="card card-outline card-itm">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">
            <?php echo isset($kategori_row) ? 'Form Edit Jenis Surat' : 'Form Tambah Jenis Surat'; ?>
          </h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors('<div class="alert alert-danger py-2 px-3 small">', '</div>'); ?>

          <form method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                   value="<?php echo $this->security->get_csrf_hash(); ?>">

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">Kode Jenis Surat <span class="text-danger">*</span></label>
                  <input type="text" name="kode_kategori" class="form-control form-control-sm"
                         placeholder="Contoh: SK, UND, PER"
                         value="<?php echo set_value('kode_kategori', isset($kategori_row) ? $kategori_row->kode_kategori : ''); ?>"
                         <?php echo isset($kategori_row) ? 'readonly' : 'required'; ?>>
                  <?php if(isset($kategori_row)): ?>
                    <small class="text-muted">Kode tidak dapat diubah</small>
                  <?php endif; ?>
                </div>
              </div>

              <div class="col-md-8">
                <div class="form-group">
                  <label class="small text-muted">Nama Jenis Surat <span class="text-danger">*</span></label>
                  <input type="text" name="nama_kategori" class="form-control form-control-sm"
                         placeholder="Contoh: Surat Keputusan, Surat Undangan"
                         value="<?php echo set_value('nama_kategori', isset($kategori_row) ? $kategori_row->nama_kategori : ''); ?>"
                         required>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label class="small text-muted">Status</label>
              <div class="d-flex small">
                <div class="form-check mr-3">
                  <input class="form-check-input" type="radio" name="status" id="statusAktif" value="1"
                    <?php echo set_radio('status','1', !isset($kategori_row) || (isset($kategori_row) && $kategori_row->status=='1')); ?>>
                  <label class="form-check-label" for="statusAktif">Aktif</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="status" id="statusNon" value="0"
                    <?php echo set_radio('status','0', isset($kategori_row) && $kategori_row->status=='0'); ?>>
                  <label class="form-check-label" for="statusNon">Nonaktif</label>
                </div>
              </div>
            </div>

            <hr class="my-3">

            <button type="submit" class="btn btn-primary-itm">
              <i class="fas fa-save mr-1"></i>
              <?php echo isset($kategori_row) ? 'Update Jenis Surat' : 'Simpan Jenis Surat'; ?>
            </button>
            <a href="<?php echo site_url('kategori'); ?>" class="btn btn-light">
              Batal
            </a>
          </form>

        </div>
      </div>

    </div>
  </section>
</div>
