<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Master Jenis Surat</h1>
          <p class="text-muted small mb-0">Daftar jenis/kategori surat di SIMAS ITM</p>
        </div>
        <a href="<?php echo site_url('kategori/tambah'); ?>" class="btn btn-primary-itm btn-sm">
          <i class="fas fa-plus mr-1"></i> Tambah Jenis Surat
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3" role="alert">
          <i class="fas fa-exclamation-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
          <button type="button" class="close py-2" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>

      <!-- Tabel kategori -->
      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Daftar Jenis Surat</h3>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="6%">No</th>
                <th width="16%">Kode Jenis</th>
                <th>Nama Jenis Surat</th>
                <th width="12%">Status</th>
                <th width="14%">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($kategori)): $no=1; foreach($kategori as $k): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td><span class="badge badge-light text-dark"><?php echo $k->kode_kategori; ?></span></td>
                <td><?php echo $k->nama_kategori; ?></td>
                <td>
                  <?php if($k->status == '1'): ?>
                    <span class="badge badge-success">Aktif</span>
                  <?php else: ?>
                    <span class="badge badge-secondary">Nonaktif</span>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <a href="<?php echo site_url('kategori/edit/'.$k->kode_kategori); ?>"
                       class="btn btn-xs btn-outline-primary" title="Edit">
                      <i class="fas fa-edit"></i>
                    </a>
                    <a href="<?php echo site_url('kategori/delete/'.$k->kode_kategori); ?>"
                       class="btn btn-xs btn-outline-danger"
                       onclick="return confirm('Yakin hapus jenis surat ini?')" title="Hapus">
                      <i class="fas fa-trash"></i>
                    </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="5" class="text-center text-muted py-3">
                  <i class="fas fa-tags fa-2x mb-2 d-block"></i>
                  Belum ada data jenis surat
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
