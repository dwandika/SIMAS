  <!-- Main Footer -->
  <footer class="main-footer text-sm">
    <strong>&copy; <?php echo date('Y'); ?> SIMAS.</strong>
    <span class="d-none d-sm-inline">.</span>
    <div class="float-right d-none d-sm-inline-block">
      <b>Versi</b> 1.0
    </div>
  </footer>
</div> <!-- ./wrapper -->

<!-- jQuery, Bootstrap, AdminLTE -->
<script src="<?php echo base_url('assets/adminlte/plugins/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/adminlte/dist/js/adminlte.min.js'); ?>"></script>

<!-- SweetAlert2 -->
<script src="<?php echo base_url('assets/adminlte/plugins/sweetalert2/sweetalert2.min.js'); ?>"></script>

<!-- Toastr -->
<script src="<?php echo base_url('assets/adminlte/plugins/toastr/toastr.min.js'); ?>"></script>

<!-- External JS -->
<script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

</body>
</html>
