<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-itm elevation-3">
  <!-- Brand Logo -->
  <a href="<?php echo site_url('dashboard'); ?>" class="brand-link text-center">
    <img src="<?php echo base_url('assets/images/logo-itm.png'); ?>"
         alt="ITM Logo" class="brand-image" style="opacity:.9">
    <span class="brand-text font-weight-light">SIMAS ITM</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">

    <!-- Sidebar Menu -->
    <nav class="mt-3">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">

        <!-- DASHBOARD -->
        <li class="nav-item">
          <a href="<?php echo site_url('dashboard'); ?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <!-- PERSURATAN -->
        <li class="nav-header">PERSURATAN</li>

        <li class="nav-item">
          <a href="<?php echo site_url('surat-masuk'); ?>" class="nav-link">
            <i class="nav-icon fas fa-inbox"></i>
            <p>Surat Masuk</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo site_url('surat-keluar'); ?>" class="nav-link">
            <i class="nav-icon fas fa-paper-plane"></i>
            <p>Surat Keluar</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo site_url('disposisi'); ?>" class="nav-link">
            <i class="nav-icon fas fa-share-square"></i>
            <p>Disposisi</p>
          </a>
        </li>

        <!-- MASTER DATA: HANYA ADMIN -->
        <?php if ($this->session->userdata('role') == 'admin'): ?>
        <li class="nav-header">MASTER DATA</li>

        <li class="nav-item">
          <a href="<?php echo site_url('users'); ?>" class="nav-link">
            <i class="nav-icon fas fa-users-cog"></i>
            <p>User</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo site_url('bagian'); ?>" class="nav-link">
            <i class="nav-icon fas fa-building"></i>
            <p>Bagian</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo site_url('kategori'); ?>" class="nav-link">
            <i class="nav-icon fas fa-tags"></i>
            <p>Jenis Surat</p>
          </a>
        </li>
        <?php endif; ?>

        <!-- LAPORAN -->
        <li class="nav-header">LAPORAN</li>

        <li class="nav-item">
          <a href="<?php echo site_url('laporan/surat-masuk'); ?>" class="nav-link">
            <i class="nav-icon fas fa-file-import"></i>
            <p>Laporan Surat Masuk</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo site_url('laporan/surat-keluar'); ?>" class="nav-link">
            <i class="nav-icon fas fa-file-export"></i>
            <p>Laporan Surat Keluar</p>
          </a>
        </li>

      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
