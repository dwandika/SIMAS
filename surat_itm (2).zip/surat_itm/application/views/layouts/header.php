<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title><?php echo isset($title) ? $title.' | ' : ''; ?>SIMAS ITM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & AdminLTE core CSS -->
  <link rel="stylesheet" href="<?php echo base_url('assets/adminlte/plugins/fontawesome-free/css/all.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/adminlte/plugins/icheck-bootstrap/icheck-bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/adminlte/dist/css/adminlte.min.css'); ?>">
  <link rel="icon" type="image/png" href="<?php echo base_url('assets/images/ITM.png'); ?>">
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/ITM.png'); ?>">

  <!-- External CSS theme ITM -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/itm-theme.css'); ?>">
  <!-- SweetAlert2 -->
  <script src="<?php echo base_url('assets/adminlte/plugins/sweetalert2/sweetalert2.min.js'); ?>"></script>
  <!-- Google Font: Source Sans Pro (opsional) -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
