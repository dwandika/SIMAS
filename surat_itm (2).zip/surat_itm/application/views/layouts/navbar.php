<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-itm navbar-dark border-bottom-0">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button">
        <i class="fas fa-bars"></i>
      </a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="<?php echo site_url('dashboard'); ?>" class="nav-link">Dashboard</a>
    </li>
  </ul>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item dropdown">
      <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fa-user-circle mr-1"></i>
        <?php echo $this->session->userdata('nama'); ?>
      </a>
      <div class="dropdown-menu dropdown-menu-right">
        <span class="dropdown-item-text text-muted small">
          <?php echo ucfirst($this->session->userdata('role')); ?> -
          <?php echo $this->session->userdata('jabatan'); ?>
        </span>
        <div class="dropdown-divider"></div>

        <!-- LINK PROFIL -->
        <a href="<?php echo site_url('Profil'); ?>" class="dropdown-item">
          <i class="fas fa-user mr-2"></i> Profil Saya
        </a>

        <div class="dropdown-divider"></div>
        <a href="<?php echo site_url('logout'); ?>" class="dropdown-item text-danger">
          <i class="fas fa-sign-out-alt mr-2"></i> Logout
        </a>
      </div>
    </li>
  </ul>
</nav>
<!-- /.navbar -->
