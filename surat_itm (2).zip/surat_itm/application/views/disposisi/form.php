<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Disposisi Surat Masuk</h1>
          <p class="text-muted small mb-0">
            Surat: <strong><?php echo $surat->no_surat_auto ?? '-'; ?></strong> •
            <?php echo $surat->pengirim; ?>
          </p>
        </div>
        <a href="<?php echo site_url('surat-masuk/detail/'.$surat->id); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <!-- Main -->
  <section class="content">
    <div class="container-fluid">

      <div class="card card-outline card-itm">
        <div class="card-header">
          <h3 class="card-title h6 mb-0">Form Disposisi</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors('<div class="alert alert-danger py-2 px-3 small">', '</div>'); ?>

          <form method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                   value="<?php echo $this->security->get_csrf_hash(); ?>">

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label class="small text-muted">
                    Tanggal Disposisi <span class="text-danger">*</span>
                  </label>
                  <input type="date" name="tanggal"
                         class="form-control form-control-sm"
                         required
                         value="<?php echo set_value('tanggal', date('Y-m-d')); ?>">
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <label class="small text-muted">
                    Dari <span class="text-danger">*</span>
                  </label>
                  <input type="text" name="dari"
                         class="form-control form-control-sm"
                         required
                         value="<?php echo set_value('dari', $this->session->userdata('nama')); ?>"
                         placeholder="Nama pejabat / unit pemberi disposisi">
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <label class="small text-muted">
                    Kepada <span class="text-danger">*</span>
                  </label>
                  <input type="text" name="kepada"
                         class="form-control form-control-sm"
                         required
                         value="<?php echo set_value('kepada'); ?>"
                         placeholder="Nama pejabat / unit tujuan disposisi">
                </div>
              </div>
            </div>

            <div class="form-group">
              <label class="small text-muted">
                Instruksi / Arahan <span class="text-danger">*</span>
              </label>
              <textarea name="instruksi" rows="2"
                        class="form-control form-control-sm"
                        required
                        placeholder="Isi instruksi disposisi"><?php echo set_value('instruksi'); ?></textarea>
            </div>

            <div class="form-group">
              <label class="small text-muted">
                Keterangan Tambahan
              </label>
              <textarea name="keterangan" rows="2"
                        class="form-control form-control-sm"
                        placeholder="Catatan tambahan (opsional)"><?php echo set_value('keterangan'); ?></textarea>
            </div>

            <hr>

            <button type="submit" class="btn btn-primary-itm">
              <i class="fas fa-save mr-1"></i> Simpan
            </button>
            <a href="<?php echo site_url('surat-masuk/detail/'.$surat->id); ?>" class="btn btn-light">
              Batal
            </a>
          </form>

        </div>
      </div>

    </div>
  </section>
</div>
