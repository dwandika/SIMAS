<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <h1 class="h4 mb-0">Disposisi Surat</h1>
      <p class="text-muted small mb-0">Daftar seluruh disposisi surat masuk</p>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert"><span>&times;</span></button>
        </div>
      <?php endif; ?>

      <div class="card card-outline card-itm">
        <div class="card-header border-0">
          <h3 class="card-title h6 mb-0">Daftar Disposisi</h3>
          <div class="card-tools">
            <span class="badge badge-primary-itm">Total: <?php echo count($disposisi); ?></span>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover table-sm mb-0">
            <thead class="thead-light-itm">
              <tr>
                <th width="4%">No</th>
                <th width="10%">Tanggal</th>
                <th>Dari</th>
                <th>Kepada</th>
                <th>Instruksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($disposisi)): $no=1; foreach($disposisi as $d): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td class="small"><?php echo tgl_indo($d->tanggal); ?></td>
                <td><?php echo $d->dari; ?></td>
                <td><?php echo $d->kepada; ?></td>
                <td class="small"><?php echo $d->instruksi; ?></td>
              </tr>
              <?php endforeach; else: ?>
              <tr>
                <td colspan="5" class="text-center text-muted py-3">
                  <i class="fas fa-share-square fa-2x mb-2 d-block"></i>
                  Belum ada data disposisi
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>
