<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Detail Disposisi</h1>
          <p class="text-muted small mb-0">
            Surat Masuk: <strong><?php echo $disp->id_suratmasuk; ?></strong>
          </p>
        </div>
        <a href="<?php echo site_url('disposisi'); ?>" class="btn btn-light btn-sm">
          <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-lg-7">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Informasi Disposisi</h3>
            </div>
            <div class="card-body">
              <table class="table table-sm table-borderless mb-0">
                <tr>
                  <td width="30%" class="text-muted small">ID Surat Masuk</td>
                  <td><strong><?php echo $disp->id_suratmasuk; ?></strong></td>
                </tr>
                <tr>
                  <td class="text-muted small">Dari Bagian</td>
                  <td><?php echo $disp->dari_nama; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Kepada Bagian</td>
                  <td><?php echo $disp->kepada_nama; ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Tgl Disposisi</td>
                  <td><?php echo tgl_indo($disp->tgl_disposisi); ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Prioritas</td>
                  <td><?php echo ucfirst($disp->prioritas ?? 'biasa'); ?></td>
                </tr>
                <tr>
                  <td class="text-muted small">Status</td>
                  <td>
                    <?php if($disp->status == 'baru'): ?>
                      <span class="badge badge-info">Baru</span>
                    <?php elseif($disp->status == 'proses'): ?>
                      <span class="badge badge-warning">Proses</span>
                    <?php else: ?>
                      <span class="badge badge-success">Selesai</span>
                    <?php endif; ?>
                  </td>
                </tr>
              </table>

              <hr>

              <p class="text-muted small mb-1">Instruksi / Tindak Lanjut</p>
              <p class="mb-0"><?php echo nl2br($disp->instruksi); ?></p>
            </div>
          </div>
        </div>

        <div class="col-lg-5">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Aksi Status</h3>
            </div>
            <div class="card-body">
              <p class="small text-muted">
                Ubah status disposisi sesuai progres tindak lanjut pada bagian Anda.
              </p>
              <div class="btn-group btn-group-sm">
                <a href="<?php echo site_url('disposisi/ubah_status/'.$disp->id.'/baru'); ?>"
                   class="btn btn-outline-secondary">Baru</a>
                <a href="<?php echo site_url('disposisi/ubah_status/'.$disp->id.'/proses'); ?>"
                   class="btn btn-outline-warning">Proses</a>
                <a href="<?php echo site_url('disposisi/ubah_status/'.$disp->id.'/selesai'); ?>"
                   class="btn btn-outline-success"
                   onclick="return confirm('Tandai disposisi ini sudah selesai?')">Selesai</a>
              </div>

              <?php if(!empty($disp->tgl_selesai)): ?>
              <hr>
              <p class="small text-muted mb-1">Tanggal Selesai</p>
              <p class="mb-0"><?php echo $disp->tgl_selesai; ?></p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
</div>
