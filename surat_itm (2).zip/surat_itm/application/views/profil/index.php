<!-- application/views/profil/index.php -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="h4 mb-0">Profil Saya</h1>
          <p class="text-muted small mb-0">Pengaturan akun pribadi</p>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3">
          <i class="fas fa-check-circle mr-1"></i>
          <?php echo $this->session->flashdata('success'); ?>
          <button type="button" class="close py-2" data-dismiss="alert"><span>&times;</span></button>
        </div>
      <?php endif; ?>

      <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3">
          <i class="fas fa-exclamation-circle mr-1"></i>
          <?php echo $this->session->flashdata('error'); ?>
          <button type="button" class="close py-2" data-dismiss="alert"><span>&times;</span></button>
        </div>
      <?php endif; ?>

      <div class="row">
        <div class="col-lg-4">
          <div class="card card-outline card-itm">
            <div class="card-body text-center">
              <?php
                $foto = $user->foto_profil
                        ? base_url('uploads/foto/'.$user->foto_profil)
                        : base_url('assets/images/default-user.png'); // default foto
              ?>
              <img src="<?php echo $foto; ?>" class="img-circle elevation-2 mb-2"
                   alt="Foto Profil" style="width:110px;height:110px;object-fit:cover;">
              <h5 class="mb-0"><?php echo $user->nama; ?></h5>
              <p class="text-muted small mb-1">
                <?php echo ucfirst($user->role); ?><?php echo $user->jabatan ? ' - '.$user->jabatan : ''; ?>
              </p>
              <p class="text-muted small mb-0">
                <?php echo $user->kode_bagian ?: '-'; ?>
              </p>
            </div>
          </div>
        </div>

        <div class="col-lg-8">
          <div class="card card-outline card-itm">
            <div class="card-header">
              <h3 class="card-title h6 mb-0">Ubah Profil</h3>
            </div>
            <div class="card-body">
              <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                       value="<?php echo $this->security->get_csrf_hash(); ?>">

                <div class="form-group">
                  <label class="small text-muted">Username</label>
                  <input type="text" class="form-control form-control-sm"
                         value="<?php echo $user->username; ?>" readonly>
                </div>

                <div class="form-group">
                  <label class="small text-muted">
                    Password Baru <span class="text-muted">(kosongkan jika tidak diganti)</span>
                  </label>
                  <input type="password" name="password" class="form-control form-control-sm">
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="small text-muted">Nama Lengkap</label>
                      <input type="text" name="nama" class="form-control form-control-sm" required
                             value="<?php echo $user->nama; ?>">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="small text-muted">Jabatan</label>
                      <input type="text" name="jabatan" class="form-control form-control-sm"
                             value="<?php echo $user->jabatan; ?>">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="small text-muted">Bagian</label>
                  <select name="kode_bagian" class="form-control form-control-sm">
                    <option value="">-- Tidak terkait bagian --</option>
                    <?php foreach($bagian as $b): ?>
                      <option value="<?php echo $b->kode_bagian; ?>"
                        <?php echo ($user->kode_bagian == $b->kode_bagian) ? 'selected' : ''; ?>>
                        <?php echo $b->kode_bagian.' - '.$b->nama_bagian; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="small text-muted">Foto Profil (JPG/PNG)</label>
                      <div class="custom-file">
                        <input type="file" name="foto_profil" class="custom-file-input"
                               id="fotoProfil" accept=".jpg,.jpeg,.png">
                        <label class="custom-file-label" for="fotoProfil">Pilih file...</label>
                      </div>
                      <small class="text-muted">Max 2 MB. Bila kosong tetap memakai foto sekarang / default.</small>
                    </div>
                  </div>
                </div>

                <hr>
                <button type="submit" class="btn btn-primary-itm">
                  <i class="fas fa-save mr-1"></i> Simpan Perubahan
                </button>
              </form>
            </div>
          </div>
        </div>

      </div>

    </div>
  </section>
</div>
