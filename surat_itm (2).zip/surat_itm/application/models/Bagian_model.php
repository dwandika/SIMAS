<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bagian_model extends CI_Model
{
    private $table = 'bagian';
    
    public function get_all()
    {
        $this->db->order_by('kode_bagian', 'ASC');
        return $this->db->get($this->table)->result();
    }
    
    public function get_active()
    {
        $this->db->where('status', '1');
        $this->db->order_by('kode_bagian', 'ASC');
        return $this->db->get($this->table)->result();
    }
    
    public function get_by_kode($kode)
    {
        return $this->db->get_where($this->table, ['kode_bagian' => $kode])->row();
    }
    
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }
    
    public function update($kode, $data)
    {
        $this->db->where('kode_bagian', $kode);
        return $this->db->update($this->table, $data);
    }
    
    public function delete($kode)
    {
        $this->db->where('kode_bagian', $kode);
        return $this->db->delete($this->table);
    }
}
