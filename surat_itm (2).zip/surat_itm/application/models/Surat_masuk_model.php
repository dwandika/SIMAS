<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_masuk_model extends CI_Model
{
    protected $table = 'surat_masuk'; // Nama tabel sebenarnya
    protected $primary = 'id';
    
    /**
     * Get all surat masuk dengan filter
     */
        public function get_all($filter = [])
    {
        $this->db->select('sm.*, b.nama_bagian, k.nama_kategori, u.nama as created_by_name');
        $this->db->from($this->table . ' sm');
        $this->db->join('bagian b', 'sm.kode_bagian = b.kode_bagian', 'left');
        $this->db->join('kategori k', 'sm.kode_kategori = k.kode_kategori', 'left');
        $this->db->join('user u', 'sm.created_by = u.id', 'left');
        
        // Filter tanggal
        if (!empty($filter['tgl_awal'])) {
            $this->db->where('sm.tanggal_terima >=', $filter['tgl_awal']);
        }
        
        if (!empty($filter['tgl_akhir'])) {
            $this->db->where('sm.tanggal_terima <=', $filter['tgl_akhir']);
        }
        
        // Filter kategori
        if (!empty($filter['kategori'])) {
            $this->db->where('sm.kode_kategori', $filter['kategori']);
        }
        
        // Filter bagian
        if (!empty($filter['bagian'])) {
            $this->db->where('sm.kode_bagian', $filter['bagian']);
        }
        
        // Filter search
        if (!empty($filter['search'])) {
            $this->db->group_start();
            $this->db->like('sm.no_surat', $filter['search']);
            $this->db->or_like('sm.pengirim', $filter['search']);
            $this->db->or_like('sm.perihal', $filter['search']);
            $this->db->group_end();
        }
        
        // Order the results
        $this->db->order_by('sm.created_at', 'DESC');
        
        return $this->db->get()->result();
    }
    
    /**
     * Get surat masuk by ID
     */
    public function get_by_id($id)
    {
        $this->db->select('sm.*, b.nama_bagian, k.nama_kategori, u.nama as created_by_name');
        $this->db->from($this->table . ' sm');
        $this->db->join('bagian b', 'sm.kode_bagian = b.kode_bagian', 'left');
        $this->db->join('kategori k', 'sm.kode_kategori = k.kode_kategori', 'left');
        $this->db->join('user u', 'sm.created_by = u.id', 'left');
        $this->db->where('sm.id', $id);
        
        return $this->db->get()->row();
    }
    
    /**
     * Insert surat masuk baru
     */
    public function insert($data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->db->insert($this->table, $data);
    }
    
    /**
     * Update surat masuk
     */
    public function update($id, $data)
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        $this->db->where($this->primary, $id);
        return $this->db->update($this->table, $data);
    }
    
    /**
     * Delete surat masuk
     */
    public function delete($id)
    {
        $this->db->where($this->primary, $id);
        return $this->db->delete($this->table);
    }
    
    /**
     * Generate nomor surat otomatis
     * Format: 01.001/ADM/XII/2025
     */
    public function generate_nomor($kode_bagian, $kode_kategori)
    {
        $tahun = date('Y');
        $bulan_romawi = $this->_bulan_romawi(date('n'));
        
        // Get last number untuk bagian dan tahun ini
        $this->db->select('no_surat');
        $this->db->from($this->table);
        $this->db->where('kode_bagian', $kode_bagian);
        $this->db->where('YEAR(created_at)', $tahun);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        
        $last = $this->db->get()->row();
        
        $urut = 1;
        
        if ($last) {
            // Extract nomor urut dari format: 01.001/ADM/XII/2025
            $parts = explode('/', $last->no_surat);
            if (isset($parts[0])) {
                $nomor_parts = explode('.', $parts[0]);
                if (isset($nomor_parts[1])) {
                    $urut = intval($nomor_parts[1]) + 1;
                }
            }
        }
        
        // Format: 01.001/ADM/XII/2025
        $nomor = sprintf('%02d.%03d/%s/%s/%s', 
            intval($kode_bagian), 
            $urut, 
            $kode_kategori, 
            $bulan_romawi, 
            $tahun
        );
        
        return $nomor;
    }
    
    /**
     * Konversi bulan ke romawi
     */
    private function _bulan_romawi($bulan)
    {
        $romawi = ['I', 'II', 'III', 'IV', 'V', 'VI', 
                   'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
        return $romawi[$bulan - 1];
    }
    
    /**
     * Get statistik surat masuk
     */
    public function get_statistik($tahun = null)
    {
        if (!$tahun) {
            $tahun = date('Y');
        }
        
        $this->db->select('MONTH(tanggal_terima) as bulan, COUNT(*) as total');
        $this->db->from($this->table);
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        $this->db->group_by('MONTH(tanggal_terima)');
        $this->db->order_by('MONTH(tanggal_terima)');
        
        return $this->db->get()->result();
    }
    
    /**
     * Count total
     */
    public function count_all($filter = [])
    {
        $this->db->from($this->table);
        
        if (!empty($filter['tgl_awal'])) {
            $this->db->where('tanggal_terima >=', $filter['tgl_awal']);
        }
        
        if (!empty($filter['tgl_akhir'])) {
            $this->db->where('tanggal_terima <=', $filter['tgl_akhir']);
        }
        
        if (!empty($filter['kategori'])) {
            $this->db->where('kode_kategori', $filter['kategori']);
        }
        
        if (!empty($filter['bagian'])) {
            $this->db->where('kode_bagian', $filter['bagian']);
        }
        
        return $this->db->count_all_results();
    }
    
}
