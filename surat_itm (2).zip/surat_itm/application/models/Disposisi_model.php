<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Disposisi_model extends CI_Model
{
    private $table = 'disposisi';
    
    public function get_all()
    {
        $this->db->select('d.*, sm.no_surat, sm.pengirim, sm.perihal');
        $this->db->from($this->table . ' d');
        $this->db->join('surat_masuk sm', 'd.id_suratmasuk = sm.id', 'left');
        $this->db->order_by('d.id_disposisi', 'DESC');
        return $this->db->get()->result();
    }
    
    public function get_by_id($id)
    {
        $this->db->select('d.*, sm.no_surat, sm.pengirim, sm.perihal');
        $this->db->from($this->table . ' d');
        $this->db->join('surat_masuk sm', 'd.id_suratmasuk = sm.id', 'left');
        $this->db->where('d.id_disposisi', $id);
        return $this->db->get()->row();
    }
    
    public function get_by_surat($id_surat)
    {
        $this->db->where('id_suratmasuk', $id_surat);
        $this->db->order_by('id_disposisi', 'DESC');
        return $this->db->get($this->table)->result();
    }
    
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }
    
    public function update($id, $data)
    {
        $this->db->where('id_disposisi', $id);
        return $this->db->update($this->table, $data);
    }
    
    public function delete($id)
    {
        $this->db->where('id_disposisi', $id);
        return $this->db->delete($this->table);
    }
}
 