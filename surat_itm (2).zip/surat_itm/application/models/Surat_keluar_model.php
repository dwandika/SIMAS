<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_keluar_model extends CI_Model
{
    private $table = 'surat_keluar';

    public function get_all($filter = [])
    {
        // Search functionality
        if (!empty($filter['search'])) {
            $this->db->group_start();
            $this->db->like('no_surat', $filter['search']);
            $this->db->or_like('tujuan', $filter['search']);
            $this->db->or_like('perihal', $filter['search']);
            $this->db->group_end();
        }

        // Filter by date range
        if (!empty($filter['tgl_awal'])) {
            $this->db->where('tanggal_surat >=', $filter['tgl_awal']);
        }
        if (!empty($filter['tgl_akhir'])) {
            $this->db->where('tanggal_surat <=', $filter['tgl_akhir']);
        }

        // Filter by kategori
        if (!empty($filter['kategori'])) {
            $this->db->where('kode_kategori', $filter['kategori']);
        }

        // Filter by bagian
        if (!empty($filter['bagian'])) {
            $this->db->where('kode_bagian', $filter['bagian']);
        }

        // Filter by status_pengesahan
        if (!empty($filter['status_pengesahan'])) {
            $this->db->where('status_pengesahan', $filter['status_pengesahan']);
        }

        // Ordering the results
        $this->db->order_by('tanggal_surat', 'DESC');
        $this->db->order_by('id', 'DESC');

        // Fetching the filtered results
        return $this->db->get($this->table)->result();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id' => $id])->row();
    }

    public function insert($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update_status($id, $status)
    {
        return $this->db->where('id', $id)
                        ->update($this->table, ['status_pengesahan' => $status]);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }
}
?>
