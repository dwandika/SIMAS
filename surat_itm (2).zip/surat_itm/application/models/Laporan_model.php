<?php
// application/models/Laporan_model.php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan_model extends CI_Model
{
    // ==========================================
    // REKAP BULANAN (SKEMA BARU)
    // ==========================================

    // surat_masuk: pakai tanggal_terima
    public function rekap_surat_masuk($tahun)
    {
        $this->db->select('MONTH(tanggal_terima) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_masuk');
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        $this->db->group_by('MONTH(tanggal_terima)');
        $this->db->order_by('bulan', 'ASC');
        return $this->db->get()->result();
    }

    // surat_keluar: pakai tanggal_surat
    public function rekap_surat_keluar($tahun)
    {
        $this->db->select('MONTH(tanggal_surat) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_keluar');
        $this->db->where('YEAR(tanggal_surat)', $tahun);
        $this->db->group_by('MONTH(tanggal_surat)');
        $this->db->order_by('bulan', 'ASC');
        return $this->db->get()->result();
    }

    // ==========================================
    // LAPORAN SURAT MASUK (SKEMA BARU)
    // ==========================================

    // tabel: surat_masuk (no_surat_auto, no_surat_asli, kode_bagian, kode_kategori,
    //                     pengirim, perihal, tanggal_surat, tanggal_terima)
    public function get_surat_masuk($dari_tgl = null, $sampai_tgl = null, $kategori = null, $bagian = null)
    {
        $this->db->select('sm.*, k.nama_kategori, b.nama_bagian');
        $this->db->from('surat_masuk sm');
        $this->db->join('kategori k', 'k.kode_kategori = sm.kode_kategori', 'left');
        $this->db->join('bagian b',   'b.kode_bagian   = sm.kode_bagian',   'left');

        if ($dari_tgl && $sampai_tgl) {
            $this->db->where('sm.tanggal_terima >=', $dari_tgl);
            $this->db->where('sm.tanggal_terima <=', $sampai_tgl);
        }

        if ($kategori) {
            $this->db->where('sm.kode_kategori', $kategori);
        }

        if ($bagian) {
            $this->db->where('sm.kode_bagian', $bagian);
        }

        $this->db->order_by('sm.tanggal_terima', 'DESC');
        return $this->db->get()->result();
    }

    public function count_surat_masuk($dari_tgl = null, $sampai_tgl = null, $kategori = null, $bagian = null)
    {
        $this->db->from('surat_masuk');

        if ($dari_tgl && $sampai_tgl) {
            $this->db->where('tanggal_terima >=', $dari_tgl);
            $this->db->where('tanggal_terima <=', $sampai_tgl);
        }

        if ($kategori) {
            $this->db->where('kode_kategori', $kategori);
        }

        if ($bagian) {
            $this->db->where('kode_bagian', $bagian);
        }

        return $this->db->count_all_results();
    }

    // ==========================================
    // LAPORAN SURAT KELUAR (SKEMA BARU)
    // ==========================================

    // tabel: surat_keluar (no_surat_auto, kode_bagian, kode_kategori,
    //                      tujuan, perihal, tanggal_surat, id_penandatangan,
    //                      nama_file_surat, status_ttd)
    public function get_surat_keluar(
        $dari_tgl = null,
        $sampai_tgl = null,
        $kategori = null,
        $status_pengesahan = null,
        $bagian = null
    ) {
        $this->db->select('sk.*, k.nama_kategori, b.nama_bagian');
        $this->db->from('surat_keluar sk');
        $this->db->join('kategori k', 'k.kode_kategori = sk.kode_kategori', 'left');
        $this->db->join('bagian b',   'b.kode_bagian   = sk.kode_bagian',   'left');

        if ($dari_tgl && $sampai_tgl) {
            $this->db->where('sk.tanggal_surat >=', $dari_tgl);
            $this->db->where('sk.tanggal_surat <=', $sampai_tgl);
        }

        if ($kategori) {
            $this->db->where('sk.kode_kategori', $kategori);
        }

        if ($status_pengesahan) {
            $this->db->where('sk.status_pengesahan', $status_pengesahan);
        }

        if ($bagian) {
            $this->db->where('sk.kode_bagian', $bagian);
        }

        $this->db->order_by('sk.tanggal_surat', 'DESC');
        return $this->db->get()->result();
    }

    public function count_surat_keluar(
        $dari_tgl = null,
        $sampai_tgl = null,
        $kategori = null,
        $status_pengesahan = null,
        $bagian = null
    ) {
        $this->db->from('surat_keluar');

        if ($dari_tgl && $sampai_tgl) {
            $this->db->where('tanggal_surat >=', $dari_tgl);
            $this->db->where('tanggal_surat <=', $sampai_tgl);
        }

        if ($kategori) {
            $this->db->where('kode_kategori', $kategori);
        }

        if ($status_pengesahan) {
            $this->db->where('status_pengesahan', $status_pengesahan);
        }

        if ($bagian) {
            $this->db->where('kode_bagian', $bagian);
        }

        return $this->db->count_all_results();
    }

    // ==========================================
    // REKAP PER KATEGORI (SKEMA BARU)
    // ==========================================

    public function rekap_per_kategori($jenis, $tahun = null)
    {
        if ($jenis == 'masuk') {
            $this->db->select('k.kode_kategori, k.nama_kategori, COUNT(*) AS jumlah');
            $this->db->from('surat_masuk sm');
            $this->db->join('kategori k', 'k.kode_kategori = sm.kode_kategori', 'left');

            if ($tahun) {
                $this->db->where('YEAR(sm.tanggal_terima)', $tahun);
            }

            $this->db->group_by('k.kode_kategori, k.nama_kategori');
            $this->db->order_by('jumlah', 'DESC');
        } else {
            $this->db->select('k.kode_kategori, k.nama_kategori, COUNT(*) AS jumlah');
            $this->db->from('surat_keluar sk');
            $this->db->join('kategori k', 'k.kode_kategori = sk.kode_kategori', 'left');

            if ($tahun) {
                $this->db->where('YEAR(sk.tanggal_surat)', $tahun);
            }

            $this->db->group_by('k.kode_kategori, k.nama_kategori');
            $this->db->order_by('jumlah', 'DESC');
        }

        return $this->db->get()->result();
    }

    // ==========================================
    // REKAP PER BAGIAN (SKEMA BARU)
    // ==========================================

    public function rekap_per_bagian($jenis, $tahun = null)
    {
        if ($jenis == 'masuk') {
            $this->db->select('b.kode_bagian, b.nama_bagian, COUNT(*) AS jumlah');
            $this->db->from('surat_masuk sm');
            $this->db->join('bagian b', 'b.kode_bagian = sm.kode_bagian', 'left');

            if ($tahun) {
                $this->db->where('YEAR(sm.tanggal_terima)', $tahun);
            }

            $this->db->group_by('b.kode_bagian, b.nama_bagian');
            $this->db->order_by('jumlah', 'DESC');
        } else {
            $this->db->select('b.kode_bagian, b.nama_bagian, COUNT(*) AS jumlah');
            $this->db->from('surat_keluar sk');
            $this->db->join('bagian b', 'b.kode_bagian = sk.kode_bagian', 'left');

            if ($tahun) {
                $this->db->where('YEAR(sk.tanggal_surat)', $tahun);
            }

            $this->db->group_by('b.kode_bagian, b.nama_bagian');
            $this->db->order_by('jumlah', 'DESC');
        }

        return $this->db->get()->result();
    }

    // ==========================================
    // STATISTIK DASHBOARD (SKEMA BARU)
    // ==========================================

    public function get_surat_masuk_bulan_ini()
    {
        $bulan = date('m');
        $tahun = date('Y');

        $this->db->from('surat_masuk');
        $this->db->where('MONTH(tanggal_terima)', $bulan);
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        return $this->db->count_all_results();
    }

    public function get_surat_keluar_bulan_ini()
    {
        $bulan = date('m');
        $tahun = date('Y');

        $this->db->from('surat_keluar');
        $this->db->where('MONTH(tanggal_surat)', $bulan);
        $this->db->where('YEAR(tanggal_surat)', $tahun);
        return $this->db->count_all_results();
    }

    public function get_surat_masuk_tahun_ini()
    {
        $tahun = date('Y');

        $this->db->from('surat_masuk');
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        return $this->db->count_all_results();
    }

    public function get_surat_keluar_tahun_ini()
    {
        $tahun = date('Y');

        $this->db->from('surat_keluar');
        $this->db->where('YEAR(tanggal_surat)', $tahun);
        return $this->db->count_all_results();
    }

    // ==========================================
    // GRAFIK DATA (SKEMA BARU)
    // ==========================================

    public function get_data_grafik($tahun)
    {
        $data = [];
        for ($i = 1; $i <= 12; $i++) {
            $data[$i] = [
                'bulan'         => $i,
                'nama_bulan'    => $this->get_nama_bulan($i),
                'surat_masuk'   => 0,
                'surat_keluar'  => 0
            ];
        }

        $surat_masuk = $this->rekap_surat_masuk($tahun);
        foreach ($surat_masuk as $sm) {
            $data[$sm->bulan]['surat_masuk'] = $sm->jumlah;
        }

        $surat_keluar = $this->rekap_surat_keluar($tahun);
        foreach ($surat_keluar as $sk) {
            $data[$sk->bulan]['surat_keluar'] = $sk->jumlah;
        }

        return array_values($data);
    }

    // ==========================================
    // HELPER
    // ==========================================

    public function get_tahun_tersedia()
    {
        $tahun_array = [];

        $this->db->select('DISTINCT YEAR(tanggal_terima) AS tahun');
        $this->db->from('surat_masuk');
        $this->db->where('tanggal_terima IS NOT NULL');
        $masuk = $this->db->get()->result();

        $this->db->select('DISTINCT YEAR(tanggal_surat) AS tahun');
        $this->db->from('surat_keluar');
        $this->db->where('tanggal_surat IS NOT NULL');
        $keluar = $this->db->get()->result();

        foreach ($masuk as $m) {
            if (!in_array($m->tahun, $tahun_array)) {
                $tahun_array[] = $m->tahun;
            }
        }
        foreach ($keluar as $k) {
            if (!in_array($k->tahun, $tahun_array)) {
                $tahun_array[] = $k->tahun;
            }
        }

        rsort($tahun_array);
        return $tahun_array;
    }

    public function get_nama_bulan($bulan)
    {
        $nama_bulan = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret',
            4 => 'April', 5 => 'Mei', 6 => 'Juni',
            7 => 'Juli', 8 => 'Agustus', 9 => 'September',
            10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];

        return $nama_bulan[$bulan] ?? '-';
    }
}
