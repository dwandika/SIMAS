<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
    /**
     * Mendapatkan total surat masuk
     */
    public function get_total_surat_masuk()
    {
        return $this->db->count_all('surat_masuk');
    }

    /**
     * Mendapatkan total surat keluar
     */
    public function get_total_surat_keluar()
    {
        return $this->db->count_all('surat_keluar');
    }

    /**
     * Mendapatkan total disposisi
     */
    public function get_total_disposisi()
    {
        return $this->db->count_all('disposisi');
    }

    /**
     * Mendapatkan total surat keluar yang menunggu pengesahan
     * Status: draft dan menunggu dianggap belum disahkan
     */
    public function get_total_belum_disahkan()
    {
        $this->db->where_in('status_pengesahan', ['draft', 'menunggu']);
        return $this->db->count_all_results('surat_keluar');
    }

    /**
     * Rekap bulanan surat masuk per tahun berdasarkan tanggal_terima
     */
    public function get_rekap_masuk_tahunan($tahun = null)
    {
        if ($tahun === null) {
            $tahun = date('Y');
        }
        
        $this->db->select('MONTH(tanggal_terima) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_masuk');
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        $this->db->group_by('MONTH(tanggal_terima)');
        $this->db->order_by('bulan', 'ASC');
        
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Rekap bulanan surat keluar per tahun berdasarkan tanggal_surat
     */
    public function get_rekap_keluar_tahunan($tahun = null)
    {
        if ($tahun === null) {
            $tahun = date('Y');
        }
        
        $this->db->select('MONTH(tanggal_surat) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_keluar');
        $this->db->where('YEAR(tanggal_surat)', $tahun);
        $this->db->group_by('MONTH(tanggal_surat)');
        $this->db->order_by('bulan', 'ASC');
        
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Mendapatkan bulan dengan surat masuk terbanyak
     */
    public function get_bulan_terpadat_masuk($tahun = null)
    {
        if ($tahun === null) {
            $tahun = date('Y');
        }
        
        $this->db->select('MONTH(tanggal_terima) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_masuk');
        $this->db->where('YEAR(tanggal_terima)', $tahun);
        $this->db->group_by('MONTH(tanggal_terima)');
        $this->db->order_by('jumlah', 'DESC');
        $this->db->limit(1);
        
        $row = $this->db->get()->row();
        
        if (!$row) {
            return null;
        }
        
        return $this->_get_nama_bulan((int)$row->bulan);
    }

    /**
     * Mendapatkan bulan dengan surat keluar terbanyak
     */
    public function get_bulan_terpadat_keluar($tahun = null)
    {
        if ($tahun === null) {
            $tahun = date('Y');
        }
        
        $this->db->select('MONTH(tanggal_surat) AS bulan, COUNT(*) AS jumlah');
        $this->db->from('surat_keluar');
        $this->db->where('YEAR(tanggal_surat)', $tahun);
        $this->db->group_by('MONTH(tanggal_surat)');
        $this->db->order_by('jumlah', 'DESC');
        $this->db->limit(1);
        
        $row = $this->db->get()->row();
        
        if (!$row) {
            return null;
        }
        
        return $this->_get_nama_bulan((int)$row->bulan);
    }

    /**
     * Mendapatkan total disposisi yang selesai
     * Berdasarkan kolom status = 'selesai'
     */
    public function get_total_disposisi_selesai()
    {
        $this->db->where('status', 'selesai');
        return $this->db->count_all_results('disposisi');
    }

    /**
     * Helper function untuk konversi nomor bulan ke nama bulan
     */
    private function _get_nama_bulan($bulan)
    {
        $nama_bulan = [
            1  => 'Januari',
            2  => 'Februari',
            3  => 'Maret',
            4  => 'April',
            5  => 'Mei',
            6  => 'Juni',
            7  => 'Juli',
            8  => 'Agustus',
            9  => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember'
        ];
        
        return isset($nama_bulan[$bulan]) ? $nama_bulan[$bulan] : null;
    }
}