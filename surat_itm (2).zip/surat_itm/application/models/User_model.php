<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    private $table = 'user';
    
    public function get_all()
    {
        $this->db->select('u.*, b.nama_bagian');
        $this->db->from($this->table . ' u');
        $this->db->join('bagian b', 'u.kode_bagian = b.kode_bagian', 'left');
        $this->db->order_by('u.id', 'ASC');
        return $this->db->get()->result();
    }
    
    public function get_by_id($id)
    {
        $this->db->select('u.*, b.nama_bagian');
        $this->db->from($this->table . ' u');
        $this->db->join('bagian b', 'u.kode_bagian = b.kode_bagian', 'left');
        $this->db->where('u.id', $id);
        return $this->db->get()->row();
    }
    
    public function get_by_username($username)
    {
        return $this->db->get_where($this->table, ['username' => $username])->row();
    }
    
    /**
     * Get pejabat penandatangan (untuk surat keluar)
     */
    public function get_pejabat()
    {
        $this->db->where('status', '1');
        $this->db->where_in('role', ['admin', 'pimpinan']);
        $this->db->order_by('role', 'DESC'); // pimpinan dulu
        $this->db->order_by('nama', 'ASC');
        return $this->db->get($this->table)->result();
    }
    
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }
    
    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }
    
    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
    
    /**
     * Login verification
     */
    public function verify_login($username, $password)
    {
        $password_hash = md5($password);
        
        $this->db->where('username', $username);
        $this->db->where('password', $password_hash);
        $this->db->where('status', '1');
        
        return $this->db->get($this->table)->row();
    }
}
