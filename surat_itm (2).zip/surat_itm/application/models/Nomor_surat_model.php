<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nomor_surat_model extends CI_Model
{
    private $table = 'nomor_surat';

    /**
     * Get next number untuk surat masuk/keluar
     * @param string $jenis 'masuk' atau 'keluar'
     * @param int $tahun
     * @param string $kode_bagian
     * @return int nomor urut berikutnya
     */
    public function get_next_number($jenis, $tahun, $kode_bagian)
    {
        // Cari nomor terakhir untuk jenis, tahun, dan bagian yang sama
        $this->db->select('nomor_urut');
        $this->db->where('jenis', $jenis);
        $this->db->where('tahun', $tahun);
        $this->db->where('kode_bagian', $kode_bagian);
        $this->db->order_by('nomor_urut', 'DESC');
        $this->db->limit(1);
        
        $result = $this->db->get($this->table)->row();
        
        if ($result) {
            $next = $result->nomor_urut + 1;
        } else {
            $next = 1; // Mulai dari 1 jika belum ada
        }

        // Simpan nomor baru ke database
        $this->db->insert($this->table, [
            'jenis'        => $jenis,
            'tahun'        => $tahun,
            'kode_bagian'  => $kode_bagian,
            'nomor_urut'   => $next,
            'created_at'   => date('Y-m-d H:i:s')
        ]);

        return $next;
    }

    /**
     * Get history nomor surat
     */
    public function get_history($filter = [])
    {
        if (!empty($filter['jenis'])) {
            $this->db->where('jenis', $filter['jenis']);
        }
        if (!empty($filter['tahun'])) {
            $this->db->where('tahun', $filter['tahun']);
        }
        if (!empty($filter['kode_bagian'])) {
            $this->db->where('kode_bagian', $filter['kode_bagian']);
        }

        $this->db->order_by('created_at', 'DESC');
        return $this->db->get($this->table)->result();
    }

    /**
     * Reset nomor untuk tahun baru (opsional, bisa dijalankan manual)
     */
    public function reset_for_new_year($tahun_baru)
    {
        // Hapus data tahun lama jika perlu
        // Atau biarkan untuk histori
        return true;
    }
}