<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    protected function require_login()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    protected function require_admin()
    {
        $this->require_login();
        if ($this->session->userdata('role') !== 'admin') {
            show_error('Anda tidak memiliki hak akses.', 403, 'Akses ditolak');
        }
    }

    protected function require_pimpinan()
    {
        $this->require_login();
        if ($this->session->userdata('role') !== 'pimpinan') {
            show_error('Anda tidak memiliki hak akses.', 403, 'Akses ditolak');
        }
    }
}

/* Controller turunan untuk grouping hak akses */
class Admin_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->require_admin();
    }
}

class User_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->require_login();
    }
}

class Pimpinan_Controller extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->require_pimpinan();
    }
}
